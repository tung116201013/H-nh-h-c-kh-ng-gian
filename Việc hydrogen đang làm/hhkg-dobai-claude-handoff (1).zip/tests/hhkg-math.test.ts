import test from 'node:test';
import assert from 'node:assert/strict';
import {
  mathToThree,
  threeToMath,
  projectPointOnPlane,
  projectPointOnLine,
  angleLinePlane,
  angleBetweenLines,
  angleBetweenPlanes,
  dihedralAngle,
  distanceSkewLines,
  commonPerpendicularSegment,
  polyhedronVolume,
  computeCrossSection,
  normalizeSceneSpec,
  intersectLinePlane,
  intersectTwoPlanes,
  reflectPointAcrossPlane,
  reflectPointAcrossPoint,
  dilatePoint,
  rodriguesRotate,
  computePolyhedronNet,
  safeEvalMathExpr,
  sampleSurfaceZ,
  buildGrade11CustomSolid,
  solveGrade11Offline,
  nextStandardVertexLabel,
  extrudeBaseToPyramid,
  extrudeBaseToPrism,
  parallelogram4thVertex,
  intersectTwoLines3D,
  projectPointParallelOnPlane,
  buildBaseStencilScene,
  bakeCrossSectionVertices,
  planeBisector,
  distanceParallelPlanes,
  circumSphere4Points,
  intersectLineSphere,
  intersectSpherePlane,
  intersectTwoSpheres,
  buildPlatonicSolid,
  TEMPLATES,
} from '../Dobai/js/hhkg-math.js';
import { executeGeoGebraCommand, refineAiGeometryPayload } from '../Dobai/js/hhkg-geogebra.js';
import { createZipBytes } from '../Dobai/js/hhkg-zip.js';

test('mathToThree and threeToMath are exact right-handed inverses', () => {
  const m = { x: 2.5, y: -1.4, z: 3.2 };
  const t = mathToThree(m);
  assert.deepEqual(t, [-1.4, 3.2, 2.5]);
  const back = threeToMath(t);
  assert.deepEqual(back, m);
});

test('projectPointOnPlane computes exact distance and foot H', () => {
  const proj = projectPointOnPlane(
    { x: 1, y: 2, z: 4 },
    { x: 0, y: 0, z: 0 },
    { x: 1, y: 0, z: 0 },
    { x: 0, y: 1, z: 0 },
  );
  assert.equal(proj.valid, true);
  assert.ok(Math.abs(proj.distance - 4) < 1e-6);
  assert.ok(Math.abs(proj.point.x - 1) < 1e-6);
  assert.ok(Math.abs(proj.point.y - 2) < 1e-6);
  assert.ok(Math.abs(proj.point.z) < 1e-6);
});

test('projectPointOnLine finds midpoint projection on diagonal', () => {
  const proj = projectPointOnLine(
    { x: 0, y: 0, z: 0 },
    { x: 2, y: 0, z: 0 },
    { x: 0, y: 2, z: 0 },
  );
  assert.equal(proj.valid, true);
  assert.ok(Math.abs(proj.distance - Math.SQRT2) < 1e-6);
  assert.ok(Math.abs(proj.point.x - 1) < 1e-6);
  assert.ok(Math.abs(proj.point.y - 1) < 1e-6);
});

test('angleLinePlane, angleBetweenLines, and dihedralAngle match exact textbook degrees', () => {
  const ang = angleLinePlane(
    { x: 0, y: 0, z: 0 },
    { x: 1, y: 0, z: 1 },
    { x: 0, y: 0, z: 0 },
    { x: 1, y: 0, z: 0 },
    { x: 0, y: 1, z: 0 },
  );
  assert.equal(ang.valid, true);
  assert.ok(Math.abs(ang.deg - 45) < 1e-5);

  const lAng = angleBetweenLines(
    { x: 0, y: 0, z: 0 },
    { x: 1, y: 0, z: 0 },
    { x: 0, y: 0, z: 0 },
    { x: 1, y: Math.sqrt(3), z: 0 },
  );
  assert.ok(Math.abs(lAng.deg - 60) < 1e-5);

  const pAng = angleBetweenPlanes(
    { x: 0, y: 0, z: 0 }, { x: 1, y: 0, z: 0 }, { x: 0, y: 1, z: 0 },
    { x: 0, y: 0, z: 0 }, { x: 0, y: 1, z: 0 }, { x: 0, y: 0, z: 1 },
  );
  assert.ok(Math.abs(pAng.deg - 90) < 1e-5);

  // Dihedral [P1(0,0,1), A(0,0,0)B(1,0,0), P2(0,1,0)] is 90°
  const dAng = dihedralAngle(
    { x: 0, y: 0, z: 1 },
    { x: 0, y: 0, z: 0 },
    { x: 1, y: 0, z: 0 },
    { x: 0, y: 1, z: 0 },
  );
  assert.equal(dAng.valid, true);
  assert.ok(Math.abs(dAng.deg - 90) < 1e-5);
});

test('distanceSkewLines & commonPerpendicularSegment compute exact perpendicular segment', () => {
  const res = distanceSkewLines(
    { x: 0, y: 0, z: 0 },
    { x: 1, y: 0, z: 0 },
    { x: 1, y: 1, z: 0 },
    { x: 1, y: 1, z: 1 },
  );
  assert.equal(res.valid, true);
  assert.equal(res.parallel, false);
  assert.ok(Math.abs(res.distance - 1) < 1e-6);

  const seg = commonPerpendicularSegment(
    { x: 0, y: 0, z: 0 },
    { x: 1, y: 0, z: 0 },
    { x: 1, y: 1, z: 0 },
    { x: 1, y: 1, z: 1 },
  );
  assert.equal(seg.valid, true);
  assert.ok(Math.abs(seg.distance - 1) < 1e-6);
  assert.ok(Math.abs(seg.p1.x - 1) < 1e-6 && Math.abs(seg.p1.y) < 1e-6);
  assert.ok(Math.abs(seg.p2.x - 1) < 1e-6 && Math.abs(seg.p2.y - 1) < 1e-6 && Math.abs(seg.p2.z) < 1e-6);
});

test('polyhedronVolume matches exact cube and Grade 11 regular square frustum formulas', () => {
  const cube = TEMPLATES.find((t) => t.id === 'hinh-lap-phuong');
  assert.ok(cube);
  // Side = 2.6 -> V = 2.6^3 = 17.576
  assert.ok(Math.abs(polyhedronVolume(cube.scene) - 2.6 ** 3) < 1e-3);

  const a = 3.0;
  const topRatio = 0.5;
  const h = 2.4;
  const frustum = buildGrade11CustomSolid({ shape: 'chop-cut-deu', a, h, topRatio });
  const s1 = a * a;
  const s2 = (a * topRatio) ** 2;
  const expectedV = (h / 3) * (s1 + s2 + Math.sqrt(s1 * s2));
  assert.ok(Math.abs(polyhedronVolume(frustum.scene) - expectedV) < 1e-2);
});

test('computeCrossSection slices cube into regular hexagon when plane is x+y+z = 1.3', () => {
  const cube = TEMPLATES.find((t) => t.id === 'hinh-lap-phuong');
  assert.ok(cube, 'Cube template must exist');
  const cs = computeCrossSection(cube.scene, { nx: 1, ny: 1, nz: 1, d: 1.3 });
  assert.equal(cs.valid, true);
  assert.equal(cs.points.length, 6);
  assert.equal(cs.shapeName, 'Lục giác');
  assert.ok(cs.area > 0);
});

test('GeoGebra kernel algorithms: intersections, reflections, dilation, rotation, and net unfolding', () => {
  // Line through (0,0,4) and (0,0,2) intersects z=0 at (0,0,0)
  const hit = intersectLinePlane(
    { x: 0, y: 0, z: 4 },
    { x: 0, y: 0, z: 2 },
    { x: 0, y: 0, z: 0 },
    { x: 1, y: 0, z: 0 },
    { x: 0, y: 1, z: 0 },
  );
  assert.equal(hit.valid, true);
  assert.ok(Math.abs(hit.point.z) < 1e-6);

  // Intersection of z = 0 and x = 1 lies along x = 1, z = 0
  const line = intersectTwoPlanes(
    { x: 0, y: 0, z: 0 }, { x: 1, y: 0, z: 0 }, { x: 0, y: 1, z: 0 },
    { x: 1, y: 0, z: 0 }, { x: 1, y: 1, z: 0 }, { x: 1, y: 0, z: 1 },
  );
  assert.equal(line.valid, true);
  assert.ok(Math.abs(line.segA.x - 1) < 1e-5 && Math.abs(line.segA.z) < 1e-5);
  assert.ok(Math.abs(line.segB.x - 1) < 1e-5 && Math.abs(line.segB.z) < 1e-5);

  // Reflections and dilation
  const refP = reflectPointAcrossPlane(
    { x: 1, y: 2, z: 3 },
    { x: 0, y: 0, z: 0 }, { x: 1, y: 0, z: 0 }, { x: 0, y: 1, z: 0 },
  );
  assert.equal(refP.valid, true);
  assert.ok(Math.abs(refP.point.z + 3) < 1e-6);
  assert.deepEqual(reflectPointAcrossPoint({ x: 1, y: 2, z: 3 }, { x: 0, y: 0, z: 0 }), { x: -1, y: -2, z: -3 });
  assert.deepEqual(dilatePoint({ x: 2, y: 0, z: 0 }, { x: 0, y: 0, z: 0 }, 0.5), { x: 1, y: 0, z: 0 });

  // Rodrigues 90 deg rotation around Z maps (1, 0, 0) -> (0, 1, 0)
  const rot = rodriguesRotate({ x: 1, y: 0, z: 0 }, { x: 0, y: 0, z: 0 }, { x: 0, y: 0, z: 1 }, Math.PI / 2);
  assert.ok(Math.abs(rot.x) < 1e-6 && Math.abs(rot.y - 1) < 1e-6 && Math.abs(rot.z) < 1e-6);

  // Polyhedron Net at unfoldRatio = 1 unfolds all faces flat onto z ≈ 0
  const cube = TEMPLATES.find((t) => t.id === 'hinh-lap-phuong');
  assert.ok(cube);
  const net = computePolyhedronNet(cube.scene, 1);
  assert.equal(net.valid, true);
  assert.equal(net.faces.length, 6);
  assert.ok(Math.abs(net.totalArea - 6 * 2.6 * 2.6) < 1e-2);
  for (const face of net.faces) {
    for (const pt of face.points) {
      assert.ok(Math.abs(pt.z) < 1e-3, `Expected unfolded net point z ≈ 0, got ${pt.z}`);
    }
  }
});

test('safeEvalMathExpr & sampleSurfaceZ compute 3D functions safely without eval', () => {
  assert.ok(Math.abs(safeEvalMathExpr('0.25*(x^2 - y^2) + 1', { x: 2, y: 0 }) - 2) < 1e-6);
  assert.ok(Math.abs(safeEvalMathExpr('sin(pi/2) + cos(0)', {}) - 2) < 1e-6);
  assert.ok(Number.isNaN(safeEvalMathExpr('window.alert(1)', { x: 1, y: 1 })));

  const surf = sampleSurfaceZ('x^2 + y^2', 2, 10);
  assert.equal(surf.valid, true);
  assert.equal(surf.grid.length, 11);
});

test('executeGeoGebraCommand supports coordinates, constructions, surfaces, and Net()', () => {
  const base = TEMPLATES[0].scene;
  const r1 = executeGeoGebraCommand('P1 = (1, 2, 3)', base);
  assert.equal(r1.ok, true);
  assert.ok(r1.scene.vertices.some((v) => v.id === 'P1' && v.x === 1 && v.y === 2 && v.z === 3));

  const r2 = executeGeoGebraCommand('Midpoint(S, C)', r1.scene);
  assert.equal(r2.ok, true);
  assert.ok(r2.scene.vertices.length === r1.scene.vertices.length + 1);

  const r3 = executeGeoGebraCommand('Vector(A, S)', r2.scene);
  assert.equal(r3.ok, true);
  assert.equal(r3.scene.vectors.length, 1);

  const r4 = executeGeoGebraCommand('Sphere(O, 1.5)', r3.scene);
  assert.equal(r4.ok, true);
  assert.ok(r4.scene.spheres.length >= 1);

  const r5 = executeGeoGebraCommand('z = 0.25*(x^2 - y^2) + 1', r4.scene);
  assert.equal(r5.ok, true);
  assert.equal(r5.scene.surfaces.length, 1);
  assert.equal(r5.scene.showOxyz, true);

  const r6 = executeGeoGebraCommand('Net(0.75)', r5.scene);
  assert.equal(r6.ok, true);
  assert.equal(r6.netRatio, 0.75);
});

test('solveGrade11Offline handles Grade 11 pyramid, frustum, and skew distance prompts', () => {
  const s1 = solveGrade11Offline('Cho hình chóp cụt tứ giác đều đáy 2a và a');
  assert.ok(s1.title && s1.scene.vertices.length >= 8 && s1.steps.length >= 2);

  const s2 = solveGrade11Offline('Cho tứ diện đều cạnh a, tính đoạn vuông góc chung AB và CD');
  assert.ok(s2.scene.vertices.length >= 4 && s2.steps.length >= 2);
});

test('normalizeSceneSpec filters invalid references and preserves hidden flags and vectors', () => {
  const norm = normalizeSceneSpec({
    showOxyz: true,
    vertices: [
      { id: 'A', x: 0, y: 0, z: 0, hidden: true },
      { id: 'B', x: 2, y: 0, z: 0 },
      { id: 'B', x: 9, y: 9, z: 9 },
      { id: 'BAD', x: NaN, y: 0, z: 0 },
    ],
    edges: [
      { from: 'A', to: 'B', style: 'solid' },
      { from: 'A', to: 'BAD', style: 'solid' },
      { from: 'B', to: 'A', style: 'dashed' },
    ],
    vectors: [
      { from: 'A', to: 'B' },
      { from: 'A', to: 'BAD' },
    ],
    faces: [
      { vertices: ['A', 'B'] },
    ],
  });
  assert.equal(norm.vertices.length, 2);
  assert.equal(norm.vertices[0].hidden, true);
  assert.equal(norm.edges.length, 1);
  assert.equal(norm.vectors.length, 1);
  assert.equal(norm.faces.length, 0);
  assert.equal(norm.showOxyz, true);
});

test('createZipBytes builds valid PKZIP archive with UTF-8 filenames', () => {
  const bytes = createZipBytes([
    { name: 'handoff/BAN_GIAO.md', content: 'Xin chào Claude 3D' },
    { name: 'js/app.js', content: new Uint8Array([1, 2, 3, 4]) },
  ]);
  assert.ok(bytes instanceof Uint8Array);
  // Local file header PK\x03\x04
  assert.equal(bytes[0], 0x50);
  assert.equal(bytes[1], 0x4b);
  assert.equal(bytes[2], 0x03);
  assert.equal(bytes[3], 0x04);
  const str = new TextDecoder().decode(bytes);
  assert.ok(str.includes('handoff/BAN_GIAO.md'));
  assert.ok(str.includes('js/app.js'));
});

test('all curriculum templates are valid and non-empty (including Grade 11 KNTT Chapter IV focus)', () => {
  assert.ok(TEMPLATES.length >= 15);
  for (const tpl of TEMPLATES) {
    assert.ok(tpl.id && tpl.name && tpl.grade);
    assert.ok(tpl.scene.vertices.length >= 4, `Template ${tpl.id} should have >= 4 vertices`);
    assert.ok(tpl.scene.edges.length >= 4, `Template ${tpl.id} should have >= 4 edges`);
  }
  const ch4Ids = ['ss-giao-tuyen-song-song', 'ss-thiet-dien-binh-hanh', 'ss-thales-hai-mp', 'ss-phep-chieu-song-song'];
  for (const id of ch4Ids) {
    const t = TEMPLATES.find((x) => x.id === id);
    assert.ok(t, `Missing Grade 11 Chapter IV template ${id}`);
    assert.equal(t.chapter, 'song-song');
  }
});

test('Toán 11 KNTT Chương IV Bài 12 EFGH cross section forms exact parallelogram', () => {
  const tpl = TEMPLATES.find((x) => x.id === 'ss-thiet-dien-binh-hanh');
  assert.ok(tpl);
  const vMap = new Map(tpl.scene.vertices.map((v) => [v.id, v]));
  const E = vMap.get('E'), F = vMap.get('F'), G = vMap.get('G'), H = vMap.get('H');
  // Midpoint of EG equals midpoint of FH iff EFGH is a parallelogram
  assert.ok(Math.abs((E.x + G.x) - (F.x + H.x)) < 1e-4);
  assert.ok(Math.abs((E.y + G.y) - (F.y + H.y)) < 1e-4);
  assert.ok(Math.abs((E.z + G.z) - (F.z + H.z)) < 1e-4);

  const sOff = solveGrade11Offline('Cho hình chóp S.ABCD đáy hình bình hành, tìm giao tuyến (SAB) và (SCD)');
  assert.ok(sOff.title.includes('Giao tuyến song song'));
});

test('easy user-drawing helpers build pyramid and prism from base vertices', () => {
  const nextId = nextStandardVertexLabel([{ id: 'A' }, { id: 'B' }]);
  assert.equal(nextId, 'C');

  const baseScene = normalizeSceneSpec({
    vertices: [
      { id: 'A', x: 1, y: -1, z: 0 },
      { id: 'B', x: 1, y: 1, z: 0 },
      { id: 'C', x: -1, y: 1, z: 0 },
      { id: 'D', x: -1, y: -1, z: 0 },
    ],
    edges: [],
    faces: [],
  });

  const pyr = extrudeBaseToPyramid(baseScene, { height: 3.0 });
  assert.equal(pyr.ok, true);
  assert.ok(pyr.scene.vertices.some((v) => v.id === 'S' && v.z === 3));
  assert.equal(pyr.scene.faces.length, 5);
  assert.ok(polyhedronVolume(pyr.scene) > 3.9);

  const prism = extrudeBaseToPrism(baseScene, { height: 2.5 });
  assert.equal(prism.ok, true);
  assert.equal(prism.scene.faces.length, 6);
  assert.ok(Math.abs(polyhedronVolume(prism.scene) - 10) < 1e-2);
});

test('new GeoGebra/KNTT drawing helpers: parallelogram4thVertex, intersectTwoLines3D, projectPointParallelOnPlane, stencils, and bakeCrossSectionVertices', () => {
  const d = parallelogram4thVertex({ x: 1, y: 0, z: 0 }, { x: 1, y: 2, z: 0 }, { x: -1, y: 2, z: 0 });
  assert.deepEqual(d, { x: -1, y: 0, z: 0 });

  const hit = intersectTwoLines3D(
    { x: 0, y: 0, z: 0 },
    { x: 2, y: 2, z: 0 },
    { x: 0, y: 2, z: 0 },
    { x: 2, y: 0, z: 0 },
  );
  assert.equal(hit.valid, true);
  assert.ok(Math.abs(hit.point.x - 1) < 1e-6 && Math.abs(hit.point.y - 1) < 1e-6);

  const proj = projectPointParallelOnPlane(
    { x: 0, y: 0, z: 3 },
    { x: 0, y: 0, z: 0 },
    { x: 1, y: 0, z: 3 },
    { x: 0, y: 0, z: 0 },
    { x: 1, y: 0, z: 0 },
    { x: 0, y: 1, z: 0 },
  );
  assert.equal(proj.valid, true);
  assert.ok(Math.abs(proj.point.x + 1) < 1e-6 && Math.abs(proj.point.z) < 1e-6);

  const stencil = buildBaseStencilScene('binh-hanh');
  assert.equal(stencil.vertices.length, 4);
  assert.equal(stencil.edges.length, 4);

  const cube = TEMPLATES.find((t) => t.id === 'hinh-lap-phuong');
  const baked = bakeCrossSectionVertices(cube.scene, { nx: 0, ny: 0, nz: 1, d: 1.3 }, 'E');
  assert.equal(baked.ok, true);
  assert.equal(baked.crossSection.vertexIds.length, 4);
  assert.ok(baked.scene.faces.some((f) => f.internal === true && f.vertices.length === 4));
});

test('extended GeoGebra commands and refineAiGeometryPayload verify right angles and apply symbolic constructions', () => {
  const base = TEMPLATES[0].scene;
  const rPar = executeGeoGebraCommand('Q = ParallelLine(S, A, B)', base);
  assert.equal(rPar.ok, true);
  assert.ok(rPar.scene.vertices.some((v) => v.id === 'Q'));

  const rFoot = executeGeoGebraCommand('H = FootOnLine(A, S, B)', rPar.scene);
  assert.equal(rFoot.ok, true);
  assert.ok(rFoot.scene.rightAngles.some((r) => r.vertex === 'H'));

  const rReg = executeGeoGebraCommand('RegularPyramid(3, 2, 3)', base);
  assert.equal(rReg.ok, true);
  assert.equal(rReg.scene.vertices.length, 5); // A, B, C + S + foot H
  assert.ok(rReg.scene.vertices.some((v) => v.id === 'S' && Math.abs(v.z - 3) < 1e-6));

  const aiPayload = {
    title: 'Test GeoGebra Refinement',
    scene: {
      vertices: [
        { id: 'A', x: 0, y: 0, z: 0, role: 'primary' },
        { id: 'B', x: 2, y: 0, z: 0, role: 'primary' },
        { id: 'C', x: 2, y: 2, z: 0, role: 'primary' },
        { id: 'D', x: 0, y: 2, z: 0, role: 'primary' },
        { id: 'S', x: 0, y: 0, z: 3, role: 'primary' },
      ],
      edges: [
        { from: 'A', to: 'B', style: 'solid' },
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'C', to: 'D', style: 'solid' },
        { from: 'D', to: 'A', style: 'solid' },
        { from: 'S', to: 'A', style: 'altitude' },
        { from: 'S', to: 'B', style: 'solid' },
        { from: 'S', to: 'C', style: 'solid' },
        { from: 'S', to: 'D', style: 'solid' },
      ],
      faces: [
        { vertices: ['A', 'B', 'C', 'D'] },
        { vertices: ['S', 'A', 'B'] },
        { vertices: ['S', 'B', 'C'] },
        { vertices: ['S', 'C', 'D'] },
        { vertices: ['S', 'D', 'A'] },
      ],
      rightAngles: [{ vertex: 'A', p1: 'S', p2: 'B' }],
    },
    constructions: ['M = Midpoint(S, C)', 'H = FootOnLine(A, S, B)'],
  };
  const refined = refineAiGeometryPayload(aiPayload);
  assert.equal(refined.mathCheck.verifiedConstructions, 2);
  assert.equal(refined.mathCheck.totalConstructions, 2);
  assert.ok(refined.mathCheck.checks.some((c) => c.includes('90° chính xác')));
  assert.ok(refined.scene.vertices.some((v) => v.id === 'M' && Math.abs(v.x - 1) < 1e-6 && Math.abs(v.z - 1.5) < 1e-6));

  const bai10 = solveGrade11Offline('Tìm giao điểm BF và mặt phẳng (ACD) trong tứ diện ABCD Bài 10 KNTT');
  assert.ok(bai10.title.includes('Bài 10') || bai10.title.includes('Giao điểm'));
  assert.ok(bai10.mathCheck && bai10.mathCheck.vertexCount >= 5);
});

test('GeoGebra AlgoIntersectRegionPlanePolyhedron handles coplanar face slice and concave L-shaped prism', () => {
  // 1. Coplanar slice z = 0 on cube side 2.6
  const cube = TEMPLATES.find((t) => t.id === 'hinh-lap-phuong');
  assert.ok(cube);
  const coplanar = computeCrossSection(cube.scene, { nx: 0, ny: 0, nz: 1, d: 0 });
  assert.equal(coplanar.valid, true);
  assert.equal(coplanar.points.length, 4);
  assert.ok(Math.abs(coplanar.area - 2.6 * 2.6) < 1e-3);

  // 2. Non-convex L-shaped prism (unit squares union: [0,2]x[0,2] minus [1,2]x[1,2] => area = 3, perimeter = 8)
  const lShape = normalizeSceneSpec({
    vertices: [
      { id: 'A', x: 0, y: 0, z: 0 },
      { id: 'B', x: 2, y: 0, z: 0 },
      { id: 'C', x: 2, y: 1, z: 0 },
      { id: 'D', x: 1, y: 1, z: 0 },
      { id: 'E', x: 1, y: 2, z: 0 },
      { id: 'F', x: 0, y: 2, z: 0 },
      { id: "A'", x: 0, y: 0, z: 2 },
      { id: "B'", x: 2, y: 0, z: 2 },
      { id: "C'", x: 2, y: 1, z: 2 },
      { id: "D'", x: 1, y: 1, z: 2 },
      { id: "E'", x: 1, y: 2, z: 2 },
      { id: "F'", x: 0, y: 2, z: 2 },
    ],
    edges: [],
    faces: [
      { vertices: ['A', 'B', 'C', 'D', 'E', 'F'] },
      { vertices: ["A'", "B'", "C'", "D'", "E'", "F'"] },
      { vertices: ['A', 'B', "B'", "A'"] },
      { vertices: ['B', 'C', "C'", "B'"] },
      { vertices: ['C', 'D', "D'", "C'"] },
      { vertices: ['D', 'E', "E'", "D'"] },
      { vertices: ['E', 'F', "F'", "E'"] },
      { vertices: ['F', 'A', "A'", "F'"] },
    ],
  });
  const lSlice = computeCrossSection(lShape, { nx: 0, ny: 0, nz: 1, d: 1 });
  assert.equal(lSlice.valid, true);
  assert.equal(lSlice.points.length, 6);
  assert.ok(Math.abs(lSlice.area - 3.0) < 1e-4, `Expected L-section area 3.0, got ${lSlice.area}`);
  assert.ok(Math.abs(lSlice.perimeter - 8.0) < 1e-4, `Expected L-section perimeter 8.0, got ${lSlice.perimeter}`);
});

test('PlatonicSolidsFactory (5 regular solids), PlaneBisector, DistancePlanes & Sphere Intersections', () => {
  const oct = buildPlatonicSolid('octahedron', 2);
  assert.equal(oct.scene.vertices.length, 6);
  assert.equal(oct.scene.faces.length, 8);
  const expectedOctV = (8 * Math.SQRT2) / 3;
  assert.ok(Math.abs(oct.volume - expectedOctV) < 1e-3);

  const dod = buildPlatonicSolid('dodecahedron', 1.5);
  assert.equal(dod.scene.vertices.length, 20);
  assert.equal(dod.scene.faces.length, 12);

  const ico = buildPlatonicSolid('icosahedron', 1.5);
  assert.equal(ico.scene.vertices.length, 12);
  assert.equal(ico.scene.faces.length, 20);

  // Plane bisector of (0,0,0) and (2,0,0) is x = 1
  const pb = planeBisector({ x: 0, y: 0, z: 0 }, { x: 2, y: 0, z: 0 });
  assert.equal(pb.valid, true);
  assert.ok(Math.abs(pb.nx - 1) < 1e-6 && Math.abs(pb.d - 1) < 1e-6);

  // Parallel planes z = 0 and z = 3 -> distance 3
  const dp = distanceParallelPlanes(
    { x: 0, y: 0, z: 0 }, { x: 1, y: 0, z: 0 }, { x: 0, y: 1, z: 0 },
    { x: 0, y: 0, z: 3 }, { x: 1, y: 0, z: 3 }, { x: 0, y: 1, z: 3 },
  );
  assert.equal(dp.valid, true);
  assert.equal(dp.parallel, true);
  assert.ok(Math.abs(dp.distance - 3) < 1e-6);

  // Circumsphere of orthogonal tetrahedron (0,0,0), (2,0,0), (0,2,0), (0,0,2) has center (1,1,1), R = sqrt(3)
  const cs = circumSphere4Points(
    { x: 0, y: 0, z: 0 },
    { x: 2, y: 0, z: 0 },
    { x: 0, y: 2, z: 0 },
    { x: 0, y: 0, z: 2 },
  );
  assert.equal(cs.valid, true);
  assert.ok(Math.abs(cs.center.x - 1) < 1e-6 && Math.abs(cs.center.y - 1) < 1e-6 && Math.abs(cs.center.z - 1) < 1e-6);
  assert.ok(Math.abs(cs.radius - Math.sqrt(3)) < 1e-6);

  // Line along X-axis through origin intersects unit sphere at (-1,0,0) and (1,0,0)
  const ils = intersectLineSphere({ x: -3, y: 0, z: 0 }, { x: 3, y: 0, z: 0 }, { x: 0, y: 0, z: 0 }, 1);
  assert.equal(ils.valid, true);
  assert.equal(ils.status, 'SECANT');
  assert.equal(ils.points.length, 2);
  assert.ok(Math.abs(Math.abs(ils.points[0].x) - 1) < 1e-6);

  // Sphere (0,0,0) R=5 cut by z=3 gives circle r=4 centered at (0,0,3)
  const isp = intersectSpherePlane(
    { x: 0, y: 0, z: 0 },
    5,
    { x: 0, y: 0, z: 3 },
    { x: 1, y: 0, z: 3 },
    { x: 0, y: 1, z: 3 },
  );
  assert.equal(isp.valid, true);
  assert.equal(isp.status, 'CIRCLE');
  assert.ok(Math.abs(isp.rCircle - 4) < 1e-6);
  assert.ok(Math.abs(isp.center.z - 3) < 1e-6);

  // Two equal spheres radius 5 centered at (0,0,0) and (6,0,0) intersect in circle r=4 at (3,0,0)
  const iss = intersectTwoSpheres({ x: 0, y: 0, z: 0 }, 5, { x: 6, y: 0, z: 0 }, 5);
  assert.equal(iss.valid, true);
  assert.equal(iss.status, 'CIRCLE');
  assert.ok(Math.abs(iss.center.x - 3) < 1e-6 && Math.abs(iss.rCircle - 4) < 1e-6);

  // GeoGebra commands integration
  const rOct = executeGeoGebraCommand('Octahedron(2)', TEMPLATES[0].scene);
  assert.equal(rOct.ok, true);
  assert.equal(rOct.scene.vertices.length, 6);
  assert.equal(rOct.title, 'Bát diện đều');
  assert.equal(rOct.replaceSolid, true);

  const rBis = executeGeoGebraCommand('PlaneBisector(A, B)', rOct.scene);
  assert.equal(rBis.ok, true);
  assert.equal(rBis.scene.planes.length, 1);

  const rCoplanar = executeGeoGebraCommand('CircumSphere(A, B, C, D)', TEMPLATES[0].scene);
  assert.equal(rCoplanar.ok, false);

  const rCircum = executeGeoGebraCommand('CircumSphere(A, B, C, S)', TEMPLATES[0].scene);
  assert.equal(rCircum.ok, true);
  assert.ok(rCircum.scene.spheres.length >= 1);
  const centerId = rCircum.scene.spheres[rCircum.scene.spheres.length - 1].center;

  const rCircleCmd = executeGeoGebraCommand(`IntersectSpherePlane(${centerId}, A, B, C)`, rCircum.scene);
  assert.equal(rCircleCmd.ok, true);
  assert.ok(rCircleCmd.scene.circles.length >= 1);
});



