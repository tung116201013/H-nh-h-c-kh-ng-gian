# CODEMAP — HỆ THỐNG HÌNH HỌC KHÔNG GIAN 11 & 12 (`hhkg-*`)

## 1. Cấu trúc module & Xuất khẩu (`exports`)

### `/Dobai/js/hhkg-math.js`
- **Hằng số & Mẫu**: `TEMPLATES` (16+ mẫu SGK Lớp 11 KNTT Chương IV Bài 10–14 Song song, Vuông góc & Lớp 12 Oxyz kèm `steps[]`, tọa độ toán học `(x trước, y phải, z lên)`).
- **Hệ tọa độ & Chuẩn hóa**:
  - `mathToThree({x, y, z})` ↔ `threeToMath([tx, ty, tz])` (right-handed).
  - `normalizeSceneSpec(raw)`: chuẩn hóa đỉnh, cạnh, véc-tơ, mặt (`internal`, `hidden`), góc vuông, góc, mặt cầu, nón, trụ, `planes`, `circles`, đồ thị mặt cong `surfaces`, lọc tham chiếu treo.
- **Hình học không gian Lớp 11 / 12**:
  - `vecSub`, `vecAdd`, `vecScale`, `vecDot`, `vecCross`, `vecNorm`, `vecDist`, `midpoint`, `centroid`, `lerpPoint`, `parallelPointThrough`, `parallelogram4thVertex`
  - `projectPointOnLine`, `projectPointOnPlane`, `projectPointParallelOnPlane`, `planeFrom3Points`, `planeFromPointAndNormal`, `planeParallelToPlane`, `planePerpToLine`, `planeBisector`, `distanceParallelPlanes`
  - `angleBetweenLines`, `angleLinePlane`, `angleBetweenPlanes`, `dihedralAngle`
  - `distanceSkewLines`, `commonPerpendicularSegment`, `triangleArea`, `polyhedronVolume`
  - `computeCrossSection(scene, {nx, ny, nz, d})` (chuẩn `AlgoIntersectRegionPlanePolyhedron` hỗ trợ khối lõm, đa vòng `allLoops` & mặt đồng phẳng) & `bakeCrossSectionVertices(scene, plane, startChar)`: cắt thiết diện và tạo đỉnh/cạnh/mặt thật ngay trong scene.
- **Nhân GeoGebra 3D**:
  - `intersectLinePlane(p1, p2, a, b, c)`, `intersectTwoLines3D(a, b, c, d)`
  - `intersectTwoPlanes(a1, b1, c1, a2, b2, c2)`
  - `circumSphere4Points(a, b, c, d)`, `intersectLineSphere(a, b, center, r)`, `intersectSpherePlane(center, r, p1, p2, p3)`, `intersectTwoSpheres(c1, r1, c2, r2)`
  - `buildPlatonicSolid(kind, edgeLen)`: 5 khối đa diện đều từ `PlatonicSolidsFactory` (`tetrahedron`, `cube`, `octahedron`, `dodecahedron`, `icosahedron`).
  - `reflectPointAcrossPlane(p, a, b, c)`, `reflectPointAcrossPoint(p, center)`, `dilatePoint(p, center, k)`
  - `rodriguesRotate(point, origin, axisUnit, angleRad)`
  - `computePolyhedronNet(scene, unfoldRatio)`: cây khung mặt đáy → xoay bản lề từng mặt theo tỉ số `0..1`.
  - `safeEvalMathExpr(expr, scope)`, `sampleSurfaceZ(expr, opts)`: đánh giá biểu thức toán học an toàn CSP để vẽ `z = f(x, y)`.
- **Dựng hình, Tự vẽ & Giải Offline**:
  - `nextStandardVertexLabel(vertices)`, `orderPolygonVertices(pts)`, `buildBaseStencilScene(kind, opts)`, `extrudeBaseToPyramid(scene, opts)`, `extrudeBaseToPrism(scene, opts)`.
  - `buildGrade11CustomSolid(cfg)`: Wizard dựng khối theo tham số (`chop-tu-giac`, `chop-tam-giac`, `chop-cut-deu`, `lang-tru-dung`, `lang-tru-xien`, `tu-dien-deu`, `hinh-hop`).
  - `solveGrade11Offline(problemText)`: nhận diện đề bài Lớp 11 (Bài 10–14 Song song Chương IV & Vuông góc) + dựng mô hình & lời giải từng bước kèm `mathCheck`.

### `/Dobai/js/hhkg-geogebra.js`
- `GEOGEBRA_QUICK_COMMANDS`: các lệnh mẫu chèn 1 chạm.
- `executeGeoGebraCommand(rawInput, currentScene)`: trả về `{ ok, message, scene?, crossPlane?, netRatio? }`.
- `refineAiGeometryPayload(rawPayload)`: thực thi tuần tự `payload.constructions` lên `payload.scene`, kiểm chứng góc 90° bằng tích vô hướng và gắn `mathCheck` + `appliedConstructions`.
- Hỗ trợ lệnh Anh/Việt: `z = f(x,y)`, `M = (x,y,z)`, `Point`, `Midpoint`/`TrungDiem`, `Centroid`/`TrongTam`, `Segment`, `Vector`, `Polygon`, `ParallelLine`/`SongSong`, `Parallelogram`/`HinhBinhHanh`, `FootOnLine`/`HinhChieuDuong`, `ProjectParallel`/`ChieuSongSong`, `Pyramid`, `RegularPyramid`/`ChopDeu`, `RegularPrism`/`LangTruDeu`, `Tetrahedron`/`TuDienDeu`, `Octahedron`/`BatDienDeu`, `Dodecahedron`/`ThapNhiDienDeu`, `Icosahedron`/`NhiThapDienDeu`, `Extrude`/`Prism`, `Cube`, `Frustum`, `Sphere`, `CircumSphere`/`MatCauNgoaiTiep`, `Cone`, `Cylinder`, `PerpendicularPoint`/`Project`, `Reflect`/`Mirror`, `Dilate`, `Intersect`, `IntersectLines`/`GiaoHaiDuong`, `IntersectPlanes`, `IntersectLineSphere`/`GiaoDuongMatCau`, `IntersectSpherePlane`/`GiaoMatCauMatPhang`, `IntersectSpheres`/`GiaoHaiMatCau`, `Plane`, `PlaneParallel`, `PlanePerp`, `PlaneBisector`/`MatTrungTruc`, `CrossSection`/`ThietDien`, `CrossSectionParallel`/`ThietDienSongSong`, `Distance`, `DistancePlanes`/`KhoangCachHaiMatPhang`, `Angle`, `Dihedral`, `CommonPerp`, `Volume`, `Net`, `Ratio`.

### `/Dobai/js/hhkg-3d.js`
- Class `Geometry3DViewer(containerEl, labelsEl, callbacks)`:
  - **Two-Pass Dynamic Hidden-Line Rendering** (`LessEqualDepth` solid pass + `GreaterDepth` dashed pass trên hull đa diện hoặc toàn bộ mặt ngoài đối với khối lõm) cho nét liền/nét đứt động theo góc quay camera 360°, tỉ lệ độ dày nét/nút theo `sceneRadius`.
  - **Smart Collision-Free Labels** (`_computePlacedLabels`): đẩy nhãn ra ngoài theo hướng tâm, tự thu gọn `.compact` và ẩn nhãn cạnh phụ khi thu nhỏ hình hoặc zoom xa.
  - Hỗ trợ dựng mặt phẳng trong suốt `sceneData.planes`, đường tròn giao tuyến 3D `sceneData.circles`, và vòng nhắm nâng cao theo cao độ `z` (`setPlacePlaneZ(z)`) kèm đường dọi xuống `z = 0`.
  - `setScene(sceneData, opts)`
  - `setViewStyle('textbook-3d' | 'solid' | 'wireframe')`
  - `setLabelsMode('all' | 'vertices' | 'none')`
  - `setShowFaces(bool)`, `setShowGrid(bool)`, `setShowAxes(bool | null)`, `setPlacePointMode(bool)`, `setPlacePlaneZ(z)`
  - `setAutoRotate(bool)`, `setCameraPreset('default' | 'top' | 'front' | 'side' | 'oxyz')`
  - `setSelectedVertices(ids)`, `setHighlight({vertices, edges, faceVertices})`
  - `setCrossSection(csResult)`, `setPolyhedronNet(netResult, ratio)`
  - `exportPngDataUrl()`, `resize()`, `dispose()`

### `/Dobai/hhkg.html`
- Trang web độc lập chạy toàn màn hình cho Hình học không gian 11 & 12 (có sẵn `importmap` Three.js và `<script type="module" src="/js/hhkg-ui.js">`), giúp `Dobai/index.html` không phải tải Three.js/WebGL.

### `/Dobai/js/hhkg-ui.js`
- Tự nhận biết chế độ độc lập (`standalone`) trên `/hhkg.html` (mở thẳng studio, nút `‹ Về Dobai`) hoặc chế độ gắn thẻ `#hhkg-entry`, xuất `window.HHKG = { open, close, state, downloadBundle, parallelPointThrough, standalone }`.
- Lưu hình trên máy vào `localStorage['dc:hhkg:saved']`.
- Các ID DOM chính trong `#hhkg-ov`:
  - Top bar: `#hhkg-close`, `#hhkg-dl-bundle`
  - Canvas HUD: `#hhkg-spec`, `#hhkg-expand-btn`, `#hhkg-place-btn`, `#hhkg-axes-btn`, `#hhkg-grid-btn`, `#hhkg-lbl-mode-btn`, `#hhkg-faces-btn`
  - Dock góc nhìn: `#hhkg-dock-toggle`, `#hhkg-dock`, `#hhkg-style-btn`, `#hhkg-rot-btn`, `#hhkg-png-btn`
  - Self-drawing card (`#hhkg-easy-draw-card`): `#hhkg-draw-blank`, `[data-draw-mode]`, `[data-draw-z]`, `[data-stencil]`, `#hhkg-draw-h`, `#hhkg-draw-pyr`, `#hhkg-draw-prism`, `#hhkg-draw-above`
  - 4 Tabs (`[data-tab]`): `templates`, `algebra`, `measure`, `ai`
  - Toolbar & Step bar: `#hhkg-undo-btn`, `#hhkg-redo-btn`, `#hhkg-save-btn`, `#hhkg-guide-toggle`, `#hhkg-reset-scene`, `#hhkg-stepbar`
  - Tab Đại số: `#hhkg-cmd-inp`, `#hhkg-cmd-run`, `[data-cmd-fill]`, `[data-alg-eye]`, `[data-alg-del]`
  - Tab Cắt & Đo: `#hhkg-net-slider`, `[data-net-set]`, `#hhkg-cs-on`, `[data-csp]`, `[data-cs-k]`
  - Tab AI Giải: `#hhkg-ai-guide`, `[data-ai-tpl]`, `#hhkg-ai-prompt`, `#hhkg-ai-file`, `#hhkg-ai-solve`, `#hhkg-offline-solve`, `#hhkg-follow-inp`, `#hhkg-follow-btn`

### `/Dobai/js/hhkg-zip.js`
- `crc32(bytes)` & `createZipBytes(entries)`: tạo file `.zip` chuẩn PKZIP UTF-8 không phụ thuộc thư viện ngoài.

## 2. API & Web Routes (`server.js` / Worker)
- `GET /hhkg` & `GET /hhkg.html` → Trang web độc lập Hình học không gian 3D.
- `GET /api/health` → `{ ok: true, hasGeminiKey: boolean }`
- `POST /api/geometry/solve` → Nhận `{ mode: 'solve' | 'followup', problemText, imageBase64, imageMimeType, currentScene, question }`, chạy Gemini (`ThinkingLevel.HIGH`) + `refineAiGeometryPayload`, trả về JSON `{ ok: true, data }`.
- `GET /api/geometry/export-bundle.zip` → Trả về file `hhkg-dobai-claude-handoff.zip` chứa `Dobai/hhkg.html`, toàn bộ mã nguồn HHKG, `vendor/three/`, tests và thư mục `handoff/` (gồm `HUONG_DAN_AI_GIAI_CHINH_XAC_HHKG.md`).
