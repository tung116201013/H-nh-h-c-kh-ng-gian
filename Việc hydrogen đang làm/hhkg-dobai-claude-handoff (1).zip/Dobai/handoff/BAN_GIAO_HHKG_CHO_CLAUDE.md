# BÀN GIAO CHỨC NĂNG HÌNH HỌC KHÔNG GIAN 11 & 12 (CHUẨN GEOGEBRA 3D) — CHO CLAUDE

Tài liệu này đi kèm toàn bộ mã nguồn Hình học không gian (`hhkg-*`) để **Claude** kiểm tra, rà soát và ghép hoàn chỉnh vào web `Dobai/index.html` + `Dobai/api-worker.js` trên Cloudflare Pages/Workers.

---

## 1. Danh mục tệp trong gói bàn giao (`hhkg-dobai-claude-handoff.zip`)

**Kiến trúc tách trang riêng (chống lag preview):** Chức năng Hình học không gian chạy trên trang web độc lập **`Dobai/hhkg.html`** (truy cập `/hhkg.html` hoặc `/hhkg`). Trong `Dobai/index.html` chỉ đặt 1 thẻ liên kết nhẹ ~1 KB không nạp Three.js/WebGL để giữ trang chủ Dobai siêu mượt.

| Tệp | Vai trò | Ghi chú ghép vào Dobai |
|---|---|---|
| `Dobai/hhkg.html` | Trang web Hình học không gian 3D độc lập | Copy trực tiếp cạnh `index.html` trên Cloudflare Pages |
| `js/hhkg-math.js` | Nhân toán học 3D thuần ES module (không phụ thuộc DOM/Three) | Có thể tách file `/js/hhkg-math.js` hoặc inline vào `hhkg.html` |
| `js/hhkg-geogebra.js` | Bộ phân tích & thực thi lệnh GeoGebra 3D + Việt hóa (`Algebra View`) + `refineAiGeometryPayload` | Import trực tiếp từ `hhkg-math.js` |
| `js/hhkg-3d.js` | Bộ dựng hình Three.js (nét khuất chuẩn SGK, trục `Oxyz`, lưới sàn, đặt điểm 3D theo cao độ `z`, mặt phẳng `planes`, trải phẳng `Net`, mặt cong `z=f(x,y)`, vector `ArrowHelper`) | Cần `three` + `OrbitControls` qua `importmap` hoặc `vendor/three/` |
| `js/hhkg-ui.js` | Giao diện mobile-first (`390–400px` & `1440px`), tự nhận biết chế độ độc lập trên `hhkg.html` (`‹ Về Dobai`), 4 tab, hướng dẫn AI, bài giảng từng bước, xuất PNG & ZIP | Đóng gói sẵn trên `hhkg.html` |
| `js/hhkg-zip.js` | Bộ tạo file `.zip` thuần JS (PKZIP + CRC32 + cờ UTF-8 `0x0800`) | Dùng cho nút tải dự phòng phía trình duyệt |
| `vendor/three/**` | Runtime `three.module.js` và `OrbitControls.js` tự host, không phụ thuộc CDN | Đặt cạnh `index.html` và `hhkg.html` trên Cloudflare Pages hoặc static hosting |
| `server.js` | Máy chủ Node/Express local: phục vụ tĩnh `Dobai/`, `/hhkg`, `POST /api/geometry/solve` (`ThinkingLevel.HIGH` + `refineAiGeometryPayload`), `GET /api/geometry/export-bundle.zip` | Tham khảo schema Gemini & endpoint đóng gói ZIP |
| `tests/hhkg-math.test.ts` | Bộ unit test `node --test` kiểm tra công thức Lớp 11/12, GeoGebra 3D, `refineAiGeometryPayload` và ZIP | Chạy lại sau mỗi lần sửa: `npm test` |
| `handoff/GEOGEBRA-THUAT-TOAN.md` | Tóm tắt chưng cất thuật toán GeoGebra 3D (chiếu, chóp/lăng trụ, thiết diện khối lõm, 5 khối Platonic, mặt cầu, Z-buffer 3 lượt) | Tài liệu tham chiếu thuật toán lõi (EUPL v1.2) |
| `handoff/HUONG_DAN_AI_GIAI_CHINH_XAC_HHKG.md` | Hướng dẫn chuẩn để AI vẽ hình và tạo lời giải chính xác (quy trình 5 bước + ánh xạ SGK KNTT + mẹo đặt đề) | Tài liệu tham chiếu kỹ thuật & prompt cho AI |
| `handoff/api-worker-geometry-snippet.js` | Đoạn mã ghép thẳng vào `Dobai/api-worker.js` trên Cloudflare Worker | Cần biến môi trường Secret `GEMINI_API_KEY` |
| `handoff/index-patch-snippet.html` | Thẻ liên kết siêu nhẹ (~1 KB) gắn vào cuối `Dobai/index.html` để mở `/hhkg.html` | Không chèn Three.js vào `index.html` |

---

## 2. Tính năng đã hoàn thiện (Trọng tâm Lớp 11 GDPT 2018 + Chuẩn GeoGebra 3D)

### A. Trọng tâm Lớp 11 (GDPT 2018 — Sách Toán 11 Kết nối tri thức Tập 1 Chương IV & Tập 2)
1. **16+ mẫu chuẩn SGK** có lời giải từng bước kèm highlight 3D & đọc giọng tiếng Việt (`speechSynthesis` `vi-VN`):
   - **Chương IV KNTT (Quan hệ song song trong không gian):** Giao điểm đường thẳng – mặt phẳng (Bài 10), Giao tuyến song song `(SAB) ∩ (SCD) = Sx // AB // CD` (Bài 11), Thiết diện hình bình hành `EFGH` (Bài 12), Hai mặt phẳng song song & Định lí Thalès (Bài 13), Phép chiếu song song lên `(P)` (Bài 14).
   - **Quan hệ vuông góc & Thể tích:** Chóp `S.ABCD` (`SA ⊥ đáy`), Chóp đều, Chóp mặt bên `(SAB) ⊥ đáy`, **Chóp cụt tứ giác đều**, Tứ diện đều (`d(AB, CD)`), Lăng trụ đứng tam giác, Lăng trụ xiên, Hình hộp lập phương / chữ nhật, cùng mẫu `Oxyz`, Mặt cầu ngoại tiếp, Nón Lớp 12.
2. **Nét liền / nét đứt động theo góc nhìn & Nhãn chống chồng chéo thông minh:**
   - Khi xoay khối đa diện 360°, thuật toán **Two-Pass WebGL Depth-Occlusion** (hỗ trợ cả đa diện lồi và đa diện lõm) tự động vẽ **nét liền cho cạnh nhìn thấy** ở phía trước và **nét đứt cho cạnh bị che khuất** ở phía sau theo góc camera hiện tại, kèm tỉ lệ độ dày nét/nút theo kích thước khối (`DrawSegment3D` / `DrawPoint3D`).
   - Nhãn đỉnh tự né nhau theo vectơ hướng tâm và tự thu gọn/ẩn nhãn cạnh phụ khi thu nhỏ hoặc zoom xa để không bao giờ rối mắt. Nút `⤢ Mở rộng` / `⤡ Thu gọn` phóng to khung xem hình 3D gần toàn màn hình.
3. **Tự vẽ hình 3D chuẩn GeoGebra & Bộ dựng nhanh Wizard (`a`, `h`)**:
   - Thanh **Tự vẽ hình 3D chuẩn GeoGebra**: `🧹 Khung trống`, `📍 Chấm điểm 3D` kèm chọn **cao độ `z = 0, 1, 2, 3`** (có vòng nhắm nâng cao + dây dọi vuông góc xuống sàn `z = 0`), **Đặt đáy nhanh** (`△ Đều`, `▢ Vuông`, `▱ Bình hành`, `⏢ Thang`, `⬠ Ngũ giác`), `📏 Nối cạnh` (chạm 2 đỉnh nối ngay), `🔺 Lên chóp S`, `▭ Lên lăng trụ`, kết hợp Wizard dựng nhanh theo tham số (`a`, `h`).
4. **Thao tác 1 chạm trên 1–5 đỉnh 3D**:
   - **1 đỉnh:** Đặt `S` phía trên, cắt mặt phẳng ngang, xóa đỉnh.
   - **2 đỉnh:** Độ dài, nối liền/đứt/nổi bật/xóa cạnh, **Véc-tơ (`ArrowHelper`)**, trung điểm, chia tỉ lệ `1/3`, mặt phẳng trung trực.
   - **3 đỉnh:** Góc & diện tích tam giác, tô mặt, trọng tâm, **⫽ Qua A // BC**, **⊥ Chiếu A lên BC**, **▱ Dựng đỉnh 4 Hình bình hành**, cắt thiết diện & **Cắt tạo đỉnh thật**.
   - **4–5 đỉnh:** Khoảng cách & góc đường-mặt, nhị diện `[P, AB, C]`, đoạn vuông góc chung 2 đường chéo nhau, hạ hình chiếu, đối xứng qua mặt phẳng, giao điểm 2 đường thẳng đồng phẳng, cắt thiết diện song song tạo đỉnh thật, và **Tìm giao điểm `AB ∩ (CDE)`** (5 đỉnh).
5. **AI Vẽ hình & Giải chính xác + Bộ hướng dẫn & kiểm chứng GeoGebra**:
   - Gemini `gemini-4-hydrogen` (`ThinkingLevel.HIGH`) xuất đỉnh gốc + mảng `constructions[]` (lệnh GeoGebra 3D) để `refineAiGeometryPayload()` dựng tọa độ chính xác, kiểm tra tích vô hướng góc 90° và hiển thị hộp **`✓ Đã kiểm chứng hình học bằng nhân GeoGebra 3D`**.
   - Tab **🤖 AI Giải** tích hợp sẵn mục **📘 Hướng dẫn giúp AI vẽ hình & giải chính xác** và khung **mẫu đề chuẩn KNTT** bấm 1 chạm, cộng chế độ dự phòng Offline Lớp 11 (`solveGrade11Offline`).

### B. Tương đương chuẩn GeoGebra 3D Calculator (`geogebra/geogebra`)
- **Tab `𝑓𝑥 Đại số` (Algebra View + Thanh nhập lệnh)**:
  - Hỗ trợ cú pháp tiếng Anh & tiếng Việt:
    - Tọa độ điểm: `M = (1, 0, 2)`, `Point(1, 2, 3)`
    - Phép dựng hình: `Midpoint(A, B)` / `TrungDiem(A, B)`, `Centroid(A, B, C)`, `Segment(A, B)`, `Vector(A, B)`, `Polygon(A, B, C, D)`, `ParallelLine(P, A, B)` / `SongSong`, `Parallelogram(A, B, C)` / `HinhBinhHanh`, `FootOnLine(P, A, B)` / `HinhChieuDuong`
    - Khối đa diện & tròn xoay: `Pyramid(A, B, C, D, S)`, `RegularPyramid(n, r, h)` / `ChopDeu`, `RegularPrism(n, r, h)` / `LangTruDeu`, `Tetrahedron(a)`, `Octahedron(a)` / `BatDienDeu`, `Dodecahedron(a)`, `Icosahedron(a)`, `Extrude(A, B, C, 3)` / `Prism`, `Cube(a)`, `Frustum(a, b, h)`, `Sphere(O, R)`, `CircumSphere(A, B, C, D)` / `MatCauNgoaiTiep`, `Cone(S, O, R)`, `Cylinder(O1, O2, R)`
    - Biến hình, giao tuyến & thiết diện thật 3D: `PerpendicularPoint(A, S, B, C)` / `Project(...)`, `ProjectParallel(P, D1, D2, A, B, C)` / `ChieuSongSong`, `Reflect(S, A, B, C)` / `Mirror(...)`, `Dilate(S, O, 0.5)`, `Intersect(S, A, A, B, C)` (giao đường-mặt), `IntersectLines(A, B, C, D)` (giao 2 đường), `IntersectPlanes(S, A, B, A, C, D)` (giao tuyến 2 mặt phẳng), `IntersectLineSphere(A, B, I, R)`, `IntersectSpherePlane(I, R, A, B, C)`, `IntersectSpheres(I1, R1, I2, R2)`, `CrossSection(A, B, C)` / `ThietDien` (hỗ trợ cả khối lõm & mặt đồng phẳng), `CrossSectionParallel(P, A, B, C, D)` / `ThietDienSongSong`
    - Mặt phẳng & đo đạc: `Plane(nx, ny, nz, d)`, `Plane(A, B, C)`, `PlaneParallel(S, A, B, C)`, `PlanePerp(M, A, B)`, `PlaneBisector(A, B)` / `MatTrungTruc`, `Distance(A, B)`, `Distance(S, A, B, C)`, `DistancePlanes(A1,B1,C1, A2,B2,C2)`, `Angle(A, B, C)`, `Dihedral(S, B, D, A)`, `CommonPerp(S, A, B, C)`, `Volume()`, `Net(0.75)`
    - **Đồ thị mặt cong `z = f(x, y)`**: ví dụ `z = 0.25*(x^2 - y^2) + 1`, `z = sin(x)*cos(y) + 1` (dùng parser đệ quy `safeEvalMathExpr`, tuyệt đối **không dùng `eval`/`new Function`** nên an toàn CSP).
  - Nút bật/tắt hiển thị (`👁️` / `🚫`) và xóa (`✕`) từng đối tượng; xóa đỉnh tự dọn sạch cạnh/mặt phụ thuộc qua `normalizeSceneSpec`.
- **Trải phẳng đa diện (`Net 0% → 100%`)**:
  - Thuật toán `computePolyhedronNet` xoay bản lề từng mặt theo trục cạnh chung (`rodriguesRotate`), hỗ trợ thanh kéo mượt theo thời gian thực và 3 mức bấm nhanh (`0%`, `50%`, `100%`).
- **Tương tác trực tiếp trên Canvas 3D**:
  - `📍 Chấm điểm 3D` hỗ trợ chọn độ cao mặt phẳng đặt điểm `z = 0, 1, 2, 3` với vòng nhắm không gian + đường dọi vuông góc xuống mặt sàn.
  - Nút bật/tắt **⤢ Mở rộng**, **Trục `Oxyz`**, **Lưới sàn**, **Nhãn (Đủ / Đỉnh / Ẩn)**, **Mặt**, **Kiểu nét đứt / Khối đặc / Khung dây**, và 5 góc nhìn chuẩn (`Góc chuẩn`, `Từ trên`, `Mặt trước`, `Mặt bên`, `Oxyz`).

---

## 3. Checklist cho Claude khi kiểm tra & ghép vào `Dobai`

1. **Cách ly hoàn toàn với CSS/JS của `Dobai/index.html`**:
   - Toàn bộ class/id của module mới bắt đầu bằng `hhkg-` (`#hhkg-entry`, `#hhkg-ov`, `.hhkg-btn`...), **tuyệt đối không dùng class `.b`** của Dobai.
   - `window.HHKG` là biến toàn cục duy nhất được gán.
   - Hộp thoại mở lên khóa cuộn bằng `html.hhkg-lock` và dùng `z-index: 2147483200`.
2. **Bảo mật & CSP**:
   - **Không** đưa khóa API vào client; toàn bộ lời gọi Gemini đi qua `POST /api/geometry/solve` ở `server.js` hoặc `Dobai/api-worker.js` đọc `env.GEMINI_API_KEY`.
   - `safeEvalMathExpr` là parser toán học thuần túy, không có `eval` hay `new Function`.
3. **Đồng bộ dữ liệu (`cfsync.js`)**:
   - Hình đã lưu trên máy ghi vào `localStorage['dc:hhkg:saved']` (prefix `dc:` hợp chuẩn backup & sync hiện hành).
4. **Kiểm tra trước khi xuất bản Cloudflare**:
   - Đặt `Dobai/hhkg.html`, thư mục `Dobai/js/hhkg-*.js` và `Dobai/vendor/three/` cạnh `Dobai/index.html` trên Cloudflare Pages.
   - Trong `Dobai/index.html` chỉ chèn đoạn liên kết nhẹ ở `handoff/index-patch-snippet.html` (tránh nhồi Three.js vào `index.html`).
   - Thêm route `POST /api/geometry/solve` từ `handoff/api-worker-geometry-snippet.js` vào `Dobai/api-worker.js` và khai báo Secret `GEMINI_API_KEY` trong Worker `dobai-api`.
   - Kiểm thử lại cả `index.html` lẫn `hhkg.html` bằng `npm test` và Playwright ở cả 2 kích thước `400×800` (điện thoại) và `1440×900` (máy tính).
