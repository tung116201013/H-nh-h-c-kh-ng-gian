# TÓM TẮT THUẬT TOÁN HÌNH HỌC KHÔNG GIAN 3D (CHƯNG CẤT TỪ GEOGEBRA)

> **Nguồn tham khảo & Giấy phép:** Chưng cất thuần túy **ý tưởng thuật toán** (viết lại bằng giả mã / JavaScript, không sao chép mã Java) từ mã nguồn **GeoGebra** (`github.com/geogebra/geogebra`, nhánh `main`), phát hành theo giấy phép **EUPL v1.2** (`https://www.geogebra.org/license`).

---

## 1. Biểu diễn tọa độ, hệ trục & phép chiếu xuyên phương (`Coords`, `CoordSys`, `CoordMatrixUtil`)

GeoGebra biểu diễn điểm và vector dưới dạng tọa độ thuần nhất 4 thành phần `(x, y, z, w)`:
- **Điểm:** `w = 1`
- **Vector chỉ phương / pháp tuyến:** `w = 0`

Mỗi mặt phẳng `CoordSys` lưu 1 hệ trục chuẩn trực gồm gốc `O` và ma trận `(v_x, v_y, v_z)` (trong đó `v_z` là vector pháp tuyến đơn vị).

**Ý tưởng phép chiếu điểm `P` lên mặt phẳng `(O, v_x, v_y)` theo phương `v` (`projectPlaneThruV`):**
```js
// Tìm u1, u2 (tọa độ trong mặt phẳng) và t sao cho: P + t * v = O + u1 * v_x + u2 * v_y
function projectPointThruDir(P, planeOrigin, vx, vy, vz, dirV) {
  // Nếu dirV song song mặt phẳng (|vz · dirV| ≈ 0), dùng pháp tuyến vz để chiếu vuông góc
  const d = Math.abs(dot(vz, dirV)) < 1e-8 ? vz : dirV;
  // Giải hệ 3x3: [vx, vy, -d] * [u1, u2, t]^T = P - planeOrigin
  const [u1, u2, t] = solveLinear3x3(vx, vy, neg(d), sub(P, planeOrigin));
  return {
    globalPoint: add(planeOrigin, add(scale(vx, u1), scale(vy, u2))),
    inPlane: { u1, u2, t },
  };
}
```

---

## 2. Dựng hình Chóp & Lăng trụ (`AlgoPolyhedronPointsPyramid`, `AlgoPolyhedronPointsPrism`)

### a) Hình chóp (`Pyramid`)
- Đầu vào: đa giác đáy có thứ tự đỉnh `B = [B_0, B_1, ..., B_{n-1}]` và đỉnh chóp `S` (hoặc chiều cao `h` dọc theo pháp tuyến đáy `mainDirection`: `S = tâm_đáy + h * n̂_đáy`).
- Tạo `n` mặt bên tam giác tuần tự quanh đáy: `(B_i, B_{(i+1)%n}, S)`.
- Thể tích: `V = (1 / 3) * area(B) * distance(S, plane(B))`.

### b) Hình lăng trụ (`Prism`)
- Đầu vào: đa giác đáy `B` và điểm đỉnh tương ứng `B'_0` (hoặc chiều cao `h` dọc `n̂_đáy`).
- Tính vector tịnh tiến: `u = B'_0 - B_0` (hoặc `u = h * n̂_đáy`).
- Tạo toàn bộ đỉnh đáy trên: `B'_i = B_i + u`.
- Tạo `n` mặt bên hình bình hành: `(B_i, B_{(i+1)%n}, B'_{(i+1)%n}, B'_i)` và đóng mặt đáy trên `(B'_0, ..., B'_{n-1})`.
- Thể tích: `V = area(B) * |u · n̂_đáy|`.

---

## 3. Giao tuyến hai mặt phẳng & Giao điểm đường – mặt (`AlgoIntersectPlanes`, `AlgoIntersectPlanePolyhedron`)

### a) Giao tuyến 2 mặt phẳng `P_1(O_1, n_1)` và `P_2(O_2, n_2)`
```js
function intersectTwoPlanes(O1, n1, O2, n2) {
  const vn = cross(n1, n2);
  if (len(vn) < 1e-8) {
    const coplanar = Math.abs(dot(sub(O2, O1), normalize(n1))) < 1e-8;
    return { status: coplanar ? 'IDENTICAL' : 'PARALLEL' };
  }
  const vnn = normalize(vn);
  const vn1 = normalize(cross(n1, vnn)); // nằm trong P1, vuông góc giao tuyến
  const vn2 = normalize(cross(n2, vnn)); // nằm trong P2, vuông góc giao tuyến
  // Chiếu O2 lên mặt phẳng (O1, vnn, vn1) dọc theo phương vn2 để lấy gốc O trên giao tuyến
  const { globalPoint: O } = projectPointThruDir(O2, O1, vnn, vn1, n1, vn2);
  return { status: 'LINE', origin: O, direction: vnn };
}
```

### b) Giao điểm đoạn thẳng `AB` với mặt phẳng `P` (`AlgoIntersectPlanePolyhedron`)
- Chiếu `A` theo phương `d = B - A` lên mặt phẳng `P` bằng `projectPointThruDir`.
- Gọi `t` là tham số trên đoạn `AB` (`I = A + t*(B - A)`). Chỉ nhận giao điểm nếu `d` không song song `P` và `0 <= t <= 1` (`respectLimitedPath`).

---

## 4. Thiết diện mặt phẳng cắt đa diện (`AlgoIntersectRegionPlanePolyhedron`)

GeoGebra xử lý tổng quát cả đa diện lồi và đa diện lõm theo 3 bước:
1. **Tìm điểm giao trên từng mặt `F` của đa diện:**
   - Nếu toàn bộ mặt `F` nằm trong mặt phẳng cắt `P` (`d1 ≈ 0` và `O1` nằm trên `P`), lấy thẳng vòng đỉnh của `F`.
   - Ngược lại, tìm giao tuyến giữa `P` và mặt phẳng chứa `F`, rồi tìm các giao điểm của `P` với từng cạnh và đỉnh thuộc `F`, sắp xếp tăng dần theo tham số `λ` dọc giao tuyến.
2. **Lọc đoạn giao thực trên mặt `F`:**
   - Với mỗi cặp điểm kề nhau `(A_k, A_{k+1})` trên đường giao tuyến, kiểm tra **trung điểm `(A_k + A_{k+1}) / 2`** có nằm trong miền đa giác `F` hay không; hợp nhất các đoạn liên tiếp cùng thuộc `F` thành các đoạn giao tuyến `(p1, p2)` kèm thông tin cạnh/mặt cha (`parentToPolygons`).
3. **Nối vòng thành đa giác thiết diện:**
   - Từ một đoạn giao trên mặt `F_1`, lấy điểm cuối cùng cạnh cha sang mặt kề `F_2` chia sẻ cạnh đó (`nextVertex`), lặp cho đến khi khép kín chu trình đa giác; chuẩn hóa thứ tự vòng bằng đỉnh nhỏ nhất theo từ điển `(x, y, z)` để loại bỏ vòng trùng lặp.

---

## 5. Khoảng cách & Đường vuông góc chung (`GeoPlane3D`, `GeoCoordSys1D`, `CoordMatrixUtil`, `AlgoOrthoLine*`)

1. **Khoảng cách từ điểm `P` đến mặt phẳng `(O, n̂)` (`GeoPlane3D.distance`):**
   - `d = |(P - O) · n̂|`.
2. **Đường thẳng qua `P` vuông góc mặt phẳng `(O, n̂)` (`AlgoOrthoLinePointPlane`):**
   - Đường thẳng có gốc `P` và vector chỉ phương `n̂`.
3. **Đoạn vuông góc chung & Khoảng cách giữa 2 đường thẳng `d_1(O_1, v_1)` và `d_2(O_2, v_2)` (`CoordMatrixUtil.nearestPointsFromTwoLines`):**
   ```js
   function nearestPointsAndDistance(O1, v1, O2, v2) {
     const vn = cross(v1, v2);
     if (len(vn) < 1e-8) {
       // Song song: khoảng cách = |(O1 - O2) · normalize((O1 - O2) × v1 × v1)|
       const perp = normalize(cross(cross(sub(O1, O2), v1), v1));
       return { parallel: true, distance: Math.abs(dot(sub(O1, O2), perp)) };
     }
     // Chiếu O2 lên mặt phẳng chứa d1 và pháp vector chung vn theo phương v2 -> được P2 trên d2
     const P2 = projectPointThruDir(O2, O1, v1, vn, cross(v1, vn), v2).globalPoint;
     // Chiếu O1 lên mặt phẳng chứa d2 và pháp vector chung vn theo phương v1 -> được P1 trên d1
     const P1 = projectPointThruDir(O1, O2, v2, vn, cross(v2, vn), v1).globalPoint;
     const dist = Math.abs(dot(sub(O1, O2), normalize(vn)));
     return { parallel: false, P1, P2, distance: dist };
   }
   ```

---

## 6. Tính Góc trong không gian (`AlgoAngleLines3D`, `AlgoAngleLinePlane`, `AlgoAnglePlanes`)

- **Góc hai đường thẳng `(v_1, v_2)` (đồng phẳng):** kiểm tra `nearestPoints` trùng nhau, rồi `θ = arccos((v_1 · v_2) / (|v_1|·|v_2|))`.
- **Góc giữa đường thẳng `(O_2, v_2)` và mặt phẳng `P`:** chiếu gốc đường thẳng lên `P`, lấy vector hình chiếu trên mặt phẳng `P` (hoặc dùng `arcsin(|v_2 · n̂_P| / |v_2|)`).
- **Góc giữa hai mặt phẳng `(n̂_1, n̂_2)`:** giao tuyến `v_n = normalize(n̂_1 × n̂_2)`, lấy hai vector tiếp tuyến vuông góc giao tuyến trên mỗi mặt `v_2 = n̂_1 × v_n`, `v_1 = n̂_2 × v_n`, giá trị góc `θ = arccos(n̂_1 · n̂_2)`.

---

## 7. Cách xác định Nét đứt / Nét liền theo góc nhìn (`Renderer`, `RendererImplShaders`, `DrawPolyhedron3D`, `HiddenLineStyleProperty`)

GeoGebra **không** tự cắt đoạn bằng CPU; thay vào đó bộ dựng 3D (`Renderer.draw()`) dùng **quy trình Z-buffer 3 lượt trên GPU**:

1. **Lượt 1 — Vẽ toàn bộ nét khuất (`drawHidden`):**
   - Bật texture/kiểu nét đứt (`enableDashHidden()` theo `LINE_TYPE_HIDDEN_DASHED`).
   - Vẽ toàn bộ các cạnh (`drawCurves(true)`). Lúc này các mặt kín chưa ghi vào Z-buffer nên toàn bộ cạnh đều hiện dạng nét đứt.
2. **Lượt 2 — Ghi mặt nạ chiều sâu (`drawHidingSurfaces`):**
   - Tắt ghi màu (`ColorMask.NONE`), giữ ghi Z-buffer (`depthWrite = true`).
   - Vẽ các mặt đóng của khối đa diện (`drawClosedSurfacesForHiding()`, lần lượt `CullFaceFront` cho mặt trong và `CullFaceBack` cho mặt ngoài). Các mặt trong suốt vẽ riêng với `disableDepthMask()` để không che mất nét đứt phía sau.
3. **Lượt 3 — Vẽ đè nét nhìn thấy (`drawNotHidden`):**
   - Bật lại kiểu nét liền (`enableDash()`), giữ bật kiểm tra độ sâu (`depthTest = true`).
   - Vẽ lại toàn bộ các cạnh (`drawCurves(false)`).
   - **Kết quả tự động theo mọi góc xoay 360°:** Những đoạn cạnh ở phía trước mặt đa diện vượt qua depth test và được tô đè thành **nét liền**; những đoạn cạnh nằm sau mặt đa diện bị depth test loại bỏ, để lộ **nét đứt** đã vẽ ở Lượt 1.
   - **Đa diện lõm (không lồi):** Khi có mặt lõm (kiểm tra half-space toàn cục không thỏa mãn đồng nhất), vẫn giữ toàn bộ các mặt ngoài thực sự vào bước ghi mặt nạ chiều sâu với `polygonOffset` dương để hốc lõm không bị lộ sai nét.

---

## 8. Thuật toán nối vòng thiết diện cho cả khối lõm & mặt đồng phẳng (`AlgoIntersectRegionPlanePolyhedron`)

1. Với từng mặt ngoài `F`: tính giao tuyến `n̂ × n̂_F`, gom toàn bộ giao điểm của mặt phẳng cắt với các cạnh và đỉnh thuộc `F`, sắp xếp theo tham số dọc giao tuyến.
2. **Lọc đoạn giao hợp lệ (`checkMidpoint`):** Với từng cặp kề nhau `(A_k, A_{k+1})`, chiếu về hệ trục 2D trực chuẩn `(u, v)` của mặt `F` để kiểm tra trung điểm có nằm trong biên/trong miền đa giác `F` hay không (thuật toán ray-casting kết hợp biên đoạn, đúng cho cả mặt lõm) rồi hợp nhất các đoạn liền kề.
3. **Nối vòng qua cạnh cha dùng chung (`parentToPolygons` / `nextVertex`):** Gán nhãn cha (`V:id` hoặc `E:u|w`) cho mỗi đầu mút đoạn giao; đi theo các mặt kề chia sẻ cạnh cha để khép kín thành 1 hoặc nhiều vòng thiết diện (`allLoops`), ưu tiên vòng diện tích lớn nhất làm thiết diện chính và xử lý cả trường hợp mặt phẳng trùng mặt đa diện (`coplanar`).

---

## 9. Năm khối đa diện đều Platonic (`PlatonicSolidsFactory`) & Giao điểm Mặt cầu (`AlgoIntersectQuadricsAsCircle`)

- **5 khối đa diện đều chuẩn hóa cạnh đơn vị (`a = 1`):** `Tetrahedron` (4 đỉnh, 4 mặt), `Cube` (8 đỉnh, 6 mặt), `Octahedron` (6 đỉnh, 8 mặt tam giác đều), `Dodecahedron` (20 đỉnh, 12 mặt ngũ giác đều với tọa độ tỷ lệ vàng `φ = (1+√5)/2`), `Icosahedron` (12 đỉnh, 20 mặt tam giác đều). Khi dựng trong app, dịch tâm về gốc `(0, 0)` và nhân tỉ lệ cạnh `a`.
- **Mặt phẳng trung trực (`AlgoOrthoPlaneBisectorPointPoint`) & Khoảng cách 2 mặt phẳng (`AlgoDistancePlanes`):**
  - Mặt phẳng trung trực `AB` đi qua `M = (A+B)/2` nhận `B - A` làm pháp tuyến.
  - Khoảng cách 2 mặt phẳng: nếu `|n̂_1 × n̂_2| > ε` trả về `0` (cắt nhau); ngược lại trả về `|(O_2 - O_1) · n̂_1|`.
- **Mặt cầu ngoại tiếp & Giao với đường/mặt/mặt cầu:**
  - Tâm ngoại tiếp tứ diện `ABCD`: giải hệ tuyến tính `3×3` từ đẳng thức `|I - P|^2 = |I - A|^2` với `P ∈ {B, C, D}`.
  - Đường thẳng cắt mặt cầu (`AlgoIntersectLineQuadric3D`): giải phương trình bậc 2 theo tham số `t` trên đoạn `AB`.
  - Mặt phẳng hoặc mặt cầu khác cắt mặt cầu (`AlgoIntersectPlaneQuadric`, `AlgoIntersectQuadricsAsCircle`): hạ hình chiếu tâm `H` lên mặt phẳng cắt (hoặc trục nối tâm), suy ra đường tròn giao tuyến tâm `H`, pháp tuyến `n̂`, bán kính `r = √(R² - d²)`.

---

## 10. Tỉ lệ nét vẽ & chống rối nhãn theo độ thu phóng (`DrawSegment3D`, `DrawPoint3D`, `DrawLabel3D`)

- Độ dày nét cạnh (ống trụ/nét đứt) và bán kính nút đỉnh được tỉ lệ mượt theo bán kính bao hình `sceneRadius` để khối lớn không bị nét mảnh như sợi chỉ và khối nhỏ không bị nút đỉnh che mất cạnh.
- Khi thu nhỏ hoặc zoom camera ra xa, bộ đặt nhãn (`_computePlacedLabels`) tự chuyển sang chế độ thu gọn (`compact` / `isTiny`), giữ ưu tiên nhãn đỉnh chính và ẩn bớt nhãn độ dài cạnh phụ để tránh chồng chéo chữ.

