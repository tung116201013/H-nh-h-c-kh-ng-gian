/* ===== hhkg-zip.js: Zero-dependency PKZIP (STORE + CRC32) writer for Node & Browser ===== */

const CRC_TABLE = (() => {
  const tbl = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    tbl[i] = c >>> 0;
  }
  return tbl;
})();

export function crc32(bytes) {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

const encUtf8 = new TextEncoder();

function toBytes(content) {
  if (content instanceof Uint8Array) return content;
  return encUtf8.encode(String(content ?? ''));
}

function dosTimeDate(date = new Date()) {
  const yr = Math.max(1980, date.getFullYear()) - 1980;
  const mo = date.getMonth() + 1;
  const dy = date.getDate();
  const hr = date.getHours();
  const mi = date.getMinutes();
  const se = Math.floor(date.getSeconds() / 2);
  return {
    time: (hr << 11) | (mi << 5) | se,
    date: (yr << 9) | (mo << 5) | dy,
  };
}

/**
 * Builds a standard PKZIP Uint8Array archive (method 0 STORE, UTF-8 filenames).
 * @param {Array<{name: string, content: string | Uint8Array}>} entries
 * @returns {Uint8Array}
 */
export function createZipBytes(entries) {
  const { time, date } = dosTimeDate();
  const localParts = [];
  const centralParts = [];
  let offset = 0;

  for (const entry of entries || []) {
    const nameBytes = encUtf8.encode(String(entry.name || 'file.txt').replace(/^\/+/, ''));
    const data = toBytes(entry.content);
    const sum = crc32(data);
    const size = data.length;

    // Local file header (30 bytes + filename)
    const lh = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(lh.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true); // version needed
    lv.setUint16(6, 0x0800, true); // UTF-8 filename flag
    lv.setUint16(8, 0, true); // compression: STORE
    lv.setUint16(10, time, true);
    lv.setUint16(12, date, true);
    lv.setUint32(14, sum, true);
    lv.setUint32(18, size, true);
    lv.setUint32(22, size, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);
    lh.set(nameBytes, 30);

    // Central directory header (46 bytes + filename)
    const ch = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(ch.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0x0800, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, time, true);
    cv.setUint16(14, date, true);
    cv.setUint32(16, sum, true);
    cv.setUint32(20, size, true);
    cv.setUint32(24, size, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    ch.set(nameBytes, 46);

    localParts.push(lh, data);
    centralParts.push(ch);
    offset += lh.length + data.length;
  }

  let centralSize = 0;
  for (const c of centralParts) centralSize += c.length;

  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  const count = (entries || []).length;
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, count, true);
  ev.setUint16(10, count, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  const totalLen = offset + centralSize + eocd.length;
  const out = new Uint8Array(totalLen);
  let cursor = 0;
  for (const part of localParts) {
    out.set(part, cursor);
    cursor += part.length;
  }
  for (const c of centralParts) {
    out.set(c, cursor);
    cursor += c.length;
  }
  out.set(eocd, cursor);
  return out;
}
