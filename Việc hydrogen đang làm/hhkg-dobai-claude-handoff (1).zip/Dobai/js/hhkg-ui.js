import {
  TEMPLATES,
  normalizeSceneSpec,
  computeCrossSection,
  midpoint,
  centroid,
  lerpPoint,
  parallelPointThrough,
  projectPointOnPlane,
  planeFrom3Points,
  planeFromPointAndNormal,
  planeParallelToPlane,
  planePerpToLine,
  dihedralAngle,
  commonPerpendicularSegment,
  polyhedronVolume,
  vecDist,
  vecSub,
  triangleArea,
  angleBetweenLines,
  angleLinePlane,
  computePolyhedronNet,
  reflectPointAcrossPlane,
  buildGrade11CustomSolid,
  solveGrade11Offline,
  nextStandardVertexLabel,
  extrudeBaseToPyramid,
  extrudeBaseToPrism,
  parallelogram4thVertex,
  intersectTwoLines3D,
  intersectLinePlane,
  projectPointOnLine,
  bakeCrossSectionVertices,
  buildBaseStencilScene,
} from './hhkg-math.js';
import { Geometry3DViewer } from './hhkg-3d.js';
import { createZipBytes } from './hhkg-zip.js';
import { executeGeoGebraCommand, GEOGEBRA_QUICK_COMMANDS, refineAiGeometryPayload } from './hhkg-geogebra.js';

(function initHhkgModule() {
  'use strict';

  const W = window;
  const D = document;
  const $ = (id) => D.getElementById(id);
  const esc = (s) =>
    String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  const STORAGE_KEY_SAVED = 'dc:hhkg:saved';

  const SAMPLE_PROBLEMS = [
    {
      label: 'Lớp 11 · Giao điểm (Bài 10 KNTT)',
      text: 'Cho hình chóp S.ABCD có đáy ABCD là hình bình hành tâm O. Gọi M là trung điểm SC, N trên cạnh SD. Tìm giao điểm của đường thẳng BN với mặt phẳng (SAC) theo Bài 10 SGK KNTT.',
    },
    {
      label: 'Lớp 11 · Song song (Bài 11 KNTT)',
      text: 'Cho hình chóp S.ABCD có đáy ABCD là hình bình hành. Xác định giao tuyến của hai mặt phẳng (SAB) và (SCD) theo định lí quan hệ song song.',
    },
    {
      label: 'Lớp 11 · Thiết diện // (Bài 12 KNTT)',
      text: 'Cho hình chóp S.ABCD có đáy ABCD là hình bình hành. Gọi M là trung điểm SA. Xác định thiết diện của hình chóp cắt bởi mặt phẳng đi qua M song song với (SBC).',
    },
    {
      label: 'Lớp 11 · Góc nhị diện & d(A,(SBD))',
      text: 'Cho hình chóp S.ABCD có đáy ABCD là hình vuông cạnh a, SA vuông góc với mặt phẳng (ABCD) và SA = a√2. Tính góc giữa đường thẳng SC và mặt phẳng (ABCD), góc nhị diện [S, BD, A], và tính khoảng cách từ A đến mặt phẳng (SBD).',
    },
    {
      label: 'Lớp 11 · Mặt bên (SAB) ⊥ đáy',
      text: 'Cho hình chóp S.ABCD có đáy ABCD là hình vuông cạnh a, tam giác SAB đều và nằm trong mặt phẳng vuông góc với đáy (ABCD). Gọi H là trung điểm AB. Tính góc giữa SC và mặt phẳng (ABCD).',
    },
    {
      label: 'Lớp 11 · Chóp cụt tứ giác đều',
      text: 'Cho hình chóp cụt tứ giác đều ABCD.A\'B\'C\'D\' có cạnh đáy lớn bằng 2a, cạnh đáy nhỏ bằng a và chiều cao OO\' = a√2. Tính thể tích khối chóp cụt và góc giữa cạnh bên với mặt đáy.',
    },
    {
      label: 'Lớp 12 · Tọa độ hóa Oxyz',
      text: 'Cho hình lăng trụ đứng ABC.A\'B\'C\' có đáy ABC là tam giác vuông tại B, AB = 2, BC = 2, AA\' = 3. Gắn hệ trục tọa độ Oxyz sao cho B trùng gốc O, BA nằm trên tia Ox, BC nằm trên tia Oy, BB\' nằm trên tia Oz. Tính góc giữa hai đường thẳng A\'B và AC\'.',
    },
  ];

  function loadSavedList() {
    try {
      const raw = W.localStorage.getItem(STORAGE_KEY_SAVED);
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  function persistSavedList(list) {
    try {
      W.localStorage.setItem(STORAGE_KEY_SAVED, JSON.stringify(list.slice(0, 25)));
    } catch {}
  }

  const initTpl = TEMPLATES[0];

  const STATE = {
    open: false,
    tab: 'templates', // 'templates' | 'ai' | 'measure'
    gradeFilter: 'Lớp 11', // 'Lớp 11' | 'all' | 'Lớp 12'
    activeTemplateId: initTpl.id,
    scene: structuredClone(initTpl.scene),
    activeTitle: initTpl.name,
    activeFormula: initTpl.formula,
    activeSteps: structuredClone(initTpl.steps || []),
    activeStepIdx: -1,
    stepBarOpen: false,
    speaking: false,
    viewStyle: 'textbook-3d',
    labelsMode: W.innerWidth < 520 ? 'vertices' : 'all', // 'all' | 'vertices' | 'none'
    showFaces: true,
    showGrid: true,
    showAxes: null, // null = follow scene.showOxyz
    stageExpanded: false,
    drawMode: 'orbit', // 'orbit' | 'point' | 'segment'
    pendingSegmentStart: '',
    drawHeight: 3.0,
    drawPlaneZ: 0,
    placePointMode: false,
    aiGuideOpen: false,
    netRatio: 0,
    autoRotate: false,
    dockCollapsed: false,
    selectedVertices: [],
    history: [],
    redoStack: [],
    // GeoGebra Algebra / Command Bar
    cmdText: '',
    cmdHistory: [],
    // Grade 11 Custom Wizard
    wizardOpen: false,
    wizard: {
      shape: 'chop-tu-giac',
      base: 'vuong',
      foot: 'A',
      a: 3.0,
      b: 2.2,
      h: 3.0,
      topRatio: 0.5,
    },
    // Cross-section state
    csEnabled: false,
    csPlane: { nx: 0, ny: 0, nz: 1, d: 1.4 },
    // Saved & Export feedback
    savedList: loadSavedList(),
    noticeMsg: '',
    noticeKind: 'ok',
    exportBusy: false,
    // AI state
    aiBusy: false,
    aiError: '',
    aiErrorNeedsFallback: false,
    aiResult: null,
    aiPromptText: '',
    aiImageBase64: '',
    aiImageMime: '',
    aiImageName: '',
    aiFollowups: [],
    viewer: null,
    ov: null,
  };

  /* ---------- History & Snapshots ---------- */
  function snapshotScene() {
    return {
      scene: structuredClone(STATE.scene),
      title: STATE.activeTitle,
      formula: STATE.activeFormula,
      steps: structuredClone(STATE.activeSteps || []),
      templateId: STATE.activeTemplateId,
      stepIdx: STATE.activeStepIdx,
    };
  }

  function pushHistory() {
    STATE.history.push(snapshotScene());
    if (STATE.history.length > 20) STATE.history.shift();
    STATE.redoStack = [];
  }

  function applySnapshot(snap) {
    if (!snap) return;
    STATE.scene = normalizeSceneSpec(snap.scene);
    STATE.activeTitle = snap.title || 'Hình không gian 3D';
    STATE.activeFormula = snap.formula || '';
    STATE.activeSteps = Array.isArray(snap.steps) ? snap.steps : [];
    STATE.activeTemplateId = snap.templateId || '';
    STATE.activeStepIdx = Number.isInteger(snap.stepIdx) ? snap.stepIdx : -1;
    STATE.selectedVertices = [];
    if (STATE.viewer) {
      STATE.viewer.setSelectedVertices([]);
      applyStepHighlight();
    }
    syncViewer({ keepCamera: true });
    renderStepBar();
    renderBody();
  }

  function undoScene() {
    if (!STATE.history.length) return;
    STATE.redoStack.push(snapshotScene());
    applySnapshot(STATE.history.pop());
  }

  function redoScene() {
    if (!STATE.redoStack.length) return;
    STATE.history.push(snapshotScene());
    applySnapshot(STATE.redoStack.pop());
  }

  function setNotice(msg, kind = 'ok') {
    STATE.noticeMsg = msg;
    STATE.noticeKind = kind;
  }

  /* ---------- Speech (TTS matching Dobai Vietnamese UX) ---------- */
  function stopSpeech() {
    STATE.speaking = false;
    try {
      if (W.speechSynthesis) W.speechSynthesis.cancel();
    } catch {}
  }

  function speakText(text) {
    stopSpeech();
    if (!text) return;
    try {
      if (W.speechSynthesis && typeof W.SpeechSynthesisUtterance === 'function') {
        const clean = String(text)
          .replace(/⊥/g, ' vuông góc với ')
          .replace(/⇒/g, ' suy ra ')
          .replace(/∠/g, ' góc ')
          .replace(/△/g, ' tam giác ')
          .replace(/√/g, ' căn ');
        const utt = new W.SpeechSynthesisUtterance(clean);
        utt.lang = 'vi-VN';
        utt.rate = 1.0;
        utt.onend = () => {
          STATE.speaking = false;
          renderStepBar();
        };
        STATE.speaking = true;
        W.speechSynthesis.speak(utt);
        renderStepBar();
      }
    } catch {
      STATE.speaking = false;
    }
  }

  /* ---------- CSS Injection (Dobai-compatible, zero .b collision, 40px+ mobile touch targets) ---------- */
  function ensureStyles() {
    if ($('hhkg-css')) return;
    const style = D.createElement('style');
    style.id = 'hhkg-css';
    style.textContent = `
      html.hhkg-lock, html.hhkg-lock body { overflow: hidden !important; overscroll-behavior: none; }
      #hhkg-entry { border: 1.5px solid #C7D7F5; background: linear-gradient(180deg, #FFFFFF 0%, #F5F8FF 100%); }
      #hhkg-entry h2 { margin: 0 0 6px; display: flex; align-items: center; gap: 6px; font-size: 17px; color: var(--ink, #17233B); flex-wrap: wrap; }
      .hhkg-badge { display: inline-block; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 999px; background: #E0E7FF; color: #1E3A8A; white-space: nowrap; }
      .hhkg-badge.g11 { background: #DCFCE7; color: #166534; }

      #hhkg-ov {
        position: fixed; inset: 0; z-index: 2147483200;
        background: #E8EEF5; color: #17233B; color-scheme: only light;
        font-family: "Be Vietnam Pro", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
        display: flex; flex-direction: column; overflow: hidden;
      }
      #hhkg-ov[hidden] { display: none; }
      #hhkg-ov *, #hhkg-ov *::before, #hhkg-ov *::after { box-sizing: border-box; }

      .hhkg-top {
        flex: none; display: flex; align-items: center; gap: 8px;
        padding: 8px 12px; padding-top: calc(8px + env(safe-area-inset-top));
        background: #17233B; color: #fff; border-bottom: 1px solid #2A3858;
      }
      .hhkg-back {
        min-height: 40px; padding: 0 11px; border: 1px solid rgba(255,255,255,0.24);
        border-radius: 10px; background: rgba(255,255,255,0.08); color: #fff;
        font-weight: 700; font-size: 13.5px; cursor: pointer; white-space: nowrap;
      }
      .hhkg-back:hover { background: rgba(255,255,255,0.18); }
      .hhkg-hd-tt { flex: 1; min-width: 0; }
      .hhkg-hd-tt h2 { margin: 0; font-size: 15.5px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .hhkg-hd-tt p { margin: 1px 0 0; font-size: 11.5px; color: #B9C4DB; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .hhkg-dl-top {
        min-height: 40px; padding: 0 10px; border: 1px solid #60A5FA;
        border-radius: 10px; background: #243B8F; color: #fff;
        font-weight: 700; font-size: 12.5px; cursor: pointer; white-space: nowrap;
      }
      .hhkg-dl-top:hover { background: #1D4ED8; }
      @media (max-width: 440px) {
        .hhkg-dl-top { font-size: 12px; padding: 0 8px; }
      }

      .hhkg-main { flex: 1 1 auto; min-height: 0; display: flex; flex-direction: column; overflow: hidden; }
      @media (min-width: 900px) {
        .hhkg-main { flex-direction: row; }
      }

      /* 3D Viewport */
      .hhkg-stage {
        position: relative; flex: none; height: 42dvh; min-height: 240px;
        background: #F3F7FD; border-bottom: 1px solid #D5DDE8; overflow: hidden;
      }
      @media (min-width: 900px) {
        .hhkg-stage { flex: 1 1 auto; height: auto; border-bottom: 0; border-right: 1px solid #D5DDE8; }
      }
      #hhkg-canvas-wrap { position: absolute; inset: 0; }
      #hhkg-canvas-wrap canvas { display: block; width: 100%; height: 100%; outline: none; touch-action: none; }
      #hhkg-labels { position: absolute; inset: 0; pointer-events: none; overflow: hidden; z-index: 2; }
      .hhkg-lbl {
        position: absolute; left: 0; top: 0;
        padding: 1px 5px; border-radius: 5px;
        font-size: 11.5px; font-weight: 700; line-height: 1.28;
        background: rgba(255, 255, 255, 0.9); color: #17233B;
        border: 1px solid rgba(23, 35, 59, 0.16);
        box-shadow: 0 1px 2px rgba(15, 23, 42, 0.1);
        white-space: nowrap; user-select: none;
      }
      .hhkg-lbl.compact { font-size: 10px; padding: 0 4px; border-radius: 4px; line-height: 1.22; }
      .hhkg-lbl-vertex-hi { background: #FFF7ED; color: #C2410C; border-color: #EA580C; }
      .hhkg-lbl-edge { background: rgba(238, 242, 255, 0.9); color: #1E40AF; font-size: 10.5px; }
      .hhkg-lbl-angle { background: #FEF3C7; color: #92400E; font-size: 10.5px; border-color: #F59E0B; }
      .hhkg-lbl-axis { background: transparent; border: 0; box-shadow: none; font-style: italic; font-size: 12.5px; color: #17233B; }

      #hhkg-ov.hhkg-expanded .hhkg-stage {
        flex: 1 1 auto !important;
        height: auto !important;
        min-height: 0;
        border-right: 0;
        border-bottom: 1px solid #D5DDE8;
      }
      #hhkg-ov.hhkg-expanded .hhkg-panel {
        flex: none !important;
        max-width: 100% !important;
        height: auto;
      }
      #hhkg-ov.hhkg-expanded .hhkg-toolbar,
      #hhkg-ov.hhkg-expanded .hhkg-stepbar,
      #hhkg-ov.hhkg-expanded .hhkg-body {
        display: none !important;
      }
      @media (min-width: 900px) {
        #hhkg-ov.hhkg-expanded .hhkg-main { flex-direction: column; }
      }

      .hhkg-hud-top {
        position: absolute; top: 8px; left: 8px; right: 8px; z-index: 3;
        display: flex; justify-content: space-between; align-items: flex-start; gap: 6px;
        pointer-events: none;
      }
      .hhkg-spec {
        pointer-events: auto; max-width: 68%;
        background: rgba(255, 255, 255, 0.94); border: 1px solid #D5DDE8;
        border-radius: 10px; padding: 5px 9px; font-size: 12px; color: #17233B;
        box-shadow: 0 2px 8px rgba(15, 23, 42, 0.08);
      }
      .hhkg-spec strong { display: block; font-size: 12.5px; line-height: 1.3; }
      .hhkg-spec span { display: block; color: #5E6B85; font-size: 11.5px; margin-top: 1px; }
      .hhkg-hud-btns { pointer-events: auto; display: flex; gap: 4px; flex-wrap: wrap; justify-content: flex-end; }
      .hhkg-hud-mini {
        min-height: 32px; padding: 0 8px; border: 1px solid #CBD5E1; border-radius: 8px;
        background: rgba(255,255,255,0.94); color: #17233B; font-size: 11.5px; font-weight: 700; cursor: pointer;
      }
      .hhkg-hud-mini.on { background: #243B8F; border-color: #243B8F; color: #fff; }
      @media (max-width: 899px) {
        .hhkg-spec { padding: 4px 8px; max-width: 62%; }
        .hhkg-spec strong { font-size: 11.5px; }
        .hhkg-spec .hhkg-unit { display: none; }
      }
      @media (max-width: 639px) {
        .hhkg-stage { height: 39dvh; min-height: 225px; }
        .hhkg-hud-top { flex-direction: column; align-items: stretch; gap: 4px; top: 6px; left: 6px; right: 6px; }
        .hhkg-spec { max-width: 100%; display: flex; align-items: baseline; justify-content: space-between; gap: 8px; padding: 3px 8px; }
        .hhkg-spec span { margin-top: 0; font-size: 10.5px; white-space: nowrap; }
        .hhkg-hud-btns { justify-content: flex-start; flex-wrap: nowrap; overflow-x: auto; gap: 3px; max-width: 100%; scrollbar-width: none; }
        .hhkg-hud-btns::-webkit-scrollbar { display: none; }
        .hhkg-hud-mini { flex: none; min-height: 28px; padding: 0 5.5px; font-size: 10.5px; letter-spacing: -0.01em; }
      }

      .hhkg-dock-wrap {
        position: absolute; left: 50%; bottom: 8px; transform: translateX(-50%);
        z-index: 4; max-width: calc(100% - 16px); display: flex; flex-direction: column; align-items: center; gap: 4px;
      }
      .hhkg-dock-toggle {
        min-height: 30px; border: 1px solid #CBD5E1; background: rgba(255,255,255,0.96); color: #17233B;
        border-radius: 999px; padding: 3px 12px; font-size: 11.5px; font-weight: 700; cursor: pointer;
      }
      .hhkg-dock {
        display: flex; flex-wrap: nowrap; overflow-x: auto; gap: 4px; max-width: 100%;
        padding: 4px; border-radius: 12px; background: rgba(255, 255, 255, 0.96);
        border: 1px solid #CBD5E1; box-shadow: 0 4px 14px rgba(15, 23, 42, 0.12);
      }
      .hhkg-dock[hidden] { display: none; }
      .hhkg-dock button {
        flex: none; min-height: 32px; padding: 0 9px; border: 1px solid #D5DDE8;
        border-radius: 8px; background: #fff; color: #17233B; font-size: 11.5px; font-weight: 600;
        cursor: pointer; white-space: nowrap;
      }
      .hhkg-dock button.on { background: #243B8F; border-color: #243B8F; color: #fff; }

      /* Side / Bottom Drawer */
      .hhkg-panel {
        flex: 1 1 auto; min-height: 0; display: flex; flex-direction: column;
        background: #fff; overflow: hidden;
      }
      @media (min-width: 900px) {
        .hhkg-panel { flex: 0 0 460px; max-width: 45vw; }
      }
      .hhkg-tabs {
        flex: none; display: flex; gap: 4px; padding: 6px 8px;
        background: #F4F7FB; border-bottom: 1px solid #D5DDE8;
      }
      .hhkg-tabs button {
        flex: 1; min-height: 40px; border: 1px solid transparent; border-radius: 10px;
        background: transparent; color: #5E6B85; font-size: 12px; font-weight: 700; cursor: pointer;
        padding: 4px 4px; white-space: nowrap;
      }
      @media (max-width: 430px) {
        .hhkg-tabs { gap: 3px; padding: 5px 6px; }
        .hhkg-tabs button { font-size: 11px; padding: 4px 2px; }
      }
      .hhkg-tabs button.on { background: #fff; color: #243B8F; border-color: #D5DDE8; box-shadow: 0 1px 3px rgba(15,23,42,0.06); }

      /* Quick Action Toolbar */
      .hhkg-toolbar {
        flex: none; display: flex; flex-wrap: wrap; gap: 4px; padding: 6px 8px;
        background: #FAFBFD; border-bottom: 1px solid #E2E8F0; overflow-x: visible;
      }
      .hhkg-tbtn {
        flex: none; min-height: 40px; padding: 0 7.5px; border: 1px solid #D5DDE8; border-radius: 10px;
        background: #fff; color: #17233B; font-size: 11.5px; font-weight: 700; cursor: pointer;
        display: inline-flex; align-items: center; gap: 3px; white-space: nowrap;
      }
      .hhkg-tbtn:disabled { opacity: 0.42; cursor: default; }
      .hhkg-tbtn.pri { background: #EEF2FF; border-color: #B7C9F6; color: #1E3A8A; }

      /* Floating Teacher Step Bar (vz-js inspired, non-occluding) */
      .hhkg-stepbar {
        flex: none; background: #FFFBF0; border-bottom: 1.5px solid #F59E0B;
        padding: 8px 12px;
      }
      .hhkg-stepbar[hidden] { display: none; }
      .hhkg-sb-prog { display: flex; gap: 4px; margin-bottom: 6px; }
      .hhkg-sb-prog i { flex: 1; height: 5px; border-radius: 3px; background: #E5E7EB; cursor: pointer; }
      .hhkg-sb-prog i.done { background: #16845B; }
      .hhkg-sb-prog i.on { background: #EA580C; }
      .hhkg-sb-head { display: flex; align-items: center; gap: 6px; justify-content: space-between; }
      .hhkg-sb-head b { font-size: 13px; color: #17233B; flex: 1; }
      .hhkg-sb-body { margin-top: 4px; font-size: 12.5px; color: #334155; line-height: 1.45; }
      .hhkg-sb-formula {
        margin-top: 4px; padding: 4px 8px; border-radius: 7px; background: #FEF3C7;
        color: #92400E; font-size: 12px; font-weight: 700; font-family: ui-monospace, Menlo, Consolas, monospace;
      }
      .hhkg-sb-nav { display: flex; gap: 6px; margin-top: 6px; align-items: center; }
      .hhkg-sb-nav button {
        min-height: 40px; padding: 0 12px; border: 1.5px solid #D5DDE8; border-radius: 10px;
        background: #fff; color: #17233B; font-size: 12.5px; font-weight: 700; cursor: pointer;
      }
      .hhkg-sb-nav button.pri { background: #EA580C; border-color: #EA580C; color: #fff; margin-left: auto; }
      .hhkg-sb-nav button:disabled { opacity: 0.4; cursor: default; }
      @media (max-width: 639px) {
        .hhkg-toolbar { gap: 4px; padding: 5px 6px; }
        .hhkg-tbtn { min-height: 40px; padding: 0 8px; font-size: 11.5px; gap: 3px; }
        .hhkg-stepbar { padding: 6px 10px; max-height: 146px; overflow-y: auto; }
        .hhkg-sb-nav button { min-height: 40px; padding: 0 10px; }
      }
      .hhkg-cmd-chips { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 8px; }
      .hhkg-cmd-chips .hhkg-chip { flex: none; min-height: 36px; font-size: 11.5px; padding: 4px 9px; white-space: nowrap; }

      .hhkg-body {
        flex: 1 1 auto; min-height: 0; overflow-y: auto; -webkit-overflow-scrolling: touch;
        padding: 12px 12px calc(26px + env(safe-area-inset-bottom));
      }

      .hhkg-notice {
        margin-bottom: 10px; padding: 9px 12px; border-radius: 10px; font-size: 13px; font-weight: 600;
        background: #ECFDF5; border: 1px solid #A7F3D0; color: #065F46; display: flex; align-items: center; justify-content: space-between; gap: 8px;
      }
      .hhkg-notice.warn { background: #FFFBEB; border-color: #FDE68A; color: #92400E; }

      .hhkg-sec-title {
        margin: 14px 0 8px; font-size: 13px; font-weight: 700; color: #17233B;
        display: flex; align-items: center; justify-content: space-between; gap: 8px;
      }
      .hhkg-sec-title:first-child { margin-top: 0; }

      .hhkg-chips { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 8px; }
      .hhkg-chip {
        min-height: 40px; padding: 6px 12px; border: 1.5px solid #D5DDE8; border-radius: 999px;
        background: #F8FAFC; color: #17233B; font-size: 13px; font-weight: 600; cursor: pointer;
      }
      .hhkg-chip.on { background: #243B8F; border-color: #243B8F; color: #fff; }
      .hhkg-chip.sel { background: #FFF7ED; border-color: #EA580C; color: #C2410C; }

      .hhkg-tpl-list { display: flex; flex-direction: column; gap: 8px; }
      .hhkg-tpl {
        width: 100%; text-align: left; padding: 10px 12px; border: 1.5px solid #D5DDE8;
        border-radius: 12px; background: #fff; cursor: pointer; min-height: 44px;
      }
      .hhkg-tpl.on { border-color: #243B8F; background: #F5F8FF; }
      .hhkg-tpl-top { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
      .hhkg-tpl-top b { font-size: 14px; color: #17233B; }
      .hhkg-tpl small { display: block; margin-top: 3px; font-size: 12px; color: #5E6B85; line-height: 1.4; }
      .hhkg-formula {
        margin-top: 6px; padding: 6px 10px; border-radius: 8px; background: #EEF2FF;
        color: #1E3A8A; font-size: 12px; font-weight: 600; font-family: ui-monospace, Menlo, Consolas, monospace;
      }

      .hhkg-card {
        border: 1.5px solid #D5DDE8; border-radius: 12px; padding: 10px 12px;
        background: #FAFBFD; margin-bottom: 10px;
      }
      .hhkg-card.hi { border-color: #FDBA74; background: #FFFBF5; }
      .hhkg-row { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; margin-top: 6px; }
      .hhkg-row label { font-size: 12.5px; font-weight: 600; color: #17233B; }
      .hhkg-inp, .hhkg-ta {
        width: 100%; min-height: 42px; padding: 8px 10px; border: 1.5px solid #D5DDE8;
        border-radius: 10px; background: #fff; font-size: 14px; color: #17233B;
      }
      .hhkg-ta { min-height: 88px; resize: vertical; line-height: 1.45; }
      .hhkg-inp-sm { width: 66px; min-height: 40px; padding: 4px 8px; border: 1.5px solid #D5DDE8; border-radius: 8px; background: #fff; font-size: 14px; }

      .hhkg-btn {
        min-height: 42px; padding: 0 14px; border: 1.5px solid #D5DDE8; border-radius: 10px;
        background: #fff; color: #17233B; font-size: 13.5px; font-weight: 700; cursor: pointer;
        display: inline-flex; align-items: center; justify-content: center; gap: 6px;
      }
      .hhkg-btn.pri { background: #243B8F; border-color: #243B8F; color: #fff; width: 100%; }
      .hhkg-btn.sm { min-height: 40px; padding: 0 10px; font-size: 12.5px; }
      .hhkg-btn:disabled { opacity: 0.55; cursor: default; }

      .hhkg-err {
        margin-top: 10px; padding: 10px 12px; border-radius: 10px;
        background: #FEF2F2; border: 1px solid #FECACA; color: #B91C1C; font-size: 13px; line-height: 1.45;
      }
      .hhkg-ans {
        margin-top: 10px; padding: 10px 12px; border-radius: 12px;
        background: #ECFDF5; border: 1.5px solid #A7F3D0; color: #065F46;
      }
      .hhkg-ans strong { display: block; font-size: 13px; margin-bottom: 2px; }
      .hhkg-ans p { margin: 0; font-size: 14px; font-weight: 700; }

      .hhkg-step {
        width: 100%; text-align: left; padding: 10px 12px; margin-top: 8px; min-height: 44px;
        border: 1.5px solid #D5DDE8; border-radius: 12px; background: #fff; cursor: pointer;
      }
      .hhkg-step.on { border-color: #EA580C; background: #FFF7ED; }
      .hhkg-step-h { display: flex; align-items: center; gap: 6px; font-size: 13.5px; font-weight: 700; color: #17233B; }
      .hhkg-step-n {
        width: 22px; height: 22px; border-radius: 50%; background: #E0E7FF; color: #1E3A8A;
        display: inline-flex; align-items: center; justify-content: center; font-size: 12px; flex: none;
      }
      .hhkg-step.on .hhkg-step-n { background: #EA580C; color: #fff; }
      .hhkg-step p { margin: 5px 0 0; font-size: 13px; color: #334155; line-height: 1.5; }
      .hhkg-step code {
        display: block; margin-top: 6px; padding: 5px 8px; border-radius: 8px;
        background: #F1F5F9; color: #0F172A; font-size: 12.5px; white-space: pre-wrap;
      }

      .hhkg-img-prev {
        display: flex; align-items: center; gap: 8px; margin-top: 8px;
        padding: 6px 8px; border: 1px solid #D5DDE8; border-radius: 10px; background: #F8FAFC;
      }
      .hhkg-img-prev img { width: 44px; height: 44px; object-fit: cover; border-radius: 6px; }
      .hhkg-img-prev span { flex: 1; font-size: 12.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

      .hhkg-slider-row { display: grid; grid-template-columns: 96px 1fr 44px; gap: 8px; align-items: center; margin-top: 6px; font-size: 12.5px; }
      .hhkg-slider-row span { white-space: nowrap; }
      .hhkg-slider-row b { text-align: right; font-variant-numeric: tabular-nums; }
      .hhkg-slider-row input[type=range] { width: 100%; accent-color: #EA580C; min-height: 36px; }

      details.hhkg-det {
        border: 1.5px solid #D5DDE8; border-radius: 12px; padding: 0 12px; background: #FAFBFD; margin-bottom: 10px;
      }
      details.hhkg-det summary {
        min-height: 44px; display: flex; align-items: center; justify-content: space-between;
        font-weight: 700; font-size: 13.5px; color: #243B8F; cursor: pointer;
      }
      details.hhkg-det[open] { padding-bottom: 10px; }
    `;
    D.head.appendChild(style);
  }

  /* ---------- Entry Card Injection in Dobai Home/Start ---------- */
  const ENTRY_HTML = `
    <section class="st-card" id="hhkg-entry">
      <h2>📐 Hình học không gian 11 & 12 <span class="hhkg-badge g11">Trọng tâm Lớp 11</span></h2>
      <p style="margin:0 0 10px;font-size:13px;color:var(--mute);line-height:1.5">
        Vẽ hình chóp, chóp cụt đều, lăng trụ đứng/xiên, góc nhị diện, đoạn vuông góc chung, cắt thiết diện 3D và giải chi tiết từng bước theo GDPT 2018.
      </p>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <button type="button" class="st-btn pri" data-hhkg-open="1" style="flex:1;min-height:44px">📐 Mở Không gian 3D &amp; Giải hình</button>
        <button type="button" class="st-btn" id="hhkg-entry-dl" style="min-height:44px">📦 Tải file + Bàn giao Claude</button>
      </div>
    </section>`;

  const IS_STANDALONE = Boolean(D.getElementById('hhkg-standalone-boot')) || !D.getElementById('app');

  function addEntry() {
    if (IS_STANDALONE) return;
    try {
      const app = $('app');
      if (!app || $('hhkg-entry')) return;
      if (typeof W.V !== 'undefined' && W.V && W.V.view !== 'home' && W.V.view !== 'start') return;
      const anchor = $('o2-entry') || $('tl-entry') || $('uimp-entry');
      if (anchor) {
        anchor.insertAdjacentHTML('beforebegin', ENTRY_HTML);
        return;
      }
      const stGo = app.querySelector('.st-go');
      if (stGo) {
        stGo.insertAdjacentHTML('afterend', ENTRY_HTML);
        return;
      }
      const bkp = app.querySelector('details.bkp') || app.querySelector('.st-ft');
      if (bkp) bkp.insertAdjacentHTML('beforebegin', ENTRY_HTML);
      else app.insertAdjacentHTML('beforeend', ENTRY_HTML);
    } catch (e) {
      console.warn('[HHKG] addEntry', e);
    }
  }

  if (!IS_STANDALONE) {
    ['renderHome', 'renderStart'].forEach((fn) => {
      try {
        const orig = W[fn];
        if (typeof orig !== 'function') return;
        W[fn] = function () {
          const res = orig.apply(this, arguments);
          addEntry();
          return res;
        };
      } catch {}
    });

    try {
      const app = $('app');
      if (app && W.MutationObserver) {
        new MutationObserver(() => addEntry()).observe(app, { childList: true });
      }
    } catch {}
  }

  /* ---------- Bundle ZIP Export (All HHKG files + Claude Handoff) ---------- */
  async function fetchTextSafe(url) {
    try {
      const r = await fetch(url);
      if (!r.ok) return null;
      return await r.text();
    } catch {
      return null;
    }
  }

  async function downloadClaudeHandoffBundle() {
    if (STATE.exportBusy) return;
    STATE.exportBusy = true;
    setNotice('Đang đóng gói toàn bộ mã nguồn 3D & tài liệu bàn giao cho Claude…');
    if (STATE.open) renderBody();

    try {
      // Prefer full server-side ZIP endpoint (includes vendor/three, server.js, tests, handoff docs)
      try {
        const serverResp = await fetch('/api/geometry/export-bundle.zip');
        if (serverResp.ok) {
          const blob = await serverResp.blob();
          triggerBlobDownload(blob, 'hhkg-dobai-claude-handoff.zip');
          setNotice('✓ Đã tải gói đầy đủ hhkg-dobai-claude-handoff.zip (gồm mã 3D, Three.js, tests và file bàn giao cho Claude).');
          return;
        }
      } catch {}

      // Client-side zero-dependency ZIP fallback
      const paths = [
        ['hhkg.html', '/hhkg.html'],
        ['js/hhkg-math.js', '/js/hhkg-math.js'],
        ['js/hhkg-geogebra.js', '/js/hhkg-geogebra.js'],
        ['js/hhkg-3d.js', '/js/hhkg-3d.js'],
        ['js/hhkg-ui.js', '/js/hhkg-ui.js'],
        ['js/hhkg-zip.js', '/js/hhkg-zip.js'],
        ['handoff/BAN_GIAO_HHKG_CHO_CLAUDE.md', '/handoff/BAN_GIAO_HHKG_CHO_CLAUDE.md'],
        ['handoff/CODEMAP_HHKG.md', '/handoff/CODEMAP_HHKG.md'],
        ['handoff/GEOGEBRA-THUAT-TOAN.md', '/handoff/GEOGEBRA-THUAT-TOAN.md'],
        ['handoff/HUONG_DAN_AI_GIAI_CHINH_XAC_HHKG.md', '/handoff/HUONG_DAN_AI_GIAI_CHINH_XAC_HHKG.md'],
        ['handoff/api-worker-geometry-snippet.js', '/handoff/api-worker-geometry-snippet.js'],
        ['handoff/index-patch-snippet.html', '/handoff/index-patch-snippet.html'],
      ];
      const entries = [];
      for (const [zipName, url] of paths) {
        const text = await fetchTextSafe(url);
        if (text != null) entries.push({ name: zipName, content: text });
      }
      if (!entries.length) {
        throw new Error('Không đọc được tệp nguồn từ máy chủ.');
      }
      const zipBytes = createZipBytes(entries);
      triggerBlobDownload(new Blob([zipBytes], { type: 'application/zip' }), 'hhkg-dobai-claude-handoff.zip');
      setNotice(`✓ Đã tạo và tải hhkg-dobai-claude-handoff.zip (${entries.length} tệp).`);
    } catch (err) {
      setNotice(`Chưa tải được gói ZIP: ${err?.message || err}`, 'warn');
    } finally {
      STATE.exportBusy = false;
      if (STATE.open) renderBody();
    }
  }

  function triggerBlobDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = D.createElement('a');
    a.href = url;
    a.download = filename;
    D.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  /* ---------- Overlay Construction ---------- */
  function ensureOverlay() {
    if (STATE.ov && D.body.contains(STATE.ov)) return STATE.ov;
    ensureStyles();

    const ov = D.createElement('div');
    ov.id = 'hhkg-ov';
    ov.hidden = true;
    ov.setAttribute('role', 'dialog');
    ov.setAttribute('aria-modal', 'true');
    ov.setAttribute('aria-label', 'Vẽ và giải Hình học không gian 11, 12');

    ov.innerHTML = `
      <header class="hhkg-top">
        <button type="button" class="hhkg-back" id="hhkg-close">${IS_STANDALONE ? '‹ Về Dobai' : '‹ Quay lại'}</button>
        <div class="hhkg-hd-tt">
          <h2>Hình học không gian 11 &amp; 12</h2>
          <p>Trọng tâm Lớp 11 GDPT 2018 · Vẽ 3D &amp; Giải từng bước</p>
        </div>
        <button type="button" class="hhkg-dl-top" id="hhkg-dl-bundle" title="Tải toàn bộ file Hình học không gian & bàn giao cho Claude">📦 Tải gói</button>
      </header>
      <div class="hhkg-main">
        <section class="hhkg-stage" aria-label="Khung hình học 3D">
          <div id="hhkg-canvas-wrap" data-testid="hhkg-canvas-wrap"></div>
          <div id="hhkg-labels"></div>
          <div class="hhkg-hud-top">
            <div class="hhkg-spec" id="hhkg-spec"></div>
            <div class="hhkg-hud-btns">
              <button type="button" class="hhkg-hud-mini" id="hhkg-expand-btn" title="Mở rộng hoặc thu gọn khung xem hình 3D">⤢ Mở rộng</button>
              <button type="button" class="hhkg-hud-mini" id="hhkg-place-btn" title="Chạm lên mặt phẳng đáy để đặt điểm mới">+ Điểm 3D</button>
              <button type="button" class="hhkg-hud-mini" id="hhkg-axes-btn">Trục</button>
              <button type="button" class="hhkg-hud-mini on" id="hhkg-grid-btn">Lưới</button>
              <button type="button" class="hhkg-hud-mini on" id="hhkg-lbl-mode-btn">Nhãn: ${STATE.labelsMode === 'vertices' ? 'Đỉnh' : 'Đủ'}</button>
              <button type="button" class="hhkg-hud-mini on" id="hhkg-faces-btn">Mặt: Hiện</button>
            </div>
          </div>
          <div class="hhkg-dock-wrap">
            <button type="button" class="hhkg-dock-toggle" id="hhkg-dock-toggle" aria-expanded="true">▾ Ẩn thanh góc nhìn</button>
            <div class="hhkg-dock" id="hhkg-dock">
              <button type="button" data-cam="default">Góc chuẩn</button>
              <button type="button" data-cam="top">Từ trên</button>
              <button type="button" data-cam="front">Mặt trước</button>
              <button type="button" data-cam="side">Mặt bên</button>
              <button type="button" data-cam="oxyz">Oxyz</button>
              <button type="button" id="hhkg-style-btn">Kiểu: Nét đứt</button>
              <button type="button" id="hhkg-rot-btn">Xoay nhẹ</button>
              <button type="button" id="hhkg-png-btn">Tải PNG</button>
            </div>
          </div>
        </section>
        <aside class="hhkg-panel">
          <nav class="hhkg-tabs" role="tablist">
            <button type="button" role="tab" data-tab="templates" class="on">📐 Mẫu &amp; Vẽ</button>
            <button type="button" role="tab" data-tab="algebra">𝑓𝑥 Đại số</button>
            <button type="button" role="tab" data-tab="measure">✂️ Cắt &amp; Đo</button>
            <button type="button" role="tab" data-tab="ai">🤖 AI Giải</button>
          </nav>
          <div class="hhkg-toolbar" id="hhkg-toolbar"></div>
          <div class="hhkg-stepbar" id="hhkg-stepbar" hidden></div>
          <div class="hhkg-body" id="hhkg-body"></div>
        </aside>
      </div>
    `;
    D.body.appendChild(ov);
    STATE.ov = ov;

    STATE.viewer = new Geometry3DViewer($('hhkg-canvas-wrap'), $('hhkg-labels'), {
      onVertexClick: (vid) => handleCanvasVertexPick(vid),
      onPlacePoint: (pt) => handleCanvasPlacePoint(pt),
    });
    STATE.viewer.setLabelsMode(STATE.labelsMode);

    bindOverlayEvents(ov);
    return ov;
  }

  function handleCanvasPlacePoint(pt) {
    pushHistory();
    const next = structuredClone(STATE.scene);
    const id = nextStandardVertexLabel(next.vertices);
    next.vertices.push({ id, x: pt.x, y: pt.y, z: pt.z, role: 'primary', hidden: false });
    STATE.scene = normalizeSceneSpec(next);
    setNotice(`Đã đặt điểm ${id}(${pt.x}; ${pt.y}; ${pt.z}). Chạm tiếp để đặt đỉnh hoặc bấm "Lên chóp S".`);
    syncViewer({ keepCamera: true });
    renderBody();
  }

  function handleCanvasVertexPick(vid) {
    if (STATE.drawMode === 'segment') {
      if (!STATE.pendingSegmentStart) {
        STATE.pendingSegmentStart = vid;
        STATE.selectedVertices = [vid];
        STATE.viewer.setSelectedVertices([vid]);
        setNotice(`Đang nối từ ${vid} — hãy chạm vào đỉnh thứ 2 trên hình.`);
        renderBody();
        return;
      }
      if (STATE.pendingSegmentStart === vid) {
        STATE.pendingSegmentStart = '';
        STATE.selectedVertices = [];
        STATE.viewer.setSelectedVertices([]);
        renderBody();
        return;
      }
      const from = STATE.pendingSegmentStart;
      const to = vid;
      pushHistory();
      const next = structuredClone(STATE.scene);
      next.edges = next.edges.filter((e) => !((e.from === from && e.to === to) || (e.from === to && e.to === from)));
      next.edges.push({ from, to, style: 'solid', label: '' });
      STATE.scene = normalizeSceneSpec(next);
      STATE.pendingSegmentStart = '';
      STATE.selectedVertices = [to];
      STATE.viewer.setSelectedVertices([to]);
      setNotice(`Đã nối cạnh ${from}${to}. Chạm hai đỉnh tiếp theo để nối tiếp.`);
      syncViewer({ keepCamera: true });
      renderBody();
      return;
    }

    const idx = STATE.selectedVertices.indexOf(vid);
    if (idx >= 0) STATE.selectedVertices.splice(idx, 1);
    else {
      STATE.selectedVertices.push(vid);
      if (STATE.selectedVertices.length > 5) STATE.selectedVertices.shift();
    }
    STATE.viewer.setSelectedVertices(STATE.selectedVertices);
    if (STATE.tab === 'templates' || STATE.tab === 'measure' || STATE.tab === 'algebra') renderBody();
  }

  function updateSpecBadge() {
    const box = $('hhkg-spec');
    if (!box) return;
    const vCount = STATE.scene.vertices.length;
    const eCount = STATE.scene.edges.length;
    const vol = polyhedronVolume(STATE.scene);
    const volTxt = vol > 0.01 ? ` · V ≈ ${vol.toFixed(2)}` : '';
    const note = STATE.scene.unitNote ? `<span class="hhkg-unit">${esc(STATE.scene.unitNote)}</span>` : '';
    box.innerHTML = `<strong>${esc(STATE.activeTitle)}</strong><span>${vCount} đỉnh · ${eCount} cạnh${volTxt}${STATE.scene.showOxyz ? ' · Oxyz' : ''}</span>${note}`;
  }

  function syncHudButtons() {
    const axesOn = STATE.showAxes !== null ? STATE.showAxes : Boolean(STATE.scene.showOxyz);
    const axesBtn = $('hhkg-axes-btn');
    if (axesBtn) axesBtn.classList.toggle('on', axesOn);
    const gridBtn = $('hhkg-grid-btn');
    if (gridBtn) gridBtn.classList.toggle('on', STATE.showGrid);
    const placeBtn = $('hhkg-place-btn');
    if (placeBtn) placeBtn.classList.toggle('on', STATE.placePointMode);
    const expBtn = $('hhkg-expand-btn');
    if (expBtn) {
      expBtn.textContent = STATE.stageExpanded ? '⤡ Thu gọn' : '⤢ Mở rộng';
      expBtn.classList.toggle('on', STATE.stageExpanded);
    }
    const lblBtn = $('hhkg-lbl-mode-btn');
    if (lblBtn) {
      const labels = { all: 'Nhãn: Đủ', vertices: 'Nhãn: Đỉnh', none: 'Nhãn: Ẩn' };
      lblBtn.textContent = labels[STATE.labelsMode] || 'Nhãn: Đủ';
      lblBtn.classList.toggle('on', STATE.labelsMode !== 'none');
    }
    if (STATE.ov) {
      STATE.ov.classList.toggle('hhkg-expanded', STATE.stageExpanded);
    }
  }

  function syncViewer(opts = {}) {
    if (!STATE.viewer) return;
    STATE.viewer.setShowAxes(STATE.showAxes);
    STATE.viewer.setShowGrid(STATE.showGrid);
    STATE.viewer.setPlacePlaneZ(STATE.drawPlaneZ);
    STATE.viewer.setPlacePointMode(STATE.placePointMode);
    STATE.viewer.setScene(STATE.scene, opts);
    if (STATE.csEnabled) {
      const cs = computeCrossSection(STATE.scene, STATE.csPlane);
      STATE.viewer.setCrossSection(cs);
    } else {
      STATE.viewer.setCrossSection(null);
    }
    if (STATE.netRatio > 0.01) {
      const net = computePolyhedronNet(STATE.scene, STATE.netRatio);
      STATE.viewer.setPolyhedronNet(net, STATE.netRatio);
    } else {
      STATE.viewer.setPolyhedronNet(null, 0);
    }
    syncHudButtons();
    updateSpecBadge();
  }

  function applyStepHighlight() {
    if (!STATE.viewer) return;
    if (STATE.activeStepIdx < 0 || !STATE.activeSteps[STATE.activeStepIdx]) {
      STATE.viewer.setHighlight({});
      return;
    }
    const st = STATE.activeSteps[STATE.activeStepIdx];
    STATE.viewer.setHighlight({
      vertices: st.highlightVertices || [],
      edges: st.highlightEdges || [],
      faceVertices: st.highlightFaceVertices || [],
    });
  }

  function renderToolbar() {
    const tb = $('hhkg-toolbar');
    if (!tb) return;
    const hasSteps = STATE.activeSteps && STATE.activeSteps.length > 0;
    tb.innerHTML = `
      <button type="button" class="hhkg-tbtn" id="hhkg-undo-btn"${STATE.history.length ? '' : ' disabled'} title="Hoàn tác thao tác vừa rồi">↶ Hoàn tác</button>
      <button type="button" class="hhkg-tbtn" id="hhkg-redo-btn"${STATE.redoStack.length ? '' : ' disabled'} title="Làm lại">↷ Làm lại</button>
      <button type="button" class="hhkg-tbtn" id="hhkg-save-btn">💾 Lưu hình</button>
      ${
        hasSteps
          ? `<button type="button" class="hhkg-tbtn pri" id="hhkg-guide-toggle">${STATE.stepBarOpen ? '✕ Đóng bài giảng' : `📖 Giảng 3D (${STATE.activeSteps.length})`}</button>`
          : ''
      }
      <button type="button" class="hhkg-tbtn" id="hhkg-reset-scene">↺ Đặt lại</button>
    `;
  }

  function renderStepBar() {
    const bar = $('hhkg-stepbar');
    if (!bar) return;
    const steps = STATE.activeSteps || [];
    if (!STATE.stepBarOpen || !steps.length) {
      bar.hidden = true;
      bar.innerHTML = '';
      renderToolbar();
      return;
    }
    if (STATE.activeStepIdx < 0 || STATE.activeStepIdx >= steps.length) {
      STATE.activeStepIdx = 0;
      applyStepHighlight();
    }
    const idx = STATE.activeStepIdx;
    const st = steps[idx];
    bar.hidden = false;
    bar.innerHTML = `
      <div class="hhkg-sb-prog">
        ${steps.map((_, k) => `<i data-sb-goto="${k}" class="${k === idx ? 'on' : k < idx ? 'done' : ''}" title="Bước ${k + 1}"></i>`).join('')}
      </div>
      <div class="hhkg-sb-head">
        <b>Bước ${idx + 1}/${steps.length}: ${esc(st.stepTitle)}</b>
        <button type="button" class="hhkg-btn sm" id="hhkg-sb-close" aria-label="Đóng bài giảng" style="min-height:36px;">✕</button>
      </div>
      <div class="hhkg-sb-body">${esc(st.explanation)}</div>
      ${st.formula ? `<div class="hhkg-sb-formula">${esc(st.formula)}</div>` : ''}
      <div class="hhkg-sb-nav">
        <button type="button" id="hhkg-sb-prev"${idx === 0 ? ' disabled' : ''}>‹ Trước</button>
        <button type="button" id="hhkg-sb-say">${STATE.speaking ? '⏹ Dừng' : '🔊 Đọc'}</button>
        <button type="button" class="pri" id="hhkg-sb-next">${idx === steps.length - 1 ? '↺ Bước 1' : 'Tiếp ›'}</button>
      </div>
    `;
    renderToolbar();
  }

  function renderTabs() {
    if (!STATE.ov) return;
    STATE.ov.querySelectorAll('.hhkg-tabs button').forEach((b) => {
      const on = b.dataset.tab === STATE.tab;
      b.classList.toggle('on', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
  }

  function nextFreeVertexName(prefix = 'M') {
    const used = new Set(STATE.scene.vertices.map((v) => v.id));
    const candidates = [prefix, 'M', 'N', 'K', 'P', 'Q', 'H', 'I', 'E', 'F'];
    for (const c of candidates) {
      if (!used.has(c)) return c;
    }
    for (let i = 1; i < 40; i++) {
      if (!used.has(`${prefix}${i}`)) return `${prefix}${i}`;
    }
    return `X${Date.now() % 100}`;
  }

  function renderQuickSelectionCard() {
    const vList = STATE.scene.vertices;
    const vMap = new Map(vList.map((v) => [v.id, v]));
    const sel = STATE.selectedVertices.filter((id) => vMap.has(id));

    let guideHtml = '';
    if (sel.length === 0) {
      guideHtml = `<p style="margin:6px 0 0;font-size:12.5px;color:#5E6B85;">
        👆 Chạm 1–5 đỉnh trên hình 3D hoặc bấm thẻ tên đỉnh để dựng song song, hạ hình chiếu ⊥, tạo đỉnh thứ 4 hình bình hành, cắt thiết diện hoặc tìm giao điểm AB ∩ (CDE).
      </p>`;
    } else if (sel.length === 1) {
      const p = vMap.get(sel[0]);
      guideHtml = `
        <p style="margin:6px 0;font-size:12.5px;color:#17233B;">Đỉnh <b>${esc(p.id)}</b> (${p.x}; ${p.y}; ${p.z})</p>
        <div class="hhkg-row">
          <button type="button" class="hhkg-btn sm" data-qact="add-s-above">⬆️ Đặt S trên ${esc(p.id)}</button>
          <button type="button" class="hhkg-btn sm" data-qact="slice-horz">✂️ Cắt MP ngang qua ${esc(p.id)}</button>
          <button type="button" class="hhkg-btn sm" data-qact="delete-vertex">🗑 Xóa đỉnh</button>
        </div>`;
    } else if (sel.length === 2) {
      const a = vMap.get(sel[0]), b = vMap.get(sel[1]);
      const d = vecDist(a, b);
      guideHtml = `
        <p style="margin:6px 0;font-size:13px;color:#065F46;">Đoạn <b>${esc(a.id)}${esc(b.id)}</b> = <b>${d.toFixed(3)}</b></p>
        <div class="hhkg-row">
          <button type="button" class="hhkg-btn sm" data-qact="edge-solid">— Nối liền</button>
          <button type="button" class="hhkg-btn sm" data-qact="edge-dashed">┄ Nét đứt</button>
          <button type="button" class="hhkg-btn sm" data-qact="edge-highlight">★ Nổi bật</button>
          <button type="button" class="hhkg-btn sm" data-qact="edge-delete">✕ Xóa cạnh</button>
          <button type="button" class="hhkg-btn sm" data-qact="vector">↗ Véc-tơ</button>
          <button type="button" class="hhkg-btn sm" data-qact="midpoint">• Trung điểm ${esc(nextFreeVertexName('M'))}</button>
          <button type="button" class="hhkg-btn sm" data-qact="ratio-third">1/3 Chia đoạn</button>
          <button type="button" class="hhkg-btn sm" data-qact="slice-perp">✂️ Trung trực</button>
        </div>`;
    } else if (sel.length === 3) {
      const a = vMap.get(sel[0]), b = vMap.get(sel[1]), c = vMap.get(sel[2]);
      const ang = angleBetweenLines(a, b, a, c);
      const area = triangleArea(a, b, c);
      guideHtml = `
        <p style="margin:6px 0;font-size:13px;color:#065F46;">
          <b>∠${esc(b.id)}${esc(a.id)}${esc(c.id)}</b> = <b>${ang.deg.toFixed(1)}°</b> · S<sub>△</sub> = <b>${area.toFixed(3)}</b>
        </p>
        <div class="hhkg-row">
          <button type="button" class="hhkg-btn sm" data-qact="make-face">⬡ Tô mặt (${esc(sel.join(''))})</button>
          <button type="button" class="hhkg-btn sm" data-qact="centroid">◎ Trọng tâm ${esc(nextFreeVertexName('G'))}</button>
          <button type="button" class="hhkg-btn sm" data-qact="parallel-line">⫽ Qua ${esc(a.id)} // ${esc(b.id)}${esc(c.id)}</button>
          <button type="button" class="hhkg-btn sm" data-qact="foot-line">⊥ Chiếu ${esc(a.id)} lên ${esc(b.id)}${esc(c.id)}</button>
          <button type="button" class="hhkg-btn sm" data-qact="parallelogram-4">▱ Đỉnh 4 Hình BH</button>
          <button type="button" class="hhkg-btn sm" data-qact="slice-3pt">✂️ Cắt (${esc(sel.join(''))})</button>
          <button type="button" class="hhkg-btn sm" data-qact="bake-3pt" style="background:#FFF7ED;border-color:#FDBA74;color:#9A3412;">✂️ Cắt &amp; Tạo đỉnh thật</button>
        </div>`;
    } else if (sel.length === 4) {
      const p = vMap.get(sel[0]), a = vMap.get(sel[1]), b = vMap.get(sel[2]), c = vMap.get(sel[3]);
      const pr = projectPointOnPlane(p, a, b, c);
      const lp = angleLinePlane(p, a, a, b, c);
      const skew = commonPerpendicularSegment(p, a, b, c);
      const dih = dihedralAngle(p, a, b, c);
      const lineHit = intersectTwoLines3D(p, a, b, c);
      guideHtml = `
        <div style="margin:6px 0;font-size:12.5px;color:#065F46;line-height:1.5;">
          ${pr.valid ? `<div>• <b>d(${esc(p.id)}, (${esc(a.id)}${esc(b.id)}${esc(c.id)}))</b> = <b>${pr.distance.toFixed(3)}</b> · <b>∠(${esc(p.id)}${esc(a.id)}, mp)</b> = <b>${lp.deg.toFixed(1)}°</b></div>` : ''}
          ${skew.valid ? `<div>• <b>d(${esc(p.id)}${esc(a.id)}, ${esc(b.id)}${esc(c.id)})</b> = <b>${skew.distance.toFixed(3)}</b></div>` : ''}
          ${dih.valid ? `<div>• <b>Nhị diện [${esc(p.id)}, ${esc(a.id)}${esc(b.id)}, ${esc(c.id)}]</b> = <b>${dih.deg.toFixed(1)}°</b></div>` : ''}
        </div>
        <div class="hhkg-row">
          <button type="button" class="hhkg-btn sm" data-qact="drop-proj" style="background:#ECFDF5;border-color:#10B981;color:#065F46;">⊥ Hạ hình chiếu ${esc(p.id)}H</button>
          <button type="button" class="hhkg-btn sm" data-qact="reflect-plane">🪞 Đối xứng qua (${esc(a.id)}${esc(b.id)}${esc(c.id)})</button>
          <button type="button" class="hhkg-btn sm" data-qact="common-perp">📏 Đoạn VG chung</button>
          ${lineHit.valid ? `<button type="button" class="hhkg-btn sm" data-qact="intersect-lines">✕ Giao ${esc(p.id)}${esc(a.id)} ∩ ${esc(b.id)}${esc(c.id)}</button>` : ''}
          <button type="button" class="hhkg-btn sm" data-qact="slice-par">✂️ Cắt // (${esc(a.id)}${esc(b.id)}${esc(c.id)})</button>
          <button type="button" class="hhkg-btn sm" data-qact="bake-par" style="background:#FFF7ED;border-color:#FDBA74;color:#9A3412;">✂️ Cắt // &amp; Tạo đỉnh thật</button>
          <button type="button" class="hhkg-btn sm" data-qact="make-face">⬡ Tô tứ giác</button>
        </div>`;
    } else if (sel.length === 5) {
      const l1 = vMap.get(sel[0]), l2 = vMap.get(sel[1]);
      const p1 = vMap.get(sel[2]), p2 = vMap.get(sel[3]), p3 = vMap.get(sel[4]);
      const hit = intersectLinePlane(l1, l2, p1, p2, p3);
      guideHtml = `
        <p style="margin:6px 0;font-size:12.5px;color:#065F46;">
          Đường thẳng <b>${esc(l1.id)}${esc(l2.id)}</b> &amp; mặt phẳng <b>(${esc(p1.id)}${esc(p2.id)}${esc(p3.id)})</b>
          ${hit.valid ? ` → Giao điểm dự kiến (${hit.point.x.toFixed(2)}; ${hit.point.y.toFixed(2)}; ${hit.point.z.toFixed(2)})` : ` → ${esc(hit.reason || 'Song song')}`}
        </p>
        <div class="hhkg-row">
          <button type="button" class="hhkg-btn sm" data-qact="intersect-line-plane"${hit.valid ? '' : ' disabled'} style="background:#EEF2FF;border-color:#93C5FD;color:#1E3A8A;">
            ✕ Dựng giao điểm ${esc(l1.id)}${esc(l2.id)} ∩ (${esc(p1.id)}${esc(p2.id)}${esc(p3.id)})
          </button>
        </div>`;
    }

    return `
      <div class="hhkg-card hi" id="hhkg-quick-card">
        <div class="hhkg-sec-title" style="margin:0 0 6px;">
          <span>🎯 Thao tác nhanh (chọn 1–5 đỉnh)</span>
          ${sel.length ? `<button type="button" class="hhkg-btn sm" id="hhkg-clear-sel" style="min-height:36px;">Xóa (${sel.length})</button>` : ''}
        </div>
        <div class="hhkg-chips" style="margin-bottom:2px;">
          ${vList
            .map(
              (v) => `<button type="button" class="hhkg-chip${sel.includes(v.id) ? ' sel' : ''}" data-pick-v="${esc(v.id)}">${esc(v.id)}</button>`,
            )
            .join('')}
        </div>
        ${guideHtml}
      </div>
    `;
  }

  function renderWizardCard() {
    const w = STATE.wizard;
    const shapes = [
      ['chop-tu-giac', 'Chóp tứ giác'],
      ['chop-tam-giac', 'Chóp tam giác'],
      ['chop-cut-deu', 'Chóp cụt đều'],
      ['lang-tru-dung', 'Lăng trụ đứng'],
      ['lang-tru-xien', 'Lăng trụ xiên'],
      ['tu-dien-deu', 'Tứ diện đều'],
      ['hinh-hop', 'Hình hộp'],
    ];
    const bases = [
      ['vuong', 'Vuông'],
      ['chu-nhat', 'Chữ nhật'],
      ['deu', 'Đều'],
      ['thang-vuong', 'Thang vuông'],
      ['thoi', 'Thoi'],
    ];
    const feet = [
      ['A', 'SA ⊥ đáy'],
      ['O', 'SO (tâm O)'],
      ['H', 'SH (mặt bên ⊥ đáy)'],
      ['G', 'SG (trọng tâm)'],
    ];
    const showBase = !['chop-cut-deu', 'tu-dien-deu'].includes(w.shape);
    const showFoot = w.shape === 'chop-tu-giac' || w.shape === 'chop-tam-giac';

    return `
      <details class="hhkg-det" id="hhkg-wizard-det"${STATE.wizardOpen ? ' open' : ''}>
        <summary>⚡ Dựng nhanh hình Lớp 11 theo tham số (a, h)<span>${STATE.wizardOpen ? '▾' : '▸'}</span></summary>
        <div style="margin-top:6px;">
          <div style="font-size:12px;font-weight:700;color:#5E6B85;margin-bottom:4px;">1. Chọn khối hình</div>
          <div class="hhkg-chips">
            ${shapes.map(([id, lb]) => `<button type="button" class="hhkg-chip${w.shape === id ? ' on' : ''}" data-wz-shape="${id}">${esc(lb)}</button>`).join('')}
          </div>
          ${
            showBase
              ? `<div style="font-size:12px;font-weight:700;color:#5E6B85;margin-bottom:4px;">2. Loại đáy</div>
                 <div class="hhkg-chips">
                   ${bases.map(([id, lb]) => `<button type="button" class="hhkg-chip${w.base === id ? ' on' : ''}" data-wz-base="${id}">${esc(lb)}</button>`).join('')}
                 </div>`
              : ''
          }
          ${
            showFoot
              ? `<div style="font-size:12px;font-weight:700;color:#5E6B85;margin-bottom:4px;">3. Vị trí chân đường cao</div>
                 <div class="hhkg-chips">
                   ${feet.map(([id, lb]) => `<button type="button" class="hhkg-chip${w.foot === id ? ' on' : ''}" data-wz-foot="${id}">${esc(lb)}</button>`).join('')}
                 </div>`
              : ''
          }
          <div class="hhkg-slider-row">
            <span>Cạnh đáy a</span>
            <input type="range" min="1.6" max="4.4" step="0.2" value="${w.a}" data-wz-num="a" aria-label="Cạnh đáy a">
            <b>${w.a}</b>
          </div>
          <div class="hhkg-slider-row">
            <span>Chiều cao h</span>
            <input type="range" min="1.6" max="4.8" step="0.2" value="${w.h}" data-wz-num="h" aria-label="Chiều cao h">
            <b>${w.h}</b>
          </div>
          <div class="hhkg-row" style="margin-top:8px;">
            <button type="button" class="hhkg-btn pri" id="hhkg-wizard-build">⚡ Dựng khối 3D ngay</button>
          </div>
        </div>
      </details>
    `;
  }

  function renderEasyDrawCard() {
    const vList = STATE.scene.vertices || [];
    const baseCount = vList.filter((v) => !v.hidden && Math.abs(v.z) < 0.25).length;
    const sel = STATE.selectedVertices.filter((id) => vList.some((v) => v.id === id));
    const selBaseId = sel.length === 1 ? sel[0] : '';

    let modeHint = 'Chạm đỉnh để chọn & đo, hoặc kéo trên khung để xoay 360°.';
    if (STATE.drawMode === 'point') {
      modeHint = STATE.drawPlaneZ > 0
        ? `Đang bật Chấm điểm ở độ cao z = ${STATE.drawPlaneZ}: chạm vào khung để đặt đỉnh nổi trên không gian!`
        : 'Đang bật Chấm điểm đáy (z = 0): chạm thẳng lên lưới để đặt các đỉnh A, B, C, D…';
    } else if (STATE.drawMode === 'segment') {
      modeHint = STATE.pendingSegmentStart
        ? `Đang nối từ đỉnh ${STATE.pendingSegmentStart} — chạm vào đỉnh thứ 2 trên hình để nối cạnh!`
        : 'Đang bật Nối cạnh: chạm lần lượt 2 đỉnh bất kỳ trên hình để nối thành cạnh.';
    }

    const stencils = [
      ['tam-giac-deu', '△ Đều'],
      ['vuong', '▢ Vuông'],
      ['binh-hanh', '▱ Bình hành'],
      ['hinh-thang', '⏢ Thang'],
      ['ngu-giac', '⬠ Ngũ giác'],
    ];
    const zLevels = [0, 1, 2, 3];

    return `
      <div class="hhkg-card" style="background:#F0F9FF;border-color:#BAE6FD;" id="hhkg-easy-draw-card">
        <div class="hhkg-sec-title" style="margin:0 0 6px;">
          <span>✏️ Tự vẽ hình 3D chuẩn GeoGebra</span>
          <button type="button" class="hhkg-btn sm" id="hhkg-draw-blank" style="min-height:34px;">🧹 Khung trống</button>
        </div>
        <div class="hhkg-chips" style="margin-bottom:6px;">
          <button type="button" class="hhkg-chip${STATE.drawMode === 'orbit' ? ' on' : ''}" data-draw-mode="orbit">👆 Xoay / Chọn</button>
          <button type="button" class="hhkg-chip${STATE.drawMode === 'point' ? ' on' : ''}" data-draw-mode="point">📍 Chấm điểm 3D</button>
          <button type="button" class="hhkg-chip${STATE.drawMode === 'segment' ? ' on' : ''}" data-draw-mode="segment">📏 Nối cạnh</button>
        </div>
        <div class="hhkg-row" style="margin-top:4px;">
          <span style="font-size:11.5px;font-weight:700;color:#0369A1;">Cao độ z:</span>
          ${zLevels.map((zVal) => `<button type="button" class="hhkg-chip${STATE.drawPlaneZ === zVal && STATE.drawMode === 'point' ? ' on' : ''}" data-draw-z="${zVal}" style="min-height:32px;padding:2px 9px;font-size:12px;">z=${zVal}</button>`).join('')}
        </div>
        <div class="hhkg-row" style="margin-top:6px;">
          <span style="font-size:11.5px;font-weight:700;color:#0369A1;">Đặt đáy nhanh:</span>
          ${stencils.map(([id, lb]) => `<button type="button" class="hhkg-btn sm" data-stencil="${id}" style="min-height:32px;padding:0 8px;font-size:12px;">${esc(lb)}</button>`).join('')}
        </div>
        <p style="margin:6px 0;font-size:12px;color:#0369A1;line-height:1.4;">${esc(modeHint)}</p>
        <div class="hhkg-row">
          <label style="font-size:12px;">Cao h:</label>
          <input type="number" id="hhkg-draw-h" class="hhkg-inp-sm" min="1" max="6" step="0.5" value="${STATE.drawHeight}" style="width:58px;min-height:36px;" aria-label="Chiều cao tự dựng">
          <button type="button" class="hhkg-btn sm" id="hhkg-draw-pyr"${baseCount < 3 ? ' disabled' : ''}>🔺 Lên chóp S</button>
          <button type="button" class="hhkg-btn sm" id="hhkg-draw-prism"${baseCount < 3 ? ' disabled' : ''}>▭ Lên lăng trụ</button>
          ${selBaseId ? `<button type="button" class="hhkg-btn sm" id="hhkg-draw-above">⬆️ Đỉnh S trên ${esc(selBaseId)}</button>` : ''}
        </div>
      </div>
    `;
  }

  function renderTemplatesTab() {
    const grades = [
      { id: 'Lớp 11', label: 'Tất cả Lớp 11' },
      { id: 'Lớp 11 · Song song', label: 'Song song (HK1 KNTT)' },
      { id: 'Lớp 11 · Vuông góc', label: 'Vuông góc (HK2)' },
      { id: 'Lớp 12', label: 'Lớp 12 (Oxyz)' },
      { id: 'all', label: 'Tất cả' },
    ];
    const filtered = TEMPLATES.filter((t) => {
      if (STATE.gradeFilter === 'all') return true;
      if (STATE.gradeFilter === 'Lớp 11 · Song song') return t.grade.includes('11') && t.chapter === 'song-song';
      if (STATE.gradeFilter === 'Lớp 11 · Vuông góc') return t.grade.includes('11') && t.chapter !== 'song-song';
      return t.grade.includes(STATE.gradeFilter.replace('Lớp ', ''));
    });
    const vList = STATE.scene.vertices;
    const v0 = vList[0]?.id || '';
    const v1 = vList[1]?.id || v0;

    return `
      ${renderEasyDrawCard()}
      ${renderQuickSelectionCard()}
      ${renderWizardCard()}

      <div class="hhkg-sec-title">
        <span>Mẫu chuẩn SGK Lớp 11 &amp; 12</span>
        <label style="font-weight:600;font-size:12.5px;display:flex;align-items:center;gap:5px;cursor:pointer;">
          <input type="checkbox" id="hhkg-toggle-oxyz"${STATE.scene.showOxyz ? ' checked' : ''}> Hệ Oxyz
        </label>
      </div>
      <div class="hhkg-chips">
        ${grades.map((g) => `<button type="button" class="hhkg-chip${STATE.gradeFilter === g.id ? ' on' : ''}" data-grade="${esc(g.id)}">${esc(g.label)}</button>`).join('')}
      </div>
      <div class="hhkg-tpl-list">
        ${filtered
          .map(
            (t) => `
          <button type="button" class="hhkg-tpl${STATE.activeTemplateId === t.id ? ' on' : ''}" data-tpl="${esc(t.id)}">
            <div class="hhkg-tpl-top">
              <b>${esc(t.name)}</b>
              <span class="hhkg-badge${t.grade === 'Lớp 11' ? ' g11' : ''}">${esc(t.chapter === 'song-song' ? 'HK1 · Song song' : t.grade)}</span>
            </div>
            <small>${esc(t.subtitle)}</small>
            ${
              STATE.activeTemplateId === t.id
                ? `<div class="hhkg-formula">${esc(t.formula)}</div>`
                : ''
            }
          </button>`,
          )
          .join('')}
      </div>

      <details class="hhkg-det" style="margin-top:12px;">
        <summary>➕ Thêm đỉnh tọa độ (x, y, z) &amp; Chia tỉ lệ k<span>▸</span></summary>
        <div class="hhkg-row" style="margin-top:6px;">
          <input type="text" id="hhkg-v-id" class="hhkg-inp-sm" placeholder="Tên" value="${esc(nextFreeVertexName('N'))}" maxlength="5" aria-label="Tên đỉnh">
          <input type="number" step="0.2" id="hhkg-v-x" class="hhkg-inp-sm" value="0" aria-label="Tọa độ x">
          <input type="number" step="0.2" id="hhkg-v-y" class="hhkg-inp-sm" value="0" aria-label="Tọa độ y">
          <input type="number" step="0.2" id="hhkg-v-z" class="hhkg-inp-sm" value="1.5" aria-label="Tọa độ z">
          <button type="button" class="hhkg-btn sm" id="hhkg-add-vertex">+ Thêm đỉnh</button>
        </div>
        <div class="hhkg-row" style="margin-top:8px;">
          <label style="font-size:12px;">Chia đoạn:</label>
          <select id="hhkg-r-a" class="hhkg-inp-sm" style="flex:1;width:auto;" aria-label="Đỉnh đầu">
            ${vList.map((v) => `<option value="${esc(v.id)}"${v.id === v0 ? ' selected' : ''}>${esc(v.id)}</option>`).join('')}
          </select>
          <select id="hhkg-r-b" class="hhkg-inp-sm" style="flex:1;width:auto;" aria-label="Đỉnh cuối">
            ${vList.map((v) => `<option value="${esc(v.id)}"${v.id === v1 ? ' selected' : ''}>${esc(v.id)}</option>`).join('')}
          </select>
          <input type="number" step="0.1" id="hhkg-r-k" class="hhkg-inp-sm" value="0.33" aria-label="Tỉ số k">
          <button type="button" class="hhkg-btn sm" id="hhkg-add-ratio">+ Tỉ lệ k</button>
        </div>
      </details>

      <div class="hhkg-sec-title" style="margin-top:12px;">
        <span>📚 Hình đã lưu trên máy (${STATE.savedList.length})</span>
      </div>
      ${
        STATE.savedList.length
          ? `<div class="hhkg-tpl-list">
              ${STATE.savedList
                .map(
                  (item, idx) => `
                <div class="hhkg-card" style="margin-bottom:0;display:flex;align-items:center;gap:8px;">
                  <div style="flex:1;min-width:0;">
                    <b style="font-size:13.5px;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${esc(item.title)}</b>
                    <small style="color:#5E6B85;">${esc(item.savedAt || '')}</small>
                  </div>
                  <button type="button" class="hhkg-btn sm" data-load-saved="${idx}">Mở</button>
                  <button type="button" class="hhkg-btn sm" data-del-saved="${idx}" aria-label="Xóa ${esc(item.title)}">🗑</button>
                </div>`,
                )
                .join('')}
            </div>`
          : '<p style="margin:0 0 10px;font-size:12.5px;color:#5E6B85;">Bấm <b>💾 Lưu hình</b> ở thanh công cụ phía trên để lưu hình bài tập (đồng bộ cùng tài khoản web).</p>'
      }

      <div class="hhkg-card" style="margin-top:12px;background:#F5F8FF;border-color:#B7C9F6;">
        <b style="font-size:13.5px;color:#1E3A8A;">📦 Tải toàn bộ mã nguồn 3D &amp; File bàn giao cho Claude</b>
        <p style="margin:4px 0 8px;font-size:12.5px;color:#334155;line-height:1.45;">
          Xuất gói <code>.zip</code> chứa đầy đủ <b>hhkg-math.js, hhkg-3d.js, hhkg-ui.js, hhkg-zip.js, server.js, thư viện Three.js, bộ test</b> và tài liệu <b>BAN_GIAO_HHKG_CHO_CLAUDE.md</b> để Claude kiểm tra và ghép vào web hoàn chỉnh.
        </p>
        <button type="button" class="hhkg-btn pri" id="hhkg-dl-bundle-card"${STATE.exportBusy ? ' disabled' : ''}>
          ${STATE.exportBusy ? '⏳ Đang đóng gói ZIP…' : '📦 Tải toàn bộ file & Bàn giao cho Claude (.zip)'}
        </button>
      </div>
    `;
  }

  function renderAiTab() {
    const res = STATE.aiResult;
    let resultHtml = '';
    if (res) {
      const stepsHtml = (res.steps || [])
        .map(
          (st, idx) => `
          <button type="button" class="hhkg-step${STATE.activeStepIdx === idx ? ' on' : ''}" data-ai-step="${idx}">
            <div class="hhkg-step-h"><span class="hhkg-step-n">${idx + 1}</span><span>${esc(st.stepTitle)}</span></div>
            <p>${esc(st.explanation)}</p>
            ${st.formula ? `<code>${esc(st.formula)}</code>` : ''}
          </button>`,
        )
        .join('');

      const followHtml = STATE.aiFollowups
        .map(
          (f) => `
          <div class="hhkg-card" style="margin-top:8px;background:#F8FAFC;">
            <b style="font-size:12.5px;color:#243B8F;">Hỏi: ${esc(f.q)}</b>
            <p style="margin:4px 0 0;font-size:13px;line-height:1.5;color:#17233B;">${esc(f.a)}</p>
          </div>`,
        )
        .join('');

      const mc = res.mathCheck;
      const verifyHtml = (mc || res.verificationNote)
        ? `<div class="hhkg-card" style="margin-top:8px;background:#ECFDF5;border-color:#6EE7B7;">
            <b style="font-size:12.5px;color:#065F46;">✓ Đã kiểm chứng hình học bằng nhân GeoGebra 3D</b>
            ${
              mc
                ? `<div style="margin-top:3px;font-size:12px;color:#047857;">
                    ${mc.vertexCount} đỉnh · ${mc.edgeCount} cạnh${mc.volume > 0 ? ` · V ≈ ${mc.volume}` : ''}${mc.totalConstructions ? ` · Dựng chính xác ${mc.verifiedConstructions}/${mc.totalConstructions} lệnh phụ` : ''}
                   </div>`
                : ''
            }
            ${
              mc && Array.isArray(mc.checks) && mc.checks.length
                ? `<div style="margin-top:4px;font-size:12px;color:#065F46;">${mc.checks.map((c) => `<div>${esc(c)}</div>`).join('')}</div>`
                : ''
            }
            ${res.verificationNote ? `<p style="margin:4px 0 0;font-size:12px;color:#065F46;line-height:1.4;">${esc(res.verificationNote)}</p>` : ''}
          </div>`
        : '';

      resultHtml = `
        <div class="hhkg-card" style="margin-top:12px;background:#fff;">
          <div class="hhkg-tpl-top">
            <b style="font-size:15px;">${esc(res.title)}</b>
            <span class="hhkg-badge${res.grade === 'Lớp 11' ? ' g11' : ''}">${esc(res.grade || 'Lớp 11')}</span>
          </div>
          <small style="display:block;margin-top:4px;color:#5E6B85;">Chuyên đề: <b>${esc(res.topic || 'Hình học không gian')}</b></small>
          <p style="margin:6px 0 0;font-size:13.5px;line-height:1.5;">${esc(res.summary || '')}</p>
          ${res.visualTips ? `<p style="margin:6px 0 0;padding:7px 10px;border-radius:8px;background:#FFFBEB;color:#92400E;font-size:12.5px;">💡 <b>Gợi ý quan sát 3D:</b> ${esc(res.visualTips)}</p>` : ''}
          ${verifyHtml}
          <div class="hhkg-ans">
            <strong>✓ Kết quả / Công thức chính</strong>
            <p>${esc(res.finalAnswer)}</p>
          </div>
        </div>
        <div class="hhkg-sec-title">
          <span>Lời giải từng bước (bấm để sáng trên hình 3D)</span>
          ${STATE.activeStepIdx >= 0 ? `<button type="button" class="hhkg-btn sm" id="hhkg-clear-step">Xem toàn hình</button>` : ''}
        </div>
        ${stepsHtml}
        <div class="hhkg-sec-title" style="margin-top:16px;"><span>Hỏi thêm AI về hình này</span></div>
        ${followHtml}
        <div class="hhkg-row">
          <input type="text" class="hhkg-inp" id="hhkg-follow-inp" placeholder="Ví dụ: Vẽ thêm trung điểm N của SC, hoặc tìm giao điểm MN ∩ (SBD)...">
          <button type="button" class="hhkg-btn" id="hhkg-follow-btn" style="width:100%;"${STATE.aiBusy ? ' disabled' : ''}>Gửi câu hỏi thêm</button>
        </div>
      `;
    }

    const aiTemplates = [
      {
        label: 'Mẫu 1 · Tìm giao điểm (Bài 10)',
        text: 'Cho hình chóp S.ABCD có đáy ABCD là hình bình hành tâm O, AB = 2a, AD = a. Gọi M là trung điểm SC, N trên cạnh SD sao cho SN = 2ND. Tìm giao điểm của đường thẳng BN và mặt phẳng (SAC), chứng minh theo chuẩn SGK KNTT Lớp 11.',
      },
      {
        label: 'Mẫu 2 · Cắt thiết diện // (Bài 12)',
        text: 'Cho hình chóp S.ABCD có đáy ABCD là hình vuông cạnh a, SA ⊥ (ABCD) và SA = a√2. Gọi M là trung điểm AB. Xác định thiết diện của hình chóp khi cắt bởi mặt phẳng (P) đi qua M và song song với (SBC), tính diện tích thiết diện theo a.',
      },
      {
        label: 'Mẫu 3 · Góc nhị diện & Khoảng cách',
        text: 'Cho hình chóp S.ABCD có đáy ABCD là hình chữ nhật AB = a, AD = a√3, SA ⊥ (ABCD) và SA = a. Tính góc nhị diện [S, BC, A] và khoảng cách từ A đến mặt phẳng (SBD).',
      },
    ];

    return `
      <details class="hhkg-det" id="hhkg-ai-guide"${STATE.aiGuideOpen ? ' open' : ''} style="margin-bottom:10px;background:#F5F8FF;border-color:#B7C9F6;">
        <summary>📘 Hướng dẫn giúp AI vẽ hình &amp; giải chính xác<span>${STATE.aiGuideOpen ? '▾' : '▸'}</span></summary>
        <div style="margin-top:8px;font-size:12.5px;color:#1E293B;line-height:1.5;">
          <p style="margin:0 0 6px;"><b>4 nguyên tắc vàng khi nhập đề bài (Toán 11 KNTT):</b></p>
          <ul style="margin:0 0 8px;padding-left:18px;">
            <li><b>Nêu rõ khối &amp; đáy:</b> ví dụ <i>"Chóp S.ABCD đáy hình bình hành"</i> hoặc <i>"Lăng trụ đứng ABC.A'B'C'"</i>.</li>
            <li><b>Nêu rõ đường cao:</b> ví dụ <i>"SA ⊥ (ABCD)"</i>, <i>"SO ⊥ đáy"</i> hoặc <i>"mặt bên (SAB) đều ⊥ (ABCD)"</i>.</li>
            <li><b>Nêu rõ tỉ lệ điểm phụ:</b> ví dụ <i>"M trung điểm SC"</i>, <i>"SM = 2MC"</i> để nhân GeoGebra dựng tọa độ chuẩn tuyệt đối.</li>
            <li><b>Kiểm chứng tự động:</b> AI xuất lệnh GeoGebra (<code>Midpoint</code>, <code>ParallelLine</code>, <code>FootOnLine</code>, <code>CrossSectionParallel</code>) để máy tự tính tọa độ, kiểm tra góc 90° và gạch nét đứt đúng khuất.</li>
          </ul>
          <p style="margin:0 0 4px;"><b>Bấm để chèn khung đề chuẩn:</b></p>
          <div class="hhkg-chips" style="margin-bottom:2px;">
            ${aiTemplates.map((tp) => `<button type="button" class="hhkg-chip" data-ai-tpl="${esc(tp.text)}" style="min-height:34px;font-size:12px;">${esc(tp.label)}</button>`).join('')}
          </div>
        </div>
      </details>

      <div class="hhkg-sec-title"><span>Nhập hoặc chụp đề bài (Ưu tiên Lớp 11 KNTT)</span></div>
      <div class="hhkg-chips">
        ${SAMPLE_PROBLEMS.map((p, i) => `<button type="button" class="hhkg-chip" data-sample="${i}">${esc(p.label)}</button>`).join('')}
      </div>
      <textarea class="hhkg-ta" id="hhkg-ai-prompt" placeholder="Dán đề bài Toán 11 hoặc 12 (ví dụ: Cho hình chóp S.ABCD đáy vuông cạnh a, SA ⊥ đáy...)">${esc(STATE.aiPromptText)}</textarea>
      <div class="hhkg-row" style="margin-top:8px;">
        <label class="hhkg-btn sm" style="flex:1;cursor:pointer;">
          📷 Đính kèm ảnh đề bài
          <input type="file" id="hhkg-ai-file" accept="image/*" hidden>
        </label>
      </div>
      ${
        STATE.aiImageName
          ? `<div class="hhkg-img-prev"><img src="${STATE.aiImageBase64}" alt="Ảnh đề bài"><span>${esc(STATE.aiImageName)}</span><button type="button" class="hhkg-btn sm" id="hhkg-ai-rmimg">✕</button></div>`
          : ''
      }
      <div class="hhkg-row" style="margin-top:10px;">
        <button type="button" class="hhkg-btn pri" id="hhkg-ai-solve"${STATE.aiBusy ? ' disabled' : ''}>
          ${STATE.aiBusy ? '⏳ AI đang dựng hình 3D và giải bài…' : '✨ AI Vẽ hình & Giải chi tiết'}
        </button>
        <button type="button" class="hhkg-btn" id="hhkg-offline-solve" style="width:100%;background:#F8FAFC;">
          ⚡ Dựng &amp; Giải nhanh trên máy (Offline Lớp 11)
        </button>
      </div>
      ${
        STATE.aiError
          ? `<div class="hhkg-err" role="alert">
              ${esc(STATE.aiError)}
              ${
                STATE.aiErrorNeedsFallback
                  ? `<div style="margin-top:8px;"><button type="button" class="hhkg-btn sm" id="hhkg-offline-solve-err">⚡ Dùng bộ dựng nhanh Lớp 11 ngay</button></div>`
                  : ''
              }
            </div>`
          : ''
      }
      ${resultHtml}
    `;
  }

  function renderAlgebraTab() {
    const sc = STATE.scene;
    const vMap = new Map(sc.vertices.map((v) => [v.id, v]));

    const objRows = [];
    sc.vertices.forEach((v, idx) => {
      objRows.push(`
        <div class="hhkg-card" style="margin-bottom:6px;padding:7px 10px;display:flex;align-items:center;gap:8px;">
          <button type="button" class="hhkg-btn sm" data-alg-eye="vertex:${idx}" aria-label="${v.hidden ? 'Hiện' : 'Ẩn'} điểm ${esc(v.id)}" style="min-height:36px;padding:0 8px;">${v.hidden ? '🚫' : '👁️'}</button>
          <div style="flex:1;min-width:0;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12.5px;">
            <b style="color:#1E3A8A;">${esc(v.id)}</b> = (${v.x}; ${v.y}; ${v.z})
          </div>
          <button type="button" class="hhkg-btn sm" data-pick-v="${esc(v.id)}" style="min-height:36px;">Chọn</button>
          <button type="button" class="hhkg-btn sm" data-alg-del="vertex:${idx}" aria-label="Xóa ${esc(v.id)}" style="min-height:36px;">✕</button>
        </div>
      `);
    });

    sc.edges.forEach((e, idx) => {
      const a = vMap.get(e.from), b = vMap.get(e.to);
      const len = a && b ? vecDist(a, b).toFixed(3) : '—';
      objRows.push(`
        <div class="hhkg-card" style="margin-bottom:6px;padding:7px 10px;display:flex;align-items:center;gap:8px;">
          <button type="button" class="hhkg-btn sm" data-alg-eye="edge:${idx}" aria-label="${e.hidden ? 'Hiện' : 'Ẩn'} đoạn ${esc(e.from + e.to)}" style="min-height:36px;padding:0 8px;">${e.hidden ? '🚫' : '👁️'}</button>
          <div style="flex:1;min-width:0;font-size:12.5px;">
            <b>Đoạn ${esc(e.from)}${esc(e.to)}</b> = ${len} <small style="color:#5E6B85;">(${esc(e.style)})</small>
          </div>
          <button type="button" class="hhkg-btn sm" data-alg-del="edge:${idx}" aria-label="Xóa đoạn ${esc(e.from + e.to)}" style="min-height:36px;">✕</button>
        </div>
      `);
    });

    (sc.vectors || []).forEach((vc, idx) => {
      const a = vMap.get(vc.from), b = vMap.get(vc.to);
      const d = a && b ? vecSub(b, a) : { x: 0, y: 0, z: 0 };
      objRows.push(`
        <div class="hhkg-card" style="margin-bottom:6px;padding:7px 10px;display:flex;align-items:center;gap:8px;">
          <button type="button" class="hhkg-btn sm" data-alg-eye="vector:${idx}" style="min-height:36px;padding:0 8px;">${vc.hidden ? '🚫' : '👁️'}</button>
          <div style="flex:1;min-width:0;font-size:12.5px;color:#6D28D9;">
            <b>→${esc(vc.from + vc.to)}</b> = (${d.x.toFixed(2)}; ${d.y.toFixed(2)}; ${d.z.toFixed(2)})
          </div>
          <button type="button" class="hhkg-btn sm" data-alg-del="vector:${idx}" style="min-height:36px;">✕</button>
        </div>
      `);
    });

    sc.faces.forEach((f, idx) => {
      objRows.push(`
        <div class="hhkg-card" style="margin-bottom:6px;padding:7px 10px;display:flex;align-items:center;gap:8px;">
          <button type="button" class="hhkg-btn sm" data-alg-eye="face:${idx}" style="min-height:36px;padding:0 8px;">${f.hidden ? '🚫' : '👁️'}</button>
          <div style="flex:1;min-width:0;font-size:12.5px;">
            <b>Đa giác (${esc(f.vertices.join(''))})</b>
          </div>
          <button type="button" class="hhkg-btn sm" data-alg-del="face:${idx}" style="min-height:36px;">✕</button>
        </div>
      `);
    });

    (sc.spheres || []).forEach((s, idx) => {
      objRows.push(`
        <div class="hhkg-card" style="margin-bottom:6px;padding:7px 10px;display:flex;align-items:center;gap:8px;">
          <button type="button" class="hhkg-btn sm" data-alg-eye="sphere:${idx}" style="min-height:36px;padding:0 8px;">${s.hidden ? '🚫' : '👁️'}</button>
          <div style="flex:1;min-width:0;font-size:12.5px;">
            <b>Mặt cầu ${esc(s.label || '')}</b> · R = ${s.radius}
          </div>
          <button type="button" class="hhkg-btn sm" data-alg-del="sphere:${idx}" style="min-height:36px;">✕</button>
        </div>
      `);
    });

    (sc.planes || []).forEach((pl, idx) => {
      objRows.push(`
        <div class="hhkg-card" style="margin-bottom:6px;padding:7px 10px;display:flex;align-items:center;gap:8px;">
          <button type="button" class="hhkg-btn sm" data-alg-eye="plane:${idx}" style="min-height:36px;padding:0 8px;">${pl.hidden ? '🚫' : '👁️'}</button>
          <div style="flex:1;min-width:0;font-size:12.5px;">
            <b>Mặt phẳng ${esc(pl.label || '(P)')}</b> · ${pl.nx}x + ${pl.ny}y + ${pl.nz}z = ${pl.d}
          </div>
          <button type="button" class="hhkg-btn sm" data-alg-del="plane:${idx}" style="min-height:36px;">✕</button>
        </div>
      `);
    });

    (sc.circles || []).forEach((c, idx) => {
      objRows.push(`
        <div class="hhkg-card" style="margin-bottom:6px;padding:7px 10px;display:flex;align-items:center;gap:8px;">
          <button type="button" class="hhkg-btn sm" data-alg-eye="circle:${idx}" style="min-height:36px;padding:0 8px;">${c.hidden ? '🚫' : '👁️'}</button>
          <div style="flex:1;min-width:0;font-size:12.5px;color:#C2410C;">
            <b>Đường tròn ${esc(c.label || '')}</b> · r = ${Number(c.radius).toFixed(2)}
          </div>
          <button type="button" class="hhkg-btn sm" data-alg-del="circle:${idx}" style="min-height:36px;">✕</button>
        </div>
      `);
    });

    (sc.surfaces || []).forEach((sf, idx) => {
      objRows.push(`
        <div class="hhkg-card" style="margin-bottom:6px;padding:7px 10px;display:flex;align-items:center;gap:8px;">
          <button type="button" class="hhkg-btn sm" data-alg-eye="surface:${idx}" style="min-height:36px;padding:0 8px;">${sf.hidden ? '🚫' : '👁️'}</button>
          <div style="flex:1;min-width:0;font-size:12.5px;font-family:ui-monospace,Menlo,Consolas,monospace;">
            <b>${esc(sf.label)}</b>
          </div>
          <button type="button" class="hhkg-btn sm" data-alg-del="surface:${idx}" style="min-height:36px;">✕</button>
        </div>
      `);
    });

    return `
      <div class="hhkg-sec-title">
        <span>𝑓𝑥 Thanh nhập lệnh GeoGebra 3D</span>
      </div>
      <div class="hhkg-card" style="background:#F5F8FF;border-color:#B7C9F6;">
        <div class="hhkg-row" style="margin-top:0;">
          <input type="text" class="hhkg-inp" id="hhkg-cmd-inp" style="flex:1;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:13.5px;" placeholder="Ví dụ: M = (1,0,2), Midpoint(S,C), z = x^2 - y^2" value="${esc(STATE.cmdText)}" aria-label="Thanh lệnh GeoGebra">
          <button type="button" class="hhkg-btn pri" id="hhkg-cmd-run" style="width:auto;min-width:74px;">Chạy ↵</button>
        </div>
        <div class="hhkg-cmd-chips">
          ${GEOGEBRA_QUICK_COMMANDS.map((q) => `<button type="button" class="hhkg-chip" data-cmd-fill="${esc(q.cmd)}">${esc(q.label)}</button>`).join('')}
        </div>
      </div>

      ${
        STATE.cmdHistory.length
          ? `<div class="hhkg-card" style="padding:8px 10px;">
              <b style="font-size:12px;color:#5E6B85;">Lịch sử lệnh gần đây</b>
              ${STATE.cmdHistory
                .slice(0, 4)
                .map(
                  (item) => `<div style="margin-top:4px;font-size:12px;color:${item.ok ? '#065F46' : '#B91C1C'};">
                    <code>${esc(item.cmd)}</code> → ${esc(item.msg)}
                  </div>`,
                )
                .join('')}
            </div>`
          : ''
      }

      <div class="hhkg-sec-title">
        <span>Danh sách đối tượng (Algebra View · ${objRows.length})</span>
      </div>
      <div>${objRows.join('')}</div>
    `;
  }

  function renderCsReadoutHtml(cs) {
    if (!STATE.csEnabled) {
      return '<p style="margin:8px 0 0;font-size:12.5px;color:#5E6B85;">Bật mặt cắt hoặc bấm mẫu cắt nhanh để xem đa giác thiết diện trực tiếp trên hình 3D.</p>';
    }
    if (cs && cs.valid) {
      return `<div class="hhkg-ans" style="margin-top:8px;">
        <strong>Thiết diện: ${esc(cs.shapeName)} (${cs.points.length} đỉnh)</strong>
        <p style="font-size:13px;font-weight:600;">Diện tích ≈ ${cs.area.toFixed(3)} đvdt · Chu vi ≈ ${cs.perimeter.toFixed(3)}</p>
        <small style="display:block;margin-top:3px;font-size:12px;">Cắt qua các cạnh: ${cs.points.map((p) => esc(p.onEdge)).join(' → ')}</small>
      </div>`;
    }
    return '<p style="margin:8px 0 0;font-size:12.5px;color:#B45309;">Mặt phẳng hiện chưa cắt qua khối đa diện (kéo thanh d hoặc đổi hướng).</p>';
  }

  function renderMeasureTab() {
    const cs = STATE.csEnabled ? computeCrossSection(STATE.scene, STATE.csPlane) : null;
    const vol = polyhedronVolume(STATE.scene);
    const net = STATE.netRatio > 0.01 ? computePolyhedronNet(STATE.scene, STATE.netRatio) : null;

    return `
      <div class="hhkg-card" style="background:#EFF6FF;border-color:#BFDBFE;">
        <b style="font-size:13.5px;color:#1E3A8A;">📦 Chỉ số khối đa diện hiện tại</b>
        <p style="margin:4px 0 0;font-size:13px;color:#1E293B;">
          Thể tích ước tính trên hình: <b>V ≈ ${vol > 0 ? vol.toFixed(3) : '0.000'} đvtt</b> ·
          ${STATE.scene.vertices.length} đỉnh · ${STATE.scene.edges.length} cạnh · ${STATE.scene.faces.length} mặt
        </p>
      </div>

      <div class="hhkg-sec-title">
        <span>📐 Khai triển đa diện 3D ↔ 2D (GeoGebra Net)</span>
        <b id="hhkg-net-pct-top" style="color:#EA580C;">${Math.round(STATE.netRatio * 100)}%</b>
      </div>
      <div class="hhkg-card">
        <div class="hhkg-slider-row" style="grid-template-columns:86px 1fr 44px;margin-top:0;">
          <span>Mở phẳng</span>
          <input type="range" min="0" max="1" step="0.05" value="${STATE.netRatio}" id="hhkg-net-slider" aria-label="Độ mở khai triển đa diện">
          <b id="hhkg-net-pct">${Math.round(STATE.netRatio * 100)}%</b>
        </div>
        <div class="hhkg-row">
          <button type="button" class="hhkg-btn sm" data-net-set="0">Đóng 3D (0%)</button>
          <button type="button" class="hhkg-btn sm" data-net-set="0.5">Mở nửa (50%)</button>
          <button type="button" class="hhkg-btn sm" data-net-set="1">Trải phẳng (100%)</button>
        </div>
        <div id="hhkg-net-readout">
          ${
            net && net.valid
              ? `<p style="margin:6px 0 0;font-size:12.5px;color:#065F46;">Diện tích toàn phần khai triển: <b>S<sub>tp</sub> ≈ ${net.totalArea.toFixed(3)} đvdt</b> (${net.faces.length} mặt)</p>`
              : ''
          }
        </div>
      </div>

      <div class="hhkg-sec-title">
        <span>✂️ Cắt thiết diện bằng mặt phẳng (P)</span>
        <label style="font-weight:700;font-size:12.5px;display:flex;align-items:center;gap:5px;cursor:pointer;">
          <input type="checkbox" id="hhkg-cs-on"${STATE.csEnabled ? ' checked' : ''}> Bật mặt cắt
        </label>
      </div>
      <div class="hhkg-card">
        <div class="hhkg-chips" style="margin-bottom:6px;">
          <button type="button" class="hhkg-chip" data-csp="0,0,1,1.3">Song song đáy</button>
          <button type="button" class="hhkg-chip" data-csp="1,1,1,1.3">Lục giác (x+y+z)</button>
          <button type="button" class="hhkg-chip" data-csp="1,0,1,1.5">Nghiêng (x+z)</button>
        </div>
        <div class="hhkg-slider-row">
          <span>Pháp tuyến x</span>
          <input type="range" min="-2" max="2" step="0.25" value="${STATE.csPlane.nx}" data-cs-k="nx" aria-label="Pháp tuyến x">
          <b>${STATE.csPlane.nx}</b>
        </div>
        <div class="hhkg-slider-row">
          <span>Pháp tuyến y</span>
          <input type="range" min="-2" max="2" step="0.25" value="${STATE.csPlane.ny}" data-cs-k="ny" aria-label="Pháp tuyến y">
          <b>${STATE.csPlane.ny}</b>
        </div>
        <div class="hhkg-slider-row">
          <span>Pháp tuyến z</span>
          <input type="range" min="-2" max="2" step="0.25" value="${STATE.csPlane.nz}" data-cs-k="nz" aria-label="Pháp tuyến z">
          <b>${STATE.csPlane.nz}</b>
        </div>
        <div class="hhkg-slider-row">
          <span>Độ dịch d</span>
          <input type="range" min="-3" max="4" step="0.1" value="${STATE.csPlane.d}" data-cs-k="d" aria-label="Độ dịch d">
          <b>${STATE.csPlane.d}</b>
        </div>
        <div id="hhkg-cs-readout">${renderCsReadoutHtml(cs)}</div>
      </div>

      ${renderQuickSelectionCard()}
    `;
  }

  function renderBody() {
    const body = $('hhkg-body');
    if (!body) return;
    renderTabs();
    renderToolbar();
    renderStepBar();
    const noticeHtml = STATE.noticeMsg
      ? `<div class="hhkg-notice${STATE.noticeKind === 'warn' ? ' warn' : ''}" role="status">
          <span>${esc(STATE.noticeMsg)}</span>
          <button type="button" class="hhkg-btn sm" id="hhkg-close-notice" style="min-height:32px;padding:0 8px;">✕</button>
        </div>`
      : '';

    if (STATE.tab === 'templates') body.innerHTML = noticeHtml + renderTemplatesTab();
    else if (STATE.tab === 'algebra') body.innerHTML = noticeHtml + renderAlgebraTab();
    else if (STATE.tab === 'ai') body.innerHTML = noticeHtml + renderAiTab();
    else body.innerHTML = noticeHtml + renderMeasureTab();
  }

  function loadTemplate(tplId) {
    const tpl = TEMPLATES.find((t) => t.id === tplId);
    if (!tpl) return;
    pushHistory();
    stopSpeech();
    STATE.activeTemplateId = tpl.id;
    STATE.activeTitle = tpl.name;
    STATE.activeFormula = tpl.formula;
    STATE.activeSteps = structuredClone(tpl.steps || []);
    STATE.activeStepIdx = STATE.activeSteps.length ? 0 : -1;
    STATE.stepBarOpen = W.innerWidth >= 900 && STATE.activeSteps.length > 0;
    STATE.scene = structuredClone(tpl.scene);
    STATE.netRatio = 0;
    STATE.csEnabled = false;
    STATE.noticeMsg = '';
    STATE.selectedVertices = [];
    STATE.viewer.setSelectedVertices([]);
    applyStepHighlight();
    syncViewer();
    renderBody();
  }

  function runQuickAction(act) {
    const vMap = new Map(STATE.scene.vertices.map((v) => [v.id, v]));
    const sel = STATE.selectedVertices.filter((id) => vMap.has(id));
    if (!sel.length) return;

    if (act === 'slice-horz') {
      const p = vMap.get(sel[0]);
      STATE.csPlane = { nx: 0, ny: 0, nz: 1, d: Math.round(p.z * 100) / 100 };
      STATE.csEnabled = true;
      syncViewer({ keepCamera: true });
      setNotice(`Đã cắt mặt phẳng ngang qua ${p.id} (z = ${STATE.csPlane.d}).`);
      renderBody();
      return;
    }

    if (act === 'slice-perp' && sel.length >= 2) {
      const a = vMap.get(sel[0]), b = vMap.get(sel[1]);
      const mid = midpoint(a, b);
      const pl = planePerpToLine(mid, a, b);
      if (pl.valid) {
        STATE.csPlane = { nx: pl.nx, ny: pl.ny, nz: pl.nz, d: pl.d };
        STATE.csEnabled = true;
        syncViewer({ keepCamera: true });
        setNotice(`Đã dựng mặt phẳng trung trực đoạn ${a.id}${b.id}.`);
        renderBody();
      }
      return;
    }

    if (act === 'slice-3pt' && sel.length >= 3) {
      const a = vMap.get(sel[0]), b = vMap.get(sel[1]), c = vMap.get(sel[2]);
      const pl = planeFrom3Points(a, b, c);
      if (pl.valid) {
        const pn = planeFromPointAndNormal(a, pl.normal);
        STATE.csPlane = { nx: pn.nx, ny: pn.ny, nz: pn.nz, d: pn.d };
        STATE.csEnabled = true;
        syncViewer({ keepCamera: true });
        setNotice(`Đã cắt theo mặt phẳng (${a.id}${b.id}${c.id}).`);
        renderBody();
      }
      return;
    }

    if (act === 'slice-par' && sel.length === 4) {
      const p = vMap.get(sel[0]), a = vMap.get(sel[1]), b = vMap.get(sel[2]), c = vMap.get(sel[3]);
      const pn = planeParallelToPlane(p, a, b, c);
      if (pn.valid) {
        STATE.csPlane = { nx: pn.nx, ny: pn.ny, nz: pn.nz, d: pn.d };
        STATE.csEnabled = true;
        syncViewer({ keepCamera: true });
        setNotice(`Đã cắt qua ${p.id} song song với (${a.id}${b.id}${c.id}).`);
        renderBody();
      }
      return;
    }

    pushHistory();
    const next = structuredClone(STATE.scene);

    if (act === 'delete-vertex' && sel.length >= 1) {
      const delId = sel[0];
      next.vertices = next.vertices.filter((v) => v.id !== delId);
      next.edges = next.edges.filter((e) => e.from !== delId && e.to !== delId);
      next.faces = next.faces.filter((f) => !(f.vertices || []).includes(delId));
      next.vectors = (next.vectors || []).filter((vc) => vc.from !== delId && vc.to !== delId);
      next.rightAngles = (next.rightAngles || []).filter((r) => r.vertex !== delId && r.p1 !== delId && r.p2 !== delId);
      STATE.selectedVertices = STATE.selectedVertices.filter((x) => x !== delId);
      STATE.viewer.setSelectedVertices(STATE.selectedVertices);
      setNotice(`Đã xóa đỉnh ${delId} và các cạnh liên quan.`);
    } else if (act === 'add-s-above' && sel.length >= 1) {
      const baseV = vMap.get(sel[0]);
      const sId = next.vertices.some((v) => v.id === 'S') ? nextStandardVertexLabel(next.vertices) : 'S';
      const hVal = Math.max(1, Math.min(6, Number(STATE.drawHeight) || 3));
      next.vertices.push({ id: sId, x: baseV.x, y: baseV.y, z: baseV.z + hVal, role: 'primary' });
      next.edges.push({ from: sId, to: baseV.id, style: 'altitude', label: `h=${hVal}` });
      setNotice(`Đã đặt ${sId} thẳng đứng phía trên ${baseV.id} (cao h = ${hVal}).`);
    } else if ((act === 'edge-solid' || act === 'edge-dashed' || act === 'edge-highlight') && sel.length >= 2) {
      const style = act === 'edge-solid' ? 'solid' : act === 'edge-dashed' ? 'dashed' : 'highlight';
      const from = sel[0], to = sel[1];
      next.edges = next.edges.filter((e) => !((e.from === from && e.to === to) || (e.from === to && e.to === from)));
      next.edges.push({ from, to, style, label: '' });
      setNotice(`Đã nối ${from}${to} (${style === 'solid' ? 'nét liền' : style === 'dashed' ? 'nét đứt' : 'nổi bật'}).`);
    } else if (act === 'edge-delete' && sel.length >= 2) {
      const from = sel[0], to = sel[1];
      next.edges = next.edges.filter((e) => !((e.from === from && e.to === to) || (e.from === to && e.to === from)));
      setNotice(`Đã xóa cạnh ${from}${to}.`);
    } else if (act === 'vector' && sel.length >= 2) {
      const from = sel[0], to = sel[1];
      next.vectors = next.vectors || [];
      if (!next.vectors.some((vc) => vc.from === from && vc.to === to)) {
        next.vectors.push({ from, to, label: `${from}${to}`, color: '#7C3AED' });
      }
      setNotice(`Đã dựng véc-tơ →${from}${to}.`);
    } else if (act === 'midpoint' && sel.length >= 2) {
      const a = vMap.get(sel[0]), b = vMap.get(sel[1]);
      const name = nextFreeVertexName('M');
      const m = midpoint(a, b);
      next.vertices.push({ id: name, x: m.x, y: m.y, z: m.z, role: 'aux' });
      setNotice(`Đã dựng trung điểm ${name} của ${a.id}${b.id}.`);
    } else if (act === 'ratio-third' && sel.length >= 2) {
      const a = vMap.get(sel[0]), b = vMap.get(sel[1]);
      const name = nextFreeVertexName('K');
      const pt = lerpPoint(a, b, 1 / 3);
      next.vertices.push({ id: name, x: pt.x, y: pt.y, z: pt.z, role: 'aux' });
      setNotice(`Đã dựng ${name} chia ${a.id}${b.id} theo tỉ số 1/3.`);
    } else if (act === 'parallel-line' && sel.length >= 3) {
      const a = vMap.get(sel[0]), b = vMap.get(sel[1]), c = vMap.get(sel[2]);
      const qName = nextFreeVertexName('Q');
      const pt = parallelPointThrough(a, b, c, 1);
      next.vertices.push({ id: qName, x: pt.x, y: pt.y, z: pt.z, role: 'aux' });
      next.edges.push({ from: a.id, to: qName, style: 'highlight', label: `// ${b.id}${c.id}` });
      setNotice(`Đã dựng ${a.id}${qName} qua ${a.id} song song với ${b.id}${c.id}.`);
    } else if (act === 'foot-line' && sel.length >= 3) {
      const a = vMap.get(sel[0]), b = vMap.get(sel[1]), c = vMap.get(sel[2]);
      const pr = projectPointOnLine(a, b, c);
      if (pr.valid) {
        const hName = nextFreeVertexName('H');
        next.vertices.push({ id: hName, x: pr.point.x, y: pr.point.y, z: pr.point.z, role: 'projection' });
        next.edges.push({ from: a.id, to: hName, style: 'altitude', label: `d=${pr.distance.toFixed(2)}` });
        next.rightAngles.push({ vertex: hName, p1: a.id, p2: b.id });
        setNotice(`Đã hạ hình chiếu ${hName} của ${a.id} ⊥ ${b.id}${c.id}, d ≈ ${pr.distance.toFixed(3)}.`);
      }
    } else if (act === 'parallelogram-4' && sel.length >= 3) {
      const a = vMap.get(sel[0]), b = vMap.get(sel[1]), c = vMap.get(sel[2]);
      const dName = nextFreeVertexName('D');
      const pt = parallelogram4thVertex(a, b, c);
      next.vertices.push({ id: dName, x: pt.x, y: pt.y, z: pt.z, role: 'primary' });
      const ensureEdge = (u, w) => {
        if (!next.edges.some((e) => (e.from === u && e.to === w) || (e.from === w && e.to === u))) {
          next.edges.push({ from: u, to: w, style: 'solid', label: '' });
        }
      };
      ensureEdge(a.id, b.id);
      ensureEdge(b.id, c.id);
      ensureEdge(c.id, dName);
      ensureEdge(dName, a.id);
      next.faces.push({ vertices: [a.id, b.id, c.id, dName], color: '#3B82F6', opacity: 0.16 });
      setNotice(`Đã dựng đỉnh ${dName} hoàn chỉnh hình bình hành ${a.id}${b.id}${c.id}${dName}.`);
    } else if (act === 'bake-3pt' && sel.length >= 3) {
      const a = vMap.get(sel[0]), b = vMap.get(sel[1]), c = vMap.get(sel[2]);
      const pl = planeFrom3Points(a, b, c);
      if (pl.valid) {
        const pn = planeFromPointAndNormal(a, pl.normal);
        const baked = bakeCrossSectionVertices(next, pn, 'E');
        if (baked.ok) {
          STATE.csPlane = { nx: pn.nx, ny: pn.ny, nz: pn.nz, d: pn.d };
          STATE.csEnabled = true;
          STATE.scene = baked.scene;
          setNotice(baked.message);
          syncViewer({ keepCamera: true });
          renderBody();
          return;
        }
        setNotice(baked.message, 'warn');
      }
    } else if (act === 'bake-par' && sel.length === 4) {
      const p = vMap.get(sel[0]), a = vMap.get(sel[1]), b = vMap.get(sel[2]), c = vMap.get(sel[3]);
      const pn = planeParallelToPlane(p, a, b, c);
      if (pn.valid) {
        const baked = bakeCrossSectionVertices(next, pn, 'E');
        if (baked.ok) {
          STATE.csPlane = { nx: pn.nx, ny: pn.ny, nz: pn.nz, d: pn.d };
          STATE.csEnabled = true;
          STATE.scene = baked.scene;
          setNotice(baked.message);
          syncViewer({ keepCamera: true });
          renderBody();
          return;
        }
        setNotice(baked.message, 'warn');
      }
    } else if (act === 'intersect-lines' && sel.length >= 4) {
      const p = vMap.get(sel[0]), a = vMap.get(sel[1]), b = vMap.get(sel[2]), c = vMap.get(sel[3]);
      const hit = intersectTwoLines3D(p, a, b, c);
      if (hit.valid) {
        const iName = nextFreeVertexName('I');
        next.vertices.push({ id: iName, x: hit.point.x, y: hit.point.y, z: hit.point.z, role: 'projection' });
        if (!hit.onSegmentAB) next.edges.push({ from: a.id, to: iName, style: 'dashed', label: '' });
        if (!hit.onSegmentCD) next.edges.push({ from: c.id, to: iName, style: 'dashed', label: '' });
        setNotice(`Đã dựng giao điểm ${iName} = ${p.id}${a.id} ∩ ${b.id}${c.id}.`);
      } else {
        setNotice(hit.reason || 'Hai đường thẳng không cắt nhau.', 'warn');
      }
    } else if (act === 'intersect-line-plane' && sel.length >= 5) {
      const l1 = vMap.get(sel[0]), l2 = vMap.get(sel[1]);
      const p1 = vMap.get(sel[2]), p2 = vMap.get(sel[3]), p3 = vMap.get(sel[4]);
      const hit = intersectLinePlane(l1, l2, p1, p2, p3);
      if (hit.valid) {
        const iName = nextFreeVertexName('I');
        next.vertices.push({ id: iName, x: hit.point.x, y: hit.point.y, z: hit.point.z, role: 'projection' });
        next.edges.push({ from: l1.id, to: iName, style: 'highlight', label: '' });
        setNotice(`Đã dựng giao điểm ${iName} = ${l1.id}${l2.id} ∩ (${p1.id}${p2.id}${p3.id}).`);
      } else {
        setNotice(hit.reason || 'Đường thẳng song song mặt phẳng.', 'warn');
      }
    } else if (act === 'centroid' && sel.length >= 3) {
      const pts = sel.slice(0, 3).map((id) => vMap.get(id));
      const name = nextFreeVertexName('G');
      const g = centroid(pts);
      next.vertices.push({ id: name, x: g.x, y: g.y, z: g.z, role: 'center' });
      setNotice(`Đã dựng trọng tâm ${name} của △${sel.slice(0, 3).join('')}.`);
    } else if (act === 'make-face' && sel.length >= 3) {
      next.faces.push({ vertices: [...sel], color: '#F59E0B', opacity: 0.25, internal: true });
      setNotice(`Đã tô mặt phẳng (${sel.join('')}).`);
    } else if (act === 'drop-proj' && sel.length === 4) {
      const p = vMap.get(sel[0]), a = vMap.get(sel[1]), b = vMap.get(sel[2]), c = vMap.get(sel[3]);
      const pr = projectPointOnPlane(p, a, b, c);
      if (pr.valid) {
        const hName = nextFreeVertexName('H');
        next.vertices.push({ id: hName, x: pr.point.x, y: pr.point.y, z: pr.point.z, role: 'projection' });
        next.edges.push({ from: p.id, to: hName, style: 'altitude', label: `d=${pr.distance.toFixed(2)}` });
        next.rightAngles.push({ vertex: hName, p1: p.id, p2: a.id });
        setNotice(`Đã dựng hình chiếu ${hName} của ${p.id} ⊥ (${a.id}${b.id}${c.id}), d ≈ ${pr.distance.toFixed(3)}.`);
      }
    } else if (act === 'reflect-plane' && sel.length === 4) {
      const p = vMap.get(sel[0]), a = vMap.get(sel[1]), b = vMap.get(sel[2]), c = vMap.get(sel[3]);
      const rf = reflectPointAcrossPlane(p, a, b, c);
      if (rf.valid) {
        const rName = nextFreeVertexName(`${p.id}'`);
        next.vertices.push({ id: rName, x: rf.point.x, y: rf.point.y, z: rf.point.z, role: 'aux' });
        next.edges.push({ from: p.id, to: rName, style: 'dashed', label: '' });
        setNotice(`Đã lấy đối xứng ${rName} của ${p.id} qua (${a.id}${b.id}${c.id}).`);
      }
    } else if (act === 'common-perp' && sel.length === 4) {
      const p = vMap.get(sel[0]), a = vMap.get(sel[1]), b = vMap.get(sel[2]), c = vMap.get(sel[3]);
      const res = commonPerpendicularSegment(p, a, b, c);
      if (res.valid) {
        const mName = nextFreeVertexName('M');
        next.vertices.push({ id: mName, x: res.p1.x, y: res.p1.y, z: res.p1.z, role: 'aux' });
        const usedTmp = new Set(next.vertices.map((x) => x.id));
        const nName = usedTmp.has('N') ? nextFreeVertexName('K') : 'N';
        next.vertices.push({ id: nName, x: res.p2.x, y: res.p2.y, z: res.p2.z, role: 'aux' });
        next.edges.push({ from: mName, to: nName, style: 'highlight', label: `d=${res.distance.toFixed(2)}` });
        next.rightAngles.push({ vertex: mName, p1: nName, p2: p.id });
        next.rightAngles.push({ vertex: nName, p1: mName, p2: b.id });
        setNotice(`Đã vẽ đoạn vuông góc chung ${mName}${nName} của ${p.id}${a.id} & ${b.id}${c.id} = ${res.distance.toFixed(3)}.`);
      }
    }

    STATE.scene = normalizeSceneSpec(next);
    syncViewer({ keepCamera: true });
    renderBody();
  }

  function runGeoCmd(explicitCmd) {
    const inp = $('hhkg-cmd-inp');
    const cmd = (explicitCmd != null ? explicitCmd : (inp ? inp.value : STATE.cmdText)).trim();
    if (!cmd) return;
    const res = executeGeoGebraCommand(cmd, STATE.scene);
    STATE.cmdHistory.unshift({ cmd, ok: res.ok, msg: res.message });
    if (STATE.cmdHistory.length > 15) STATE.cmdHistory.pop();

    if (!res.ok) {
      STATE.cmdText = cmd;
      setNotice(res.message, 'warn');
      renderBody();
      return;
    }

    if (res.scene) {
      pushHistory();
      STATE.scene = normalizeSceneSpec(res.scene);
    }
    if (res.replaceSolid || res.title) {
      stopSpeech();
      STATE.activeTemplateId = '';
      STATE.activeTitle = res.title || 'Hình không gian 3D';
      STATE.activeFormula = res.formula || '';
      STATE.activeSteps = [];
      STATE.activeStepIdx = -1;
      STATE.stepBarOpen = false;
      if (!res.crossPlane) STATE.csEnabled = false;
      if (typeof res.netRatio !== 'number') STATE.netRatio = 0;
      STATE.selectedVertices = [];
      if (STATE.viewer) STATE.viewer.setSelectedVertices([]);
      applyStepHighlight();
    }
    if (res.crossPlane) {
      STATE.csPlane = res.crossPlane;
      STATE.csEnabled = true;
    }
    if (typeof res.netRatio === 'number') {
      STATE.netRatio = Math.max(0, Math.min(1, res.netRatio));
    }
    STATE.cmdText = '';
    setNotice(res.message);
    syncViewer({ keepCamera: !res.replaceSolid });
    renderBody();
  }

  async function runAiSolve() {
    const promptEl = $('hhkg-ai-prompt');
    const txt = (promptEl ? promptEl.value : STATE.aiPromptText || '').trim();
    STATE.aiPromptText = txt;
    if (!txt && !STATE.aiImageBase64) {
      STATE.aiError = 'Vui lòng nhập đề bài hoặc đính kèm ảnh đề bài hình học không gian.';
      STATE.aiErrorNeedsFallback = false;
      renderBody();
      return;
    }
    STATE.aiBusy = true;
    STATE.aiError = '';
    STATE.aiErrorNeedsFallback = false;
    renderBody();

    try {
      const resp = await fetch('/api/geometry/solve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'solve',
          problemText: txt,
          imageBase64: STATE.aiImageBase64 || undefined,
          imageMimeType: STATE.aiImageMime || undefined,
        }),
      });
      const json = await resp.json().catch(() => ({}));
      if (!resp.ok || !json.ok || !json.data) {
        STATE.aiErrorNeedsFallback = resp.status === 503;
        throw new Error(json.error || `Lỗi máy chủ (${resp.status})`);
      }
      applySolvedResult(json.data);
    } catch (err) {
      STATE.aiError = err?.message || 'Không thể kết nối AI lúc này.';
    } finally {
      STATE.aiBusy = false;
      renderBody();
      if ($('hhkg-ai-prompt') && txt) $('hhkg-ai-prompt').value = txt;
    }
  }

  function runOfflineSolve() {
    const promptEl = $('hhkg-ai-prompt');
    const txt = (promptEl ? promptEl.value : STATE.aiPromptText || '').trim();
    STATE.aiPromptText = txt;
    const data = solveGrade11Offline(txt);
    STATE.aiError = '';
    STATE.aiErrorNeedsFallback = false;
    applySolvedResult(data);
    setNotice('Đã dựng hình & giải nhanh theo chuẩn Lớp 11 ngay trên máy (chế độ Offline).');
    renderBody();
  }

  function applySolvedResult(data) {
    pushHistory();
    stopSpeech();
    const payload = data && !data.isOfflineFallback && !data.mathCheck ? refineAiGeometryPayload(data) : data;
    STATE.aiResult = payload;
    STATE.aiFollowups = [];
    STATE.activeTemplateId = '';
    STATE.activeTitle = payload.title || 'Bài toán Hình học 3D';
    STATE.activeFormula = payload.finalAnswer || '';
    STATE.activeSteps = Array.isArray(payload.steps) ? payload.steps : [];
    STATE.activeStepIdx = STATE.activeSteps.length ? 0 : -1;
    STATE.stepBarOpen = STATE.activeSteps.length > 0;
    STATE.scene = normalizeSceneSpec(payload.scene);
    STATE.netRatio = 0;
    STATE.selectedVertices = [];
    STATE.viewer.setSelectedVertices([]);
    applyStepHighlight();
    syncViewer();
  }

  async function runAiFollowup() {
    const inp = $('hhkg-follow-inp');
    const q = (inp ? inp.value : '').trim();
    if (!q || STATE.aiBusy) return;
    STATE.aiBusy = true;
    STATE.aiError = '';
    renderBody();

    try {
      const resp = await fetch('/api/geometry/solve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'followup',
          question: q,
          currentScene: STATE.scene,
        }),
      });
      const json = await resp.json().catch(() => ({}));
      if (!resp.ok || !json.ok || !json.data) {
        throw new Error(json.error || `Lỗi máy chủ (${resp.status})`);
      }
      const d = json.data;
      STATE.aiFollowups.push({ q, a: d.answer || '' });
      if (d.updatedScene) {
        pushHistory();
        let next = structuredClone(STATE.scene);
        if (Array.isArray(d.updatedScene.addVertices)) {
          for (const v of d.updatedScene.addVertices) {
            if (!next.vertices.some((x) => x.id === v.id)) next.vertices.push(v);
          }
        }
        if (Array.isArray(d.updatedScene.addEdges)) {
          next.edges.push(...d.updatedScene.addEdges);
        }
        if (Array.isArray(d.updatedScene.addFaces)) {
          next.faces.push(...d.updatedScene.addFaces);
        }
        if (Array.isArray(d.updatedScene.addRightAngles)) {
          next.rightAngles.push(...d.updatedScene.addRightAngles);
        }
        if (Array.isArray(d.updatedScene.addConstructions)) {
          for (const cmd of d.updatedScene.addConstructions) {
            const r = executeGeoGebraCommand(String(cmd || ''), next);
            if (r.ok && r.scene) next = r.scene;
          }
        }
        STATE.scene = normalizeSceneSpec(next);
        syncViewer({ keepCamera: true });
      }
      if (d.highlightVertices || d.highlightEdges) {
        STATE.viewer.setHighlight({
          vertices: d.highlightVertices || [],
          edges: d.highlightEdges || [],
        });
      }
    } catch (err) {
      STATE.aiError = err?.message || 'Không gửi được câu hỏi thêm.';
    } finally {
      STATE.aiBusy = false;
      renderBody();
    }
  }

  function saveCurrentFigure() {
    const nowStr = new Date().toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });
    const entry = {
      id: `hhkg-${Date.now()}`,
      title: STATE.activeTitle || 'Hình không gian 3D',
      formula: STATE.activeFormula || '',
      savedAt: nowStr,
      scene: structuredClone(STATE.scene),
      steps: structuredClone(STATE.activeSteps || []),
    };
    STATE.savedList.unshift(entry);
    STATE.savedList = STATE.savedList.slice(0, 25);
    persistSavedList(STATE.savedList);
    setNotice(`Đã lưu "${entry.title}" vào bộ nhớ máy.`);
    renderBody();
  }

  function bindOverlayEvents(ov) {
    ov.addEventListener('click', (e) => {
      const t = e.target;
      if (t.closest('#hhkg-close')) { closeStudio(); return; }
      if (t.closest('#hhkg-dl-bundle') || t.closest('#hhkg-dl-bundle-card')) {
        downloadClaudeHandoffBundle();
        return;
      }
      if (t.closest('#hhkg-close-notice')) {
        STATE.noticeMsg = '';
        renderBody();
        return;
      }

      const tabBtn = t.closest('.hhkg-tabs button');
      if (tabBtn) {
        STATE.tab = tabBtn.dataset.tab;
        if (STATE.stageExpanded) {
          STATE.stageExpanded = false;
          syncHudButtons();
          requestAnimationFrame(() => STATE.viewer && STATE.viewer.resize());
        }
        renderBody();
        return;
      }

      if (t.closest('#hhkg-expand-btn')) {
        STATE.stageExpanded = !STATE.stageExpanded;
        syncHudButtons();
        if (STATE.viewer) {
          STATE.viewer.resize();
          requestAnimationFrame(() => STATE.viewer && STATE.viewer.resize());
        }
        return;
      }

      if (t.closest('#hhkg-undo-btn')) { undoScene(); return; }
      if (t.closest('#hhkg-redo-btn')) { redoScene(); return; }
      if (t.closest('#hhkg-save-btn')) { saveCurrentFigure(); return; }
      if (t.closest('#hhkg-guide-toggle')) {
        STATE.stepBarOpen = !STATE.stepBarOpen;
        if (STATE.stepBarOpen && STATE.activeStepIdx < 0 && STATE.activeSteps.length) STATE.activeStepIdx = 0;
        if (!STATE.stepBarOpen) {
          stopSpeech();
          STATE.viewer.setHighlight({});
        } else {
          applyStepHighlight();
        }
        renderStepBar();
        return;
      }

      if (t.closest('#hhkg-sb-close')) {
        STATE.stepBarOpen = false;
        stopSpeech();
        STATE.viewer.setHighlight({});
        renderStepBar();
        return;
      }
      if (t.closest('#hhkg-sb-prev') && STATE.activeStepIdx > 0) {
        stopSpeech();
        STATE.activeStepIdx--;
        applyStepHighlight();
        renderStepBar();
        if (STATE.tab === 'ai') renderBody();
        return;
      }
      if (t.closest('#hhkg-sb-next') && STATE.activeSteps.length) {
        stopSpeech();
        STATE.activeStepIdx = (STATE.activeStepIdx + 1) % STATE.activeSteps.length;
        applyStepHighlight();
        renderStepBar();
        if (STATE.tab === 'ai') renderBody();
        return;
      }
      if (t.closest('#hhkg-sb-say')) {
        if (STATE.speaking) {
          stopSpeech();
          renderStepBar();
        } else {
          const st = STATE.activeSteps[STATE.activeStepIdx];
          if (st) speakText(`${st.stepTitle}. ${st.explanation}`);
        }
        return;
      }
      const sbGoto = t.closest('[data-sb-goto]');
      if (sbGoto) {
        stopSpeech();
        STATE.activeStepIdx = Number(sbGoto.dataset.sbGoto);
        applyStepHighlight();
        renderStepBar();
        if (STATE.tab === 'ai') renderBody();
        return;
      }

      const camBtn = t.closest('[data-cam]');
      if (camBtn) {
        STATE.viewer.setCameraPreset(camBtn.dataset.cam);
        return;
      }

      if (t.closest('#hhkg-lbl-mode-btn')) {
        const order = ['all', 'vertices', 'none'];
        const labels = { all: 'Nhãn: Đủ', vertices: 'Nhãn: Đỉnh', none: 'Nhãn: Ẩn' };
        STATE.labelsMode = order[(order.indexOf(STATE.labelsMode) + 1) % order.length];
        const btn = t.closest('#hhkg-lbl-mode-btn');
        btn.textContent = labels[STATE.labelsMode];
        btn.classList.toggle('on', STATE.labelsMode !== 'none');
        STATE.viewer.setLabelsMode(STATE.labelsMode);
        return;
      }

      if (t.closest('#hhkg-faces-btn')) {
        STATE.showFaces = !STATE.showFaces;
        const btn = t.closest('#hhkg-faces-btn');
        btn.textContent = STATE.showFaces ? 'Mặt: Hiện' : 'Mặt: Ẩn';
        btn.classList.toggle('on', STATE.showFaces);
        STATE.viewer.setShowFaces(STATE.showFaces);
        return;
      }

      if (t.closest('#hhkg-dock-toggle')) {
        STATE.dockCollapsed = !STATE.dockCollapsed;
        applyDockVisibility();
        return;
      }

      if (t.closest('#hhkg-style-btn')) {
        const order = ['textbook-3d', 'solid', 'wireframe'];
        const labels = { 'textbook-3d': 'Kiểu: Nét đứt', solid: 'Kiểu: Khối đặc', wireframe: 'Kiểu: Khung dây' };
        STATE.viewStyle = order[(order.indexOf(STATE.viewStyle) + 1) % order.length];
        t.closest('#hhkg-style-btn').textContent = labels[STATE.viewStyle];
        STATE.viewer.setViewStyle(STATE.viewStyle);
        return;
      }

      if (t.closest('#hhkg-rot-btn')) {
        STATE.autoRotate = !STATE.autoRotate;
        t.closest('#hhkg-rot-btn').classList.toggle('on', STATE.autoRotate);
        STATE.viewer.setAutoRotate(STATE.autoRotate);
        return;
      }

      if (t.closest('#hhkg-png-btn')) {
        const url = STATE.viewer.exportPngDataUrl();
        const a = D.createElement('a');
        a.href = url;
        a.download = `hinh-hoc-3d-${Date.now()}.png`;
        D.body.appendChild(a);
        a.click();
        a.remove();
        return;
      }

      const gradeBtn = t.closest('[data-grade]');
      if (gradeBtn) {
        STATE.gradeFilter = gradeBtn.dataset.grade;
        renderBody();
        return;
      }

      const tplBtn = t.closest('[data-tpl]');
      if (tplBtn) {
        loadTemplate(tplBtn.dataset.tpl);
        return;
      }

      if (t.closest('#hhkg-reset-scene')) {
        loadTemplate(STATE.activeTemplateId || TEMPLATES[0].id);
        return;
      }

      const pickV = t.closest('[data-pick-v]');
      if (pickV) {
        handleCanvasVertexPick(pickV.dataset.pickV);
        return;
      }

      if (t.closest('#hhkg-clear-sel')) {
        STATE.selectedVertices = [];
        STATE.viewer.setSelectedVertices([]);
        renderBody();
        return;
      }

      const qActBtn = t.closest('[data-qact]');
      if (qActBtn) {
        runQuickAction(qActBtn.dataset.qact);
        return;
      }

      const wzShape = t.closest('[data-wz-shape]');
      if (wzShape) {
        STATE.wizard.shape = wzShape.dataset.wzShape;
        STATE.wizardOpen = true;
        renderBody();
        return;
      }
      const wzBase = t.closest('[data-wz-base]');
      if (wzBase) {
        STATE.wizard.base = wzBase.dataset.wzBase;
        STATE.wizardOpen = true;
        renderBody();
        return;
      }
      const wzFoot = t.closest('[data-wz-foot]');
      if (wzFoot) {
        STATE.wizard.foot = wzFoot.dataset.wzFoot;
        STATE.wizardOpen = true;
        renderBody();
        return;
      }
      const drawModeBtn = t.closest('[data-draw-mode]');
      if (drawModeBtn) {
        STATE.drawMode = drawModeBtn.dataset.drawMode || 'orbit';
        STATE.placePointMode = STATE.drawMode === 'point';
        STATE.pendingSegmentStart = '';
        STATE.viewer.setPlacePlaneZ(STATE.drawPlaneZ);
        STATE.viewer.setPlacePointMode(STATE.placePointMode);
        syncHudButtons();
        renderBody();
        return;
      }

      const drawZBtn = t.closest('[data-draw-z]');
      if (drawZBtn) {
        STATE.drawPlaneZ = Math.max(0, Math.min(5, Number(drawZBtn.dataset.drawZ) || 0));
        STATE.drawMode = 'point';
        STATE.placePointMode = true;
        STATE.pendingSegmentStart = '';
        STATE.viewer.setPlacePlaneZ(STATE.drawPlaneZ);
        STATE.viewer.setPlacePointMode(true);
        syncHudButtons();
        setNotice(`Đã đặt mặt phẳng chấm điểm ở cao độ z = ${STATE.drawPlaneZ}. Chạm lên khung 3D để đặt đỉnh mới.`);
        renderBody();
        return;
      }

      const stencilBtn = t.closest('[data-stencil]');
      if (stencilBtn) {
        const kind = stencilBtn.dataset.stencil;
        pushHistory();
        stopSpeech();
        STATE.activeTemplateId = '';
        STATE.activeFormula = '';
        STATE.activeSteps = [];
        STATE.activeStepIdx = -1;
        STATE.stepBarOpen = false;
        STATE.csEnabled = false;
        STATE.netRatio = 0;
        STATE.selectedVertices = [];
        STATE.pendingSegmentStart = '';
        STATE.drawMode = 'orbit';
        STATE.placePointMode = false;
        STATE.scene = buildBaseStencilScene(kind);
        STATE.activeTitle = `Khung đáy ${stencilBtn.textContent.trim()}`;
        STATE.viewer.setSelectedVertices([]);
        STATE.viewer.setHighlight({});
        setNotice(`Đã đặt ${STATE.activeTitle}! Bấm "🔺 Lên chóp S" hoặc "▭ Lên lăng trụ" để dựng khối 3D.`);
        syncViewer();
        renderBody();
        return;
      }

      if (t.closest('#hhkg-draw-blank')) {
        pushHistory();
        stopSpeech();
        STATE.activeTemplateId = '';
        STATE.activeTitle = 'Hình tự vẽ 3D';
        STATE.activeFormula = '';
        STATE.activeSteps = [];
        STATE.activeStepIdx = -1;
        STATE.stepBarOpen = false;
        STATE.csEnabled = false;
        STATE.netRatio = 0;
        STATE.selectedVertices = [];
        STATE.pendingSegmentStart = '';
        STATE.drawPlaneZ = 0;
        STATE.drawMode = 'point';
        STATE.placePointMode = true;
        STATE.scene = normalizeSceneSpec({ showOxyz: false, unitNote: 'Chạm lên lưới để đặt các đỉnh đáy A, B, C, D…', vertices: [], edges: [], faces: [] });
        STATE.viewer.setSelectedVertices([]);
        STATE.viewer.setHighlight({});
        STATE.viewer.setPlacePlaneZ(0);
        setNotice('Đã mở khung trống! Chạm lên mặt phẳng lưới để đặt các đỉnh đáy A, B, C…');
        syncViewer({ keepCamera: true });
        renderBody();
        return;
      }

      if (t.closest('#hhkg-draw-pyr')) {
        const res = extrudeBaseToPyramid(STATE.scene, { height: STATE.drawHeight });
        if (!res.ok) {
          setNotice(res.message, 'warn');
          renderBody();
          return;
        }
        pushHistory();
        STATE.scene = res.scene;
        STATE.drawMode = 'orbit';
        STATE.placePointMode = false;
        STATE.pendingSegmentStart = '';
        STATE.activeTitle = 'Hình chóp tự vẽ';
        setNotice(res.message);
        syncViewer({ keepCamera: true });
        renderBody();
        return;
      }

      if (t.closest('#hhkg-draw-prism')) {
        const res = extrudeBaseToPrism(STATE.scene, { height: STATE.drawHeight });
        if (!res.ok) {
          setNotice(res.message, 'warn');
          renderBody();
          return;
        }
        pushHistory();
        STATE.scene = res.scene;
        STATE.drawMode = 'orbit';
        STATE.placePointMode = false;
        STATE.pendingSegmentStart = '';
        STATE.activeTitle = 'Hình lăng trụ tự vẽ';
        setNotice(res.message);
        syncViewer({ keepCamera: true });
        renderBody();
        return;
      }

      if (t.closest('#hhkg-draw-above')) {
        const selId = STATE.selectedVertices[0];
        const baseV = STATE.scene.vertices.find((v) => v.id === selId);
        if (baseV) {
          pushHistory();
          const next = structuredClone(STATE.scene);
          const sId = next.vertices.some((v) => v.id === 'S') ? nextStandardVertexLabel(next.vertices) : 'S';
          const hVal = Math.max(1, Math.min(6, Number(STATE.drawHeight) || 3));
          next.vertices.push({ id: sId, x: baseV.x, y: baseV.y, z: baseV.z + hVal, role: 'primary' });
          next.edges.push({ from: sId, to: baseV.id, style: 'altitude', label: `h=${hVal}` });
          STATE.scene = normalizeSceneSpec(next);
          setNotice(`Đã đặt ${sId} thẳng đứng phía trên ${baseV.id} (cao h = ${hVal}).`);
          syncViewer({ keepCamera: true });
          renderBody();
        }
        return;
      }

      if (t.closest('#hhkg-place-btn')) {
        STATE.placePointMode = !STATE.placePointMode;
        STATE.drawMode = STATE.placePointMode ? 'point' : 'orbit';
        STATE.pendingSegmentStart = '';
        STATE.viewer.setPlacePointMode(STATE.placePointMode);
        syncHudButtons();
        setNotice(
          STATE.placePointMode
            ? 'Đang bật chế độ chạm lên mặt phẳng đáy (z = 0) để đặt điểm mới.'
            : 'Đã tắt chế độ đặt điểm trên mặt phẳng đáy.',
        );
        renderBody();
        return;
      }

      if (t.closest('#hhkg-axes-btn')) {
        const cur = STATE.showAxes !== null ? STATE.showAxes : Boolean(STATE.scene.showOxyz);
        STATE.showAxes = !cur;
        syncViewer({ keepCamera: true });
        return;
      }

      if (t.closest('#hhkg-grid-btn')) {
        STATE.showGrid = !STATE.showGrid;
        syncViewer({ keepCamera: true });
        return;
      }

      if (t.closest('#hhkg-cmd-run')) {
        runGeoCmd();
        return;
      }

      const cmdFill = t.closest('[data-cmd-fill]');
      if (cmdFill) {
        STATE.cmdText = cmdFill.dataset.cmdFill || '';
        const inp = $('hhkg-cmd-inp');
        if (inp) {
          inp.value = STATE.cmdText;
          inp.focus();
        }
        return;
      }

      const algEye = t.closest('[data-alg-eye]');
      if (algEye) {
        const [kind, idxStr] = String(algEye.dataset.algEye).split(':');
        const idx = Number(idxStr);
        const listKey = { vertex: 'vertices', edge: 'edges', vector: 'vectors', face: 'faces', sphere: 'spheres', plane: 'planes', circle: 'circles', surface: 'surfaces' }[kind];
        if (listKey && Array.isArray(STATE.scene[listKey]) && STATE.scene[listKey][idx]) {
          STATE.scene[listKey][idx].hidden = !STATE.scene[listKey][idx].hidden;
          syncViewer({ keepCamera: true });
          renderBody();
        }
        return;
      }

      const algDel = t.closest('[data-alg-del]');
      if (algDel) {
        const [kind, idxStr] = String(algDel.dataset.algDel).split(':');
        const idx = Number(idxStr);
        const listKey = { vertex: 'vertices', edge: 'edges', vector: 'vectors', face: 'faces', sphere: 'spheres', plane: 'planes', circle: 'circles', surface: 'surfaces' }[kind];
        if (listKey && Array.isArray(STATE.scene[listKey]) && STATE.scene[listKey][idx]) {
          pushHistory();
          const next = structuredClone(STATE.scene);
          next[listKey].splice(idx, 1);
          STATE.scene = normalizeSceneSpec(next);
          syncViewer({ keepCamera: true });
          renderBody();
        }
        return;
      }

      const netBtn = t.closest('[data-net-set]');
      if (netBtn) {
        STATE.netRatio = Math.max(0, Math.min(1, Number(netBtn.dataset.netSet) || 0));
        syncViewer({ keepCamera: true });
        renderBody();
        return;
      }

      if (t.closest('#hhkg-wizard-build')) {
        pushHistory();
        const built = buildGrade11CustomSolid(STATE.wizard);
        STATE.activeTemplateId = '';
        STATE.activeTitle = built.title;
        STATE.activeFormula = built.formula;
        STATE.activeSteps = built.steps || [];
        STATE.activeStepIdx = STATE.activeSteps.length ? 0 : -1;
        STATE.stepBarOpen = STATE.activeSteps.length > 0;
        STATE.scene = built.scene;
        STATE.netRatio = 0;
        STATE.selectedVertices = [];
        STATE.viewer.setSelectedVertices([]);
        applyStepHighlight();
        syncViewer();
        setNotice(`Đã dựng: ${built.title}.`);
        renderBody();
        return;
      }

      if (t.closest('#hhkg-add-vertex')) {
        const id = ($('hhkg-v-id')?.value || '').trim();
        const x = Number($('hhkg-v-x')?.value);
        const y = Number($('hhkg-v-y')?.value);
        const z = Number($('hhkg-v-z')?.value);
        if (!id || !Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) return;
        pushHistory();
        const next = structuredClone(STATE.scene);
        const idx = next.vertices.findIndex((v) => v.id === id);
        const nv = { id, x, y, z, role: 'aux' };
        if (idx >= 0) next.vertices[idx] = nv;
        else next.vertices.push(nv);
        STATE.scene = normalizeSceneSpec(next);
        syncViewer({ keepCamera: true });
        renderBody();
        return;
      }

      if (t.closest('#hhkg-add-ratio')) {
        const idA = $('hhkg-r-a')?.value;
        const idB = $('hhkg-r-b')?.value;
        const k = Number($('hhkg-r-k')?.value ?? 0.5);
        const vMap = new Map(STATE.scene.vertices.map((v) => [v.id, v]));
        const A = vMap.get(idA), B = vMap.get(idB);
        if (!A || !B || A.id === B.id || !Number.isFinite(k)) return;
        pushHistory();
        const pt = lerpPoint(A, B, k);
        const next = structuredClone(STATE.scene);
        const nm = nextFreeVertexName('K');
        next.vertices.push({ id: nm, x: pt.x, y: pt.y, z: pt.z, role: 'aux' });
        STATE.scene = normalizeSceneSpec(next);
        syncViewer({ keepCamera: true });
        setNotice(`Đã dựng ${nm} chia đoạn ${A.id}${B.id} theo tỉ số k = ${k}.`);
        renderBody();
        return;
      }

      const loadSavedBtn = t.closest('[data-load-saved]');
      if (loadSavedBtn) {
        const idx = Number(loadSavedBtn.dataset.loadSaved);
        const item = STATE.savedList[idx];
        if (item && item.scene) {
          pushHistory();
          applySnapshot({
            scene: item.scene,
            title: item.title,
            formula: item.formula,
            steps: item.steps || [],
            templateId: '',
            stepIdx: (item.steps && item.steps.length) ? 0 : -1,
          });
          STATE.stepBarOpen = Boolean(item.steps && item.steps.length);
          renderStepBar();
          setNotice(`Đã mở lại "${item.title}".`);
          renderBody();
        }
        return;
      }

      const delSavedBtn = t.closest('[data-del-saved]');
      if (delSavedBtn) {
        const idx = Number(delSavedBtn.dataset.delSaved);
        STATE.savedList.splice(idx, 1);
        persistSavedList(STATE.savedList);
        renderBody();
        return;
      }

      const aiTplBtn = t.closest('[data-ai-tpl]');
      if (aiTplBtn) {
        STATE.aiPromptText = aiTplBtn.dataset.aiTpl || '';
        if ($('hhkg-ai-prompt')) {
          $('hhkg-ai-prompt').value = STATE.aiPromptText;
          $('hhkg-ai-prompt').focus();
        }
        return;
      }

      const sampleBtn = t.closest('[data-sample]');
      if (sampleBtn) {
        const item = SAMPLE_PROBLEMS[Number(sampleBtn.dataset.sample)];
        if (item) {
          STATE.aiPromptText = item.text;
          if ($('hhkg-ai-prompt')) {
            $('hhkg-ai-prompt').value = item.text;
            $('hhkg-ai-prompt').focus();
          }
        }
        return;
      }

      if (t.closest('#hhkg-ai-rmimg')) {
        STATE.aiImageBase64 = '';
        STATE.aiImageMime = '';
        STATE.aiImageName = '';
        renderBody();
        return;
      }

      if (t.closest('#hhkg-ai-solve')) {
        runAiSolve();
        return;
      }

      if (t.closest('#hhkg-offline-solve') || t.closest('#hhkg-offline-solve-err')) {
        runOfflineSolve();
        return;
      }

      if (t.closest('#hhkg-follow-btn')) {
        runAiFollowup();
        return;
      }

      if (t.closest('#hhkg-clear-step')) {
        STATE.activeStepIdx = -1;
        STATE.viewer.setHighlight({});
        renderStepBar();
        renderBody();
        return;
      }

      const stepBtn = t.closest('[data-ai-step]');
      if (stepBtn) {
        STATE.activeStepIdx = Number(stepBtn.dataset.aiStep);
        STATE.stepBarOpen = true;
        applyStepHighlight();
        renderStepBar();
        renderBody();
        return;
      }

      const cspBtn = t.closest('[data-csp]');
      if (cspBtn) {
        const [nx, ny, nz, d] = cspBtn.dataset.csp.split(',').map(Number);
        STATE.csPlane = { nx, ny, nz, d };
        STATE.csEnabled = true;
        syncViewer({ keepCamera: true });
        renderBody();
      }
    });

    ov.addEventListener('toggle', (e) => {
      if (e.target && e.target.id === 'hhkg-wizard-det') {
        STATE.wizardOpen = e.target.open;
      } else if (e.target && e.target.id === 'hhkg-ai-guide') {
        STATE.aiGuideOpen = e.target.open;
      }
    }, true);

    ov.addEventListener('change', (e) => {
      const t = e.target;
      if (t.id === 'hhkg-toggle-oxyz') {
        STATE.scene.showOxyz = Boolean(t.checked);
        syncViewer({ keepCamera: true });
        return;
      }
      if (t.id === 'hhkg-cs-on') {
        STATE.csEnabled = Boolean(t.checked);
        syncViewer({ keepCamera: true });
        renderBody();
        return;
      }
      if (t.id === 'hhkg-ai-file' && t.files && t.files[0]) {
        const f = t.files[0];
        const reader = new FileReader();
        reader.onload = () => {
          STATE.aiImageBase64 = String(reader.result || '');
          STATE.aiImageMime = f.type || 'image/png';
          STATE.aiImageName = f.name;
          renderBody();
        };
        reader.readAsDataURL(f);
      }
    });

    ov.addEventListener('input', (e) => {
      const t = e.target;
      if (t.id === 'hhkg-cmd-inp') {
        STATE.cmdText = t.value;
        return;
      }
      if (t.id === 'hhkg-ai-prompt') {
        STATE.aiPromptText = t.value;
        return;
      }
      if (t.id === 'hhkg-net-slider') {
        STATE.netRatio = Math.max(0, Math.min(1, Number(t.value) || 0));
        const pct = `${Math.round(STATE.netRatio * 100)}%`;
        const p1 = $('hhkg-net-pct');
        const p2 = $('hhkg-net-pct-top');
        if (p1) p1.textContent = pct;
        if (p2) p2.textContent = pct;
        const net = STATE.netRatio > 0.01 ? computePolyhedronNet(STATE.scene, STATE.netRatio) : null;
        if (STATE.viewer) STATE.viewer.setPolyhedronNet(net, STATE.netRatio);
        const nr = $('hhkg-net-readout');
        if (nr) {
          nr.innerHTML = net && net.valid
            ? `<p style="margin:6px 0 0;font-size:12.5px;color:#065F46;">Diện tích toàn phần khai triển: <b>S<sub>tp</sub> ≈ ${net.totalArea.toFixed(3)} đvdt</b> (${net.faces.length} mặt)</p>`
            : '';
        }
        return;
      }
      if (t.id === 'hhkg-draw-h') {
        const v = Number(t.value);
        if (Number.isFinite(v)) STATE.drawHeight = Math.max(1, Math.min(6, v));
        return;
      }
      if (t.dataset && t.dataset.wzNum) {
        STATE.wizard[t.dataset.wzNum] = Number(t.value);
        const valEl = t.nextElementSibling;
        if (valEl) valEl.textContent = String(STATE.wizard[t.dataset.wzNum]);
        return;
      }
      if (t.dataset && t.dataset.csK) {
        STATE.csPlane[t.dataset.csK] = Number(t.value);
        STATE.csEnabled = true;
        const csToggle = $('hhkg-cs-on');
        if (csToggle) csToggle.checked = true;
        const valEl = t.nextElementSibling;
        if (valEl) valEl.textContent = String(STATE.csPlane[t.dataset.csK]);
        syncViewer({ keepCamera: true });
        const cs = computeCrossSection(STATE.scene, STATE.csPlane);
        const ro = $('hhkg-cs-readout');
        if (ro) ro.innerHTML = renderCsReadoutHtml(cs);
      }
    });

    ov.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !IS_STANDALONE) {
        e.stopPropagation();
        closeStudio();
        return;
      }
      if (e.key === 'Enter' && e.target && e.target.id === 'hhkg-cmd-inp') {
        e.preventDefault();
        runGeoCmd();
        return;
      }
      if (e.key === 'Enter' && e.target && e.target.id === 'hhkg-follow-inp') {
        e.preventDefault();
        runAiFollowup();
      }
    });
  }

  function applyDockVisibility() {
    const dock = $('hhkg-dock');
    const tog = $('hhkg-dock-toggle');
    if (dock) dock.hidden = STATE.dockCollapsed;
    if (tog) {
      tog.textContent = STATE.dockCollapsed ? '▴ Thanh góc nhìn' : '▾ Ẩn thanh góc nhìn';
      tog.setAttribute('aria-expanded', STATE.dockCollapsed ? 'false' : 'true');
    }
  }

  function openStudio(tab = 'templates') {
    const ov = ensureOverlay();
    STATE.tab = tab;
    STATE.open = true;
    STATE.dockCollapsed = W.innerWidth < 640;
    ov.hidden = false;
    D.documentElement.classList.add('hhkg-lock');
    applyDockVisibility();
    STATE.viewer.resize();
    syncViewer();
    renderBody();
  }

  W.addEventListener('resize', () => {
    if (!STATE.open) return;
    const wantCollapsed = W.innerWidth < 640;
    if (wantCollapsed !== STATE.dockCollapsed) {
      STATE.dockCollapsed = wantCollapsed;
      applyDockVisibility();
    }
  });

  function closeStudio() {
    if (IS_STANDALONE) {
      stopSpeech();
      W.location.href = '/index.html';
      return;
    }
    if (!STATE.ov) return;
    stopSpeech();
    STATE.open = false;
    STATE.ov.hidden = true;
    D.documentElement.classList.remove('hhkg-lock');
  }

  D.addEventListener('click', (e) => {
    const btn = e.target.closest && e.target.closest('[data-hhkg-open]');
    if (btn) {
      e.preventDefault();
      openStudio('templates');
      return;
    }
    const dlEntry = e.target.closest && e.target.closest('#hhkg-entry-dl');
    if (dlEntry) {
      e.preventDefault();
      downloadClaudeHandoffBundle();
    }
  });

  // Expose minimal namespace consistent with Dobai rules (parallelPointThrough exported in math too)
  W.HHKG = { open: openStudio, close: closeStudio, state: STATE, downloadBundle: downloadClaudeHandoffBundle, parallelPointThrough, standalone: IS_STANDALONE };
  if (IS_STANDALONE) {
    let initTab = 'templates';
    try {
      const sp = new URLSearchParams(W.location.search);
      const t = sp.get('tab');
      if (t === 'algebra' || t === 'measure' || t === 'ai' || t === 'templates') initTab = t;
    } catch {}
    const boot = $('hhkg-standalone-boot');
    if (boot) boot.remove();
    openStudio(initTab);
  } else {
    addEntry();
    try {
      const sp = new URLSearchParams(W.location.search);
      if (sp.get('hhkg') === '1') {
        setTimeout(() => openStudio('templates'), 60);
      }
    } catch {}
  }
})();
