import express from 'express';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';
import { createZipBytes } from './Dobai/js/hhkg-zip.js';
import { refineAiGeometryPayload } from './Dobai/js/hhkg-geogebra.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT) || 3000;
const DOBAI_DIR = path.join(__dirname, 'Dobai');

const app = express();
app.use(express.json({ limit: '15mb' }));

// Static hosting for Dobai web app and local Three.js vendor modules
app.use(express.static(DOBAI_DIR, {
  extensions: ['html'],
  setHeaders(res, filePath) {
    if (filePath.endsWith('.js') || filePath.endsWith('.mjs')) {
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    }
  },
}));

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim()),
  });
});

async function collectFilesRecursively(dirAbs, zipPrefix, entries) {
  let items = [];
  try {
    items = await fs.readdir(dirAbs, { withFileTypes: true });
  } catch {
    return;
  }
  for (const item of items) {
    const full = path.join(dirAbs, item.name);
    const zipName = `${zipPrefix}/${item.name}`.replace(/\\/g, '/');
    if (item.isDirectory()) {
      await collectFilesRecursively(full, zipName, entries);
    } else if (item.isFile()) {
      const buf = await fs.readFile(full);
      entries.push({ name: zipName, content: new Uint8Array(buf) });
    }
  }
}

app.get('/api/geometry/export-bundle.zip', async (_req, res) => {
  try {
    const entries = [];
    await collectFilesRecursively(path.join(DOBAI_DIR, 'js'), 'Dobai/js', entries);
    await collectFilesRecursively(path.join(DOBAI_DIR, 'handoff'), 'Dobai/handoff', entries);
    await collectFilesRecursively(path.join(DOBAI_DIR, 'vendor', 'three'), 'Dobai/vendor/three', entries);

    const extraFiles = [
      ['Dobai/hhkg.html', path.join(DOBAI_DIR, 'hhkg.html')],
      ['server.js', path.join(__dirname, 'server.js')],
      ['package.json', path.join(__dirname, 'package.json')],
      ['tests/hhkg-math.test.ts', path.join(__dirname, 'tests', 'hhkg-math.test.ts')],
      ['.env.example', path.join(__dirname, '.env.example')],
    ];
    for (const [zipName, absPath] of extraFiles) {
      try {
        const buf = await fs.readFile(absPath);
        entries.push({ name: zipName, content: new Uint8Array(buf) });
      } catch {}
    }

    const zipBytes = createZipBytes(entries);
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="hhkg-dobai-claude-handoff.zip"');
    res.setHeader('Cache-Control', 'no-store');
    res.send(Buffer.from(zipBytes));
  } catch (err) {
    console.error('[HHKG Bundle Error]', err);
    res.status(500).json({ error: 'Không thể đóng gói tệp bàn giao lúc này.' });
  }
});

app.get('/hhkg', (_req, res) => {
  res.sendFile(path.join(DOBAI_DIR, 'hhkg.html'));
});

function getAiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || !apiKey.trim()) {
    const err = new Error('Trợ lý AI giải hình chưa được kích hoạt trên máy chủ. Bạn vẫn có thể sử dụng đầy đủ tính năng vẽ hình 3D, dựng điểm và cắt thiết diện.');
    err.status = 503;
    throw err;
  }
  return new GoogleGenAI({
    apiKey: apiKey.trim(),
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const SOLVE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: 'Tên ngắn gọn của bài toán (tiếng Việt).' },
    grade: { type: Type.STRING, description: 'Lớp 11 hoặc Lớp 12 (theo chương trình GDPT 2018).' },
    topic: { type: Type.STRING, description: 'Chuyên đề chính: Quan hệ vuông góc, Góc, Khoảng cách, Thể tích, Thiết diện, hoặc Tọa độ Oxyz.' },
    summary: { type: Type.STRING, description: 'Tóm tắt ngắn gọn giả thiết và mục tiêu bài toán (1-2 câu).' },
    finalAnswer: { type: Type.STRING, description: 'Đáp số cuối cùng chính xác, viết rõ ràng (ví dụ: a√6 / 3 hoặc 60°).' },
    visualTips: { type: Type.STRING, description: 'Mẹo quan sát hình 3D trực quan để học sinh dễ hiểu.' },
    verificationNote: { type: Type.STRING, description: 'Tự kiểm tra ngắn gọn các điều kiện vuông góc, song song, tỉ số trên tọa độ đã dựng.' },
    constructions: {
      type: Type.ARRAY,
      description: 'Danh sách lệnh dựng hình GeoGebra 3D chuẩn chạy tuần tự sau các đỉnh gốc trong scene.vertices để khóa tọa độ chính xác tuyệt đối (ví dụ: M = Midpoint(S, C), H = PerpendicularPoint(A, S, B, D), ParallelLine(S, A, B), I = Intersect(B, F, A, C, D), E = CrossSectionParallel(M, A, B, C, D)).',
      items: {
        type: Type.OBJECT,
        properties: {
          command: { type: Type.STRING, description: 'Lệnh GeoGebra 3D hợp lệ.' },
          note: { type: Type.STRING, description: 'Mục đích phép dựng trong lời giải.' },
        },
        required: ['command'],
      },
    },
    scene: {
      type: Type.OBJECT,
      description: 'Mô tả hình học không gian 3D theo hệ tọa độ Toán học (x hướng ra trước, y hướng sang phải, z hướng lên trên). Đặt đơn vị chuẩn a = 2 hoặc a = 3 để hình cân đối quanh gốc tọa độ.',
      properties: {
        showOxyz: { type: Type.BOOLEAN, description: 'Bật hệ trục tọa độ Oxyz khi bài toán thuộc Lớp 12 hoặc dùng phương pháp tọa độ hóa.' },
        unitNote: { type: Type.STRING, description: 'Ghi chú tỉ lệ quy ước khi dựng hình 3D (ví dụ: Quy ước a = 2 đơn vị).' },
        vertices: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING, description: 'Tên đỉnh ngắn gọn, viết hoa như S, A, B, C, D, A\', M, H, O, I.' },
              x: { type: Type.NUMBER },
              y: { type: Type.NUMBER },
              z: { type: Type.NUMBER },
              role: { type: Type.STRING, description: 'primary | aux | projection | center' },
            },
            required: ['id', 'x', 'y', 'z'],
          },
        },
        edges: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              from: { type: Type.STRING },
              to: { type: Type.STRING },
              style: { type: Type.STRING, description: 'solid | dashed | highlight | altitude' },
              label: { type: Type.STRING, description: 'Độ dài hoặc ký hiệu cạnh nếu cần (ví dụ a, a√2), có thể để trống.' },
            },
            required: ['from', 'to', 'style'],
          },
        },
        faces: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              vertices: { type: Type.ARRAY, items: { type: Type.STRING } },
              color: { type: Type.STRING, description: 'Mã màu hex nhạt, ví dụ #3B82F6, #10B981, #F59E0B.' },
              opacity: { type: Type.NUMBER, description: 'Từ 0.12 đến 0.45.' },
              label: { type: Type.STRING },
              internal: { type: Type.BOOLEAN, description: 'Đặt true nếu là mặt cắt chéo / mặt phẳng phụ bên trong khối đa diện (không phải mặt ngoài).' },
            },
            required: ['vertices'],
          },
        },
        rightAngles: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              vertex: { type: Type.STRING, description: 'Đỉnh góc vuông.' },
              p1: { type: Type.STRING, description: 'Điểm thứ nhất tạo tia vuông góc.' },
              p2: { type: Type.STRING, description: 'Điểm thứ hai tạo tia vuông góc.' },
            },
            required: ['vertex', 'p1', 'p2'],
          },
        },
        angles: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              vertex: { type: Type.STRING },
              p1: { type: Type.STRING },
              p2: { type: Type.STRING },
              label: { type: Type.STRING, description: 'Ví dụ: α = 60° hoặc φ.' },
            },
            required: ['vertex', 'p1', 'p2'],
          },
        },
        vectors: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              from: { type: Type.STRING },
              to: { type: Type.STRING },
              label: { type: Type.STRING },
              color: { type: Type.STRING },
            },
            required: ['from', 'to'],
          },
        },
        planes: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              label: { type: Type.STRING },
              nx: { type: Type.NUMBER },
              ny: { type: Type.NUMBER },
              nz: { type: Type.NUMBER },
              d: { type: Type.NUMBER },
              color: { type: Type.STRING },
            },
            required: ['nx', 'ny', 'nz', 'd'],
          },
        },
        spheres: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              center: { type: Type.STRING, description: 'ID đỉnh làm tâm hoặc để trống nếu dùng tọa độ.' },
              cx: { type: Type.NUMBER },
              cy: { type: Type.NUMBER },
              cz: { type: Type.NUMBER },
              radius: { type: Type.NUMBER },
              label: { type: Type.STRING },
            },
            required: ['radius'],
          },
        },
        cones: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              apex: { type: Type.STRING },
              baseCenter: { type: Type.STRING },
              radius: { type: Type.NUMBER },
            },
            required: ['apex', 'baseCenter', 'radius'],
          },
        },
        cylinders: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              topCenter: { type: Type.STRING },
              bottomCenter: { type: Type.STRING },
              radius: { type: Type.NUMBER },
            },
            required: ['topCenter', 'bottomCenter', 'radius'],
          },
        },
        circles: {
          type: Type.ARRAY,
          description: 'Các đường tròn giao tuyến 3D (ví dụ giao mặt cầu và mặt phẳng hoặc hai mặt cầu).',
          items: {
            type: Type.OBJECT,
            properties: {
              center: {
                type: Type.OBJECT,
                properties: {
                  x: { type: Type.NUMBER },
                  y: { type: Type.NUMBER },
                  z: { type: Type.NUMBER },
                },
                required: ['x', 'y', 'z'],
              },
              normal: {
                type: Type.OBJECT,
                properties: {
                  x: { type: Type.NUMBER },
                  y: { type: Type.NUMBER },
                  z: { type: Type.NUMBER },
                },
                required: ['x', 'y', 'z'],
              },
              radius: { type: Type.NUMBER },
              color: { type: Type.STRING },
              label: { type: Type.STRING },
            },
            required: ['center', 'normal', 'radius'],
          },
        },
        crossSection: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: 'Danh sách ID các đỉnh theo đúng thứ tự vòng tạo thành thiết diện nếu bài toán có thiết diện.',
        },
      },
      required: ['vertices', 'edges', 'faces'],
    },
    steps: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          stepTitle: { type: Type.STRING },
          explanation: { type: Type.STRING, description: 'Giải thích rõ ràng, chặt chẽ theo chuẩn Toán 11/12 GDPT 2018.' },
          formula: { type: Type.STRING, description: 'Biểu thức tính toán chính ở bước này (viết gọn dễ đọc).' },
          highlightVertices: { type: Type.ARRAY, items: { type: Type.STRING } },
          highlightEdges: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                from: { type: Type.STRING },
                to: { type: Type.STRING },
              },
              required: ['from', 'to'],
            },
          },
          highlightFaceVertices: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ['stepTitle', 'explanation'],
      },
    },
  },
  required: ['title', 'grade', 'topic', 'summary', 'finalAnswer', 'scene', 'steps'],
};

const FOLLOWUP_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    answer: { type: Type.STRING, description: 'Câu trả lời sư phạm chính xác, trực quan bằng tiếng Việt.' },
    highlightVertices: { type: Type.ARRAY, items: { type: Type.STRING } },
    highlightEdges: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          from: { type: Type.STRING },
          to: { type: Type.STRING },
        },
        required: ['from', 'to'],
      },
    },
    updatedScene: {
      type: Type.OBJECT,
      description: 'Chỉ điền nếu người dùng yêu cầu vẽ thêm điểm/đoạn thẳng/mặt phẳng/thiết diện hoặc sửa hình.',
      properties: {
        addConstructions: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: 'Lệnh GeoGebra 3D thực thi thêm vào hình hiện tại (ví dụ: M = Midpoint(S, C), ParallelLine(S, A, B), CrossSection(A, M, N)).',
        },
        addVertices: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              x: { type: Type.NUMBER },
              y: { type: Type.NUMBER },
              z: { type: Type.NUMBER },
              role: { type: Type.STRING },
            },
            required: ['id', 'x', 'y', 'z'],
          },
        },
        addEdges: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              from: { type: Type.STRING },
              to: { type: Type.STRING },
              style: { type: Type.STRING },
              label: { type: Type.STRING },
            },
            required: ['from', 'to', 'style'],
          },
        },
        addFaces: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              vertices: { type: Type.ARRAY, items: { type: Type.STRING } },
              color: { type: Type.STRING },
              opacity: { type: Type.NUMBER },
              internal: { type: Type.BOOLEAN },
            },
            required: ['vertices'],
          },
        },
        addRightAngles: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              vertex: { type: Type.STRING },
              p1: { type: Type.STRING },
              p2: { type: Type.STRING },
            },
            required: ['vertex', 'p1', 'p2'],
          },
        },
      },
    },
  },
  required: ['answer'],
};

const SYSTEM_INSTRUCTION = `Bạn là giáo viên Toán THPT xuất sắc tại Việt Nam và là chuyên gia dựng hình GeoGebra 3D, chuyên Hình học không gian lớp 11 và lớp 12 theo Chương trình GDPT 2018 (SGK Toán 11 Kết nối tri thức Tập 1 Chương IV Song song, Tập 2 Vuông góc, và Toán 12 Oxyz).

QUY TRÌNH 5 BƯỚC BẮT BUỘC ĐỂ VẼ HÌNH & GIẢI CHÍNH XÁC TUYỆT ĐỐI:
1. Đặt hệ trục chuẩn (x hướng ra trước, y sang phải, z hướng lên). Quy ước cạnh a = 2 hoặc a = 3 (hoặc số đo cụ thể nếu đề cho sẵn) để khối nằm gọn trong [-4, +4]. Đỉnh đáy đặt tại z = 0; chân đường cao đặt chính xác (SA ⊥ đáy ⇒ S có cùng (x,y) với A; mặt bên (SAB) ⊥ đáy ⇒ chân đường cao H ∈ AB).
2. Khai báo đầy đủ CÁC ĐỈNH GỐC trong scene.vertices và ĐẦY ĐỦ MẶT NGOÀI của khối đa diện trong scene.faces (mặt cắt chéo/mặt phụ bên trong đánh dấu internal: true) để bộ dựng hình 3D tự động chia nét liền / nét đứt chuẩn xác theo góc xoay camera 360°.
3. DÙNG TRƯỜNG constructions (lệnh GeoGebra 3D) cho các điểm suy dẫn quan trọng để hệ thống tính lại tọa độ chính xác tuyệt đối, không bị sai số làm tròn:
   - Trung điểm: M = Midpoint(S, C)
   - Trọng tâm: G = Centroid(A, B, C)
   - Chia đoạn tỉ lệ k: K = Ratio(A, B, 0.3333)
   - Đường song song (Bài 11-12 KNTT): Q = ParallelLine(S, A, B)
   - Đỉnh thứ 4 hình bình hành: D = Parallelogram(A, B, C)
   - Hình chiếu ⊥ lên đường thẳng: H = FootOnLine(A, S, O)
   - Hình chiếu ⊥ lên mặt phẳng: H = PerpendicularPoint(A, S, B, D)
   - Giao điểm đường & mặt (Bài 10 KNTT): I = Intersect(B, F, A, C, D)
   - Giao điểm 2 đường đồng phẳng: I = IntersectLines(A, C, B, D)
   - Phép chiếu song song (Bài 14 KNTT): A' = ProjectParallel(A, D1, D2, P1, P2, P3)
   - Mặt phẳng trung trực đoạn AB: PlaneBisector(A, B)
   - Mặt cầu ngoại tiếp tứ diện: I = CircumSphere(A, B, C, D)
   - Giao tuyến mặt cầu & mặt phẳng / đường thẳng: IntersectSpherePlane(I, R, A, B, C), IntersectLineSphere(A, B, I, R)
   - Khối đa diện đều (Platonic): Tetrahedron(a), Octahedron(a), Dodecahedron(a), Icosahedron(a)
   - Cắt & tạo đỉnh thiết diện thật: CrossSection(A, M, N) hoặc CrossSectionParallel(E, A, B, C, D)
4. Đánh dấu góc vuông (rightAngles), góc (angles), véc-tơ (vectors), mặt phẳng (planes), đường tròn 3D (circles) và kiểu cạnh ("altitude" cho đường cao, "highlight" cho khoảng cách/giao tuyến/thiết diện).
5. Viết lời giải chặt chẽ theo đúng thuật ngữ GDPT 2018 (góc nhị diện [P, d, Q], giao tuyến song song, Định lí Thalès trong không gian, phép chiếu song song, thể tích chóp cụt đều V = h/3*(S1 + S2 + √(S1*S2))), kèm highlightVertices/highlightEdges/highlightFaceVertices cho từng bước.`;

app.post('/api/geometry/solve', async (req, res) => {
  try {
    const { problemText, imageBase64, imageMimeType, mode = 'solve', currentScene, question } = req.body || {};
    const ai = getAiClient();

    if (mode === 'followup') {
      const q = String(question || '').trim();
      if (!q) {
        return res.status(400).json({ error: 'Vui lòng nhập câu hỏi thêm về hình đang vẽ.' });
      }
      const prompt = `Ngữ cảnh bài toán / mô hình 3D hiện tại (JSON):\n${JSON.stringify(currentScene || {}).slice(0, 12000)}\n\nCâu hỏi của người dùng: ${q}\nHãy giải thích chính xác, trực quan dựa đúng vào tọa độ và ký hiệu đỉnh đang có. Nếu người dùng nhờ vẽ thêm điểm/đường/thiết diện phụ, ưu tiên xuất lệnh GeoGebra trong updatedScene.addConstructions (ví dụ "N = Midpoint(S, C)", "CrossSection(A, M, N)") hoặc tọa độ chính xác trong addVertices/addEdges.`;
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: prompt,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
          responseMimeType: 'application/json',
          responseSchema: FOLLOWUP_SCHEMA,
        },
      });
      const parsed = JSON.parse((response.text || '{}').trim());
      return res.json({ ok: true, data: parsed });
    }

    const txt = String(problemText || '').trim();
    if (!txt && !imageBase64) {
      return res.status(400).json({ error: 'Vui lòng nhập đề bài hoặc tải ảnh đề bài hình học không gian.' });
    }

    const parts = [];
    if (imageBase64 && typeof imageBase64 === 'string') {
      const cleanB64 = imageBase64.replace(/^data:[^;]+;base64,/, '');
      parts.push({
        inlineData: {
          mimeType: imageMimeType || 'image/png',
          data: cleanB64,
        },
      });
    }
    parts.push({
      text: txt
        ? `Hãy phân tích bài toán Hình học không gian sau theo quy trình 5 bước, dựng mô hình 3D chính xác tọa độ kèm lệnh GeoGebra constructions để kiểm chứng hình học và giải chi tiết từng bước:\n\n${txt}`
        : 'Hãy đọc đề bài Hình học không gian trong ảnh, dựng mô hình 3D chính xác tọa độ kèm lệnh GeoGebra constructions và giải chi tiết từng bước.',
    });

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: { parts },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
        responseMimeType: 'application/json',
        responseSchema: SOLVE_SCHEMA,
      },
    });

    const rawText = (response.text || '{}').trim();
    const parsed = refineAiGeometryPayload(JSON.parse(rawText));
    return res.json({ ok: true, data: parsed });
  } catch (err) {
    console.error('[HHKG API Error]', err);
    const status = err?.status || (String(err?.message || '').includes('API_KEY') ? 401 : 500);
    return res.status(status).json({
      error: err?.message || 'Không thể kết nối AI để giải bài lúc này. Vui lòng thử lại.',
    });
  }
});

app.use((_req, res) => {
  res.sendFile(path.join(DOBAI_DIR, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Dobai & HHKG 3D server running at http://0.0.0.0:${PORT}`);
});
