# HƯỚNG DẪN TẠO LỜI GIẢI & VẼ HÌNH 3D CHÍNH XÁC CHO TÍNH NĂNG AI (HHKG 11 & 12)

Tài liệu này hướng dẫn cả **kỹ sư tích hợp (Claude / Cloudflare Worker)** lẫn **học sinh & giáo viên** cách khai thác tối đa độ chính xác hình học của tính năng **AI Giải & Vẽ 3D** dựa trên sách **Toán 11 Tập 1 – Kết nối tri thức với cuộc sống (KNTT Chương IV: Quan hệ song song)** và nhân thuật toán **GeoGebra 3D (`geogebra/geogebra` `kernel3D`)**.

---

## 1. Kiến trúc "AI Sinh Kịch Bản + Nhân GeoGebra Kiểm Chứng Tọa Độ" (Hybrid Neuro-Symbolic Pipeline)

Trong hình học không gian, nếu để mô hình LLM tự tính tọa độ điểm phụ, giao tuyến, hình chiếu hay thiết diện bằng nhẩm số học thì dễ bị sai lệch hoặc lệch góc 90°. Vì vậy hệ thống áp dụng quy trình **5 bước bắt buộc** giữa `server.js` (Gemini `gemini-4-hydrogen` với `ThinkingLevel.HIGH`) và `Dobai/js/hhkg-geogebra.js` (`refineAiGeometryPayload`):

1. **Bước 1 — Đặt hệ tọa độ chuẩn hóa (Coordinate Framing)**:
   - Quy ước hệ trục thuận: `x` hướng ra trước (tâm màn hình), `y` sang phải, `z` hướng thẳng lên trên.
   - Đáy đa giác nằm trong mặt phẳng `z = 0` với thứ tự đỉnh ngược chiều kim đồng hồ quanh đáy (`A → B → C → D`), cạnh dài khoảng `2.4 – 3.4` để tỉ lệ nhìn rõ ràng.
   - Chân đường cao xác định đúng theo giả thiết đề bài:
     - `SA ⊥ (ABCD)` → `A(x_A, y_A, 0)`, `S(x_A, y_A, h)`.
     - Chóp đều `S.ABCD` → `O = (0, 0, 0)`, `S(0, 0, h)`.
     - Mặt bên `(SAB) ⊥ (ABCD)` (ví dụ `△SAB` cân/đều tại `S`) → `H = Midpoint(A, B)`, `S(H_x, H_y, h)`.
2. **Bước 2 — Xuất đỉnh gốc (`scene.vertices`) + Mặt ngoại biên (`scene.faces`)**:
   - Chỉ đặt **tọa độ số trực tiếp** cho các đỉnh gốc của khối đa diện (`A, B, C, D, S` hoặc `A, B, C, A', B', C'`).
   - Toàn bộ mặt bên/mặt đáy của khối đa diện phải khai báo đủ ở `scene.faces` với thứ tự vòng đỉnh liên tiếp, để thuật toán **Two-Pass WebGL Depth-Occlusion** trong `hhkg-3d.js` tự phân biệt cạnh nhìn thấy (**nét liền**) và cạnh bị che khuất (**nét đứt**) theo mọi góc xoay 360°.
   - Các mặt cắt chéo bên trong hoặc thiết diện phải gắn cờ `"internal": true` để không làm sai bao lồi (exterior hull) khi tính nét khuất.
3. **Bước 3 — Xuất lệnh dựng hình ký hiệu (`constructions[]`) thay vì tự nhẩm tọa độ phụ**:
   - Thay vì tự đoán tọa độ trung điểm, đường song song, hình chiếu vuông góc hay đỉnh thiết diện, AI điền mảng `constructions` bằng các lệnh GeoGebra 3D chuẩn:
     - Trung điểm / chia tỉ lệ: `M = Midpoint(S, C)`, `N = Ratio(S, D, 0.3333)`
     - Trọng tâm: `G = Centroid(A, B, C)`
     - Đỉnh thứ 4 hình bình hành: `D = Parallelogram(A, B, C)`
     - Đường thẳng qua điểm `P` song song `AB`: `Q = ParallelLine(P, A, B)`
     - Hình chiếu vuông góc lên đường thẳng / mặt phẳng: `H = FootOnLine(A, S, O)`, `H = PerpendicularPoint(A, S, B, D)`
     - Giao điểm đường thẳng – mặt phẳng (Bài 10 KNTT): `I = Intersect(B, F, A, C, D)`
     - Giao điểm 2 đường thẳng đồng phẳng: `I = IntersectLines(A, C, B, D)`
     - Giao tuyến 2 mặt phẳng (Bài 11 KNTT): `IntersectPlanes(S, A, B, S, C, D)`
     - Phép chiếu song song (Bài 14 KNTT): `S' = ProjectParallel(S, D1, D2, A, B, C)`
     - Cắt thiết diện & tạo đỉnh thật (Bài 12 KNTT): `CrossSection(M, N, P)` hoặc `CrossSectionParallel(M, S, B, B, C)`
4. **Bước 4 — Hậu kiểm hình học tất định (`refineAiGeometryPayload`)**:
   - Cả backend (`server.js`) và frontend (`hhkg-ui.js` trong `applySolvedResult`) đều chạy `refineAiGeometryPayload(payload)`.
   - Hàm thực thi tuần tự từng lệnh trong `payload.constructions`, tính lại tọa độ IEEE-754 chính xác, tạo cạnh nối/góc vuông, tự kiểm tra tích vô hướng mọi `rightAngles` (cảnh báo nếu lệch khỏi 90°), và ghi kết quả vào `payload.mathCheck` để hiển thị huy hiệu **`✓ Đã kiểm chứng hình học bằng nhân GeoGebra 3D`** ngay dưới đề bài.
5. **Bước 5 — Giải thích 4 phần chuẩn KNTT gắn Highlight 3D (`steps[]`) & Sửa lại theo hình người dùng chỉnh**:
   - Mỗi bước trình bày theo cấu trúc 4 phần chuẩn SGK **Toán 11 KNTT**: (a) Nêu giả thiết & chọn mặt phẳng phụ/đường cao chuẩn; (b) Lập luận song song / giao tuyến / 3 đường vuông góc; (c) Thay số hoặc biểu thức theo `a`; (d) Kết luận kèm `highlightVertices`, `highlightEdges`, `highlightFaceVertices` khớp 100% ID đỉnh.
   - Sau khi AI trả lời, học sinh có thể bấm **`✏️ Chỉnh sửa hình AI`** để đổi tọa độ đỉnh, thêm điểm hoặc sửa kiểu cạnh trong tab **✏️ Vẽ hình**, rồi bấm **`🔄 Giải lại theo hình đã sửa`** (`mode: 'recompute'` gửi `currentScene` cho AI tính lại đáp số khớp hình mới).

---

## 2. Ánh xạ công thức Toán 11 KNTT → Lệnh GeoGebra 3D

| Chuyên đề Toán 11 KNTT | Định lí / Quy tắc giải chuẩn | Lệnh GeoGebra 3D tương ứng |
|---|---|---|
| **Bài 10:** Đường thẳng và mặt phẳng trong không gian | Tìm giao điểm `M = d ∩ (P)` bằng cách chọn mặt phẳng phụ `(Q) ⊃ d`, tìm giao tuyến `Δ = (P) ∩ (Q)`, suy ra `M = d ∩ Δ`. | `Intersect(A, B, C, D, E)` / `IntersectLines(A, B, C, D)` |
| **Bài 11:** Hai đường thẳng song song | Ba mặt phẳng cắt nhau theo 3 giao tuyến đôi một song song hoặc đồng quy; `(P) ⊃ a, (Q) ⊃ b, a // b ⇒ (P) ∩ (Q) = d // a // b`. | `ParallelLine(S, A, B)` / `IntersectPlanes(...)` |
| **Bài 12:** Đường thẳng và mặt phẳng song song | Nếu `a ⊄ (P)` và `a // b ⊂ (P) ⇒ a // (P)`. Mặt phẳng `(Q) ⊃ a` cắt `(P)` theo giao tuyến `Δ // a`. | `CrossSectionParallel(M, A, B, C, D)` |
| **Bài 13:** Hai mặt phẳng song song | Định lí Thalès trong không gian: 3 mặt phẳng đôi một song song chắn trên hai cát tuyến những đoạn thẳng tỉ lệ. | `PlaneParallel(M, A, B, C)` + `CrossSection(...)` |
| **Bài 14:** Phép chiếu song song | Bảo toàn tỉ số độ dài các đoạn thẳng nằm trên hai đường thẳng song song hoặc cùng nằm trên một đường thẳng; biến hình bình hành thành hình bình hành. | `ProjectParallel(P, D1, D2, A, B, C)` |
| **HK2:** Quan hệ vuông góc, Góc nhị diện, Khoảng cách | Định lí 3 đường vuông góc; `d(A,(SBC))` bằng phương pháp quy về chân đường cao `O`/`A`. | `FootOnLine`, `PerpendicularPoint`, `Dihedral`, `CommonPerp` |

---

## 3. Hướng dẫn cho Học sinh & Giáo viên viết đề bài để AI vẽ & giải chuẩn 100%

Khi nhập đề bài ở Tab **🤖 AI Giải**, hãy đảm bảo đủ 4 thông tin sau:
1. **Tên khối & loại đáy:** Ghi rõ *"hình chóp S.ABCD đáy hình bình hành"*, *"hình vuông cạnh a"*, *"tam giác ABC vuông tại B"* hoặc *"hình hộp ABCD.A'B'C'D'"*.
2. **Đường cao & tính chất vuông góc:** Ghi rõ *"SA ⊥ (ABCD)"*, *"SO ⊥ đáy"*, hoặc *"mặt bên (SAB) đều nằm trong mặt phẳng vuông góc với đáy"*.
3. **Điểm phụ & tỉ số:** Ghi rõ *"M là trung điểm SC"*, *"N trên SD sao cho SN = 2ND"* (tránh nói mơ hồ *"điểm N bất kỳ"* nếu cần tính tỉ lệ số).
4. **Câu hỏi rõ ràng & ảnh rõ nét:** Nêu cụ thể *"tìm giao tuyến (SAB) và (SCD)"*, *"tìm thiết diện qua M song song với (SBC)"*, *"tính góc nhị diện [S, BD, A]"*. Nếu dùng camera chụp đề, chụp thẳng trang sách, đủ sáng, không cắt mất chữ *"vuông"* / *"đều"* / *"song song"*.

---

## 4. Lưu ý kỹ thuật khi tích hợp vào Cloudflare Worker (`Dobai/api-worker.js`)

- Sử dụng model `gemini-4-hydrogen` với `thinkingConfig: { thinkingLevel: 'HIGH' }`. **Không** truyền `temperature`, `topP`, `topK` để tránh suy giảm hiệu năng suy luận của dòng model hydrogen.
- Hỗ trợ cả 3 mode: `solve`, `followup` (gồm `updateVertices`/`updateEdges`), và `recompute` (giải lại dựa trên `currentScene` đã chỉnh sửa).
- Giữ nguyên `responseSchema` có trường `constructions`, `verificationNote`, `scene.planes`, `scene.vectors`, và `faces[].internal`.
- Nếu Worker chưa import được `refineAiGeometryPayload`, client `hhkg-ui.js` (`applySolvedResult`) vẫn tự động gọi `refineAiGeometryPayload(data)` ngay khi nhận JSON từ `/api/geometry/solve`, đảm bảo 100% tương thích cả hai phía.
