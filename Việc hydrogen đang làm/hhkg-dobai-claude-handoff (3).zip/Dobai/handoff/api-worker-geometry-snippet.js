/**
 * Đoạn mã tích hợp endpoint Giải Hình học không gian AI vào Dobai/api-worker.js (Cloudflare Worker)
 * Yêu cầu biến môi trường Secret trên Worker: env.GEMINI_API_KEY
 *
 * Cách ghép vào api-worker.js:
 * 1. Đặt hàm handleGeometrySolve(req, env) trước `export default { async fetch(req, env) { ... } }`.
 * 2. Trong `fetch(req, env)` (trước phần kiểm tra token bắt buộc nếu muốn cho phép dùng thử, hoặc sau `readToken` nếu yêu cầu đăng nhập):
 *      if (path === '/api/geometry/solve' && req.method === 'POST') return await handleGeometrySolve(req, env);
 *    Lưu ý giữ `CORS(env)` cho response.
 */

const HHKG_SYSTEM_INSTRUCTION = `Bạn là giáo viên Toán THPT xuất sắc tại Việt Nam và chuyên gia dựng hình GeoGebra 3D, chuyên Hình học không gian lớp 11 và 12 theo Chương trình GDPT 2018 (Kết nối tri thức Tập 1 Chương IV Song song, Tập 2 Vuông góc, và Oxyz).
1. Đặt hệ trục chuẩn (x ra trước, y sang phải, z lên trên), a = 2..3. Khai báo đủ mặt ngoài trong scene.faces (mặt cắt/phụ bên trong đặt internal: true).
2. Xuất thêm mảng constructions chứa các lệnh GeoGebra 3D chuẩn (Midpoint, Centroid, Ratio, ParallelLine, Parallelogram, FootOnLine, PerpendicularPoint, Intersect, IntersectLines, ProjectParallel, CrossSection, CrossSectionParallel) để client tự kiểm chứng tọa độ chính xác tuyệt đối.
3. Trả về đúng JSON schema gồm title, grade, topic, summary, finalAnswer, visualTips, verificationNote, constructions, scene (vertices, edges, faces, rightAngles, angles, vectors, planes, spheres, cones, cylinders, crossSection), steps (stepTitle, explanation, formula, highlightVertices, highlightEdges, highlightFaceVertices).`;

async function handleGeometrySolve(req, env) {
  const sendJson = (obj, status = 200) =>
    new Response(JSON.stringify(obj), {
      status,
      headers: {
        'content-type': 'application/json; charset=utf-8',
        'cache-control': 'no-store',
        'access-control-allow-origin': env.SITE_ORIGIN || '*',
        'access-control-allow-headers': 'authorization,content-type',
      },
    });

  try {
    const apiKey = (env.GEMINI_API_KEY || '').trim();
    if (!apiKey) {
      return sendJson(
        {
          error:
            'Chưa cấu hình Secret GEMINI_API_KEY trên Worker. Bạn vẫn có thể dùng chế độ Dựng & Giải nhanh Offline Lớp 11.',
        },
        503,
      );
    }

    const body = await req.json().catch(() => ({}));
    const { problemText, imageBase64, imageMimeType, mode = 'solve', currentScene, question } = body || {};

    const parts = [];
    if (mode === 'followup') {
      const q = String(question || '').trim();
      if (!q) return sendJson({ error: 'Vui lòng nhập câu hỏi thêm về hình đang vẽ.' }, 400);
      parts.push({
        text: `Ngữ cảnh mô hình 3D hiện tại (JSON):\n${JSON.stringify(currentScene || {}).slice(0, 12000)}\n\nCâu hỏi: ${q}\nTrả về JSON gồm { answer, highlightVertices, highlightEdges, updatedScene?: { addConstructions, addVertices, addEdges, addFaces, addRightAngles, updateVertices, updateEdges } }.`,
      });
    } else if (mode === 'recompute') {
      if (!currentScene || !Array.isArray(currentScene.vertices) || !currentScene.vertices.length) {
        return sendJson({ error: 'Chưa có mô hình hình học 3D để giải lại.' }, 400);
      }
      const txtCtx = String(problemText || '').trim();
      parts.push({
        text: `Người dùng vừa TỰ CHỈNH SỬA mô hình 3D. Hãy giữ nguyên tọa độ đỉnh đã sửa trong currentScene, chỉ bổ sung điểm/đoạn dựng phụ nếu cần, rồi tính lại đáp số và lời giải 4 bước khớp với hình mới.\nĐề bài: ${txtCtx || 'Theo hình đã sửa'}\nMô hình 3D (JSON):\n${JSON.stringify(currentScene).slice(0, 14000)}`,
      });
    } else {
      const txt = String(problemText || '').trim();
      if (!txt && !imageBase64) {
        return sendJson({ error: 'Vui lòng nhập đề bài hoặc tải ảnh đề bài.' }, 400);
      }
      if (imageBase64 && typeof imageBase64 === 'string') {
        parts.push({
          inlineData: {
            mimeType: imageMimeType || 'image/png',
            data: imageBase64.replace(/^data:[^;]+;base64,/, ''),
          },
        });
      }
      parts.push({
        text: txt
          ? `Hãy phân tích bài toán Hình học không gian sau theo quy trình 5 bước, dựng mô hình 3D chính xác tọa độ kèm lệnh GeoGebra constructions và giải chi tiết từng bước:\n\n${txt}`
          : 'Hãy đọc đề bài Hình học không gian trong ảnh, dựng mô hình 3D chính xác tọa độ kèm lệnh GeoGebra constructions và giải chi tiết từng bước.',
      });
    }

    const model = env.GEMINI_MODEL || 'gemini-4-hydrogen';
    const upstream = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`,
      {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: HHKG_SYSTEM_INSTRUCTION }] },
          contents: [{ role: 'user', parts }],
          generationConfig: {
            responseMimeType: 'application/json',
          },
        }),
      },
    );

    const payload = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      return sendJson({ error: payload?.error?.message || `Gemini HTTP ${upstream.status}` }, upstream.status);
    }

    const rawText = payload?.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
    const parsed = JSON.parse(rawText.trim());
    return sendJson({ ok: true, data: parsed }, 200);
  } catch (err) {
    return sendJson({ error: err?.message || 'Lỗi xử lý AI giải hình trên Worker.' }, 500);
  }
}
