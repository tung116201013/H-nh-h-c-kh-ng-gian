# BÀN GIAO CHỨC NĂNG HÌNH HỌC KHÔNG GIAN 11 & 12 (CHUẨN GEOGEBRA 3D) — CHO CLAUDE

Tài liệu này đi kèm toàn bộ mã nguồn Hình học không gian (`hhkg-*`) để **Claude** kiểm tra, rà soát và ghép hoàn chỉnh vào web `Dobai/index.html` + `Dobai/api-worker.js` trên Cloudflare Pages/Workers.

---

## 1. Danh mục tệp trong gói bàn giao (`hhkg-dobai-claude-handoff.zip`)

**Kiến trúc tách trang riêng (chống lag preview):** Chức năng Hình học không gian chạy trên trang web độc lập **`Dobai/hhkg.html`** (truy cập `/hhkg.html` hoặc `/hhkg`). Trong `Dobai/index.html` chỉ đặt 1 thẻ liên kết nhẹ ~1 KB không nạp Three.js/WebGL để giữ trang chủ Dobai siêu mượt.

| Tệp | Vai trò | Ghi chú ghép vào Dobai |
|---|---|---|
| `Dobai/hhkg.html` | Trang web Hình học không gian 3D độc lập | Copy trực tiếp cạnh `index.html` trên Cloudflare Pages |
| `js/hhkg-math.js` | Nhân toán học 3D thuần ES module (không phụ thuộc DOM/Three) | Có thể tách file `/js/hhkg-math.js` hoặc inline vào `hhkg.html` |
| `js/hhkg-geogebra.js` | Bộ phân tích & thực thi lệnh GeoGebra 3D + Việt hóa (`Algebra View`) + `refineAiGeometryPayload` | Import trực tiếp từ `hhkg-math.js` |
| `js/hhkg-3d.js` | Bộ dựng hình Three.js (nét khuất chuẩn SGK + phân loại cạnh xuyên tâm, chế độ 3D phối cảnh ↔ 2D phẳng trực giao, đóng khung an toàn `computeCameraFraming`, trục `Oxyz`, lưới sàn, đặt điểm 3D theo cao độ `z`, mặt phẳng `planes`, trải phẳng `Net`, mặt cong `z=f(x,y)`, vector `ArrowHelper`) | Cần `three` + `OrbitControls` qua `importmap` hoặc `vendor/three/` |
| `js/hhkg-ui.js` | Giao diện Studio học thuật (`Plus Jakarta Sans` + `JetBrains Mono`, `390px` & `1440px`), tự nhận biết chế độ độc lập trên `hhkg.html` (`‹ Về Dobai`), 5 tab (gồm tab `✏️ Vẽ hình` & bộ sửa trực tiếp), chuyển `3D ↔ 2D`, sửa & giải lại hình AI, bài giảng 3D, xuất PNG & ZIP | Đóng gói sẵn trên `hhkg.html` |
| `js/hhkg-zip.js` | Bộ tạo file `.zip` thuần JS (PKZIP + CRC32 + cờ UTF-8 `0x0800`) | Dùng cho nút tải dự phòng phía trình duyệt |
| `vendor/three/**` | Runtime `three.module.js` và `OrbitControls.js` tự host, không phụ thuộc CDN | Đặt cạnh `index.html` và `hhkg.html` trên Cloudflare Pages hoặc static hosting |
| `server.js` | Máy chủ Node/Express local: phục vụ tĩnh `Dobai/`, `/hhkg`, `POST /api/geometry/solve` (hỗ trợ `solve`, `followup`, `recompute` với `ThinkingLevel.HIGH` + `refineAiGeometryPayload`), `GET /api/geometry/export-bundle.zip` | Tham khảo schema Gemini & endpoint đóng gói ZIP |
| `tests/hhkg-math.test.ts` | Bộ unit test `node --test` kiểm tra công thức Lớp 11/12, GeoGebra 3D, `refineAiGeometryPayload` và ZIP | Chạy lại sau mỗi lần sửa: `npm test` |
| `handoff/GEOGEBRA-THUAT-TOAN.md` | Tóm tắt chưng cất thuật toán GeoGebra 3D (chiếu, chóp/lăng trụ, thiết diện khối lõm, 5 khối Platonic, mặt cầu, Z-buffer 3 lượt) | Tài liệu tham chiếu thuật toán lõi (EUPL v1.2) |
| `handoff/HUONG_DAN_AI_GIAI_CHINH_XAC_HHKG.md` | Hướng dẫn chuẩn để AI vẽ hình và tạo lời giải chính xác (quy trình 5 bước + ánh xạ SGK KNTT + mẹo đặt đề) | Tài liệu tham chiếu kỹ thuật & prompt cho AI |
| `handoff/api-worker-geometry-snippet.js` | Đoạn mã ghép thẳng vào `Dobai/api-worker.js` trên Cloudflare Worker | Cần biến môi trường Secret `GEMINI_API_KEY` |
| `handoff/index-patch-snippet.html` | Thẻ liên kết siêu nhẹ (~1 KB) gắn vào cuối `Dobai/index.html` để mở `/hhkg.html` | Không chèn Three.js vào `index.html` |

---

## 2. Tính năng đã hoàn thiện (Trọng tâm Lớp 11 GDPT 2018 + Chuẩn GeoGebra 3D)

### A. Trọng tâm Lớp 11 (GDPT 2018 — Sách Toán 11 Kết nối tri thức Tập 1 Chương IV & Tập 2)
1. **16+ mẫu chuẩn SGK** có lời giải từng bước kèm highlight 3D & đọc giọng tiếng Việt (`speechSynthesis` `vi-VN`):
   - **Chương IV KNTT (Quan hệ song song trong không gian):** Giao điểm đường thẳng – mặt phẳng (Bài 10), Giao tuyến song song `(SAB) ∩ (SCD) = Sx // AB // CD` (Bài 11), Thiết diện hình bình hành `EFGH` (Bài 12), Hai mặt phẳng song song & Định lí Thalès (Bài 13), Phép chiếu song song lên `(P)` (Bài 14).
   - **Quan hệ vuông góc & Thể tích:** Chóp `S.ABCD` (`SA ⊥ đáy`), Chóp đều, Chóp mặt bên `(SAB) ⊥ đáy`, **Chóp cụt tứ giác đều**, Tứ diện đều (`d(AB, CD)`), Lăng trụ đứng tam giác, Lăng trụ xiên, Hình hộp lập phương / chữ nhật, cùng mẫu `Oxyz`, Mặt cầu ngoại tiếp, Nón Lớp 12.
2. **Nét liền / nét đứt động theo góc nhìn, Đóng khung HUD-safe & Chuyển 3D ↔ 2D:**
   - Khi xoay khối đa diện 3D 360°, thuật toán **Two-Pass WebGL Depth-Occlusion** tự động vẽ **nét liền cho cạnh nhìn thấy** và **nét đứt cho cạnh khuất**, đồng thời nhận diện cạnh xuyên bên trong khối (như `AH`, `SO`) để render nét đứt sạch sẽ, không lòi đầu nét liền ở đỉnh.
   - Hàm `computeCameraFraming()` tính đúng vùng an toàn trên cả màn hình hẹp `390px` (tránh thanh góc nhìn phía dưới và thanh nút HUD phía trên) lẫn desktop `1440px`.
   - Nút **`📐 3D / 📄 2D`** chuyển tức thì giữa `PerspectiveCamera` (nền xanh nhạt phối cảnh 3D) và `OrthographicCamera` (nền trắng phẳng 2D chuẩn hình vẽ vở SGK).
3. **Tab riêng `✏️ Vẽ hình` & Bộ chỉnh sửa hình AI trực tiếp**:
   - Tách riêng thành tab **✏️ Vẽ hình** gồm: công cụ có hướng dẫn (`📍 Chấm điểm 3D` theo cao độ `z`, `📏 Nối cạnh` chọn kiểu nét, `↗ Véc-tơ`, `⬡ Tô mặt`), 11 công cụ GeoGebra (`Trung điểm`, `Trọng tâm`, `Chia tỉ lệ k`, `Kẻ //`, `Đỉnh 4 Hình BH`, `Chiếu ⊥ đường/mặt`, `Giao 2 đường`, `Giao đg ∩ mp`, `VG chung`, `Đối xứng MP`), 6 khung đáy nhanh, `🔺 Lên chóp S`, `▭ Lên lăng trụ`, 8 khối nhanh (5 khối Platonic + Mặt cầu/Nón/Trụ) và **bảng chỉnh sửa trực tiếp tọa độ `(x, y, z)`, vai trò đỉnh, xoay vòng kiểu nét / xóa cạnh**.
4. **Chỉnh sửa hình AI & Giải lại theo hình đã sửa**:
   - Kết quả từ **🤖 AI Giải** có nút **`✏️ Chỉnh sửa hình AI`** (mở sang tab `✏️ Vẽ hình` để sửa tọa độ/thêm cạnh/thêm điểm phụ) và **`🔄 Giải lại theo hình đã sửa`** (`mode: 'recompute'` gửi `currentScene` cho Gemini hoặc tự kiểm chứng Offline).
5. **Thao tác 1 chạm trên 1–5 đỉnh 3D** & **AI Vẽ hình + Kiểm chứng GeoGebra (`refineAiGeometryPayload`)**:
   - Hỗ trợ đầy đủ thao tác nhanh trên 1–5 đỉnh, hướng dẫn đặt đề chuẩn SGK KNTT Lớp 11, tự động gắn nhãn `internal: true` cho mặt cắt/mặt chéo và kiểm tra tích vô hướng 90°.

### B. Tương đương chuẩn GeoGebra 3D Calculator (`geogebra/geogebra`)
- **Tab `𝑓𝑥 Đại số` (Algebra View + Thanh nhập lệnh)**:
  - Hỗ trợ cú pháp tiếng Anh & tiếng Việt:
    - Tọa độ điểm: `M = (1, 0, 2)`, `Point(1, 2, 3)`
    - Phép dựng hình: `Midpoint(A, B)` / `TrungDiem(A, B)`, `Centroid(A, B, C)`, `Segment(A, B)`, `Vector(A, B)`, `Polygon(A, B, C, D)`, `ParallelLine(P, A, B)` / `SongSong`, `Parallelogram(A, B, C)` / `HinhBinhHanh`, `FootOnLine(P, A, B)` / `HinhChieuDuong`
    - Khối đa diện & tròn xoay: `Pyramid(A, B, C, D, S)`, `RegularPyramid(n, r, h)` / `ChopDeu`, `RegularPrism(n, r, h)` / `LangTruDeu`, `Tetrahedron(a)`, `Octahedron(a)` / `BatDienDeu`, `Dodecahedron(a)`, `Icosahedron(a)`, `Extrude(A, B, C, 3)` / `Prism`, `Cube(a)`, `Frustum(a, b, h)`, `Sphere(O, R)`, `CircumSphere(A, B, C, D)` / `MatCauNgoaiTiep`, `Cone(S, O, R)`, `Cylinder(O1, O2, R)`
    - Biến hình, giao tuyến & thiết diện thật 3D: `PerpendicularPoint(A, S, B, C)` / `Project(...)`, `ProjectParallel(P, D1, D2, A, B, C)` / `ChieuSongSong`, `Reflect(S, A, B, C)` / `Mirror(...)`, `Dilate(S, O, 0.5)`, `Intersect(S, A, A, B, C)` (giao đường-mặt), `IntersectLines(A, B, C, D)` (giao 2 đường), `IntersectPlanes(S, A, B, A, C, D)` (giao tuyến 2 mặt phẳng), `IntersectLineSphere(A, B, I, R)`, `IntersectSpherePlane(I, R, A, B, C)`, `IntersectSpheres(I1, R1, I2, R2)`, `CrossSection(A, B, C)` / `ThietDien` (hỗ trợ cả khối lõm & mặt đồng phẳng), `CrossSectionParallel(P, A, B, C, D)` / `ThietDienSongSong`
    - Mặt phẳng & đo đạc: `Plane(nx, ny, nz, d)`, `Plane(A, B, C)`, `PlaneParallel(S, A, B, C)`, `PlanePerp(M, A, B)`, `PlaneBisector(A, B)` / `MatTrungTruc`, `Distance(A, B)`, `Distance(S, A, B, C)`, `DistancePlanes(A1,B1,C1, A2,B2,C2)`, `Angle(A, B, C)`, `Dihedral(S, B, D, A)`, `CommonPerp(S, A, B, C)`, `Volume()`, `Net(0.75)`
    - **Đồ thị mặt cong `z = f(x, y)`**: ví dụ `z = 0.25*(x^2 - y^2) + 1`, `z = sin(x)*cos(y) + 1` (dùng parser đệ quy `safeEvalMathExpr`, tuyệt đối **không dùng `eval`/`new Function`** nên an toàn CSP).
  - Nút bật/tắt hiển thị (`👁️` / `🚫`) và xóa (`✕`) từng đối tượng; xóa đỉnh tự dọn sạch cạnh/mặt phụ thuộc qua `normalizeSceneSpec`.
- **Trải phẳng đa diện (`Net 0% → 100%`)**:
  - Thuật toán `computePolyhedronNet` xoay bản lề từng mặt theo trục cạnh chung (`rodriguesRotate`), hỗ trợ thanh kéo mượt theo thời gian thực và 3 mức bấm nhanh (`0%`, `50%`, `100%`).
- **Tương tác trực tiếp trên Canvas 3D**:
  - `📍 Chấm điểm 3D` hỗ trợ chọn độ cao mặt phẳng đặt điểm `z = 0, 1, 2, 3` với vòng nhắm không gian + đường dọi vuông góc xuống mặt sàn.
  - Nút bật/tắt **⤢ Mở rộng**, **Trục `Oxyz`**, **Lưới sàn**, **Nhãn (Đủ / Đỉnh / Ẩn)**, **Mặt**, **Kiểu nét đứt / Khối đặc / Khung dây**, và 5 góc nhìn chuẩn (`Góc chuẩn`, `Từ trên`, `Mặt trước`, `Mặt bên`, `Oxyz`).

---

## 3. Checklist cho Claude khi kiểm tra & ghép vào `Dobai`

1. **Cách ly hoàn toàn với CSS/JS của `Dobai/index.html`**:
   - Toàn bộ class/id của module mới bắt đầu bằng `hhkg-` (`#hhkg-entry`, `#hhkg-ov`, `.hhkg-btn`...), **tuyệt đối không dùng class `.b`** của Dobai.
   - `window.HHKG` là biến toàn cục duy nhất được gán.
   - Hộp thoại mở lên khóa cuộn bằng `html.hhkg-lock` và dùng `z-index: 2147483200`.
2. **Bảo mật & CSP**:
   - **Không** đưa khóa API vào client; toàn bộ lời gọi Gemini đi qua `POST /api/geometry/solve` ở `server.js` hoặc `Dobai/api-worker.js` đọc `env.GEMINI_API_KEY`.
   - `safeEvalMathExpr` là parser toán học thuần túy, không có `eval` hay `new Function`.
3. **Đồng bộ dữ liệu (`cfsync.js`)**:
   - Hình đã lưu trên máy ghi vào `localStorage['dc:hhkg:saved']` (prefix `dc:` hợp chuẩn backup & sync hiện hành).
4. **Kiểm tra trước khi xuất bản Cloudflare**:
   - Đặt `Dobai/hhkg.html`, thư mục `Dobai/js/hhkg-*.js` và `Dobai/vendor/three/` cạnh `Dobai/index.html` trên Cloudflare Pages.
   - Trong `Dobai/index.html` chỉ chèn đoạn liên kết nhẹ ở `handoff/index-patch-snippet.html` (tránh nhồi Three.js vào `index.html`).
   - Thêm route `POST /api/geometry/solve` từ `handoff/api-worker-geometry-snippet.js` vào `Dobai/api-worker.js` và khai báo Secret `GEMINI_API_KEY` trong Worker `dobai-api`.
   - Kiểm thử lại cả `index.html` lẫn `hhkg.html` bằng `npm test` và Playwright ở cả 2 kích thước `400×800` (điện thoại) và `1440×900` (máy tính).
