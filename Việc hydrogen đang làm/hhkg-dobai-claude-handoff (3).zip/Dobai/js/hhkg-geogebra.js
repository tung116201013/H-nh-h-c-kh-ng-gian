/* ===== hhkg-geogebra.js: GeoGebra 3D Command Parser, Algebra View Engine & Symbolic Evaluator ===== */
import {
  normalizeSceneSpec,
  midpoint,
  centroid,
  lerpPoint,
  parallelPointThrough,
  parallelogram4thVertex,
  intersectTwoLines3D,
  projectPointParallelOnPlane,
  projectPointOnLine,
  projectPointOnPlane,
  planeFrom3Points,
  planeFromPointAndNormal,
  planeParallelToPlane,
  planePerpToLine,
  angleBetweenLines,
  angleLinePlane,
  dihedralAngle,
  distanceSkewLines,
  commonPerpendicularSegment,
  intersectLinePlane,
  intersectTwoPlanes,
  reflectPointAcrossPlane,
  reflectPointAcrossPoint,
  dilatePoint,
  polyhedronVolume,
  bakeCrossSectionVertices,
  buildBaseStencilScene,
  extrudeBaseToPyramid,
  extrudeBaseToPrism,
  vecDist,
  vecSub,
  vecCross,
  vecDot,
  vecNormalize,
  vecLen,
  buildGrade11CustomSolid,
  safeEvalMathExpr,
  planeBisector,
  distanceParallelPlanes,
  circumSphere4Points,
  intersectLineSphere,
  intersectSpherePlane,
  intersectTwoSpheres,
  buildPlatonicSolid,
} from './hhkg-math.js';

export const GEOGEBRA_QUICK_COMMANDS = [
  { label: 'M = (1, 0, 2)', cmd: 'M = (1, 0, 2)' },
  { label: 'Midpoint(S, C)', cmd: 'Midpoint(S, C)' },
  { label: 'ParallelLine(S, A, B)', cmd: 'ParallelLine(S, A, B)' },
  { label: 'Parallelogram(A, B, C)', cmd: 'Parallelogram(A, B, C)' },
  { label: 'FootOnLine(A, S, O)', cmd: 'FootOnLine(A, S, O)' },
  { label: 'PerpendicularPoint(A, S, B, D)', cmd: 'PerpendicularPoint(A, S, B, D)' },
  { label: 'Intersect(S, C, A, B, D)', cmd: 'Intersect(S, C, A, B, D)' },
  { label: 'CrossSection(0, 0, 1, 1.2)', cmd: 'CrossSection(0, 0, 1, 1.2)' },
  { label: 'CrossSectionParallel(M, A, B, C, D)', cmd: 'CrossSectionParallel(M, A, B, C, D)' },
  { label: 'PlaneBisector(A, C)', cmd: 'PlaneBisector(A, C)' },
  { label: 'Octahedron(2.2)', cmd: 'Octahedron(2.2)' },
  { label: 'CircumSphere(A, B, C, S)', cmd: 'CircumSphere(A, B, C, S)' },
  { label: 'Sphere(O, 1.5)', cmd: 'Sphere(O, 1.5)' },
  { label: 'IntersectSpherePlane(O, 1.5, A, B, C)', cmd: 'IntersectSpherePlane(O, 1.5, A, B, C)' },
  { label: 'Net(1)', cmd: 'Net(1)' },
  { label: 'z = 0.25*(x^2 - y^2) + 1', cmd: 'z = 0.25*(x^2 - y^2) + 1' },
];

function nextFreeId(scene, prefix = 'P') {
  const used = new Set((scene.vertices || []).map((v) => v.id));
  const pool = [prefix, 'P', 'Q', 'M', 'N', 'K', 'H', 'I', 'E', 'F', 'R', 'T'];
  for (const id of pool) {
    if (!used.has(id)) return id;
  }
  for (let i = 1; i < 60; i++) {
    if (!used.has(`${prefix}${i}`)) return `${prefix}${i}`;
  }
  return `V${Date.now() % 1000}`;
}

function splitTopArgs(str) {
  const out = [];
  let cur = '';
  let depth = 0;
  for (const ch of String(str || '')) {
    if (ch === '(' || ch === '[') depth++;
    else if (ch === ')' || ch === ']') depth = Math.max(0, depth - 1);
    if (ch === ',' && depth === 0) {
      if (cur.trim()) out.push(cur.trim());
      cur = '';
    } else {
      cur += ch;
    }
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}

function parseNum(raw) {
  const s = String(raw || '').trim();
  const direct = Number(s);
  if (Number.isFinite(direct)) return direct;
  const evaled = safeEvalMathExpr(s, {});
  return Number.isFinite(evaled) ? evaled : NaN;
}

function buildVertexMap(scene) {
  return new Map((scene.vertices || []).map((v) => [v.id, v]));
}

function getPt(vMap, token) {
  const t = String(token || '').trim();
  return vMap.get(t) || vMap.get(t.toUpperCase()) || null;
}

/**
 * Executes a GeoGebra 3D Command or Algebra equation against the current scene.
 * Pure & deterministic — returns `{ ok, message, scene, crossPlane?, netRatio?, showOxyz? }`.
 */
export function executeGeoGebraCommand(rawInput, currentScene) {
  const input = String(rawInput || '').trim();
  if (!input) {
    return { ok: false, message: 'Vui lòng nhập lệnh GeoGebra (ví dụ: M = (1,0,2), Midpoint(S,C), z = x^2 - y^2).' };
  }

  const next = normalizeSceneSpec(structuredClone(currentScene || {}));
  const vMap = buildVertexMap(next);

  // 1. Check 3D Surface equation: "z = f(x, y)"
  const surfEq = /^z\s*=\s*(.+)$/i.exec(input);
  if (surfEq) {
    const expr = surfEq[1].trim();
    const testVal = safeEvalMathExpr(expr, { x: 0.5, y: 0.5 });
    if (!Number.isFinite(testVal) && !Number.isFinite(safeEvalMathExpr(expr, { x: 1, y: 1 }))) {
      return { ok: false, message: `Biểu thức mặt cong không hợp lệ: z = ${expr}` };
    }
    next.surfaces.push({ expr, range: 2.8, label: `z = ${expr}`, hidden: false });
    next.showOxyz = true;
    return {
      ok: true,
      message: `Đã vẽ mặt cong z = ${expr} trên hệ trục Oxyz.`,
      scene: normalizeSceneSpec(next),
    };
  }

  // 2. Check optional assignment "Name = ..."
  let assignName = '';
  let rhs = input;
  const assignMatch = /^([A-Za-z][A-Za-z0-9']*)\s*=\s*(.+)$/.exec(input);
  if (assignMatch && assignMatch[1].toLowerCase() !== 'z') {
    assignName = assignMatch[1].trim();
    rhs = assignMatch[2].trim();
  }

  // 3. Coordinate tuple "(x, y, z)" or "(x, y)"
  const tupleMatch = /^\((.+)\)$/.exec(rhs);
  if (tupleMatch && !/^[A-Za-z]+\s*\(/.test(rhs)) {
    const nums = splitTopArgs(tupleMatch[1]).map(parseNum);
    if (nums.length >= 2 && nums.length <= 3 && nums.every(Number.isFinite)) {
      const id = assignName || nextFreeId(next, 'P');
      const pt = { id, x: nums[0], y: nums[1], z: nums[2] ?? 0, role: 'aux', hidden: false };
      const idx = next.vertices.findIndex((v) => v.id === id);
      if (idx >= 0) next.vertices[idx] = pt;
      else next.vertices.push(pt);
      return {
        ok: true,
        message: `Đã đặt điểm ${id} = (${pt.x}; ${pt.y}; ${pt.z}).`,
        scene: normalizeSceneSpec(next),
      };
    }
  }

  // 4. Function-style command "CommandName(arg1, arg2, ...)"
  const fnMatch = /^([A-Za-zÀ-ỹ_][A-Za-zÀ-ỹ0-9_]*)\s*\((.*)\)$/i.exec(rhs);
  if (!fnMatch) {
    return { ok: false, message: `Không nhận diện được cú pháp "${input}". Thử: M = (1, 0, 2), Midpoint(S, C), Sphere(O, 1.5), Net(1).` };
  }

  const cmd = fnMatch[1].toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const args = splitTopArgs(fnMatch[2]);

  const upsertVertex = (id, pt, role = 'aux') => {
    const idx = next.vertices.findIndex((v) => v.id === id);
    const nv = { id, x: pt.x, y: pt.y, z: pt.z, role, hidden: false };
    if (idx >= 0) next.vertices[idx] = nv;
    else next.vertices.push(nv);
    return nv;
  };

  // Point(x, y, z) / Diem(x, y, z)
  if (cmd === 'point' || cmd === 'diem') {
    const nums = args.map(parseNum);
    if (nums.length < 2 || nums.some((n) => !Number.isFinite(n))) {
      return { ok: false, message: 'Cú pháp: Point(x, y, z) với x, y, z là số thực.' };
    }
    const id = assignName || nextFreeId(next, 'P');
    const pt = upsertVertex(id, { x: nums[0], y: nums[1], z: nums[2] ?? 0 });
    return { ok: true, message: `Đã tạo điểm ${id}(${pt.x}; ${pt.y}; ${pt.z}).`, scene: normalizeSceneSpec(next) };
  }

  // Midpoint(A, B) / TrungDiem(A, B)
  if (cmd === 'midpoint' || cmd === 'trungdiem') {
    const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]);
    if (!a || !b) return { ok: false, message: 'Không tìm thấy 2 đỉnh để dựng trung điểm.' };
    const id = assignName || nextFreeId(next, 'M');
    const m = midpoint(a, b);
    upsertVertex(id, m, 'aux');
    return { ok: true, message: `Đã dựng trung điểm ${id} của ${a.id}${b.id} = (${m.x.toFixed(2)}; ${m.y.toFixed(2)}; ${m.z.toFixed(2)}).`, scene: normalizeSceneSpec(next) };
  }

  // Centroid(A, B, C, ...) / TrongTam(A, B, C)
  if (cmd === 'centroid' || cmd === 'trongtam') {
    const pts = args.map((t) => getPt(vMap, t)).filter(Boolean);
    if (pts.length < 3) return { ok: false, message: 'Cần ít nhất 3 đỉnh để dựng trọng tâm.' };
    const id = assignName || nextFreeId(next, 'G');
    const g = centroid(pts);
    upsertVertex(id, g, 'center');
    return { ok: true, message: `Đã dựng trọng tâm ${id} = (${g.x.toFixed(2)}; ${g.y.toFixed(2)}; ${g.z.toFixed(2)}).`, scene: normalizeSceneSpec(next) };
  }

  // Segment(A, B) / Line(A, B) / DoanThang(A, B)
  if (cmd === 'segment' || cmd === 'line' || cmd === 'doanthang' || cmd === 'duongthang') {
    const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]);
    if (!a || !b || a.id === b.id) return { ok: false, message: 'Cần 2 đỉnh phân biệt để nối đoạn thẳng.' };
    const style = ['solid', 'dashed', 'highlight', 'altitude'].includes(args[2]) ? args[2] : 'solid';
    next.edges = next.edges.filter((e) => !((e.from === a.id && e.to === b.id) || (e.from === b.id && e.to === a.id)));
    next.edges.push({ from: a.id, to: b.id, style, label: '' });
    return { ok: true, message: `Đã nối đoạn ${a.id}${b.id} (độ dài ${vecDist(a, b).toFixed(3)}).`, scene: normalizeSceneSpec(next) };
  }

  // Vector(A, B) / Vecto(A, B)
  if (cmd === 'vector' || cmd === 'vecto') {
    const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]);
    if (!a || !b || a.id === b.id) return { ok: false, message: 'Cần 2 đỉnh để dựng véc-tơ.' };
    const d = vecSub(b, a);
    next.vectors.push({ from: a.id, to: b.id, color: '#7C3AED', label: assignName || `${a.id}${b.id}` });
    return { ok: true, message: `Véc-tơ ${a.id}${b.id} = (${d.x.toFixed(2)}; ${d.y.toFixed(2)}; ${d.z.toFixed(2)}), |${a.id}${b.id}| = ${vecLen(d).toFixed(3)}.`, scene: normalizeSceneSpec(next) };
  }

  // Polygon(A, B, C, ...) / DaGiac(...)
  if (cmd === 'polygon' || cmd === 'dagiac') {
    const pts = args.map((t) => getPt(vMap, t)).filter(Boolean);
    if (pts.length < 3) return { ok: false, message: 'Đa giác cần ít nhất 3 đỉnh.' };
    const ids = pts.map((p) => p.id);
    next.faces.push({ vertices: ids, color: '#F59E0B', opacity: 0.24, label: assignName || `(${ids.join('')})` });
    for (let i = 0; i < ids.length; i++) {
      const u = ids[i], w = ids[(i + 1) % ids.length];
      if (!next.edges.some((e) => (e.from === u && e.to === w) || (e.from === w && e.to === u))) {
        next.edges.push({ from: u, to: w, style: 'solid', label: '' });
      }
    }
    return { ok: true, message: `Đã tạo mặt đa giác (${ids.join('')}).`, scene: normalizeSceneSpec(next) };
  }

  // Pyramid(base1, base2, ..., Apex)
  if (cmd === 'pyramid' || cmd === 'chop') {
    const pts = args.map((t) => getPt(vMap, t)).filter(Boolean);
    if (pts.length < 4) return { ok: false, message: 'Cú pháp: Pyramid(A, B, C, [D], S) với điểm cuối là đỉnh S.' };
    const apex = pts[pts.length - 1];
    const base = pts.slice(0, -1);
    const bIds = base.map((p) => p.id);
    next.faces.push({ vertices: bIds, color: '#3B82F6', opacity: 0.16 });
    for (let i = 0; i < bIds.length; i++) {
      const u = bIds[i], w = bIds[(i + 1) % bIds.length];
      next.edges.push({ from: u, to: w, style: 'solid', label: '' });
      next.edges.push({ from: apex.id, to: u, style: 'solid', label: '' });
      next.faces.push({ vertices: [apex.id, u, w], color: '#60A5FA', opacity: 0.15 });
    }
    const sc = normalizeSceneSpec(next);
    return { ok: true, message: `Đã dựng hình chóp ${apex.id}.${bIds.join('')} (V ≈ ${polyhedronVolume(sc).toFixed(3)}).`, scene: sc };
  }

  // Extrude(A, B, C, ..., height) / Prism(...)
  if (cmd === 'extrude' || cmd === 'prism' || cmd === 'langtru') {
    const hVal = parseNum(args[args.length - 1]);
    if (!Number.isFinite(hVal) || args.length < 4) {
      return { ok: false, message: 'Cú pháp: Extrude(A, B, C, h) với h là chiều cao.' };
    }
    const base = args.slice(0, -1).map((t) => getPt(vMap, t)).filter(Boolean);
    if (base.length < 3) return { ok: false, message: 'Đáy cần ít nhất 3 đỉnh hợp lệ.' };
    const pl = planeFrom3Points(base[0], base[1], base[2]);
    let n = pl.valid ? pl.normal : { x: 0, y: 0, z: 1 };
    if (n.z < 0) n = { x: -n.x, y: -n.y, z: -n.z };
    const bIds = base.map((p) => p.id);
    const tIds = [];
    for (const p of base) {
      const tid = vMap.has(`${p.id}'`) ? nextFreeId(next, p.id) : `${p.id}'`;
      tIds.push(tid);
      upsertVertex(tid, { x: p.x + n.x * hVal, y: p.y + n.y * hVal, z: p.z + n.z * hVal }, 'primary');
    }
    next.faces.push({ vertices: bIds, color: '#3B82F6', opacity: 0.16 });
    next.faces.push({ vertices: tIds, color: '#10B981', opacity: 0.18 });
    for (let i = 0; i < bIds.length; i++) {
      const j = (i + 1) % bIds.length;
      next.edges.push({ from: bIds[i], to: bIds[j], style: 'solid', label: '' });
      next.edges.push({ from: tIds[i], to: tIds[j], style: 'solid', label: '' });
      next.edges.push({ from: bIds[i], to: tIds[i], style: i === 0 ? 'altitude' : 'solid', label: '' });
      next.faces.push({ vertices: [bIds[i], bIds[j], tIds[j], tIds[i]], color: '#60A5FA', opacity: 0.14 });
    }
    const sc = normalizeSceneSpec(next);
    return { ok: true, message: `Đã dựng khối lăng trụ cao h = ${hVal} (V ≈ ${polyhedronVolume(sc).toFixed(3)}).`, scene: sc };
  }

  // Cube(a) / LapPhuong(a)
  if (cmd === 'cube' || cmd === 'lapphuong') {
    const a = parseNum(args[0] ?? 2.6);
    const side = Number.isFinite(a) && a > 0 ? Math.min(5, Math.max(1, a)) : 2.6;
    const built = buildGrade11CustomSolid({ shape: 'hinh-hop', base: 'vuong', a: side, h: side });
    return {
      ok: true,
      message: `Đã dựng hình lập phương cạnh ${side} (V = ${(side ** 3).toFixed(3)}).`,
      scene: built.scene,
      title: `Hình lập phương (cạnh ${side})`,
      formula: `V = ${side}³ = ${(side ** 3).toFixed(2)}`,
      replaceSolid: true,
    };
  }

  // Frustum(a, b, h) / ChopCut(a, b, h)
  if (cmd === 'frustum' || cmd === 'chopcut') {
    const a = parseNum(args[0] ?? 3.2);
    const b = parseNum(args[1] ?? 1.6);
    const h = parseNum(args[2] ?? 2.6);
    const ratio = a > 0 && b > 0 ? Math.min(0.9, Math.max(0.2, b / a)) : 0.5;
    const built = buildGrade11CustomSolid({ shape: 'chop-cut-deu', a: Number.isFinite(a) ? a : 3.2, topRatio: ratio, h: Number.isFinite(h) ? h : 2.6 });
    return {
      ok: true,
      message: `Đã dựng chóp cụt tứ giác đều.`,
      scene: built.scene,
      title: built.title || 'Chóp cụt tứ giác đều',
      formula: built.formula || 'V = (h/3)·(S + S\' + √(SS\'))',
      replaceSolid: true,
    };
  }

  // Sphere(I, R) or Sphere(I, A)
  if (cmd === 'sphere' || cmd === 'matcau') {
    const c = getPt(vMap, args[0]);
    if (!c) return { ok: false, message: 'Cần đỉnh tâm I để dựng mặt cầu (ví dụ: Sphere(O, 1.5)).' };
    const ptOn = getPt(vMap, args[1]);
    const r = ptOn ? vecDist(c, ptOn) : parseNum(args[1]);
    if (!Number.isFinite(r) || r <= 0) return { ok: false, message: 'Bán kính mặt cầu phải > 0.' };
    next.spheres.push({ center: c.id, cx: c.x, cy: c.y, cz: c.z, radius: r, label: assignName || `(${c.id}; ${r.toFixed(2)})` });
    return { ok: true, message: `Đã vẽ mặt cầu tâm ${c.id}, R = ${r.toFixed(3)} (V = ${((4 / 3) * Math.PI * r ** 3).toFixed(2)}).`, scene: normalizeSceneSpec(next) };
  }

  // Cone(S, O, r) / Cylinder(O1, O2, r)
  if (cmd === 'cone' || cmd === 'hinhnon' || cmd === 'cylinder' || cmd === 'hinhtru') {
    const p1 = getPt(vMap, args[0]), p2 = getPt(vMap, args[1]);
    const r = parseNum(args[2] ?? 1.5);
    if (!p1 || !p2 || !Number.isFinite(r) || r <= 0) return { ok: false, message: 'Cần 2 đỉnh trục và bán kính r > 0.' };
    if (cmd === 'cone' || cmd === 'hinhnon') next.cones.push({ apex: p1.id, baseCenter: p2.id, radius: r });
    else next.cylinders.push({ topCenter: p1.id, bottomCenter: p2.id, radius: r });
    return { ok: true, message: `Đã dựng hình ${cmd.includes('cone') || cmd.includes('non') ? 'nón' : 'trụ'} trục ${p1.id}${p2.id}, r = ${r}.`, scene: normalizeSceneSpec(next) };
  }

  // PerpendicularPoint(P, A, B, C) / HinhChieu(P, A, B, C)
  if (cmd === 'perpendicularpoint' || cmd === 'project' || cmd === 'hinhchieu') {
    const p = getPt(vMap, args[0]), a = getPt(vMap, args[1]), b = getPt(vMap, args[2]), c = getPt(vMap, args[3]);
    if (!p || !a || !b || !c) return { ok: false, message: 'Cú pháp: PerpendicularPoint(P, A, B, C).' };
    const pr = projectPointOnPlane(p, a, b, c);
    if (!pr.valid) return { ok: false, message: 'Ba điểm mặt phẳng thẳng hàng.' };
    const id = assignName || nextFreeId(next, 'H');
    upsertVertex(id, pr.point, 'projection');
    next.edges.push({ from: p.id, to: id, style: 'altitude', label: `d=${pr.distance.toFixed(2)}` });
    next.rightAngles.push({ vertex: id, p1: p.id, p2: a.id });
    return { ok: true, message: `Hình chiếu ${id} của ${p.id} ⊥ (${a.id}${b.id}${c.id}), d = ${pr.distance.toFixed(3)}.`, scene: normalizeSceneSpec(next) };
  }

  // Reflect(P, A, B, C) or Reflect(P, O) / DoiXung
  if (cmd === 'reflect' || cmd === 'mirror' || cmd === 'doixung') {
    const p = getPt(vMap, args[0]);
    if (!p) return { ok: false, message: 'Không tìm thấy điểm gốc cần lấy đối xứng.' };
    if (args.length === 2) {
      const center = getPt(vMap, args[1]);
      if (!center) return { ok: false, message: 'Không tìm thấy tâm đối xứng.' };
      const id = assignName || nextFreeId(next, `${p.id}'`);
      const pt = reflectPointAcrossPoint(p, center);
      upsertVertex(id, pt, 'aux');
      next.edges.push({ from: p.id, to: id, style: 'dashed', label: '' });
      return { ok: true, message: `Đã dựng điểm ${id} đối xứng với ${p.id} qua ${center.id}.`, scene: normalizeSceneSpec(next) };
    }
    const a = getPt(vMap, args[1]), b = getPt(vMap, args[2]), c = getPt(vMap, args[3]);
    if (!a || !b || !c) return { ok: false, message: 'Cú pháp: Reflect(P, O) hoặc Reflect(P, A, B, C).' };
    const rf = reflectPointAcrossPlane(p, a, b, c);
    if (!rf.valid) return { ok: false, message: 'Mặt phẳng đối xứng không hợp lệ.' };
    const id = assignName || nextFreeId(next, `${p.id}'`);
    upsertVertex(id, rf.point, 'aux');
    next.edges.push({ from: p.id, to: id, style: 'dashed', label: '' });
    return { ok: true, message: `Đã dựng ${id} đối xứng ${p.id} qua (${a.id}${b.id}${c.id}).`, scene: normalizeSceneSpec(next) };
  }

  // Dilate(P, Center, k) / ViTu
  if (cmd === 'dilate' || cmd === 'vitu') {
    const p = getPt(vMap, args[0]), c = getPt(vMap, args[1]);
    const k = parseNum(args[2] ?? 2);
    if (!p || !c || !Number.isFinite(k)) return { ok: false, message: 'Cú pháp: Dilate(P, O, k).' };
    const id = assignName || nextFreeId(next, `${p.id}v`);
    const pt = dilatePoint(p, c, k);
    upsertVertex(id, pt, 'aux');
    return { ok: true, message: `Vị tự tâm ${c.id} tỉ số ${k}: ${p.id} ↦ ${id}(${pt.x.toFixed(2)}; ${pt.y.toFixed(2)}; ${pt.z.toFixed(2)}).`, scene: normalizeSceneSpec(next) };
  }

  // Intersect(A, B, C, D, E) => Line AB intersect Plane (CDE)
  if (cmd === 'intersect' || cmd === 'giaodiem') {
    if (args.length === 5) {
      const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]);
      const p1 = getPt(vMap, args[2]), p2 = getPt(vMap, args[3]), p3 = getPt(vMap, args[4]);
      if (!a || !b || !p1 || !p2 || !p3) return { ok: false, message: 'Cú pháp: Intersect(A, B, C, D, E) tìm giao điểm AB ∩ (CDE).' };
      const hit = intersectLinePlane(a, b, p1, p2, p3);
      if (!hit.valid) return { ok: false, message: hit.reason || 'Không có giao điểm duy nhất.' };
      const id = assignName || nextFreeId(next, 'I');
      upsertVertex(id, hit.point, 'projection');
      next.edges.push({ from: a.id, to: id, style: 'highlight', label: '' });
      return {
        ok: true,
        message: `Giao điểm ${id} = ${a.id}${b.id} ∩ (${p1.id}${p2.id}${p3.id}) tại (${hit.point.x.toFixed(2)}; ${hit.point.y.toFixed(2)}; ${hit.point.z.toFixed(2)}).`,
        scene: normalizeSceneSpec(next),
      };
    }
    if (args.length === 6) {
      const pts = args.map((t) => getPt(vMap, t));
      if (pts.some((x) => !x)) return { ok: false, message: 'Cú pháp: Intersect(A,B,C, D,E,F) tìm giao tuyến (ABC) ∩ (DEF).' };
      const res = intersectTwoPlanes(pts[0], pts[1], pts[2], pts[3], pts[4], pts[5]);
      if (!res.valid) return { ok: false, message: res.reason };
      const id1 = nextFreeId(next, 'I');
      upsertVertex(id1, res.segA, 'aux');
      const vMap2 = buildVertexMap(next);
      void vMap2;
      const id2 = nextFreeId(next, 'J');
      upsertVertex(id2, res.segB, 'aux');
      next.edges.push({ from: id1, to: id2, style: 'highlight', label: 'd' });
      return {
        ok: true,
        message: `Đã dựng đường giao tuyến ${id1}${id2} của hai mặt phẳng.`,
        scene: normalizeSceneSpec(next),
      };
    }
    return { ok: false, message: 'Dùng Intersect(A,B, C,D,E) cho giao điểm hoặc Intersect(A,B,C, D,E,F) cho giao tuyến.' };
  }

  // IntersectPlanes(A1,B1,C1, A2,B2,C2)
  if (cmd === 'intersectplanes' || cmd === 'giaotuyen') {
    const pts = args.map((t) => getPt(vMap, t));
    if (pts.length < 6 || pts.some((x) => !x)) {
      return { ok: false, message: 'Cú pháp: IntersectPlanes(A, B, C, S, B, D).' };
    }
    const res = intersectTwoPlanes(pts[0], pts[1], pts[2], pts[3], pts[4], pts[5]);
    if (!res.valid) return { ok: false, message: res.reason };
    const id1 = nextFreeId(next, 'I');
    upsertVertex(id1, res.segA, 'aux');
    const id2 = nextFreeId(next, 'J');
    upsertVertex(id2, res.segB, 'aux');
    next.edges.push({ from: id1, to: id2, style: 'highlight', label: 'giao tuyến' });
    return { ok: true, message: `Đã vẽ giao tuyến ${id1}${id2}.`, scene: normalizeSceneSpec(next) };
  }

  // Plane(A, B, C) or Plane(nx, ny, nz, d) -> activates live cross-section plane!
  if (cmd === 'plane' || cmd === 'matphang') {
    if (args.length === 3) {
      const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]), c = getPt(vMap, args[2]);
      if (!a || !b || !c) return { ok: false, message: 'Không tìm thấy 3 đỉnh của mặt phẳng.' };
      const pl = planeFrom3Points(a, b, c);
      if (!pl.valid) return { ok: false, message: 'Ba điểm thẳng hàng, không xác định được mặt phẳng.' };
      const pn = planeFromPointAndNormal(a, pl.normal);
      return {
        ok: true,
        message: `Mặt phẳng (${a.id}${b.id}${c.id}): ${pn.nx}x + ${pn.ny}y + ${pn.nz}z = ${pn.d}`,
        scene: next,
        crossPlane: { nx: pn.nx, ny: pn.ny, nz: pn.nz, d: pn.d },
      };
    }
    if (args.length === 4) {
      const nums = args.map(parseNum);
      if (nums.some((n) => !Number.isFinite(n))) return { ok: false, message: 'Hệ số mặt phẳng không hợp lệ.' };
      return {
        ok: true,
        message: `Đã bật mặt phẳng ${nums[0]}x + ${nums[1]}y + ${nums[2]}z = ${nums[3]}.`,
        scene: next,
        crossPlane: { nx: nums[0], ny: nums[1], nz: nums[2], d: nums[3] },
      };
    }
    return { ok: false, message: 'Cú pháp: Plane(A, B, C) hoặc Plane(nx, ny, nz, d).' };
  }

  if (cmd === 'planeparallel') {
    const p = getPt(vMap, args[0]), a = getPt(vMap, args[1]), b = getPt(vMap, args[2]), c = getPt(vMap, args[3]);
    if (!p || !a || !b || !c) return { ok: false, message: 'Cú pháp: PlaneParallel(P, A, B, C).' };
    const pn = planeParallelToPlane(p, a, b, c);
    return { ok: true, message: `Mặt phẳng qua ${p.id} // (${a.id}${b.id}${c.id}).`, scene: next, crossPlane: { nx: pn.nx, ny: pn.ny, nz: pn.nz, d: pn.d } };
  }

  if (cmd === 'planeperp') {
    const p = getPt(vMap, args[0]), a = getPt(vMap, args[1]), b = getPt(vMap, args[2]);
    if (!p || !a || !b) return { ok: false, message: 'Cú pháp: PlanePerp(P, A, B).' };
    const pn = planePerpToLine(p, a, b);
    return { ok: true, message: `Mặt phẳng qua ${p.id} ⊥ ${a.id}${b.id}.`, scene: next, crossPlane: { nx: pn.nx, ny: pn.ny, nz: pn.nz, d: pn.d } };
  }

  // Distance(...) / Angle(...) / Dihedral(...) / Volume()
  if (cmd === 'distance' || cmd === 'khoangcach') {
    if (args.length === 2) {
      const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]);
      if (!a || !b) return { ok: false, message: 'Không tìm thấy 2 đỉnh.' };
      return { ok: true, message: `d(${a.id}, ${b.id}) = ${vecDist(a, b).toFixed(4)}`, scene: next };
    }
    if (args.length === 4) {
      const p = getPt(vMap, args[0]), a = getPt(vMap, args[1]), b = getPt(vMap, args[2]), c = getPt(vMap, args[3]);
      if (!p || !a || !b || !c) return { ok: false, message: 'Không tìm thấy 4 đỉnh.' };
      const pr = projectPointOnPlane(p, a, b, c);
      const sk = distanceSkewLines(p, a, b, c);
      return {
        ok: true,
        message: `d(${p.id}, (${a.id}${b.id}${c.id})) = ${pr.distance.toFixed(4)} · d(${p.id}${a.id}, ${b.id}${c.id}) = ${sk.distance.toFixed(4)}`,
        scene: next,
      };
    }
  }

  if (cmd === 'angle' || cmd === 'goc') {
    if (args.length === 3) {
      // GeoGebra Angle(A, B, C) has vertex at middle point B
      const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]), c = getPt(vMap, args[2]);
      if (!a || !b || !c) return { ok: false, message: 'Cú pháp: Angle(A, B, C) với B là đỉnh góc.' };
      const ang = angleBetweenLines(b, a, b, c);
      return { ok: true, message: `∠${a.id}${b.id}${c.id} = ${ang.deg.toFixed(2)}°`, scene: next };
    }
    if (args.length === 5) {
      const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]), p1 = getPt(vMap, args[2]), p2 = getPt(vMap, args[3]), p3 = getPt(vMap, args[4]);
      if (!a || !b || !p1 || !p2 || !p3) return { ok: false, message: 'Cú pháp: Angle(A, B, C, D, E).' };
      const lp = angleLinePlane(a, b, p1, p2, p3);
      return { ok: true, message: `∠(${a.id}${b.id}, (${p1.id}${p2.id}${p3.id})) = ${lp.deg.toFixed(2)}°`, scene: next };
    }
  }

  if (cmd === 'dihedral' || cmd === 'nhidien') {
    const p1 = getPt(vMap, args[0]), a = getPt(vMap, args[1]), b = getPt(vMap, args[2]), p2 = getPt(vMap, args[3]);
    if (!p1 || !a || !b || !p2) return { ok: false, message: 'Cú pháp: Dihedral(P1, A, B, P2).' };
    const d = dihedralAngle(p1, a, b, p2);
    return { ok: true, message: `Góc nhị diện [${p1.id}, ${a.id}${b.id}, ${p2.id}] = ${d.deg.toFixed(2)}°`, scene: next };
  }

  if (cmd === 'commonperp' || cmd === 'vuonggocchung') {
    const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]), c = getPt(vMap, args[2]), d = getPt(vMap, args[3]);
    if (!a || !b || !c || !d) return { ok: false, message: 'Cú pháp: CommonPerp(A, B, C, D).' };
    const cp = commonPerpendicularSegment(a, b, c, d);
    if (!cp.valid) return { ok: false, message: 'Không tính được đoạn vuông góc chung.' };
    const mId = nextFreeId(next, 'M');
    upsertVertex(mId, cp.p1, 'aux');
    const nId = nextFreeId(next, 'N');
    upsertVertex(nId, cp.p2, 'aux');
    next.edges.push({ from: mId, to: nId, style: 'highlight', label: `d=${cp.distance.toFixed(2)}` });
    return { ok: true, message: `Đoạn VG chung ${mId}${nId} = ${cp.distance.toFixed(3)}.`, scene: normalizeSceneSpec(next) };
  }

  if (cmd === 'volume' || cmd === 'thetich') {
    return { ok: true, message: `Thể tích khối đa diện hiện tại: V ≈ ${polyhedronVolume(next).toFixed(4)} đvtt`, scene: next };
  }

  // Net(ratio) / KhaiTrien(ratio)
  if (cmd === 'net' || cmd === 'khaitrien') {
    const r = parseNum(args[0] ?? 1);
    const ratio = Number.isFinite(r) ? Math.min(1, Math.max(0, r)) : 1;
    return { ok: true, message: `Đã đặt độ mở khai triển đa diện (Net) = ${Math.round(ratio * 100)}%.`, scene: next, netRatio: ratio };
  }

  // Ratio point Divide/Ratio(A, B, k)
  if (cmd === 'ratio' || cmd === 'lerp' || cmd === 'chiadoan') {
    const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]);
    const k = parseNum(args[2] ?? 0.5);
    if (!a || !b || !Number.isFinite(k)) return { ok: false, message: 'Cú pháp: Ratio(A, B, k).' };
    const id = assignName || nextFreeId(next, 'K');
    const pt = lerpPoint(a, b, k);
    upsertVertex(id, pt, 'aux');
    return { ok: true, message: `Đã dựng điểm ${id} trên ${a.id}${b.id} với k = ${k}.`, scene: normalizeSceneSpec(next) };
  }

  // ParallelLine(P, A, B, [scale]) / SongSong(P, A, B)
  if (cmd === 'parallelline' || cmd === 'parallelthrough' || cmd === 'songsong') {
    const p = getPt(vMap, args[0]), a = getPt(vMap, args[1]), b = getPt(vMap, args[2]);
    const k = args[3] !== undefined ? parseNum(args[3]) : 1;
    if (!p || !a || !b || !Number.isFinite(k)) return { ok: false, message: 'Cú pháp: ParallelLine(P, A, B, [tỉ_lệ]).' };
    const id = assignName || nextFreeId(next, 'Q');
    const pt = parallelPointThrough(p, a, b, k);
    upsertVertex(id, pt, 'aux');
    next.edges.push({ from: p.id, to: id, style: 'highlight', label: `// ${a.id}${b.id}` });
    return {
      ok: true,
      message: `Đã dựng đường thẳng ${p.id}${id} qua ${p.id} song song với ${a.id}${b.id}.`,
      scene: normalizeSceneSpec(next),
    };
  }

  // Parallelogram(A, B, C) / HinhBinhHanh(A, B, C) -> constructs D = A + C - B
  if (cmd === 'parallelogram' || cmd === 'hinhbinhhanh') {
    const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]), c = getPt(vMap, args[2]);
    if (!a || !b || !c) return { ok: false, message: 'Cú pháp: Parallelogram(A, B, C) dựng đỉnh thứ 4 hoàn chỉnh hình bình hành ABCD.' };
    const id = assignName || nextFreeId(next, 'D');
    const pt = parallelogram4thVertex(a, b, c);
    upsertVertex(id, pt, 'primary');
    const ensureEdge = (u, w, style = 'solid') => {
      if (!next.edges.some((e) => (e.from === u && e.to === w) || (e.from === w && e.to === u))) {
        next.edges.push({ from: u, to: w, style, label: '' });
      }
    };
    ensureEdge(a.id, b.id, 'solid');
    ensureEdge(b.id, c.id, 'solid');
    ensureEdge(c.id, id, 'solid');
    ensureEdge(id, a.id, 'solid');
    next.faces.push({ vertices: [a.id, b.id, c.id, id], color: '#3B82F6', opacity: 0.16 });
    return {
      ok: true,
      message: `Đã dựng đỉnh ${id} hoàn chỉnh hình bình hành ${a.id}${b.id}${c.id}${id}.`,
      scene: normalizeSceneSpec(next),
    };
  }

  // FootOnLine(P, A, B) / HinhChieuDuong(P, A, B)
  if (cmd === 'footonline' || cmd === 'perpendicularline' || cmd === 'hinhchieuduong') {
    const p = getPt(vMap, args[0]), a = getPt(vMap, args[1]), b = getPt(vMap, args[2]);
    if (!p || !a || !b) return { ok: false, message: 'Cú pháp: FootOnLine(P, A, B) hạ chân đường cao PH ⊥ AB.' };
    const pr = projectPointOnLine(p, a, b);
    if (!pr.valid) return { ok: false, message: 'Hai điểm A, B trùng nhau.' };
    const id = assignName || nextFreeId(next, 'H');
    upsertVertex(id, pr.point, 'projection');
    next.edges.push({ from: p.id, to: id, style: 'altitude', label: `d=${pr.distance.toFixed(2)}` });
    next.rightAngles.push({ vertex: id, p1: p.id, p2: a.id });
    return {
      ok: true,
      message: `Hình chiếu ${id} của ${p.id} lên đường thẳng ${a.id}${b.id}, PH = ${pr.distance.toFixed(3)}.`,
      scene: normalizeSceneSpec(next),
    };
  }

  // ProjectParallel(P, D1, D2, A, B, C) / ChieuSongSong(P, D1, D2, A, B, C)
  if (cmd === 'projectparallel' || cmd === 'chieusongsong') {
    const p = getPt(vMap, args[0]), d1 = getPt(vMap, args[1]), d2 = getPt(vMap, args[2]);
    const a = getPt(vMap, args[3]), b = getPt(vMap, args[4]), c = getPt(vMap, args[5]);
    if (!p || !d1 || !d2 || !a || !b || !c) {
      return { ok: false, message: 'Cú pháp: ProjectParallel(P, D1, D2, A, B, C) — chiếu P theo phương D1D2 lên (ABC).' };
    }
    const pr = projectPointParallelOnPlane(p, d1, d2, a, b, c);
    if (!pr.valid) return { ok: false, message: pr.reason || 'Không chiếu song song được.' };
    const id = assignName || nextFreeId(next, `${p.id}'`);
    upsertVertex(id, pr.point, 'projection');
    next.edges.push({ from: p.id, to: id, style: 'dashed', label: `// ${d1.id}${d2.id}` });
    return {
      ok: true,
      message: `Ảnh chiếu song song ${id} của ${p.id} theo phương ${d1.id}${d2.id} lên (${a.id}${b.id}${c.id}).`,
      scene: normalizeSceneSpec(next),
    };
  }

  // IntersectLines(A, B, C, D) / GiaoHaiDuong(A, B, C, D)
  if (cmd === 'intersectlines' || cmd === 'giaohaiduong') {
    const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]), c = getPt(vMap, args[2]), d = getPt(vMap, args[3]);
    if (!a || !b || !c || !d) return { ok: false, message: 'Cú pháp: IntersectLines(A, B, C, D) tìm giao điểm AB ∩ CD.' };
    const hit = intersectTwoLines3D(a, b, c, d);
    if (!hit.valid) return { ok: false, message: hit.reason || 'Hai đường thẳng không cắt nhau.' };
    const id = assignName || nextFreeId(next, 'I');
    upsertVertex(id, hit.point, 'projection');
    if (!hit.onSegmentAB) next.edges.push({ from: b.id, to: id, style: 'dashed', label: '' });
    if (!hit.onSegmentCD) next.edges.push({ from: d.id, to: id, style: 'dashed', label: '' });
    return {
      ok: true,
      message: `Giao điểm ${id} = ${a.id}${b.id} ∩ ${c.id}${d.id} = (${hit.point.x.toFixed(2)}; ${hit.point.y.toFixed(2)}; ${hit.point.z.toFixed(2)}).`,
      scene: normalizeSceneSpec(next),
    };
  }

  // CrossSection(A, B, C) or CrossSection(nx, ny, nz, d) / ThietDien(...) -> bakes real vertices & edges!
  if (cmd === 'crosssection' || cmd === 'thietdien') {
    let planeSpec = null;
    if (args.length === 3) {
      const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]), c = getPt(vMap, args[2]);
      if (!a || !b || !c) return { ok: false, message: 'Cú pháp: CrossSection(A, B, C) hoặc CrossSection(nx, ny, nz, d).' };
      const pl = planeFrom3Points(a, b, c);
      if (!pl.valid) return { ok: false, message: 'Ba điểm thẳng hàng.' };
      planeSpec = planeFromPointAndNormal(a, pl.normal);
    } else if (args.length === 4) {
      const nums = args.map(parseNum);
      if (nums.some((n) => !Number.isFinite(n))) return { ok: false, message: 'Hệ số mặt phẳng cắt không hợp lệ.' };
      planeSpec = { nx: nums[0], ny: nums[1], nz: nums[2], d: nums[3] };
    } else {
      return { ok: false, message: 'Cú pháp: CrossSection(A, B, C) hoặc CrossSection(nx, ny, nz, d).' };
    }
    const baked = bakeCrossSectionVertices(next, planeSpec, assignName || 'E');
    if (!baked.ok) return { ok: false, message: baked.message };
    return {
      ok: true,
      message: baked.message,
      scene: baked.scene,
      crossPlane: planeSpec,
    };
  }

  // CrossSectionParallel(P, A, B, C, D) -> Bài 12 KNTT plane through P // AB & // CD
  if (cmd === 'crosssectionparallel' || cmd === 'thietdiensongsong') {
    const p = getPt(vMap, args[0]);
    const a = getPt(vMap, args[1]), b = getPt(vMap, args[2]);
    const c = getPt(vMap, args[3]), d = getPt(vMap, args[4]);
    if (!p || !a || !b || !c || !d) {
      return { ok: false, message: 'Cú pháp: CrossSectionParallel(P, A, B, C, D) — cắt qua P song song AB và CD.' };
    }
    const nRaw = vecCross(vecSub(b, a), vecSub(d, c));
    if (vecLen(nRaw) < 1e-5) {
      return { ok: false, message: `${a.id}${b.id} và ${c.id}${d.id} song song hoặc trùng phương nên chưa xác định duy nhất mặt phẳng.` };
    }
    const planeSpec = planeFromPointAndNormal(p, nRaw);
    const baked = bakeCrossSectionVertices(next, planeSpec, assignName || 'E');
    if (!baked.ok) return { ok: false, message: baked.message };
    return {
      ok: true,
      message: `Thiết diện qua ${p.id} // ${a.id}${b.id}, ${c.id}${d.id}: ${baked.crossSection.shapeName} (${baked.crossSection.vertexIds.join('')}).`,
      scene: baked.scene,
      crossPlane: planeSpec,
    };
  }

  // RegularPyramid(n, r, h) / ChopDeu(n, r, h) & RegularPrism(n, r, h) / LangTruDeu(n, r, h)
  if (cmd === 'regularpyramid' || cmd === 'chopdeu' || cmd === 'regularprism' || cmd === 'langtrudeu') {
    const n = Math.max(3, Math.min(6, Math.round(parseNum(args[0] ?? 4) || 4)));
    const r = Math.max(1.0, Math.min(3.6, parseNum(args[1] ?? 2.0) || 2.0));
    const h = Math.max(1.0, Math.min(5.5, parseNum(args[2] ?? 3.0) || 3.0));
    const kind = n === 3 ? 'tam-giac-deu' : n === 5 ? 'ngu-giac' : n === 6 ? 'luc-giac' : 'vuong';
    const isPyr = cmd === 'regularpyramid' || cmd === 'chopdeu';
    const baseScene = buildBaseStencilScene(kind, { radius: r });
    const built = isPyr
      ? extrudeBaseToPyramid(baseScene, { height: h })
      : extrudeBaseToPrism(baseScene, { height: h });
    return {
      ok: built.ok,
      message: built.message,
      scene: built.scene,
      title: isPyr ? `Chóp ${n}-giác đều` : `Lăng trụ ${n}-giác đều`,
      formula: isPyr ? 'V = (1/3)·S_đáy·h' : 'V = S_đáy·h',
      replaceSolid: built.ok,
    };
  }

  // Platonic Solids: Tetrahedron(a), Octahedron(a), Dodecahedron(a), Icosahedron(a)
  if (
    cmd === 'tetrahedron' || cmd === 'tudiendeu' ||
    cmd === 'octahedron' || cmd === 'batdiendeu' ||
    cmd === 'dodecahedron' || cmd === 'thapnhidiendeu' ||
    cmd === 'icosahedron' || cmd === 'nhithapdiendeu'
  ) {
    const kindMap = {
      tetrahedron: 'tetrahedron',
      tudiendeu: 'tetrahedron',
      octahedron: 'octahedron',
      batdiendeu: 'octahedron',
      dodecahedron: 'dodecahedron',
      thapnhidiendeu: 'dodecahedron',
      icosahedron: 'icosahedron',
      nhithapdiendeu: 'icosahedron',
    };
    const rawLen = args[0] !== undefined ? parseNum(args[0]) : 2.2;
    const edgeLen = Number.isFinite(rawLen) && rawLen > 0 ? rawLen : 2.2;
    const built = buildPlatonicSolid(kindMap[cmd], edgeLen);
    return {
      ok: true,
      message: `Đã dựng khối ${built.name} cạnh ${edgeLen} (V ≈ ${built.volume.toFixed(3)}).`,
      scene: built.scene,
      title: built.name,
      formula: `Cạnh a = ${edgeLen} · V ≈ ${built.volume.toFixed(3)}`,
      replaceSolid: true,
    };
  }

  // PlaneBisector(A, B) / MatTrungTruc(A, B)
  if (cmd === 'planebisector' || cmd === 'mattrungtruc') {
    const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]);
    if (!a || !b) return { ok: false, message: 'Cú pháp: PlaneBisector(A, B) dựng mặt phẳng trung trực đoạn AB.' };
    const pb = planeBisector(a, b);
    if (!pb.valid) return { ok: false, message: pb.reason || 'Hai điểm trùng nhau.' };
    const planeObj = {
      label: assignName || `trung trực ${a.id}${b.id}`,
      nx: pb.nx,
      ny: pb.ny,
      nz: pb.nz,
      d: pb.d,
      color: '#0EA5E9',
      hidden: false,
    };
    next.planes.push(planeObj);
    return {
      ok: true,
      message: `Mặt phẳng trung trực ${a.id}${b.id}: ${pb.nx}x + ${pb.ny}y + ${pb.nz}z = ${pb.d}.`,
      scene: normalizeSceneSpec(next),
      crossPlane: { nx: pb.nx, ny: pb.ny, nz: pb.nz, d: pb.d },
    };
  }

  // DistancePlanes(A1,B1,C1, A2,B2,C2) / KhoangCachHaiMatPhang(...)
  if (cmd === 'distanceplanes' || cmd === 'khoangcachhaimatphang') {
    const pts = args.map((t) => getPt(vMap, t));
    if (pts.length < 6 || pts.some((x) => !x)) {
      return { ok: false, message: 'Cú pháp: DistancePlanes(A1, B1, C1, A2, B2, C2).' };
    }
    const res = distanceParallelPlanes(pts[0], pts[1], pts[2], pts[3], pts[4], pts[5]);
    if (!res.valid) return { ok: false, message: res.reason };
    return {
      ok: true,
      message: res.parallel
        ? `Hai mặt phẳng song song có khoảng cách d = ${res.distance.toFixed(4)}.`
        : 'Hai mặt phẳng cắt nhau nên khoảng cách d = 0.',
      scene: next,
    };
  }

  // CircumSphere(A, B, C, D) / MatCauNgoaiTiep(A, B, C, D)
  if (cmd === 'circumsphere' || cmd === 'matcaungoaitiep') {
    const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]), c = getPt(vMap, args[2]), d = getPt(vMap, args[3]);
    if (!a || !b || !c || !d) return { ok: false, message: 'Cú pháp: CircumSphere(A, B, C, D) với 4 đỉnh không đồng phẳng.' };
    const cs = circumSphere4Points(a, b, c, d);
    if (!cs.valid) return { ok: false, message: cs.reason };
    const cid = assignName || nextFreeId(next, 'I');
    upsertVertex(cid, cs.center, 'center');
    next.spheres.push({
      center: cid,
      cx: cs.center.x,
      cy: cs.center.y,
      cz: cs.center.z,
      radius: cs.radius,
      label: `ngoại tiếp (${cid}; R=${cs.radius.toFixed(2)})`,
    });
    return {
      ok: true,
      message: `Mặt cầu ngoại tiếp ${a.id}${b.id}${c.id}${d.id}: tâm ${cid}(${cs.center.x.toFixed(2)}; ${cs.center.y.toFixed(2)}; ${cs.center.z.toFixed(2)}), R = ${cs.radius.toFixed(3)}.`,
      scene: normalizeSceneSpec(next),
    };
  }

  // Helper to resolve sphere (center vertex ID + radius, or existing sphere in scene)
  const resolveSphere = (centerTok, radiusTok) => {
    const cPt = getPt(vMap, centerTok);
    if (!cPt) return null;
    if (radiusTok !== undefined) {
      const rPt = getPt(vMap, radiusTok);
      const r = rPt ? vecDist(cPt, rPt) : parseNum(radiusTok);
      if (Number.isFinite(r) && r > 0) return { center: cPt, radius: r, id: cPt.id };
    }
    const found = (next.spheres || []).find((s) => s.center === cPt.id && s.radius > 0);
    if (found) return { center: cPt, radius: found.radius, id: cPt.id };
    return null;
  };

  // IntersectLineSphere(A, B, Center, [R]) / GiaoDuongMatCau(A, B, Center, [R])
  if (cmd === 'intersectlinesphere' || cmd === 'giaoduongmatcau') {
    const a = getPt(vMap, args[0]), b = getPt(vMap, args[1]);
    const sph = resolveSphere(args[2], args[3]);
    if (!a || !b || !sph) {
      return { ok: false, message: 'Cú pháp: IntersectLineSphere(A, B, Tâm, [R]).' };
    }
    const res = intersectLineSphere(a, b, sph.center, sph.radius);
    if (!res.valid) return { ok: false, message: res.reason };
    if (!res.points.length) {
      return { ok: true, message: `Đường thẳng ${a.id}${b.id} không cắt mặt cầu tâm ${sph.id}.`, scene: next };
    }
    const createdIds = [];
    for (let i = 0; i < res.points.length; i++) {
      const pid = assignName && res.points.length === 1
        ? assignName
        : nextFreeId(next, i === 0 ? 'K' : 'L');
      upsertVertex(pid, res.points[i], 'projection');
      createdIds.push(pid);
    }
    return {
      ok: true,
      message: res.status === 'TANGENT'
        ? `${a.id}${b.id} tiếp xúc mặt cầu tâm ${sph.id} tại ${createdIds[0]}.`
        : `${a.id}${b.id} cắt mặt cầu tâm ${sph.id} tại ${createdIds.join(' và ')}.`,
      scene: normalizeSceneSpec(next),
    };
  }

  // IntersectSpherePlane(Center, [R], P1, P2, P3) / GiaoMatCauMatPhang(...)
  if (cmd === 'intersectsphereplane' || cmd === 'giaomatcaumatphang') {
    let sph = null;
    let pStart = 1;
    if (args.length === 5) {
      sph = resolveSphere(args[0], args[1]);
      pStart = 2;
    } else if (args.length === 4) {
      sph = resolveSphere(args[0], undefined);
      pStart = 1;
    }
    const p1 = getPt(vMap, args[pStart]), p2 = getPt(vMap, args[pStart + 1]), p3 = getPt(vMap, args[pStart + 2]);
    if (!sph || !p1 || !p2 || !p3) {
      return { ok: false, message: 'Cú pháp: IntersectSpherePlane(Tâm, R, A, B, C) hoặc bỏ R nếu mặt cầu đã tồn tại.' };
    }
    const res = intersectSpherePlane(sph.center, sph.radius, p1, p2, p3);
    if (!res.valid) return { ok: false, message: res.reason };
    if (res.status === 'DISJOINT') {
      return { ok: true, message: `Mặt phẳng (${p1.id}${p2.id}${p3.id}) không cắt mặt cầu (d = ${res.distance.toFixed(3)} > R = ${sph.radius.toFixed(3)}).`, scene: next };
    }
    const hid = assignName || nextFreeId(next, 'H');
    upsertVertex(hid, res.center, 'projection');
    next.edges.push({ from: sph.id, to: hid, style: 'altitude', label: `d=${res.distance.toFixed(2)}` });
    if (res.status === 'TANGENT') {
      return { ok: true, message: `Mặt phẳng tiếp xúc mặt cầu tại ${hid} (d = R = ${sph.radius.toFixed(3)}).`, scene: normalizeSceneSpec(next) };
    }
    next.circles.push({
      center: res.center,
      normal: res.normal,
      radius: res.rCircle,
      color: '#EA580C',
      label: `(C: ${hid}; r=${res.rCircle.toFixed(2)})`,
    });
    return {
      ok: true,
      message: `Giao tuyến là đường tròn tâm ${hid}, bán kính r = ${res.rCircle.toFixed(3)}.`,
      scene: normalizeSceneSpec(next),
    };
  }

  // IntersectSpheres(C1, R1, C2, R2) or IntersectSpheres(C1, C2)
  if (cmd === 'intersectspheres' || cmd === 'giaohaimatcau') {
    let s1 = null, s2 = null;
    if (args.length === 4) {
      s1 = resolveSphere(args[0], args[1]);
      s2 = resolveSphere(args[2], args[3]);
    } else if (args.length === 2) {
      s1 = resolveSphere(args[0], undefined);
      s2 = resolveSphere(args[1], undefined);
    }
    if (!s1 || !s2) {
      return { ok: false, message: 'Cú pháp: IntersectSpheres(I1, R1, I2, R2) hoặc IntersectSpheres(I1, I2).' };
    }
    const res = intersectTwoSpheres(s1.center, s1.radius, s2.center, s2.radius);
    if (!res.valid) return { ok: false, message: res.reason };
    if (res.status === 'DISJOINT') {
      return { ok: true, message: `Hai mặt cầu không cắt nhau (d = ${res.distance.toFixed(3)}).`, scene: next };
    }
    const hid = assignName || nextFreeId(next, 'H');
    upsertVertex(hid, res.center, 'projection');
    if (res.status === 'TANGENT') {
      return { ok: true, message: `Hai mặt cầu tiếp xúc tại ${hid}.`, scene: normalizeSceneSpec(next) };
    }
    next.circles.push({
      center: res.center,
      normal: res.normal,
      radius: res.rCircle,
      color: '#EA580C',
      label: `(C: ${hid}; r=${res.rCircle.toFixed(2)})`,
    });
    return {
      ok: true,
      message: `Hai mặt cầu cắt nhau theo đường tròn tâm ${hid}, r = ${res.rCircle.toFixed(3)}.`,
      scene: normalizeSceneSpec(next),
    };
  }

  return { ok: false, message: `Chưa hỗ trợ lệnh "${fnMatch[1]}". Bấm chip gợi ý bên trên để chèn nhanh.` };
}

/**
 * Deterministic AI Geometry Payload Refiner (GeoGebra Kernel Verification Pipeline):
 * Executes symbolic `constructions` from AI onto `payload.scene` so midpoints, perpendicular feet,
 * parallel lines, intersections, and cross-sections obtain exact IEEE 3D coordinates, and attaches `mathCheck`.
 */
export function refineAiGeometryPayload(rawPayload) {
  if (!rawPayload || typeof rawPayload !== 'object') return rawPayload;
  const out = structuredClone(rawPayload);
  const rawCrossSection = Array.isArray(out.scene?.crossSection) ? out.scene.crossSection.map((x) => String(x || '').trim()).filter(Boolean) : [];
  let scene = normalizeSceneSpec(out.scene || {});
  const applied = [];

  if (Array.isArray(out.constructions)) {
    for (const item of out.constructions) {
      const cmdStr = typeof item === 'string' ? item : String(item?.command || '').trim();
      if (!cmdStr) continue;
      const res = executeGeoGebraCommand(cmdStr, scene);
      applied.push({
        command: cmdStr,
        note: typeof item === 'object' && item?.note ? String(item.note) : '',
        ok: Boolean(res.ok),
        message: res.message,
      });
      if (res.ok && res.scene) {
        scene = normalizeSceneSpec(res.scene);
      }
    }
  }

  // Auto-tag internal diagonal/auxiliary faces so Two-Pass Depth-Occlusion uses only exterior boundary faces
  const primaryVerts = scene.vertices.filter((v) => !v.hidden && (v.role === 'primary' || !v.role));
  if (scene.faces.length >= 5 && primaryVerts.length >= 4) {
    const vById = new Map(scene.vertices.map((v) => [v.id, v]));
    for (const f of scene.faces) {
      if (f.internal || f.hidden || !Array.isArray(f.vertices) || f.vertices.length < 3) continue;
      const pts = f.vertices.map((id) => vById.get(id)).filter(Boolean);
      if (pts.length < 3) continue;
      const pl = planeFrom3Points(pts[0], pts[1], pts[2]);
      if (!pl.valid) continue;
      let hasPos = false;
      let hasNeg = false;
      for (const pv of primaryVerts) {
        const sd = vecDot(vecSub(pv, pts[0]), pl.normal);
        if (sd > 0.12) hasPos = true;
        else if (sd < -0.12) hasNeg = true;
        if (hasPos && hasNeg) break;
      }
      if (hasPos && hasNeg) {
        f.internal = true;
      }
    }
  }

  // Auto-sync crossSection (>= 3 IDs): ensure internal highlight face and perimeter edges exist
  const csSourceIds = rawCrossSection.length >= 3 ? rawCrossSection : (Array.isArray(scene.crossSection) ? scene.crossSection : []);
  if (csSourceIds.length >= 3) {
    const vSet = new Set(scene.vertices.map((v) => v.id));
    const csIds = csSourceIds.filter((id) => vSet.has(id));
    if (csIds.length >= 3) {
      scene.crossSection = csIds;
      const csSet = new Set(csIds);
      const hasFace = scene.faces.some(
        (f) => Array.isArray(f.vertices) && f.vertices.length === csIds.length && f.vertices.every((id) => csSet.has(id)),
      );
      if (!hasFace) {
        scene.faces.push({
          vertices: csIds,
          color: '#F59E0B',
          opacity: 0.32,
          label: csIds.join(''),
          internal: true,
        });
      }
      for (let i = 0; i < csIds.length; i++) {
        const u = csIds[i];
        const w = csIds[(i + 1) % csIds.length];
        const exists = scene.edges.some((e) => (e.from === u && e.to === w) || (e.from === w && e.to === u));
        if (!exists) {
          scene.edges.push({ from: u, to: w, style: 'highlight', label: '' });
        }
      }
      scene = normalizeSceneSpec(scene);
    }
  }

  // Verify right angles geometrically (dot product near 0) and inspect edge lengths
  const vMap = new Map(scene.vertices.map((v) => [v.id, v]));
  const checks = [];
  for (const r of scene.rightAngles || []) {
    const v = vMap.get(r.vertex), p1 = vMap.get(r.p1), p2 = vMap.get(r.p2);
    if (!v || !p1 || !p2) continue;
    const u1 = vecNormalize(vecSub(p1, v));
    const u2 = vecNormalize(vecSub(p2, v));
    const cosErr = Math.abs(vecDot(u1, u2));
    if (cosErr < 0.04) {
      checks.push(`✓ Góc ${p1.id}${v.id}${p2.id} = 90° chính xác`);
    } else {
      checks.push(`⚠ Kiểm tra góc ${p1.id}${v.id}${p2.id} (lệch ${(90 - (Math.acos(Math.min(1, cosErr)) * 180) / Math.PI).toFixed(1)}°)`);
    }
  }

  // Check parallel edge pairs among base/auxiliary edges (helpful for Chapter IV Song song)
  const validEdges = (scene.edges || []).filter((e) => !e.hidden && vMap.has(e.from) && vMap.has(e.to));
  let zeroLenCount = 0;
  for (const e of validEdges) {
    if (vecDist(vMap.get(e.from), vMap.get(e.to)) < 1e-4) zeroLenCount++;
  }
  if (zeroLenCount > 0) {
    checks.push(`⚠ Có ${zeroLenCount} cạnh trùng điểm đầu cuối`);
  }

  const vol = polyhedronVolume(scene);
  if (vol > 0.01) {
    checks.push(`✓ Thể tích khối kiểm chứng V ≈ ${vol.toFixed(3)} đvtt`);
  }
  out.scene = scene;
  out.appliedConstructions = applied;
  out.mathCheck = {
    vertexCount: scene.vertices.length,
    edgeCount: scene.edges.length,
    volume: Number(vol.toFixed(3)),
    verifiedConstructions: applied.filter((x) => x.ok).length,
    totalConstructions: applied.length,
    checks: checks.slice(0, 8),
  };
  return out;
}

