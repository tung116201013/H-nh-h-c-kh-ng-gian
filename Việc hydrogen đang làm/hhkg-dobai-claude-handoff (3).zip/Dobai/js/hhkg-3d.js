import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { mathToThree, threeToMath, vecSub, vecNormalize, vecCross, vecAdd, vecScale, vecDist, sampleSurfaceZ, computeCameraFraming } from './hhkg-math.js';

const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _proj = new THREE.Vector3();

function detectSoftwareGl() {
  try {
    const gl = document.createElement('canvas').getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) || '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function disposeObjectTree(root) {
  root.traverse((obj) => {
    if (obj.geometry) obj.geometry.dispose();
    if (obj.material) {
      if (Array.isArray(obj.material)) obj.material.forEach((m) => m.dispose());
      else obj.material.dispose();
    }
  });
}

function createFloorGridTexture() {
  const cv = document.createElement('canvas');
  cv.width = 512;
  cv.height = 512;
  const ctx = cv.getContext('2d');
  ctx.fillStyle = '#F3F7FD';
  ctx.fillRect(0, 0, 512, 512);

  // Subtle sub-grid
  ctx.strokeStyle = 'rgba(148, 163, 184, 0.22)';
  ctx.lineWidth = 1;
  const step = 32;
  for (let i = 0; i <= 512; i += step) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, 512);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(512, i);
    ctx.stroke();
  }
  // Major grid
  ctx.strokeStyle = 'rgba(100, 116, 139, 0.35)';
  ctx.lineWidth = 1.5;
  for (let i = 0; i <= 512; i += 128) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, 512);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(512, i);
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(4, 4);
  return tex;
}

export class Geometry3DViewer {
  constructor(mountEl, labelLayerEl, options = {}) {
    this.mountEl = mountEl;
    this.labelLayerEl = labelLayerEl;
    this.onVertexClick = options.onVertexClick || null;
    this.isSoftwareGl = detectSoftwareGl();

    this.sceneData = null;
    this.crossSectionData = null;
    this.highlight = { vertices: new Set(), edges: new Set(), faceVertices: new Set() };
    this.selectedVertexIds = new Set();
    this.viewStyle = 'textbook-3d'; // 'textbook-3d' | 'solid' | 'wireframe'
    this.projectionMode = '3d'; // '3d' | '2d'
    this.dockCollapsed = false;
    this._orthoHalfHeight = 2.8;
    this._lastCamPreset = 'default';
    this._sceneThreePts = [];
    this.autoRotate = false;
    this.labelsMode = 'all'; // 'all' | 'vertices' | 'none'
    this.showFaces = true;
    this.showGrid = true;
    this.showAxes = null; // null = follow sceneData.showOxyz, boolean = override
    this.placePointMode = false;
    this.placePlaneZ = 0;
    this.onPlacePoint = options.onPlacePoint || null;
    this.netRatio = 0;

    this._renderBusy = false;
    this._renderDirty = false;
    this._frameId = 0;
    this._disposed = false;
    this._camAnim = null;
    this._lastTime = performance.now();

    this._labelItems = [];
    this._clickableMeshes = [];

    this._initScene();
    this._bindEvents();
    this.resize();
    this.requestRender();
  }

  _initScene() {
    const w = Math.max(200, this.mountEl.clientWidth || 400);
    const h = Math.max(200, this.mountEl.clientHeight || 320);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xF3F7FD);
    this.scene.fog = new THREE.Fog(0xF3F7FD, 20, 48);

    this._perspCam = new THREE.PerspectiveCamera(38, w / h, 0.1, 100);
    this._perspCam.position.set(6.2, 4.8, 6.8);
    const aspect = w / h;
    const hh = this._orthoHalfHeight;
    this._orthoCam = new THREE.OrthographicCamera(-hh * aspect, hh * aspect, hh, -hh, 0.05, 100);
    this._orthoCam.position.copy(this._perspCam.position);
    this.camera = this._perspCam;

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      preserveDrawingBuffer: this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setSize(w, h);
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.mountEl.appendChild(this.renderer.domElement);

    // Mandatory studio environment reflection
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this._envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environment = this._envTex;
    pmrem.dispose();

    // Warm/cool 3-point lighting rig
    const hemi = new THREE.HemisphereLight(0xDBEAFE, 0x94A3B8, 0.85);
    this.scene.add(hemi);

    const keyLight = new THREE.DirectionalLight(0xFFF7ED, 1.35);
    keyLight.position.set(6, 10, 7);
    if (!this.isSoftwareGl) {
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.set(1024, 1024);
      keyLight.shadow.camera.near = 1;
      keyLight.shadow.camera.far = 25;
      keyLight.shadow.camera.left = -6;
      keyLight.shadow.camera.right = 6;
      keyLight.shadow.camera.top = 6;
      keyLight.shadow.camera.bottom = -6;
      keyLight.shadow.bias = -0.0005;
      keyLight.shadow.normalBias = 0.02;
    }
    this.scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0xBFDBFE, 0.55);
    rimLight.position.set(-7, 4, -6);
    this.scene.add(rimLight);

    // Ground drafting plane (offset -0.02 below z=0 to avoid z-fighting with base faces)
    this._floorTex = createFloorGridTexture();
    this._floorTex.anisotropy = this.renderer.capabilities.getMaxAnisotropy();
    const floorGeo = new THREE.CircleGeometry(14, 48);
    const floorMat = new THREE.MeshStandardMaterial({
      map: this._floorTex,
      color: 0xffffff,
      roughness: 0.92,
      metalness: 0.02,
    });
    this.floorMesh = new THREE.Mesh(floorGeo, floorMat);
    this.floorMesh.rotation.x = -Math.PI / 2;
    this.floorMesh.position.y = -0.025;
    this.floorMesh.receiveShadow = !this.isSoftwareGl;
    this.scene.add(this.floorMesh);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = !this.isSoftwareGl;
    this.controls.dampingFactor = 0.08;
    this.controls.minDistance = 2.4;
    this.controls.maxDistance = 24;
    this.controls.minZoom = 0.45;
    this.controls.maxZoom = 4.2;
    this.controls.maxPolarAngle = Math.PI * 0.85;
    this.controls.target.set(0, 1.1, 0);
    this.controls.update();

    this.figureGroup = new THREE.Group();
    this.oxyzGroup = new THREE.Group();
    this.crossGroup = new THREE.Group();
    this.netGroup = new THREE.Group();
    this.scene.add(this.figureGroup);
    this.scene.add(this.oxyzGroup);
    this.scene.add(this.crossGroup);
    this.scene.add(this.netGroup);

    this._raycaster = new THREE.Raycaster();
    this._pointer = new THREE.Vector2();
    this._floorPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    this._planeHit = new THREE.Vector3();

    // Subtle reticle ring + plumb line + elevation plane disc for interactive 3D point placement at z = placePlaneZ
    const retGeo = new THREE.RingGeometry(0.11, 0.17, 24);
    retGeo.rotateX(-Math.PI / 2);
    const retMat = new THREE.MeshBasicMaterial({
      color: 0x2563EB,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
      depthTest: false,
    });
    this._reticle = new THREE.Mesh(retGeo, retMat);
    this._reticle.visible = false;
    this._reticle.renderOrder = 6;
    this.scene.add(this._reticle);

    const plumbGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 1, 0)]);
    const plumbMat = new THREE.LineDashedMaterial({ color: 0x2563EB, dashSize: 0.12, gapSize: 0.08, transparent: true, opacity: 0.78 });
    this._plumbLine = new THREE.Line(plumbGeo, plumbMat);
    this._plumbLine.visible = false;
    this._plumbLine.renderOrder = 6;
    this.scene.add(this._plumbLine);

    const elevGeo = new THREE.CircleGeometry(4.5, 40);
    elevGeo.rotateX(-Math.PI / 2);
    const elevMat = new THREE.MeshBasicMaterial({
      color: 0x3B82F6,
      transparent: true,
      opacity: 0.09,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this._elevDisc = new THREE.Mesh(elevGeo, elevMat);
    this._elevDisc.visible = false;
    this._elevDisc.renderOrder = 1;
    this.scene.add(this._elevDisc);
  }

  _bindEvents() {
    this._onControlsChange = () => this.requestRender();
    this._onControlsStart = () => {
      this._camAnim = null;
    };
    this.controls.addEventListener('change', this._onControlsChange);
    this.controls.addEventListener('start', this._onControlsStart);

    this._downPos = null;
    this._onPointerDown = (e) => {
      this._downPos = { x: e.clientX, y: e.clientY };
    };
    this._onPointerUp = (e) => {
      if (!this._downPos) return;
      const dist = Math.hypot(e.clientX - this._downPos.x, e.clientY - this._downPos.y);
      this._downPos = null;
      if (dist > 6) return;

      const rect = this.renderer.domElement.getBoundingClientRect();
      this._pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this._pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      this._raycaster.setFromCamera(this._pointer, this.camera);

      // Prioritize clicking existing vertex unless strictly placing empty ground point
      if (this._clickableMeshes.length && this.onVertexClick && !this.placePointMode) {
        const hits = this._raycaster.intersectObjects(this._clickableMeshes, false);
        if (hits.length > 0 && hits[0].object.userData.vertexId) {
          this.onVertexClick(hits[0].object.userData.vertexId);
          return;
        }
      }

      if (this.placePointMode && this.onPlacePoint) {
        this._floorPlane.constant = -this.placePlaneZ;
        if (this._raycaster.ray.intersectPlane(this._floorPlane, this._planeHit)) {
          const m = threeToMath([this._planeHit.x, this.placePlaneZ, this._planeHit.z]);
          const step = e.shiftKey ? 0.25 : 0.5;
          const snap = (val) => Math.round(val / step) * step;
          const x = Math.max(-5, Math.min(5, snap(m.x)));
          const y = Math.max(-5, Math.min(5, snap(m.y)));
          const z = Math.round(this.placePlaneZ * 100) / 100;
          this.onPlacePoint({ x, y, z });
        }
      }
    };
    this._lastHoverCheck = 0;
    this._onPointerMove = (e) => {
      const rect = this.renderer.domElement.getBoundingClientRect();
      this._pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      this._pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      if (this.placePointMode) {
        this.renderer.domElement.style.cursor = 'crosshair';
        this._floorPlane.constant = -this.placePlaneZ;
        this._raycaster.setFromCamera(this._pointer, this.camera);
        if (this._raycaster.ray.intersectPlane(this._floorPlane, this._planeHit)) {
          const m = threeToMath([this._planeHit.x, this.placePlaneZ, this._planeHit.z]);
          const step = e.shiftKey ? 0.25 : 0.5;
          const snap = (val) => Math.round(val / step) * step;
          const sx = Math.max(-5, Math.min(5, snap(m.x)));
          const sy = Math.max(-5, Math.min(5, snap(m.y)));
          const [tx, ty, tz] = mathToThree({ x: sx, y: sy, z: this.placePlaneZ + 0.01 });
          this._reticle.position.set(tx, ty, tz);
          this._reticle.visible = true;
          if (this._plumbLine) {
            if (Math.abs(this.placePlaneZ) > 0.05) {
              const posAttr = this._plumbLine.geometry.getAttribute('position');
              posAttr.setXYZ(0, tx, 0, tz);
              posAttr.setXYZ(1, tx, ty, tz);
              posAttr.needsUpdate = true;
              this._plumbLine.computeLineDistances();
              this._plumbLine.visible = true;
            } else {
              this._plumbLine.visible = false;
            }
          }
          this.requestRender();
        }
        return;
      }
      if (this._reticle && this._reticle.visible) {
        this._reticle.visible = false;
        if (this._plumbLine) this._plumbLine.visible = false;
        this.requestRender();
      }
      const now = performance.now();
      if (now - this._lastHoverCheck < 50 || !this._clickableMeshes.length) return;
      this._lastHoverCheck = now;
      this._raycaster.setFromCamera(this._pointer, this.camera);
      const hits = this._raycaster.intersectObjects(this._clickableMeshes, false);
      this.renderer.domElement.style.cursor = hits.length > 0 ? 'pointer' : 'grab';
    };
    this.renderer.domElement.addEventListener('pointerdown', this._onPointerDown);
    this.renderer.domElement.addEventListener('pointerup', this._onPointerUp);
    this.renderer.domElement.addEventListener('pointermove', this._onPointerMove);

    if (typeof ResizeObserver !== 'undefined') {
      this._ro = new ResizeObserver(() => this.resize());
      this._ro.observe(this.mountEl);
    }
  }

  _updateOrthoFrustum(w, h) {
    if (!this._orthoCam) return;
    const aspect = Math.max(0.25, w / Math.max(1, h));
    const hh = Math.max(1.5, this._orthoHalfHeight || 2.8);
    const hw = hh * aspect;
    this._orthoCam.left = -hw;
    this._orthoCam.right = hw;
    this._orthoCam.top = hh;
    this._orthoCam.bottom = -hh;
    this._orthoCam.updateProjectionMatrix();
  }

  resize() {
    if (this._disposed) return;
    const w = Math.max(160, this.mountEl.clientWidth || 320);
    const h = Math.max(160, this.mountEl.clientHeight || 280);
    this._perspCam.aspect = w / h;
    this._perspCam.updateProjectionMatrix();
    this._updateOrthoFrustum(w, h);
    this.renderer.setSize(w, h);
    if (this.scene && this.camera) {
      this.renderer.render(this.scene, this.camera);
      this._updateLabels();
    }
    this.requestRender();
  }

  _afterDraw(cb) {
    const gl = this.renderer.getContext();
    if (!gl || typeof gl.fenceSync !== 'function') {
      this._frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this._disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this._frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this._frameId = window.setTimeout(cb, 80);
      }
    };
    this._frameId = window.setTimeout(poll, 5);
  }

  requestRender() {
    if (this._disposed || this._renderBusy) {
      if (!this._disposed) this._renderDirty = true;
      return;
    }
    this._renderBusy = true;
    this._frameId = requestAnimationFrame((now) => {
      if (this._disposed) return;
      const dt = Math.min(0.08, Math.max(0.001, (now - this._lastTime) / 1000));
      this._lastTime = now;
      this._renderDirty = false;

      let keepGoing = false;
      if (this._camAnim) {
        const lambda = 7.5;
        this.camera.position.x = THREE.MathUtils.damp(this.camera.position.x, this._camAnim.pos.x, lambda, dt);
        this.camera.position.y = THREE.MathUtils.damp(this.camera.position.y, this._camAnim.pos.y, lambda, dt);
        this.camera.position.z = THREE.MathUtils.damp(this.camera.position.z, this._camAnim.pos.z, lambda, dt);
        this.controls.target.x = THREE.MathUtils.damp(this.controls.target.x, this._camAnim.target.x, lambda, dt);
        this.controls.target.y = THREE.MathUtils.damp(this.controls.target.y, this._camAnim.target.y, lambda, dt);
        this.controls.target.z = THREE.MathUtils.damp(this.controls.target.z, this._camAnim.target.z, lambda, dt);
        const rem = this.camera.position.distanceTo(this._camAnim.pos) + this.controls.target.distanceTo(this._camAnim.target);
        if (rem < 0.025) {
          this.camera.position.copy(this._camAnim.pos);
          this.controls.target.copy(this._camAnim.target);
          this._camAnim = null;
        } else {
          keepGoing = true;
        }
      }

      this.controls.autoRotate = this.autoRotate && !this.isSoftwareGl;
      this.controls.autoRotateSpeed = 1.6;
      const damped = this.controls.update();
      if (damped && this.controls.enableDamping) keepGoing = true;
      if (this.controls.autoRotate) keepGoing = true;

      this.renderer.render(this.scene, this.camera);
      this._updateLabels();

      const done = () => {
        this._renderBusy = false;
        if (this._renderDirty || keepGoing) this.requestRender();
      };
      if (this.isSoftwareGl) this._afterDraw(done);
      else done();
    });
  }

  setViewStyle(style) {
    this.viewStyle = style;
    if (this.sceneData) this.setScene(this.sceneData, { keepCamera: true });
  }

  setDockCollapsed(collapsed) {
    this.dockCollapsed = Boolean(collapsed);
    this._updateLabels();
    this.requestRender();
  }

  setProjectionMode(mode) {
    const nextMode = mode === '2d' ? '2d' : '3d';
    if (this.projectionMode === nextMode) return;
    this.projectionMode = nextMode;

    const prevPos = this.camera.position.clone();
    const prevTarget = this.controls.target.clone();

    if (nextMode === '2d') {
      this.camera = this._orthoCam;
      this.scene.background = new THREE.Color(0xFFFFFF);
      this.scene.fog = null;
      if (this.floorMesh && this.floorMesh.material) {
        this.floorMesh.material.transparent = true;
        this.floorMesh.material.opacity = 0.28;
      }
      this._orthoCam.zoom = 1;
    } else {
      this.camera = this._perspCam;
      this.scene.background = new THREE.Color(0xF3F7FD);
      this.scene.fog = new THREE.Fog(0xF3F7FD, 20, 48);
      if (this.floorMesh && this.floorMesh.material) {
        this.floorMesh.material.transparent = false;
        this.floorMesh.material.opacity = 1.0;
      }
    }

    this.camera.position.copy(prevPos);
    this.controls.object = this.camera;
    this.controls.target.copy(prevTarget);
    this.controls.update();

    const targetPreset = nextMode === '2d'
      ? '2d-oblique'
      : (this._lastCamPreset === '2d-oblique' ? 'default' : this._lastCamPreset);
    this.setCameraPreset(targetPreset);
    this.resize();
  }

  setLabelsMode(mode) {
    this.labelsMode = mode || 'all';
    this._updateLabels();
  }

  setShowFaces(show) {
    this.showFaces = Boolean(show);
    if (this.sceneData) this.setScene(this.sceneData, { keepCamera: true });
  }

  setShowGrid(show) {
    this.showGrid = Boolean(show);
    this.floorMesh.visible = this.showGrid;
    this.requestRender();
  }

  setShowAxes(show) {
    this.showAxes = show === null ? null : Boolean(show);
    if (this.sceneData) this.setScene(this.sceneData, { keepCamera: true });
  }

  setPlacePointMode(on, cb) {
    this.placePointMode = Boolean(on);
    if (cb) this.onPlacePoint = cb;
    this.renderer.domElement.style.cursor = this.placePointMode ? 'crosshair' : 'grab';
    if (!this.placePointMode) {
      if (this._reticle) this._reticle.visible = false;
      if (this._plumbLine) this._plumbLine.visible = false;
      if (this._elevDisc) this._elevDisc.visible = false;
      this.requestRender();
    } else if (this._elevDisc) {
      this._elevDisc.position.y = this.placePlaneZ;
      this._elevDisc.visible = Math.abs(this.placePlaneZ) > 0.05;
      this.requestRender();
    }
  }

  setPlacePlaneZ(z) {
    const val = Number(z);
    this.placePlaneZ = Number.isFinite(val) ? Math.max(-2, Math.min(6, val)) : 0;
    this._floorPlane.constant = -this.placePlaneZ;
    if (this._elevDisc) {
      this._elevDisc.position.y = this.placePlaneZ;
      this._elevDisc.visible = this.placePointMode && Math.abs(this.placePlaneZ) > 0.05;
    }
    this.requestRender();
  }

  setAutoRotate(on) {
    this.autoRotate = Boolean(on);
    this.requestRender();
  }

  setSelectedVertices(ids) {
    this.selectedVertexIds = new Set(ids || []);
    if (this.sceneData) this.setScene(this.sceneData, { keepCamera: true });
  }

  setHighlight(hl) {
    const h = hl || {};
    this.highlight = {
      vertices: new Set(h.vertices || []),
      edges: new Set((h.edges || []).map((e) => (e.from < e.to ? `${e.from}|${e.to}` : `${e.to}|${e.from}`))),
      faceVertices: new Set(h.faceVertices || []),
    };
    if (this.sceneData) this.setScene(this.sceneData, { keepCamera: true });
  }

  setCameraPreset(preset) {
    const pKey = preset || (this.projectionMode === '2d' ? '2d-oblique' : 'default');
    this._lastCamPreset = pKey;
    const w = Math.max(180, this.mountEl.clientWidth || 400);
    const h = Math.max(180, this.mountEl.clientHeight || 320);
    const topPad = w < 640 ? 92 : 52;
    const botPad = w < 640 ? (this.dockCollapsed ? 56 : 100) : (this.dockCollapsed ? 52 : 90);
    const sidePad = w < 640 ? 28 : 34;

    const framing = computeCameraFraming(this._sceneThreePts, {
      width: w,
      height: h,
      fovDeg: 38,
      preset: pKey,
      topPad,
      botPad,
      sidePad,
    });

    this._orthoHalfHeight = framing.orthoHalfHeight;
    if (this._orthoCam) {
      this._orthoCam.zoom = 1;
      this._updateOrthoFrustum(w, h);
    }

    const pos = new THREE.Vector3(framing.position.x, framing.position.y, framing.position.z);
    const center = new THREE.Vector3(framing.target.x, framing.target.y, framing.target.z);

    if (this.isSoftwareGl) {
      this._camAnim = null;
      this._perspCam.position.copy(pos);
      this._orthoCam.position.copy(pos);
      this.controls.target.copy(center);
      this.controls.update();
    } else {
      this._camAnim = { pos, target: center };
    }
    this.requestRender();
  }

  setScene(sceneData, opts = {}) {
    this.sceneData = sceneData;
    disposeObjectTree(this.figureGroup);
    this.figureGroup.clear();
    disposeObjectTree(this.oxyzGroup);
    this.oxyzGroup.clear();
    this._clickableMeshes = [];
    this._labelItems = [];

    if (!sceneData || !Array.isArray(sceneData.vertices) || !sceneData.vertices.length) {
      this._sceneThreePts = [];
      this._updateLabels();
      this.requestRender();
      return;
    }

    const vMap = new Map();
    const tMap = new Map();
    const box = new THREE.Box3();
    const threePts = [];

    for (const v of sceneData.vertices) {
      vMap.set(v.id, v);
      const [tx, ty, tz] = mathToThree(v);
      const vec = new THREE.Vector3(tx, ty, tz);
      tMap.set(v.id, vec);
      if (!v.hidden) {
        box.expandByPoint(vec);
        threePts.push({ x: tx, y: ty, z: tz });
      }
    }

    this._sceneThreePts = threePts;
    const center = new THREE.Vector3();
    const size = new THREE.Vector3();
    box.getCenter(center);
    box.getSize(size);
    this._sceneCenter = center;
    this._sceneSizeY = size.y || 2.6;
    this._sceneRadius = Math.max(2.2, size.length() * 0.65);

    // Adjust floor height just beneath lowest vertex
    const minY = box.min.y;
    this.floorMesh.position.y = Math.min(-0.025, minY - 0.03);

    // 1. Oxyz axes if enabled
    const wantAxes = this.showAxes !== null ? this.showAxes : Boolean(sceneData.showOxyz);
    if (wantAxes) {
      this._buildOxyzAxes();
    }

    const hasStepHighlight =
      this.highlight.vertices.size > 0 ||
      this.highlight.edges.size > 0 ||
      this.highlight.faceVertices.size > 0;

    // 1b. Collect exterior boundary hull faces for Two-Pass Dynamic Hidden-Line Occlusion
    const hullFaceList = [];
    const candidateFaces = (sceneData.faces || []).filter((f) => !f.hidden && !f.internal && Array.isArray(f.vertices) && f.vertices.length >= 3);
    const hullVertexIds = new Set();
    for (const f of candidateFaces) {
      for (const id of f.vertices) {
        if (tMap.has(id)) hullVertexIds.add(id);
      }
    }
    const hullVerts = [...hullVertexIds].map((id) => tMap.get(id));
    for (const f of candidateFaces) {
      const pts = f.vertices.map((id) => tMap.get(id)).filter(Boolean);
      if (pts.length < 3) continue;
      // Half-space check: exterior face keeps all solid vertices on one side
      const e1 = _v1.subVectors(pts[1], pts[0]);
      const e2 = _v2.subVectors(pts[2], pts[0]);
      const normal = new THREE.Vector3().crossVectors(e1, e2);
      if (normal.lengthSq() < 1e-8) continue;
      normal.normalize();
      let hasPos = false;
      let hasNeg = false;
      for (const hv of hullVerts) {
        const sd = normal.dot(_v1.subVectors(hv, pts[0]));
        if (sd > 0.08) hasPos = true;
        else if (sd < -0.08) hasNeg = true;
        if (hasPos && hasNeg) break;
      }
      if (!(hasPos && hasNeg)) {
        hullFaceList.push(pts);
      }
    }

    const isConvexHull = hullFaceList.length >= 4 && hullFaceList.length === candidateFaces.length;
    const depthFaces = isConvexHull
      ? hullFaceList
      : candidateFaces.map((f) => f.vertices.map((id) => tMap.get(id)).filter(Boolean)).filter((pts) => pts.length >= 3);

    const useDynamicOcclusion =
      this.viewStyle === 'textbook-3d' &&
      this.netRatio <= 0.05 &&
      depthFaces.length >= 4;

    // Build inward-oriented hull planes to cleanly classify strictly-interior auxiliary edges (e.g. AH, SO)
    const hullPlanesInward = [];
    if (useDynamicOcclusion && isConvexHull) {
      const hullCenter = new THREE.Vector3();
      hullVerts.forEach((v) => hullCenter.add(v));
      if (hullVerts.length) hullCenter.divideScalar(hullVerts.length);
      for (const pts of hullFaceList) {
        const e1 = new THREE.Vector3().subVectors(pts[1], pts[0]);
        const e2 = new THREE.Vector3().subVectors(pts[2], pts[0]);
        const n = new THREE.Vector3().crossVectors(e1, e2);
        if (n.lengthSq() < 1e-8) continue;
        n.normalize();
        if (n.dot(_v1.subVectors(hullCenter, pts[0])) < 0) n.negate();
        hullPlanesInward.push({ pt: pts[0], n });
      }
    }
    const isStrictlyInteriorEdge = (p1, p2) => {
      if (hullPlanesInward.length < 4) return false;
      const mid = _v2.copy(p1).add(p2).multiplyScalar(0.5);
      for (const hp of hullPlanesInward) {
        if (hp.n.dot(_v1.subVectors(mid, hp.pt)) <= 0.04) return false;
      }
      return true;
    };

    if (useDynamicOcclusion) {
      const depthPositions = [];
      for (const pts of depthFaces) {
        for (let i = 1; i < pts.length - 1; i++) {
          depthPositions.push(
            pts[0].x, pts[0].y, pts[0].z,
            pts[i].x, pts[i].y, pts[i].z,
            pts[i + 1].x, pts[i + 1].y, pts[i + 1].z,
          );
        }
      }
      if (depthPositions.length >= 9) {
        const depthGeo = new THREE.BufferGeometry();
        depthGeo.setAttribute('position', new THREE.Float32BufferAttribute(depthPositions, 3));
        const depthMat = new THREE.MeshBasicMaterial({
          colorWrite: false,
          depthWrite: true,
          depthTest: true,
          transparent: false,
          side: THREE.DoubleSide,
          polygonOffset: true,
          polygonOffsetFactor: isConvexHull ? 2 : 3,
          polygonOffsetUnits: isConvexHull ? 2 : 3,
        });
        const depthMesh = new THREE.Mesh(depthGeo, depthMat);
        depthMesh.renderOrder = 0;
        this.figureGroup.add(depthMesh);
      }
    }

    // 2. Faces (suppressed softly when Net unfold > 0.05 so unfolded net reads cleanly)
    if (this.showFaces && this.viewStyle !== 'wireframe' && this.netRatio <= 0.05) {
      for (const f of sceneData.faces || []) {
        if (f.hidden) continue;
        const pts = f.vertices.map((id) => tMap.get(id)).filter(Boolean);
        if (pts.length < 3) continue;
        const positions = [];
        for (let i = 1; i < pts.length - 1; i++) {
          positions.push(pts[0].x, pts[0].y, pts[0].z, pts[i].x, pts[i].y, pts[i].z, pts[i + 1].x, pts[i + 1].y, pts[i + 1].z);
        }
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        geo.computeVertexNormals();

        const isFaceHighlighted =
          this.highlight.faceVertices.size >= 3 &&
          f.vertices.every((id) => this.highlight.faceVertices.has(id));

        const baseOp = this.viewStyle === 'solid' ? Math.max(0.55, (f.opacity || 0.2) * 2.4) : (f.opacity || 0.16);
        const dimFactor = hasStepHighlight && !isFaceHighlighted ? 0.55 : 1;
        const isOpaqueSolid = this.viewStyle === 'solid' && !isFaceHighlighted && !hasStepHighlight;
        const mat = new THREE.MeshPhysicalMaterial({
          color: isFaceHighlighted ? 0xF59E0B : new THREE.Color(f.color || '#3B82F6'),
          transparent: !isOpaqueSolid,
          opacity: isFaceHighlighted ? 0.42 : baseOp * dimFactor,
          roughness: 0.35,
          metalness: 0.05,
          side: THREE.DoubleSide,
          depthWrite: isOpaqueSolid,
          polygonOffset: true,
          polygonOffsetFactor: 1,
          polygonOffsetUnits: 1,
        });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.renderOrder = isOpaqueSolid ? 1 : 3;
        this.figureGroup.add(mesh);
      }
    }

    // GeoGebra DrawSegment3D / DrawPoint3D scale-aware thickness factor
    const scaleMult = Math.max(0.75, Math.min(1.45, (this._sceneRadius || 3.2) / 3.0));

    // 3. Edges (Two-Pass dynamic visible-solid / occluded-dashed in textbook-3d polyhedra; static fallback otherwise)
    for (const e of sceneData.edges || []) {
      if (e.hidden) continue;
      const p1 = tMap.get(e.from);
      const p2 = tMap.get(e.to);
      if (!p1 || !p2) continue;
      const edgeKey = e.from < e.to ? `${e.from}|${e.to}` : `${e.to}|${e.from}`;
      const isHi = this.highlight.edges.has(edgeKey) || e.style === 'highlight';
      const isAlt = e.style === 'altitude';

      if (useDynamicOcclusion) {
        const dir = _v1.subVectors(p2, p1);
        const len = dir.length();
        const solidColor = isHi ? 0xEA580C : isAlt ? 0x059669 : 0x1E293B;
        const dashColor = isHi ? 0xEA580C : isAlt ? 0x059669 : 0x334155;
        const radius = (isHi ? 0.026 : 0.017) * scaleMult;
        const interiorOnly = isStrictlyInteriorEdge(p1, p2);

        // Pass 1 (Visible part in front of depth-prepass hull): SOLID cylinder (skipped for strictly interior segments like AH/SO)
        if (!interiorOnly && len > 1e-4) {
          const cylGeo = new THREE.CylinderGeometry(radius, radius, len, 10);
          const cylMat = new THREE.MeshStandardMaterial({
            color: solidColor,
            roughness: 0.35,
            metalness: 0.15,
            depthTest: true,
            depthFunc: THREE.LessEqualDepth,
            depthWrite: false,
          });
          const cyl = new THREE.Mesh(cylGeo, cylMat);
          cyl.position.copy(p1).addScaledVector(dir, 0.5);
          cyl.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
          cyl.renderOrder = 1;
          this.figureGroup.add(cyl);
        }

        // Pass 2 (Occluded / interior part behind depth-prepass hull): DASHED line (renders after translucent faces!)
        const lineGeo = new THREE.BufferGeometry().setFromPoints([p1, p2]);
        const lineMat = new THREE.LineDashedMaterial({
          color: dashColor,
          dashSize: (isAlt ? 0.14 : 0.13) * scaleMult,
          gapSize: 0.085 * scaleMult,
          transparent: true,
          opacity: isHi ? 0.96 : 0.88,
          depthTest: !interiorOnly,
          depthFunc: THREE.GreaterDepth,
          depthWrite: false,
        });
        const line = new THREE.Line(lineGeo, lineMat);
        line.computeLineDistances();
        line.renderOrder = 4;
        this.figureGroup.add(line);
      } else if (this.viewStyle === 'solid' || isHi || e.style === 'solid') {
        const radius = (isHi ? 0.028 : 0.017) * scaleMult;
        const dir = _v1.subVectors(p2, p1);
        const len = dir.length();
        if (len > 1e-4) {
          const cylGeo = new THREE.CylinderGeometry(radius, radius, len, 10);
          const cylMat = new THREE.MeshStandardMaterial({
            color: isHi ? 0xEA580C : 0x1E293B,
            roughness: 0.35,
            metalness: 0.15,
          });
          const cyl = new THREE.Mesh(cylGeo, cylMat);
          cyl.position.copy(p1).addScaledVector(dir, 0.5);
          cyl.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
          cyl.castShadow = !this.isSoftwareGl;
          cyl.renderOrder = 2;
          this.figureGroup.add(cyl);
        }
      } else {
        const lineGeo = new THREE.BufferGeometry().setFromPoints([p1, p2]);
        const lineMat = new THREE.LineDashedMaterial({
          color: isAlt ? 0x059669 : 0x475569,
          dashSize: isAlt ? 0.14 : 0.12,
          gapSize: isAlt ? 0.08 : 0.09,
        });
        const line = new THREE.Line(lineGeo, lineMat);
        line.computeLineDistances();
        line.renderOrder = 4;
        this.figureGroup.add(line);
      }

      if (e.label) {
        const mid = p1.clone().add(p2).multiplyScalar(0.5);
        this._labelItems.push({
          text: e.label,
          pos: mid,
          kind: 'edge',
        });
      }
    }

    // 4. Right-angle markers
    for (const r of sceneData.rightAngles || []) {
      const v = vMap.get(r.vertex), p1 = vMap.get(r.p1), p2 = vMap.get(r.p2);
      if (!v || !p1 || !p2) continue;
      const u1 = vecNormalize(vecSub(p1, v));
      const u2 = vecNormalize(vecSub(p2, v));
      const sz = 0.24;
      const a = vecAdd(v, vecScale(u1, sz));
      const b = vecAdd(a, vecScale(u2, sz));
      const c = vecAdd(v, vecScale(u2, sz));
      const pts = [a, b, c].map((pt) => new THREE.Vector3(...mathToThree(pt)));
      const geo = new THREE.BufferGeometry().setFromPoints(pts);
      const mat = new THREE.LineBasicMaterial({
        color: 0xDC2626,
        transparent: true,
        opacity: 0.92,
        depthTest: false,
        depthWrite: false,
      });
      const rLine = new THREE.Line(geo, mat);
      rLine.renderOrder = 5;
      this.figureGroup.add(rLine);
    }

    // 5. Angle arcs
    for (const ang of sceneData.angles || []) {
      const v = vMap.get(ang.vertex), p1 = vMap.get(ang.p1), p2 = vMap.get(ang.p2);
      if (!v || !p1 || !p2) continue;
      const u1 = vecNormalize(vecSub(p1, v));
      const u2 = vecNormalize(vecSub(p2, v));
      const rad = 0.42;
      const arcPts = [];
      const steps = 16;
      for (let i = 0; i <= steps; i++) {
        const t = i / steps;
        const dir = vecNormalize({
          x: u1.x * (1 - t) + u2.x * t,
          y: u1.y * (1 - t) + u2.y * t,
          z: u1.z * (1 - t) + u2.z * t,
        });
        arcPts.push(new THREE.Vector3(...mathToThree(vecAdd(v, vecScale(dir, rad)))));
      }
      const geo = new THREE.BufferGeometry().setFromPoints(arcPts);
      const mat = new THREE.LineBasicMaterial({
        color: 0xD97706,
        transparent: true,
        opacity: 0.92,
        depthTest: false,
        depthWrite: false,
      });
      const aLine = new THREE.Line(geo, mat);
      aLine.renderOrder = 5;
      this.figureGroup.add(aLine);
      if (ang.label) {
        const midDir = vecNormalize(vecAdd(u1, u2));
        const lp = vecAdd(v, vecScale(midDir, rad + 0.25));
        this._labelItems.push({
          text: ang.label,
          pos: new THREE.Vector3(...mathToThree(lp)),
          kind: 'angle',
        });
      }
    }

    // 6. Spheres, Cones, Cylinders, Vectors & 3D Surfaces z = f(x, y)
    for (const s of sceneData.spheres || []) {
      if (s.hidden) continue;
      const cPos = s.center && tMap.has(s.center)
        ? tMap.get(s.center)
        : new THREE.Vector3(...mathToThree({ x: s.cx, y: s.cy, z: s.cz }));
      const sGeo = new THREE.SphereGeometry(s.radius, 32, 24);
      const sMat = new THREE.MeshPhysicalMaterial({
        color: 0x38BDF8,
        transparent: true,
        opacity: 0.22,
        roughness: 0.15,
        metalness: 0.05,
        depthWrite: false,
        side: THREE.DoubleSide,
      });
      const mesh = new THREE.Mesh(sGeo, sMat);
      mesh.position.copy(cPos);
      mesh.renderOrder = 2;
      this.figureGroup.add(mesh);

      const eqPts = [];
      for (let i = 0; i <= 48; i++) {
        const a = (i / 48) * Math.PI * 2;
        eqPts.push(new THREE.Vector3(cPos.x + Math.cos(a) * s.radius, cPos.y, cPos.z + Math.sin(a) * s.radius));
      }
      this.figureGroup.add(new THREE.Line(
        new THREE.BufferGeometry().setFromPoints(eqPts),
        new THREE.LineBasicMaterial({ color: 0x0284C7 }),
      ));
    }

    for (const cn of sceneData.cones || []) {
      if (cn.hidden) continue;
      const apex = tMap.get(cn.apex);
      const base = tMap.get(cn.baseCenter);
      if (!apex || !base) continue;
      const dir = _v1.subVectors(apex, base);
      const h = dir.length();
      if (h < 1e-4) continue;
      const cGeo = new THREE.ConeGeometry(cn.radius, h, 36, 1, true);
      const cMat = new THREE.MeshPhysicalMaterial({
        color: 0x60A5FA,
        transparent: true,
        opacity: 0.22,
        roughness: 0.25,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const cMesh = new THREE.Mesh(cGeo, cMat);
      cMesh.position.copy(base).addScaledVector(dir, 0.5);
      cMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
      cMesh.renderOrder = 2;
      this.figureGroup.add(cMesh);

      const bPts = [];
      const q = cMesh.quaternion;
      for (let i = 0; i <= 48; i++) {
        const a = (i / 48) * Math.PI * 2;
        const pt = new THREE.Vector3(Math.cos(a) * cn.radius, 0, Math.sin(a) * cn.radius).applyQuaternion(q).add(base);
        bPts.push(pt);
      }
      this.figureGroup.add(new THREE.Line(
        new THREE.BufferGeometry().setFromPoints(bPts),
        new THREE.LineBasicMaterial({ color: 0x1D4ED8 }),
      ));
    }

    for (const cy of sceneData.cylinders || []) {
      if (cy.hidden) continue;
      const top = tMap.get(cy.topCenter);
      const bot = tMap.get(cy.bottomCenter);
      if (!top || !bot) continue;
      const dir = _v1.subVectors(top, bot);
      const h = dir.length();
      if (h < 1e-4) continue;
      const g = new THREE.CylinderGeometry(cy.radius, cy.radius, h, 36, 1, true);
      const m = new THREE.MeshPhysicalMaterial({
        color: 0x60A5FA,
        transparent: true,
        opacity: 0.22,
        roughness: 0.25,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(g, m);
      mesh.position.copy(bot).addScaledVector(dir, 0.5);
      mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
      mesh.renderOrder = 2;
      this.figureGroup.add(mesh);
    }

    for (const vc of sceneData.vectors || []) {
      if (vc.hidden) continue;
      const p1 = tMap.get(vc.from);
      const p2 = tMap.get(vc.to);
      if (!p1 || !p2) continue;
      const dir = _v1.subVectors(p2, p1);
      const len = dir.length();
      if (len < 1e-4) continue;
      const col = new THREE.Color(vc.color || '#7C3AED').getHex();
      const arrow = new THREE.ArrowHelper(dir.clone().normalize(), p1, len, col, 0.26, 0.12);
      this.figureGroup.add(arrow);
      if (vc.label) {
        this._labelItems.push({
          text: `→${vc.label}`,
          pos: p1.clone().add(p2).multiplyScalar(0.5),
          kind: 'edge',
        });
      }
    }

    for (const sf of sceneData.surfaces || []) {
      if (sf.hidden) continue;
      const res = sampleSurfaceZ(sf.expr, sf.range || 2.8, this.isSoftwareGl ? 20 : 28);
      if (!res.valid) continue;
      const positions = [];
      const colors = [];
      const spanZ = Math.max(0.5, res.maxZ - res.minZ);
      const colLow = new THREE.Color(0x2563EB);
      const colMid = new THREE.Color(0x10B981);
      const colHigh = new THREE.Color(0xF59E0B);
      const cTmp = new THREE.Color();
      const pushV = (pt) => {
        const [tx, ty, tz] = mathToThree(pt);
        positions.push(tx, ty, tz);
        const u = Math.min(1, Math.max(0, (pt.z - res.minZ) / spanZ));
        if (u < 0.5) cTmp.copy(colLow).lerp(colMid, u * 2);
        else cTmp.copy(colMid).lerp(colHigh, (u - 0.5) * 2);
        colors.push(cTmp.r, cTmp.g, cTmp.b);
      };
      for (let i = 0; i < res.segs; i++) {
        for (let j = 0; j < res.segs; j++) {
          const p00 = res.grid[i][j], p10 = res.grid[i + 1][j];
          const p11 = res.grid[i + 1][j + 1], p01 = res.grid[i][j + 1];
          if ([p00.z, p10.z, p11.z].every(Number.isFinite)) {
            pushV(p00); pushV(p10); pushV(p11);
          }
          if ([p00.z, p11.z, p01.z].every(Number.isFinite)) {
            pushV(p00); pushV(p11); pushV(p01);
          }
        }
      }
      if (positions.length) {
        const sGeo = new THREE.BufferGeometry();
        sGeo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        sGeo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
        sGeo.computeVertexNormals();
        const sMat = new THREE.MeshPhysicalMaterial({
          vertexColors: true,
          transparent: true,
          opacity: 0.72,
          roughness: 0.35,
          side: THREE.DoubleSide,
          polygonOffset: true,
          polygonOffsetFactor: 1,
          polygonOffsetUnits: 1,
        });
        const sMesh = new THREE.Mesh(sGeo, sMat);
        sMesh.renderOrder = 2;
        this.figureGroup.add(sMesh);
      }
    }

    // 6b. Planes (nx*x + ny*y + nz*z = d)
    for (const pl of sceneData.planes || []) {
      if (pl.hidden) continue;
      const nMath = vecNormalize({ x: Number(pl.nx) || 0, y: Number(pl.ny) || 0, z: Number(pl.nz) || 1 });
      const nLen = Math.hypot(nMath.x, nMath.y, nMath.z);
      if (nLen < 1e-4) continue;
      const dVal = Number(pl.d) || 0;
      const origin = vecScale(nMath, dVal);
      const ref = Math.abs(nMath.z) < 0.9 ? { x: 0, y: 0, z: 1 } : { x: 1, y: 0, z: 0 };
      const uAx = vecNormalize(vecCross(ref, nMath));
      const vAx = vecNormalize(vecCross(nMath, uAx));
      const half = 2.6;
      const corners = [
        vecAdd(origin, vecAdd(vecScale(uAx, -half), vecScale(vAx, -half))),
        vecAdd(origin, vecAdd(vecScale(uAx, half), vecScale(vAx, -half))),
        vecAdd(origin, vecAdd(vecScale(uAx, half), vecScale(vAx, half))),
        vecAdd(origin, vecAdd(vecScale(uAx, -half), vecScale(vAx, half))),
      ].map((pt) => new THREE.Vector3(...mathToThree(pt)));

      const pPos = [
        corners[0].x, corners[0].y, corners[0].z,
        corners[1].x, corners[1].y, corners[1].z,
        corners[2].x, corners[2].y, corners[2].z,
        corners[0].x, corners[0].y, corners[0].z,
        corners[2].x, corners[2].y, corners[2].z,
        corners[3].x, corners[3].y, corners[3].z,
      ];
      const pGeo = new THREE.BufferGeometry();
      pGeo.setAttribute('position', new THREE.Float32BufferAttribute(pPos, 3));
      pGeo.computeVertexNormals();
      const pCol = new THREE.Color(pl.color || '#0EA5E9');
      const pMat = new THREE.MeshPhysicalMaterial({
        color: pCol,
        transparent: true,
        opacity: 0.16,
        roughness: 0.35,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const pMesh = new THREE.Mesh(pGeo, pMat);
      pMesh.renderOrder = 2;
      this.figureGroup.add(pMesh);

      const borderGeo = new THREE.BufferGeometry().setFromPoints([...corners, corners[0]]);
      const borderMat = new THREE.LineDashedMaterial({ color: pCol, dashSize: 0.16, gapSize: 0.1 });
      const border = new THREE.Line(borderGeo, borderMat);
      border.computeLineDistances();
      this.figureGroup.add(border);
      if (pl.label) {
        this._labelItems.push({ text: pl.label, pos: corners[2].clone(), kind: 'edge' });
      }
    }

    // 6c. 3D Circles (e.g. GeoGebra AlgoIntersectPlaneQuadric / AlgoIntersectQuadricsAsCircle)
    for (const c of sceneData.circles || []) {
      if (c.hidden || !c.center || !(c.radius > 0)) continue;
      const nMath = vecNormalize(c.normal || { x: 0, y: 0, z: 1 });
      const ref = Math.abs(nMath.z) < 0.9 ? { x: 0, y: 0, z: 1 } : { x: 1, y: 0, z: 0 };
      const uAx = vecNormalize(vecCross(ref, nMath));
      const vAx = vecNormalize(vecCross(nMath, uAx));
      const segs = 48;
      const ringPts = [];
      for (let i = 0; i < segs; i++) {
        const theta = (i / segs) * Math.PI * 2;
        const pm = vecAdd(
          c.center,
          vecAdd(vecScale(uAx, Math.cos(theta) * c.radius), vecScale(vAx, Math.sin(theta) * c.radius)),
        );
        ringPts.push(new THREE.Vector3(...mathToThree(pm)));
      }
      const cCol = new THREE.Color(c.color || '#EA580C');
      const loopGeo = new THREE.BufferGeometry().setFromPoints(ringPts);
      const loopMat = new THREE.LineBasicMaterial({ color: cCol, depthTest: false });
      const loopLine = new THREE.LineLoop(loopGeo, loopMat);
      loopLine.renderOrder = 5;
      this.figureGroup.add(loopLine);

      // Subtle translucent disc fill
      const cCtrThree = new THREE.Vector3(...mathToThree(c.center));
      const discPos = [];
      for (let i = 0; i < segs; i++) {
        const p1 = ringPts[i];
        const p2 = ringPts[(i + 1) % segs];
        discPos.push(cCtrThree.x, cCtrThree.y, cCtrThree.z, p1.x, p1.y, p1.z, p2.x, p2.y, p2.z);
      }
      const dGeo = new THREE.BufferGeometry();
      dGeo.setAttribute('position', new THREE.Float32BufferAttribute(discPos, 3));
      const dMat = new THREE.MeshBasicMaterial({
        color: cCol,
        transparent: true,
        opacity: 0.14,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const dMesh = new THREE.Mesh(dGeo, dMat);
      dMesh.renderOrder = 3;
      this.figureGroup.add(dMesh);

      if (c.label) {
        this._labelItems.push({ text: c.label, pos: ringPts[0].clone(), kind: 'edge' });
      }
    }

    // 7. Vertices (composite sphere + invisible touch target + halo; depthTest: false in textbook-3d so occluded back vertices remain visible & tappable)
    const vGeo = new THREE.SphereGeometry(0.068 * scaleMult, 16, 12);
    const hitGeo = new THREE.SphereGeometry(0.22 * scaleMult, 10, 8);
    const hitMat = new THREE.MeshBasicMaterial({ visible: false });
    const haloGeo = new THREE.RingGeometry(0.095 * scaleMult, 0.145 * scaleMult, 22);
    for (const v of sceneData.vertices) {
      if (v.hidden) continue;
      const pos = tMap.get(v.id);
      const isHi = this.highlight.vertices.has(v.id);
      const isSel = this.selectedVertexIds.has(v.id);

      let color = 0x1D4ED8;
      if (v.role === 'projection') color = 0x059669;
      else if (v.role === 'aux') color = 0xD97706;
      else if (v.role === 'center') color = 0x7C3AED;
      if (isHi || isSel) color = 0xEA580C;

      const vMat = new THREE.MeshStandardMaterial({
        color,
        roughness: 0.3,
        metalness: 0.2,
        transparent: useDynamicOcclusion,
        opacity: 0.96,
        depthTest: !useDynamicOcclusion,
        depthWrite: !useDynamicOcclusion,
      });
      const dot = new THREE.Mesh(vGeo.clone(), vMat);
      dot.position.copy(pos);
      dot.renderOrder = 5;
      this.figureGroup.add(dot);

      const hit = new THREE.Mesh(hitGeo.clone(), hitMat);
      hit.position.copy(pos);
      hit.userData.vertexId = v.id;
      this.figureGroup.add(hit);
      this._clickableMeshes.push(hit);

      if (isHi || isSel) {
        const hMat = new THREE.MeshBasicMaterial({
          color: isSel ? 0xDC2626 : 0xF59E0B,
          side: THREE.DoubleSide,
          transparent: true,
          depthTest: false,
          depthWrite: false,
        });
        const halo = new THREE.Mesh(haloGeo.clone(), hMat);
        halo.position.copy(pos);
        halo.lookAt(this.camera.position);
        halo.renderOrder = 5;
        this.figureGroup.add(halo);
      }

      this._labelItems.push({
        text: v.id,
        pos: pos.clone(),
        kind: isHi || isSel ? 'vertex-hi' : 'vertex',
        role: v.role || 'primary',
      });
    }
    vGeo.dispose();
    hitGeo.dispose();
    hitMat.dispose();
    haloGeo.dispose();

    // 8. Built-in crossSection IDs if specified by AI
    if (Array.isArray(sceneData.crossSection) && sceneData.crossSection.length >= 3) {
      const csPts = sceneData.crossSection.map((id) => vMap.get(id)).filter(Boolean);
      if (csPts.length >= 3) {
        this.setCrossSection({ valid: true, points: csPts });
      }
    }

    if (!opts.keepCamera) {
      const autoPreset = this.projectionMode === '2d' ? '2d-oblique' : (sceneData.showOxyz ? 'oxyz' : 'default');
      this.setCameraPreset(autoPreset);
    } else {
      this.requestRender();
    }
  }

  _buildOxyzAxes() {
    const len = 3.8;
    const specs = [
      { dir: new THREE.Vector3(...mathToThree({ x: 1, y: 0, z: 0 })), color: 0xDC2626, label: 'x' },
      { dir: new THREE.Vector3(...mathToThree({ x: 0, y: 1, z: 0 })), color: 0x16A34A, label: 'y' },
      { dir: new THREE.Vector3(...mathToThree({ x: 0, y: 0, z: 1 })), color: 0x2563EB, label: 'z' },
    ];
    for (const sp of specs) {
      const arrow = new THREE.ArrowHelper(sp.dir.normalize(), new THREE.Vector3(0, 0, 0), len, sp.color, 0.24, 0.11);
      this.oxyzGroup.add(arrow);
      this._labelItems.push({
        text: sp.label,
        pos: sp.dir.clone().multiplyScalar(len + 0.22),
        kind: 'axis',
      });
    }
  }

  setCrossSection(csResult) {
    this.crossSectionData = csResult;
    disposeObjectTree(this.crossGroup);
    this.crossGroup.clear();
    if (!csResult || !csResult.valid || !Array.isArray(csResult.points) || csResult.points.length < 3) {
      this.requestRender();
      return;
    }

    const pts = csResult.points.map((p) => new THREE.Vector3(...mathToThree(p)));
    const positions = [];
    for (let i = 1; i < pts.length - 1; i++) {
      positions.push(pts[0].x, pts[0].y, pts[0].z, pts[i].x, pts[i].y, pts[i].z, pts[i + 1].x, pts[i + 1].y, pts[i + 1].z);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.computeVertexNormals();
    const mat = new THREE.MeshPhysicalMaterial({
      color: 0xF97316,
      transparent: true,
      opacity: 0.38,
      roughness: 0.3,
      side: THREE.DoubleSide,
      depthTest: false,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -1,
      polygonOffsetUnits: -1,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.renderOrder = 4;
    this.crossGroup.add(mesh);

    // Bold perimeter loop
    const loopPts = [...pts, pts[0]];
    for (let i = 0; i < pts.length; i++) {
      const a = loopPts[i], b = loopPts[i + 1];
      const dir = _v1.subVectors(b, a);
      const len = dir.length();
      if (len < 1e-4) continue;
      const tGeo = new THREE.CylinderGeometry(0.026, 0.026, len, 10);
      const tMat = new THREE.MeshStandardMaterial({
        color: 0xEA580C,
        roughness: 0.3,
        transparent: true,
        opacity: 0.96,
        depthTest: false,
        depthWrite: false,
      });
      const cyl = new THREE.Mesh(tGeo, tMat);
      cyl.position.copy(a).addScaledVector(dir, 0.5);
      cyl.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.clone().normalize());
      cyl.renderOrder = 5;
      this.crossGroup.add(cyl);
    }

    const dotGeo = new THREE.SphereGeometry(0.055, 14, 10);
    const dotMat = new THREE.MeshStandardMaterial({
      color: 0xC2410C,
      roughness: 0.3,
      transparent: true,
      opacity: 0.98,
      depthTest: false,
      depthWrite: false,
    });
    pts.forEach((pt) => {
      const m = new THREE.Mesh(dotGeo.clone(), dotMat);
      m.position.copy(pt);
      m.renderOrder = 6;
      this.crossGroup.add(m);
    });
    dotGeo.dispose();

    this.requestRender();
  }

  setPolyhedronNet(netResult, ratio = 0) {
    this.netRatio = Math.min(1, Math.max(0, Number(ratio) || 0));
    const nowShowNet = this.netRatio > 0.02 && Boolean(netResult && netResult.valid && Array.isArray(netResult.faces));
    disposeObjectTree(this.netGroup);
    this.netGroup.clear();
    this.figureGroup.visible = !nowShowNet;

    if (nowShowNet) {
      for (const face of netResult.faces) {
        const pts = face.points.map((p) => new THREE.Vector3(...mathToThree(p)));
        if (pts.length < 3) continue;
        const positions = [];
        for (let i = 1; i < pts.length - 1; i++) {
          positions.push(pts[0].x, pts[0].y, pts[0].z, pts[i].x, pts[i].y, pts[i].z, pts[i + 1].x, pts[i + 1].y, pts[i + 1].z);
        }
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        geo.computeVertexNormals();
        const mat = new THREE.MeshPhysicalMaterial({
          color: face.isBase ? 0x2563EB : new THREE.Color(face.color || '#10B981'),
          transparent: true,
          opacity: face.isBase ? 0.42 : 0.56,
          roughness: 0.35,
          side: THREE.DoubleSide,
          polygonOffset: true,
          polygonOffsetFactor: -1,
          polygonOffsetUnits: -1,
        });
        const mesh = new THREE.Mesh(geo, mat);
        mesh.renderOrder = 3;
        this.netGroup.add(mesh);

        const loop = [...pts, pts[0]];
        this.netGroup.add(new THREE.Line(
          new THREE.BufferGeometry().setFromPoints(loop),
          new THREE.LineBasicMaterial({ color: 0x0F172A }),
        ));
      }
    }

    this._updateLabels();
    this.requestRender();
  }

  _computePlacedLabels(w, h) {
    if (this.labelsMode === 'none' || !this._labelItems.length) {
      return { placed: [], isCompact: false };
    }
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    let sumX = 0, sumY = 0, vCount = 0;
    const projected = [];

    for (const item of this._labelItems) {
      if (this.netRatio > 0.02 && item.kind !== 'axis') continue;
      if (this.labelsMode === 'vertices' && (item.kind === 'edge' || item.kind === 'angle')) continue;
      _proj.copy(item.pos).project(this.camera);
      if (_proj.z > 1 || _proj.z < -1) continue;
      const sx = ((_proj.x + 1) * 0.5) * w;
      const sy = ((-_proj.y + 1) * 0.5) * h;
      if (sx < -24 || sx > w + 24 || sy < -24 || sy > h + 24) continue;
      projected.push({ item, sx, sy });
      if (item.kind === 'vertex' || item.kind === 'vertex-hi') {
        if (sx < minX) minX = sx;
        if (sx > maxX) maxX = sx;
        if (sy < minY) minY = sy;
        if (sy > maxY) maxY = sy;
        sumX += sx;
        sumY += sy;
        vCount++;
      }
    }

    const span = vCount >= 2 ? Math.max(maxX - minX, maxY - minY) : Math.min(w, h);
    const camDist = this._sceneCenter ? this.camera.position.distanceTo(this._sceneCenter) : 9;
    const zoomedOut = camDist > Math.max(9.5, (this._sceneRadius || 3.2) * 3.1);
    const isCompact = span < 205 || zoomedOut || Math.min(w, h) < 250;
    const isTiny = span < 130 || (zoomedOut && span < 165) || Math.min(w, h) < 185;
    const cx = vCount ? sumX / vCount : w * 0.5;
    const cy = vCount ? sumY / vCount : h * 0.5;

    const prioOf = (it) => {
      if (it.kind === 'vertex-hi') return 100;
      if (it.kind === 'vertex') {
        if (it.role === 'primary') return 88;
        if (it.role === 'center' || it.role === 'projection') return 76;
        return 66;
      }
      if (it.kind === 'axis') return 60;
      if (it.kind === 'angle') return 40;
      return 20;
    };

    projected.sort((a, b) => prioOf(b.item) - prioOf(a.item));

    const placed = [];
    const boxes = [];
    const topSafe = w < 640 ? 92 : 52;
    const botSafe = w >= 640 ? (this.dockCollapsed ? h - 46 : h - 90) : (this.dockCollapsed ? h - 54 : h - 98);
    const dist = isTiny ? 12 : isCompact ? 14 : 18;

    const overlapArea = (a, b) => {
      const ox = Math.max(0, Math.min(a.r, b.r) - Math.max(a.l, b.l));
      const oy = Math.max(0, Math.min(a.b, b.b) - Math.max(a.t, b.t));
      return ox * oy;
    };

    for (const entry of projected) {
      const { item, sx, sy } = entry;
      if ((isTiny || (isCompact && zoomedOut)) && item.kind === 'edge') continue;
      if (isTiny && item.kind === 'angle' && span < 95) continue;

      const charW = isCompact ? 6.2 : 7.4;
      const bw = Math.max(18, Math.round(item.text.length * charW + (isCompact ? 7 : 12)));
      const bh = isCompact ? 15 : 19;

      let ux = sx - cx;
      let uy = sy - cy;
      const uLen = Math.hypot(ux, uy);
      if (uLen > 2) {
        ux /= uLen;
        uy /= uLen;
      } else {
        ux = 0;
        uy = -1;
      }

      const candidates = item.kind === 'edge' || item.kind === 'angle'
        ? [[0, 0], [0, -dist], [dist, 0], [-dist, 0], [0, dist]]
        : [
            [ux * dist, uy * dist],
            [0, -dist],
            [dist * 0.95, -dist * 0.45],
            [-dist * 0.95, -dist * 0.45],
            [dist, 0],
            [-dist, 0],
            [dist * 1.1, dist * 0.75],
            [-dist * 1.1, dist * 0.75],
            [0, dist],
            [ux * (dist + 12), uy * (dist + 12)],
            [ux * (dist + 18), uy * (dist + 18)],
          ];

      let best = null;
      let bestScore = Infinity;

      for (const [dx, dy] of candidates) {
        const lx = Math.max(bw / 2 + 4, Math.min(w - bw / 2 - 4, sx + dx));
        const ly = Math.max(topSafe + bh / 2, Math.min(botSafe - bh / 2, sy + dy));
        const box = { l: lx - bw / 2 - 3, r: lx + bw / 2 + 3, t: ly - bh / 2 - 3, b: ly + bh / 2 + 3 };
        let col = 0;
        for (const pb of boxes) col += overlapArea(box, pb);
        const shiftPenalty = Math.hypot(lx - (sx + dx), ly - (sy + dy)) * 0.5;
        const score = col * 10 + shiftPenalty;
        if (score < bestScore) {
          bestScore = score;
          best = { lx, ly, box, col };
        }
        if (col === 0 && shiftPenalty < 1) break;
      }

      if (!best) continue;
      if ((item.kind === 'edge' || item.kind === 'angle') && best.col > 6) continue;
      if (isTiny && item.role === 'aux' && best.col > bw * bh * 0.65) continue;

      boxes.push(best.box);
      placed.push({ item, lx: best.lx, ly: best.ly });
    }

    return { placed, isCompact };
  }

  _updateLabels() {
    if (!this.labelLayerEl) return;
    const w = this.mountEl.clientWidth || 1;
    const h = this.mountEl.clientHeight || 1;

    this.labelLayerEl.innerHTML = '';
    const { placed, isCompact } = this._computePlacedLabels(w, h);
    if (!placed.length) return;

    const frag = document.createDocumentFragment();
    for (const { item, lx, ly } of placed) {
      const el = document.createElement('span');
      el.className = `hhkg-lbl hhkg-lbl-${item.kind || 'vertex'}${isCompact ? ' compact' : ''}`;
      el.textContent = item.text;
      el.style.transform = `translate(${Math.round(lx)}px, ${Math.round(ly)}px) translate(-50%, -50%)`;
      frag.appendChild(el);
    }
    this.labelLayerEl.appendChild(frag);
  }

  exportPngDataUrl() {
    this.renderer.render(this.scene, this.camera);
    const glCanvas = this.renderer.domElement;
    const out = document.createElement('canvas');
    out.width = glCanvas.width;
    out.height = glCanvas.height;
    const ctx = out.getContext('2d');
    ctx.drawImage(glCanvas, 0, 0);

    const w = this.mountEl.clientWidth || 1;
    const h = this.mountEl.clientHeight || 1;
    const scaleX = out.width / w;
    const scaleY = out.height / h;

    const { placed, isCompact } = this._computePlacedLabels(w, h);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = `700 ${Math.round((isCompact ? 11 : 13.5) * scaleX)}px "Plus Jakarta Sans", system-ui, sans-serif`;

    for (const { item, lx, ly } of placed) {
      const sx = lx * scaleX;
      const sy = ly * scaleY;
      ctx.fillStyle = 'rgba(255,255,255,0.9)';
      const tw = ctx.measureText(item.text).width + 10 * scaleX;
      const th = (isCompact ? 16 : 20) * scaleY;
      ctx.fillRect(sx - tw / 2, sy - th / 2, tw, th);
      ctx.fillStyle = item.kind === 'vertex-hi' ? '#C2410C' : '#17233B';
      ctx.fillText(item.text, sx, sy);
    }

    return out.toDataURL('image/png');
  }

  dispose() {
    this._disposed = true;
    cancelAnimationFrame(this._frameId);
    clearTimeout(this._frameId);
    if (this._ro) this._ro.disconnect();
    this.controls.removeEventListener('change', this._onControlsChange);
    this.controls.removeEventListener('start', this._onControlsStart);
    this.renderer.domElement.removeEventListener('pointerdown', this._onPointerDown);
    this.renderer.domElement.removeEventListener('pointerup', this._onPointerUp);
    this.renderer.domElement.removeEventListener('pointermove', this._onPointerMove);
    this.controls.dispose();
    disposeObjectTree(this.scene);
    if (this._envTex) this._envTex.dispose();
    if (this._floorTex) this._floorTex.dispose();
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode === this.mountEl) {
      this.mountEl.removeChild(this.renderer.domElement);
    }
  }
}
