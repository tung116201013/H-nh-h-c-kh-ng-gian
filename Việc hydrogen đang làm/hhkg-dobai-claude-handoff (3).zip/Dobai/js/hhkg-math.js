/* ===== hhkg-math.js: Pure 3D Geometry Math, GDPT 2018 Grade 11-12 Engine & Cross-Section Solver =====
   Math coordinate system (Vietnamese textbooks):
   - x: forward/outward (Ox)
   - y: right (Oy)
   - z: vertical height UP (Oz)
   Right-handed bijection to Three.js (X right, Y up, Z forward):
   mathToThree([x, y, z]) => [y, z, x]
*/

export const EPS = 1e-6;

export function mathToThree(p) {
  return [Number(p.y ?? p[1] ?? 0), Number(p.z ?? p[2] ?? 0), Number(p.x ?? p[0] ?? 0)];
}

export function threeToMath(v) {
  return { x: Number(v[2] ?? 0), y: Number(v[0] ?? 0), z: Number(v[1] ?? 0) };
}

export const vecAdd = (a, b) => ({ x: a.x + b.x, y: a.y + b.y, z: a.z + b.z });
export const vecSub = (a, b) => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z });
export const vecScale = (a, s) => ({ x: a.x * s, y: a.y * s, z: a.z * s });
export const vecDot = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;
export const vecCross = (a, b) => ({
  x: a.y * b.z - a.z * b.y,
  y: a.z * b.x - a.x * b.z,
  z: a.x * b.y - a.y * b.x,
});
export const vecLen = (a) => Math.hypot(a.x, a.y, a.z);
export const vecDist = (a, b) => vecLen(vecSub(a, b));

export function vecNormalize(a) {
  const l = vecLen(a);
  if (l < EPS) return { x: 0, y: 0, z: 0 };
  return { x: a.x / l, y: a.y / l, z: a.z / l };
}

export const midpoint = (a, b) => ({
  x: (a.x + b.x) / 2,
  y: (a.y + b.y) / 2,
  z: (a.z + b.z) / 2,
});

export function centroid(pts) {
  if (!pts || !pts.length) return { x: 0, y: 0, z: 0 };
  let sx = 0, sy = 0, sz = 0;
  for (const p of pts) {
    sx += p.x;
    sy += p.y;
    sz += p.z;
  }
  const n = pts.length;
  return { x: sx / n, y: sy / n, z: sz / n };
}

export const lerpPoint = (a, b, k) => ({
  x: a.x + (b.x - a.x) * k,
  y: a.y + (b.y - a.y) * k,
  z: a.z + (b.z - a.z) * k,
});

export function parallelPointThrough(p, a, b, scale = 1) {
  return vecAdd(p, vecScale(vecSub(b, a), scale));
}

/**
 * Returns the 4th vertex D of parallelogram ABCD given A, B, C (D = A + C - B).
 */
export function parallelogram4thVertex(a, b, c) {
  return {
    x: a.x + c.x - b.x,
    y: a.y + c.y - b.y,
    z: a.z + c.z - b.z,
  };
}

/**
 * Computes intersection of two 3D lines AB and CD (exact when coplanar within tol).
 */
export function intersectTwoLines3D(a, b, c, d, tol = 0.05) {
  const res = distanceSkewLines(a, b, c, d);
  if (!res.valid) return { valid: false, reason: 'Đường thẳng không xác định.' };
  if (res.parallel) {
    return {
      valid: false,
      parallel: true,
      coplanarDist: res.distance,
      reason: res.distance < tol ? 'Hai đường thẳng trùng nhau.' : 'Hai đường thẳng song song, không cắt nhau.',
    };
  }
  if (res.distance > tol) {
    return {
      valid: false,
      skew: true,
      coplanarDist: res.distance,
      reason: `Hai đường thẳng chéo nhau (khoảng cách d = ${res.distance.toFixed(3)}).`,
    };
  }
  const point = midpoint(res.pOnAB, res.pOnCD);
  return {
    valid: true,
    point,
    coplanarDist: res.distance,
    s: res.s,
    t: res.t,
    onSegmentAB: res.s >= -1e-4 && res.s <= 1 + 1e-4,
    onSegmentCD: res.t >= -1e-4 && res.t <= 1 + 1e-4,
  };
}

/**
 * Bài 14 KNTT (Phép chiếu song song): projects point P along direction (dirB - dirA) onto plane (a, b, c).
 */
export function projectPointParallelOnPlane(p, dirA, dirB, a, b, c) {
  const pl = planeFrom3Points(a, b, c);
  if (!pl.valid) return { valid: false, reason: 'Mặt phẳng chiếu (P) không xác định.' };
  const dir = vecSub(dirB, dirA);
  if (vecLen(dir) < EPS) return { valid: false, reason: 'Phương chiếu Δ không xác định.' };
  const denom = vecDot(pl.normal, dir);
  if (Math.abs(denom) < EPS) {
    return { valid: false, parallelToPlane: true, reason: 'Phương chiếu Δ song song với mặt phẳng chiếu (P).' };
  }
  const s = vecDot(pl.normal, p) + pl.d;
  const t = -s / denom;
  const point = vecAdd(p, vecScale(dir, t));
  return { valid: true, point, t, distance: vecDist(p, point) };
}

export function projectPointOnLine(p, a, b) {
  const ab = vecSub(b, a);
  const lenSq = vecDot(ab, ab);
  if (lenSq < EPS * EPS) {
    return { valid: false, point: { ...a }, t: 0, distance: vecDist(p, a) };
  }
  const t = vecDot(vecSub(p, a), ab) / lenSq;
  const point = lerpPoint(a, b, t);
  return { valid: true, point, t, distance: vecDist(p, point) };
}

export function planeFrom3Points(a, b, c) {
  const ab = vecSub(b, a);
  const ac = vecSub(c, a);
  const nRaw = vecCross(ab, ac);
  const len = vecLen(nRaw);
  if (len < EPS) return { valid: false, a: 0, b: 0, c: 1, d: 0, normal: { x: 0, y: 0, z: 1 } };
  const n = vecScale(nRaw, 1 / len);
  const d = -vecDot(n, a);
  return { valid: true, a: n.x, b: n.y, c: n.z, d, normal: n };
}

export function planeFromPointAndNormal(p, normal) {
  const n = vecNormalize(normal);
  if (vecLen(n) < EPS) return { valid: false, nx: 0, ny: 0, nz: 1, d: 0 };
  return {
    valid: true,
    nx: Math.round(n.x * 1000) / 1000,
    ny: Math.round(n.y * 1000) / 1000,
    nz: Math.round(n.z * 1000) / 1000,
    d: Math.round(vecDot(n, p) * 1000) / 1000,
  };
}

export function planeParallelToPlane(ptOnPlane, a, b, c) {
  const pl = planeFrom3Points(a, b, c);
  if (!pl.valid) return { valid: false, nx: 0, ny: 0, nz: 1, d: 0 };
  return planeFromPointAndNormal(ptOnPlane, pl.normal);
}

export function planePerpToLine(ptOnPlane, lineA, lineB) {
  const dir = vecSub(lineB, lineA);
  return planeFromPointAndNormal(ptOnPlane, dir);
}

export function projectPointOnPlane(p, a, b, c) {
  const pl = planeFrom3Points(a, b, c);
  if (!pl.valid) return { valid: false, point: { ...p }, distance: 0, normal: pl.normal };
  const signed = vecDot(pl.normal, p) + pl.d;
  const point = vecSub(p, vecScale(pl.normal, signed));
  return { valid: true, point, distance: Math.abs(signed), normal: pl.normal };
}

export function angleBetweenLines(a, b, c, d) {
  const u = vecNormalize(vecSub(b, a));
  const v = vecNormalize(vecSub(d, c));
  if (vecLen(u) < EPS || vecLen(v) < EPS) return { valid: false, deg: 0, rad: 0 };
  const cos = Math.min(1, Math.max(0, Math.abs(vecDot(u, v))));
  const rad = Math.acos(cos);
  return { valid: true, rad, deg: (rad * 180) / Math.PI };
}

export function angleLinePlane(a, b, p1, p2, p3) {
  const u = vecNormalize(vecSub(b, a));
  const pl = planeFrom3Points(p1, p2, p3);
  if (!pl.valid || vecLen(u) < EPS) return { valid: false, deg: 0, rad: 0 };
  const sin = Math.min(1, Math.max(0, Math.abs(vecDot(u, pl.normal))));
  const rad = Math.asin(sin);
  return { valid: true, rad, deg: (rad * 180) / Math.PI };
}

export function angleBetweenPlanes(a1, b1, c1, a2, b2, c2) {
  const p1 = planeFrom3Points(a1, b1, c1);
  const p2 = planeFrom3Points(a2, b2, c2);
  if (!p1.valid || !p2.valid) return { valid: false, deg: 0, rad: 0 };
  const cos = Math.min(1, Math.max(0, Math.abs(vecDot(p1.normal, p2.normal))));
  const rad = Math.acos(cos);
  return { valid: true, rad, deg: (rad * 180) / Math.PI };
}

/**
 * Computes exact dihedral angle [P1, AB, P2] (GDPT 2018 Lớp 11).
 * Drops perpendiculars from P1 and P2 onto edge AB and measures the oriented plane angle [0, 180°].
 */
export function dihedralAngle(p1, edgeA, edgeB, p2) {
  const h1 = projectPointOnLine(p1, edgeA, edgeB);
  const h2 = projectPointOnLine(p2, edgeA, edgeB);
  if (!h1.valid || !h2.valid || h1.distance < EPS || h2.distance < EPS) {
    return { valid: false, deg: 0, rad: 0, foot: midpoint(edgeA, edgeB), foot2: null };
  }
  const u1 = vecNormalize(vecSub(p1, h1.point));
  const u2 = vecNormalize(vecSub(p2, h2.point));
  const cos = Math.min(1, Math.max(-1, vecDot(u1, u2)));
  const rad = Math.acos(cos);
  const foot = midpoint(h1.point, h2.point);
  return {
    valid: true,
    rad,
    deg: (rad * 180) / Math.PI,
    foot: h1.point,
    foot2: h2.point,
    midFoot: foot,
    ray1: vecAdd(h1.point, u1),
    ray2: vecAdd(h1.point, u2),
  };
}

export function distanceSkewLines(a, b, c, d) {
  const u = vecSub(b, a);
  const v = vecSub(d, c);
  const w0 = vecSub(a, c);
  const aa = vecDot(u, u);
  const bb = vecDot(u, v);
  const cc = vecDot(v, v);
  const dd = vecDot(u, w0);
  const ee = vecDot(v, w0);
  const denom = aa * cc - bb * bb;
  if (denom < EPS) {
    const proj = projectPointOnLine(a, c, d);
    return { valid: true, parallel: true, distance: proj.distance, pOnAB: { ...a }, pOnCD: proj.point };
  }
  const s = (bb * ee - cc * dd) / denom;
  const t = (aa * ee - bb * dd) / denom;
  const pOnAB = vecAdd(a, vecScale(u, s));
  const pOnCD = vecAdd(c, vecScale(v, t));
  return { valid: true, parallel: false, distance: vecDist(pOnAB, pOnCD), pOnAB, pOnCD, s, t };
}

export function commonPerpendicularSegment(a, b, c, d) {
  const res = distanceSkewLines(a, b, c, d);
  return {
    valid: res.valid,
    parallel: res.parallel,
    distance: res.distance,
    p1: res.pOnAB,
    p2: res.pOnCD,
  };
}

export function triangleArea(a, b, c) {
  return 0.5 * vecLen(vecCross(vecSub(b, a), vecSub(c, a)));
}

export function polygonArea(pts) {
  if (!pts || pts.length < 3) return 0;
  let total = 0;
  for (let i = 1; i < pts.length - 1; i++) {
    total += triangleArea(pts[0], pts[i], pts[i + 1]);
  }
  return total;
}

export function polygonPerimeter(pts) {
  if (!pts || pts.length < 2) return 0;
  let per = 0;
  for (let i = 0; i < pts.length; i++) {
    per += vecDist(pts[i], pts[(i + 1) % pts.length]);
  }
  return per;
}

/**
 * Computes exact volume of a closed polyhedron from its faces via signed tetrahedra around centroid.
 * Handles arbitrary vertex winding by orienting each face outward from the polyhedron centroid.
 */
export function polyhedronVolume(scene) {
  if (!scene || !Array.isArray(scene.faces) || scene.faces.length < 4) return 0;
  const vMap = new Map((scene.vertices || []).map((v) => [v.id, v]));
  const facePtsList = [];
  const used = new Map();
  for (const f of scene.faces) {
    const pts = (f.vertices || []).map((id) => vMap.get(id)).filter(Boolean);
    if (pts.length >= 3) {
      facePtsList.push(pts);
      for (const p of pts) used.set(p.id, p);
    }
  }
  if (facePtsList.length < 4) return 0;
  const origin = centroid([...used.values()]);
  let vol6 = 0;
  for (const pts of facePtsList) {
    for (let i = 1; i < pts.length - 1; i++) {
      const a = vecSub(pts[0], origin);
      const b = vecSub(pts[i], origin);
      const c = vecSub(pts[i + 1], origin);
      vol6 += Math.abs(vecDot(a, vecCross(b, c)));
    }
  }
  return vol6 / 6;
}

/**
 * Checks whether a 3D point coplanar with polygon `polyPts` lies inside or on the boundary
 * of `polyPts` (works for both convex and non-convex faces — GeoGebra `checkMidpoint` principle).
 */
function pointInPolygon3D(pt, polyPts, faceNormal) {
  if (!polyPts || polyPts.length < 3) return false;
  const n = vecNormalize(faceNormal);
  if (vecLen(n) < EPS) return false;
  const ref = Math.abs(n.z) < 0.9 ? { x: 0, y: 0, z: 1 } : { x: 1, y: 0, z: 0 };
  const uAxis = vecNormalize(vecCross(ref, n));
  const vAxis = vecNormalize(vecCross(n, uAxis));
  const o = polyPts[0];
  const to2D = (p) => {
    const rel = vecSub(p, o);
    return { x: vecDot(rel, uAxis), y: vecDot(rel, vAxis) };
  };
  const q = to2D(pt);
  const pts2 = polyPts.map(to2D);

  // Boundary check (point on any edge)
  for (let i = 0; i < pts2.length; i++) {
    const a = pts2[i];
    const b = pts2[(i + 1) % pts2.length];
    const abx = b.x - a.x;
    const aby = b.y - a.y;
    const lenSq = abx * abx + aby * aby;
    if (lenSq < 1e-10) continue;
    const t = Math.max(0, Math.min(1, ((q.x - a.x) * abx + (q.y - a.y) * aby) / lenSq));
    const dx = q.x - (a.x + t * abx);
    const dy = q.y - (a.y + t * aby);
    if (dx * dx + dy * dy < 1e-7) return true;
  }

  // Standard ray-casting for concave & convex 2D polygons
  let inside = false;
  for (let i = 0, j = pts2.length - 1; i < pts2.length; j = i++) {
    const xi = pts2[i].x, yi = pts2[i].y;
    const xj = pts2[j].x, yj = pts2[j].y;
    const intersect = ((yi > q.y) !== (yj > q.y)) &&
      (q.x < ((xj - xi) * (q.y - yi)) / ((yj - yi) || 1e-12) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}

/**
 * Computes exact cross-section polygon when plane nx*x + ny*y + nz*z = d slices a polyhedron.
 * Upgraded with GeoGebra `AlgoIntersectRegionPlanePolyhedron` (EUPL v1.2) face-segment midpoint
 * filtering and shared-parent polygon chaining so both convex and non-convex (L-shape/concave)
 * polyhedra and coplanar slices produce clean, untwisted polygons.
 */
export function computeCrossSection(scene, plane) {
  const empty = { valid: false, points: [], shapeName: '', area: 0, perimeter: 0 };
  if (!scene || !Array.isArray(scene.vertices) || !scene.vertices.length) return empty;
  const n = vecNormalize({ x: Number(plane.nx) || 0, y: Number(plane.ny) || 0, z: Number(plane.nz) || 1 });
  if (vecLen(n) < EPS) return empty;
  const d = Number(plane.d) || 0;

  const vMap = new Map();
  for (const v of scene.vertices) vMap.set(v.id, v);

  const exteriorFaces = (scene.faces || []).filter(
    (f) => f && !f.hidden && !f.internal && Array.isArray(f.vertices) && f.vertices.length >= 3,
  );

  const SHAPE_NAMES = {
    3: 'Tam giác',
    4: 'Tứ giác',
    5: 'Ngũ giác',
    6: 'Lục giác',
    7: 'Thất giác',
    8: 'Bát giác',
  };

  const makeResult = (pts, loops = null) => ({
    valid: true,
    points: pts,
    allLoops: loops || [pts],
    shapeName: SHAPE_NAMES[pts.length] || `Đa giác ${pts.length} cạnh`,
    area: polygonArea(pts),
    perimeter: polygonPerimeter(pts),
  });

  // 1. GeoGebra AlgoIntersectRegionPlanePolyhedron pipeline when exterior faces exist
  if (exteriorFaces.length >= 3) {
    const faceSegments = new Map(); // faceIdx -> Array<{ p1, p2 }>
    const coplanarFaces = [];
    const parentToFaces = new Map(); // parentKey -> Set<faceIdx>

    const linkParent = (parentKey, fIdx) => {
      if (!parentToFaces.has(parentKey)) parentToFaces.set(parentKey, new Set());
      parentToFaces.get(parentKey).add(fIdx);
    };

    for (let fIdx = 0; fIdx < exteriorFaces.length; fIdx++) {
      const f = exteriorFaces[fIdx];
      const ids = f.vertices.filter((id) => vMap.has(id));
      if (ids.length < 3) continue;
      const polyPts = ids.map((id) => vMap.get(id));
      const pl = planeFrom3Points(polyPts[0], polyPts[1], polyPts[2]);
      if (!pl.valid) continue;

      const lineDirRaw = vecCross(n, pl.normal);
      if (vecLen(lineDirRaw) < 1e-5) {
        // Coplanar face check
        const distPlane = Math.abs(vecDot(n, polyPts[0]) - d);
        if (distPlane < 1e-4) {
          coplanarFaces.push(polyPts.map((p, idx) => ({ x: p.x, y: p.y, z: p.z, onEdge: ids[idx] })));
        }
        continue;
      }
      const lineDir = vecNormalize(lineDirRaw);

      // Collect intersections of cutting plane with every edge/vertex of this face
      const rawHits = [];
      for (let i = 0; i < ids.length; i++) {
        const uId = ids[i];
        const wId = ids[(i + 1) % ids.length];
        const p1 = vMap.get(uId);
        const p2 = vMap.get(wId);
        const s1 = vecDot(n, p1) - d;
        const s2 = vecDot(n, p2) - d;

        if (Math.abs(s1) < 1e-4) {
          rawHits.push({ x: p1.x, y: p1.y, z: p1.z, parent: `V:${uId}`, onEdge: uId });
        }
        if ((s1 > 1e-4 && s2 < -1e-4) || (s1 < -1e-4 && s2 > 1e-4)) {
          const t = s1 / (s1 - s2);
          const pt = lerpPoint(p1, p2, t);
          const eKey = uId < wId ? `E:${uId}|${wId}` : `E:${wId}|${uId}`;
          rawHits.push({ x: pt.x, y: pt.y, z: pt.z, parent: eKey, onEdge: `${uId}${wId}` });
        }
      }

      if (rawHits.length < 2) continue;
      const origin = rawHits[0];
      const sorted = rawHits
        .map((h) => ({ ...h, param: vecDot(vecSub(h, origin), lineDir) }))
        .sort((a, b) => a.param - b.param);

      // Deduplicate collinear hits within 1e-4 (prefer vertex parent if one is a vertex)
      const uniq = [];
      for (const h of sorted) {
        const last = uniq[uniq.length - 1];
        if (last && vecDist(last, h) < 1e-4) {
          if (h.parent.startsWith('V:') && !last.parent.startsWith('V:')) {
            uniq[uniq.length - 1] = h;
          }
          continue;
        }
        uniq.push(h);
      }
      if (uniq.length < 2) continue;

      // GeoGebra checkMidpoint: merge consecutive subsegments whose midpoints lie inside face polygon
      const segs = [];
      let segStart = null;
      let segEnd = null;
      for (let i = 0; i < uniq.length - 1; i++) {
        const a = uniq[i];
        const b = uniq[i + 1];
        const mid = midpoint(a, b);
        if (pointInPolygon3D(mid, polyPts, pl.normal)) {
          if (!segStart) segStart = a;
          segEnd = b;
        } else if (segStart) {
          segs.push({ p1: segStart, p2: segEnd });
          segStart = null;
          segEnd = null;
        }
      }
      if (segStart) segs.push({ p1: segStart, p2: segEnd });

      if (segs.length) {
        faceSegments.set(fIdx, segs);
        for (const sg of segs) {
          linkParent(sg.p1.parent, fIdx);
          linkParent(sg.p2.parent, fIdx);
        }
      }
    }

    // Chain face segments across shared parent edges/vertices into closed polygon loops
    const loops = [];
    const samePoint = (a, b) => a.parent === b.parent || vecDist(a, b) < 1e-3;
    while (faceSegments.size > 0) {
      const startFace = faceSegments.keys().next().value;
      const startSegs = faceSegments.get(startFace);
      if (!startSegs || !startSegs.length) {
        faceSegments.delete(startFace);
        continue;
      }
      const firstSeg = startSegs.shift();
      if (!startSegs.length) faceSegments.delete(startFace);

      const firstPt = firstSeg.p1;
      let curPt = firstSeg.p2;
      let curFace = startFace;
      let prevParent = firstPt.parent;
      const loop = [firstPt];

      let guard = 0;
      let closed = false;
      while (guard++ < 120) {
        if (samePoint(curPt, firstPt) && loop.length >= 3) {
          closed = true;
          break;
        }
        loop.push(curPt);

        // Search adjacent faces sharing curPt.parent (prefer other face before same face)
        const candFaces = [...(parentToFaces.get(curPt.parent) || [])];
        if (!candFaces.includes(curFace)) candFaces.push(curFace);
        candFaces.sort((fa, fb) => (fa === curFace ? 1 : 0) - (fb === curFace ? 1 : 0));

        let nextStep = null;
        for (const nf of candFaces) {
          const list = faceSegments.get(nf);
          if (!list || !list.length) continue;
          for (let i = 0; i < list.length; i++) {
            const sg = list[i];
            if (samePoint(sg.p1, curPt) && sg.p2.parent !== prevParent) {
              nextStep = { nf, idx: i, nextPt: sg.p2 };
              break;
            }
            if (samePoint(sg.p2, curPt) && sg.p1.parent !== prevParent) {
              nextStep = { nf, idx: i, nextPt: sg.p1 };
              break;
            }
          }
          if (nextStep) break;
        }

        if (!nextStep) break;
        const targetList = faceSegments.get(nextStep.nf);
        targetList.splice(nextStep.idx, 1);
        if (!targetList.length) faceSegments.delete(nextStep.nf);
        prevParent = curPt.parent;
        curPt = nextStep.nextPt;
        curFace = nextStep.nf;
      }

      if (closed && loop.length >= 3) {
        loops.push(loop.map(({ x, y, z, onEdge }) => ({ x, y, z, onEdge })));
      }
    }

    if (loops.length) {
      loops.sort((a, b) => polygonArea(b) - polygonArea(a));
      return makeResult(loops[0], loops);
    }
    if (coplanarFaces.length) {
      coplanarFaces.sort((a, b) => polygonArea(b) - polygonArea(a));
      return makeResult(coplanarFaces[0], coplanarFaces);
    }
  }

  // 2. Wireframe-only fallback (when user drew edges without closing faces)
  const edgePairSet = new Map();
  const addPair = (uId, wId) => {
    if (!uId || !wId || uId === wId) return;
    if (!vMap.has(uId) || !vMap.has(wId)) return;
    const key = uId < wId ? `${uId}|${wId}` : `${wId}|${uId}`;
    if (!edgePairSet.has(key)) edgePairSet.set(key, [uId, wId]);
  };
  for (const f of exteriorFaces) {
    for (let i = 0; i < f.vertices.length; i++) addPair(f.vertices[i], f.vertices[(i + 1) % f.vertices.length]);
  }
  if (!edgePairSet.size && Array.isArray(scene.edges)) {
    for (const e of scene.edges) addPair(e.from, e.to);
  }

  const hits = [];
  const pushUnique = (pt, edgeName) => {
    for (const existing of hits) {
      if (vecDist(existing, pt) < 1e-4) return;
    }
    hits.push({ x: pt.x, y: pt.y, z: pt.z, onEdge: edgeName });
  };

  for (const [uId, wId] of edgePairSet.values()) {
    const p1 = vMap.get(uId);
    const p2 = vMap.get(wId);
    const s1 = vecDot(n, p1) - d;
    const s2 = vecDot(n, p2) - d;
    if (Math.abs(s1) < 1e-5 && Math.abs(s2) < 1e-5) {
      pushUnique(p1, uId);
      pushUnique(p2, wId);
    } else if (Math.abs(s1) < 1e-5) {
      pushUnique(p1, uId);
    } else if (Math.abs(s2) < 1e-5) {
      pushUnique(p2, wId);
    } else if ((s1 > 0 && s2 < 0) || (s1 < 0 && s2 > 0)) {
      const t = s1 / (s1 - s2);
      pushUnique(lerpPoint(p1, p2, t), `${uId}${wId}`);
    }
  }

  if (hits.length < 3) return { valid: false, points: hits, shapeName: '', area: 0, perimeter: 0 };

  const ctr = centroid(hits);
  const ref = Math.abs(n.z) < 0.9 ? { x: 0, y: 0, z: 1 } : { x: 1, y: 0, z: 0 };
  const uAxis = vecNormalize(vecCross(ref, n));
  const vAxis = vecNormalize(vecCross(n, uAxis));
  const ordered = hits
    .map((pt) => {
      const rel = vecSub(pt, ctr);
      return { ...pt, _ang: Math.atan2(vecDot(rel, vAxis), vecDot(rel, uAxis)) };
    })
    .sort((a, b) => a._ang - b._ang)
    .map(({ _ang, ...pt }) => pt);

  return makeResult(ordered);
}

/**
 * Sanitizes and normalizes any scene specification so the 3D renderer always receives valid coordinates & IDs.
 */
export function normalizeSceneSpec(raw) {
  const src = raw && typeof raw === 'object' ? raw : {};
  const vertices = [];
  const seen = new Set();

  if (Array.isArray(src.vertices)) {
    for (const v of src.vertices) {
      if (!v || typeof v.id !== 'string') continue;
      const id = v.id.trim();
      if (!id || seen.has(id)) continue;
      const x = Number(v.x), y = Number(v.y), z = Number(v.z);
      if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(z)) continue;
      seen.add(id);
      vertices.push({
        id,
        x: Math.round(x * 10000) / 10000,
        y: Math.round(y * 10000) / 10000,
        z: Math.round(z * 10000) / 10000,
        role: ['primary', 'aux', 'projection', 'center'].includes(v.role) ? v.role : 'primary',
        hidden: Boolean(v.hidden),
      });
    }
  }

  const edges = [];
  const edgeKeys = new Set();
  if (Array.isArray(src.edges)) {
    for (const e of src.edges) {
      if (!e || !seen.has(e.from) || !seen.has(e.to) || e.from === e.to) continue;
      const k = e.from < e.to ? `${e.from}|${e.to}` : `${e.to}|${e.from}`;
      if (edgeKeys.has(k)) continue;
      edgeKeys.add(k);
      edges.push({
        from: e.from,
        to: e.to,
        style: ['solid', 'dashed', 'highlight', 'altitude'].includes(e.style) ? e.style : 'solid',
        label: typeof e.label === 'string' ? e.label.trim() : '',
        hidden: Boolean(e.hidden),
      });
    }
  }

  const faces = [];
  if (Array.isArray(src.faces)) {
    for (const f of src.faces) {
      if (!f || !Array.isArray(f.vertices)) continue;
      const vIds = f.vertices.filter((id) => seen.has(id));
      if (vIds.length < 3) continue;
      const op = Number(f.opacity);
      faces.push({
        vertices: vIds,
        color: typeof f.color === 'string' && /^#[0-9a-fA-F]{6}$/.test(f.color) ? f.color : '#3B82F6',
        opacity: Number.isFinite(op) ? Math.min(0.65, Math.max(0.08, op)) : 0.18,
        label: typeof f.label === 'string' ? f.label.trim() : '',
        hidden: Boolean(f.hidden),
        internal: Boolean(f.internal),
      });
    }
  }

  const rightAngles = Array.isArray(src.rightAngles)
    ? src.rightAngles.filter((r) => r && seen.has(r.vertex) && seen.has(r.p1) && seen.has(r.p2))
    : [];

  const angles = Array.isArray(src.angles)
    ? src.angles
        .filter((a) => a && seen.has(a.vertex) && seen.has(a.p1) && seen.has(a.p2))
        .map((a) => ({ vertex: a.vertex, p1: a.p1, p2: a.p2, label: String(a.label || '') }))
    : [];

  const spheres = Array.isArray(src.spheres)
    ? src.spheres
        .filter((s) => s && Number(s.radius) > 0)
        .map((s) => ({
          center: s.center && seen.has(s.center) ? s.center : '',
          cx: Number(s.cx) || 0,
          cy: Number(s.cy) || 0,
          cz: Number(s.cz) || 0,
          radius: Number(s.radius),
          label: String(s.label || ''),
          hidden: Boolean(s.hidden),
        }))
    : [];

  const cones = Array.isArray(src.cones)
    ? src.cones
        .filter((c) => c && seen.has(c.apex) && seen.has(c.baseCenter) && Number(c.radius) > 0)
        .map((c) => ({ ...c, radius: Number(c.radius), hidden: Boolean(c.hidden) }))
    : [];

  const cylinders = Array.isArray(src.cylinders)
    ? src.cylinders
        .filter((c) => c && seen.has(c.topCenter) && seen.has(c.bottomCenter) && Number(c.radius) > 0)
        .map((c) => ({ ...c, radius: Number(c.radius), hidden: Boolean(c.hidden) }))
    : [];

  const vectors = Array.isArray(src.vectors)
    ? src.vectors
        .filter((vc) => vc && seen.has(vc.from) && seen.has(vc.to) && vc.from !== vc.to)
        .map((vc) => ({
          from: vc.from,
          to: vc.to,
          color: typeof vc.color === 'string' && /^#[0-9a-fA-F]{6}$/.test(vc.color) ? vc.color : '#7C3AED',
          label: typeof vc.label === 'string' ? vc.label.trim() : '',
          hidden: Boolean(vc.hidden),
        }))
    : [];

  const planes = Array.isArray(src.planes)
    ? src.planes
        .filter((pl) => pl && Number.isFinite(Number(pl.nx)) && Number.isFinite(Number(pl.ny)) && Number.isFinite(Number(pl.nz)))
        .map((pl) => ({
          label: typeof pl.label === 'string' ? pl.label.trim() : '(P)',
          nx: Number(pl.nx),
          ny: Number(pl.ny),
          nz: Number(pl.nz),
          d: Number(pl.d) || 0,
          color: typeof pl.color === 'string' && /^#[0-9a-fA-F]{6}$/.test(pl.color) ? pl.color : '#0EA5E9',
          hidden: Boolean(pl.hidden),
        }))
    : [];

  const surfaces = Array.isArray(src.surfaces)
    ? src.surfaces
        .filter((sf) => sf && typeof sf.expr === 'string' && sf.expr.trim())
        .map((sf) => ({
          expr: sf.expr.trim(),
          range: Math.min(6, Math.max(1.5, Number(sf.range) || 3)),
          label: typeof sf.label === 'string' ? sf.label.trim() : `z = ${sf.expr.trim()}`,
          hidden: Boolean(sf.hidden),
        }))
    : [];

  const circles = Array.isArray(src.circles)
    ? src.circles
        .filter((c) => c && c.center && Number(c.radius) > 0 && c.normal)
        .map((c) => ({
          center: { x: Number(c.center.x) || 0, y: Number(c.center.y) || 0, z: Number(c.center.z) || 0 },
          normal: vecNormalize({ x: Number(c.normal.x) || 0, y: Number(c.normal.y) || 0, z: Number(c.normal.z) || 1 }),
          radius: Number(c.radius),
          color: typeof c.color === 'string' && /^#[0-9a-fA-F]{6}$/.test(c.color) ? c.color : '#EA580C',
          label: typeof c.label === 'string' ? c.label.trim() : '',
          hidden: Boolean(c.hidden),
        }))
    : [];

  const crossSection = Array.isArray(src.crossSection)
    ? src.crossSection.filter((id) => seen.has(id))
    : [];

  return {
    showOxyz: Boolean(src.showOxyz),
    unitNote: typeof src.unitNote === 'string' ? src.unitNote : '',
    vertices,
    edges,
    faces,
    rightAngles,
    angles,
    spheres,
    cones,
    cylinders,
    vectors,
    planes,
    circles,
    surfaces,
    crossSection,
  };
}

/**
 * Parametric Grade 11 Wizard Builder (GDPT 2018)
 */
export function buildGrade11CustomSolid(cfg = {}) {
  const shape = cfg.shape || 'chop-tu-giac';
  const base = cfg.base || 'vuong';
  const foot = cfg.foot || 'A';
  const a = Math.max(1.2, Math.min(5, Number(cfg.a) || 3));
  const b = Math.max(1.0, Math.min(5, Number(cfg.b) || 2.2));
  const h = Math.max(1.2, Math.min(5.5, Number(cfg.h) || 3));
  const topRatio = Math.max(0.25, Math.min(0.85, Number(cfg.topRatio) || 0.5));

  if (shape === 'tu-dien-deu') {
    const r = a / Math.sqrt(3);
    const hz = a * Math.sqrt(2 / 3);
    const A = { id: 'A', x: r, y: 0, z: 0, role: 'primary' };
    const B = { id: 'B', x: -r / 2, y: -a / 2, z: 0, role: 'primary' };
    const C = { id: 'C', x: -r / 2, y: a / 2, z: 0, role: 'primary' };
    const G = { id: 'G', x: 0, y: 0, z: 0, role: 'center' };
    const S = { id: 'S', x: 0, y: 0, z: hz, role: 'primary' };
    const M = midpoint(B, C);
    const N = midpoint(S, A);
    const scene = normalizeSceneSpec({
      unitNote: `Tứ diện đều cạnh a = ${a.toFixed(1)}, SG = a√6/3 ≈ ${hz.toFixed(2)}`,
      vertices: [A, B, C, G, S, { id: 'M', ...M, role: 'aux' }, { id: 'N', ...N, role: 'aux' }],
      edges: [
        { from: 'A', to: 'B', style: 'solid' },
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'C', to: 'A', style: 'dashed' },
        { from: 'S', to: 'A', style: 'solid' },
        { from: 'S', to: 'B', style: 'solid' },
        { from: 'S', to: 'C', style: 'solid' },
        { from: 'S', to: 'G', style: 'altitude', label: 'h' },
        { from: 'A', to: 'M', style: 'dashed' },
        { from: 'M', to: 'N', style: 'highlight', label: 'd(SA,BC)' },
      ],
      faces: [
        { vertices: ['A', 'B', 'C'], color: '#3B82F6', opacity: 0.16 },
        { vertices: ['S', 'A', 'B'], color: '#60A5FA', opacity: 0.14 },
        { vertices: ['S', 'B', 'C'], color: '#F59E0B', opacity: 0.16 },
        { vertices: ['S', 'C', 'A'], color: '#60A5FA', opacity: 0.12 },
      ],
      rightAngles: [
        { vertex: 'G', p1: 'S', p2: 'A' },
        { vertex: 'N', p1: 'M', p2: 'A' },
        { vertex: 'M', p1: 'N', p2: 'C' },
      ],
    });
    return {
      title: `Tứ diện đều S.ABC (cạnh ${a.toFixed(1)})`,
      grade: 'Lớp 11',
      formula: 'h = a√6 / 3 · V = a³√2 / 12 · MN = a√2 / 2',
      scene,
      steps: [
        {
          stepTitle: 'Xác định đường cao SG ⊥ (ABC)',
          explanation: 'Vì S.ABC là tứ diện đều nên hình chiếu của đỉnh S lên đáy (ABC) là trọng tâm G của tam giác đều ABC.',
          formula: `SG = a√6 / 3 ≈ ${hz.toFixed(2)}`,
          highlightVertices: ['S', 'G'],
          highlightEdges: [{ from: 'S', to: 'G' }],
          highlightFaceVertices: ['A', 'B', 'C'],
        },
        {
          stepTitle: 'Đoạn vuông góc chung MN của SA và BC',
          explanation: 'Gọi M, N lần lượt là trung điểm BC và SA. Khi đó MN ⊥ SA và MN ⊥ BC nên MN là đoạn vuông góc chung.',
          formula: `d(SA, BC) = MN = a√2 / 2 ≈ ${(a * Math.SQRT1_2).toFixed(2)}`,
          highlightVertices: ['M', 'N', 'S', 'A', 'B', 'C'],
          highlightEdges: [{ from: 'M', to: 'N' }, { from: 'S', to: 'A' }, { from: 'B', to: 'C' }],
        },
      ],
    };
  }

  if (shape === 'chop-cut-deu') {
    const halfB = a / 2;
    const halfT = (a * topRatio) / 2;
    const vertices = [
      { id: 'A', x: halfB, y: -halfB, z: 0, role: 'primary' },
      { id: 'B', x: halfB, y: halfB, z: 0, role: 'primary' },
      { id: 'C', x: -halfB, y: halfB, z: 0, role: 'primary' },
      { id: 'D', x: -halfB, y: -halfB, z: 0, role: 'primary' },
      { id: "A'", x: halfT, y: -halfT, z: h, role: 'primary' },
      { id: "B'", x: halfT, y: halfT, z: h, role: 'primary' },
      { id: "C'", x: -halfT, y: halfT, z: h, role: 'primary' },
      { id: "D'", x: -halfT, y: -halfT, z: h, role: 'primary' },
      { id: 'O', x: 0, y: 0, z: 0, role: 'center' },
      { id: "O'", x: 0, y: 0, z: h, role: 'center' },
    ];
    const S1 = a * a;
    const S2 = (a * topRatio) ** 2;
    const vol = (h / 3) * (S1 + S2 + Math.sqrt(S1 * S2));
    const scene = normalizeSceneSpec({
      unitNote: `Chóp cụt đều: đáy lớn ${a.toFixed(1)}, đáy nhỏ ${(a * topRatio).toFixed(1)}, h = ${h.toFixed(1)}`,
      vertices,
      edges: [
        { from: 'A', to: 'B', style: 'solid', label: `${a}` },
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'C', to: 'D', style: 'dashed' },
        { from: 'D', to: 'A', style: 'dashed' },
        { from: "A'", to: "B'", style: 'solid', label: `${(a * topRatio).toFixed(1)}` },
        { from: "B'", to: "C'", style: 'solid' },
        { from: "C'", to: "D'", style: 'solid' },
        { from: "D'", to: "A'", style: 'solid' },
        { from: 'A', to: "A'", style: 'solid' },
        { from: 'B', to: "B'", style: 'solid' },
        { from: 'C', to: "C'", style: 'solid' },
        { from: 'D', to: "D'", style: 'dashed' },
        { from: 'O', to: "O'", style: 'altitude', label: `h=${h}` },
      ],
      faces: [
        { vertices: ['A', 'B', 'C', 'D'], color: '#3B82F6', opacity: 0.16 },
        { vertices: ["A'", "B'", "C'", "D'"], color: '#10B981', opacity: 0.22 },
        { vertices: ['A', 'B', "B'", "A'"], color: '#60A5FA', opacity: 0.14 },
        { vertices: ['B', 'C', "C'", "B'"], color: '#F59E0B', opacity: 0.16 },
        { vertices: ['C', 'D', "D'", "C'"], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['D', 'A', "A'", "D'"], color: '#60A5FA', opacity: 0.12 },
      ],
      rightAngles: [
        { vertex: 'O', p1: "O'", p2: 'B' },
        { vertex: "O'", p1: 'O', p2: "B'" },
      ],
    });
    return {
      title: `Chóp cụt tứ giác đều ABCD.A'B'C'D'`,
      grade: 'Lớp 11',
      formula: `V = (h/3)(S + S' + √(S·S')) ≈ ${vol.toFixed(2)}`,
      scene,
      steps: [
        {
          stepTitle: 'Hai đáy song song và đường cao OO\'',
          explanation: "Chóp cụt tứ giác đều có hai đáy là hai hình vuông đồng dạng nằm trên hai mặt phẳng song song, OO' ⊥ (ABCD).",
          formula: `S = ${S1.toFixed(2)}, S' = ${S2.toFixed(2)}`,
          highlightVertices: ['O', "O'"],
          highlightEdges: [{ from: 'O', to: "O'" }],
          highlightFaceVertices: ["A'", "B'", "C'", "D'"],
        },
        {
          stepTitle: 'Tính thể tích theo công thức SGK Lớp 11 mới',
          explanation: 'Áp dụng công thức chuẩn trong SGK GDPT 2018 cho khối chóp cụt đều.',
          formula: `V = (${h}/3)·(${S1.toFixed(2)} + ${S2.toFixed(2)} + ${(Math.sqrt(S1 * S2)).toFixed(2)}) = ${vol.toFixed(2)}`,
          highlightFaceVertices: ['B', 'C', "C'", "B'"],
        },
      ],
    };
  }

  // Base vertices helper
  let baseVerts = [];
  let baseEdges = [];
  if (shape === 'chop-tam-giac' || shape === 'lang-tru-dung' || shape === 'lang-tru-xien') {
    const isRightTri = base === 'vuong';
    const A = isRightTri
      ? { id: 'A', x: -a * 0.45, y: -b * 0.45, z: 0, role: 'primary' }
      : { id: 'A', x: a * 0.48, y: -a * 0.5, z: 0, role: 'primary' };
    const B = isRightTri
      ? { id: 'B', x: a * 0.55, y: -b * 0.45, z: 0, role: 'primary' }
      : { id: 'B', x: a * 0.48, y: a * 0.5, z: 0, role: 'primary' };
    const C = isRightTri
      ? { id: 'C', x: a * 0.55, y: b * 0.55, z: 0, role: 'primary' }
      : { id: 'C', x: -a * 0.42, y: 0, z: 0, role: 'primary' };
    baseVerts = [A, B, C];
    baseEdges = [
      { from: 'A', to: 'B', style: 'solid' },
      { from: 'B', to: 'C', style: 'solid' },
      { from: 'C', to: 'A', style: 'dashed' },
    ];
  } else {
    // 4-gon base
    const hw = a / 2;
    const hd = base === 'chu-nhat' ? b / 2 : base === 'thoi' ? a * 0.42 : hw;
    let A, B, C, D;
    if (base === 'thang-vuong') {
      A = { id: 'A', x: -hw * 0.6, y: -a / 2, z: 0, role: 'primary' };
      D = { id: 'D', x: hw * 0.6, y: -a / 2, z: 0, role: 'primary' };
      C = { id: 'C', x: hw * 0.6, y: 0, z: 0, role: 'primary' };
      B = { id: 'B', x: -hw * 0.6, y: a / 2, z: 0, role: 'primary' };
    } else if (base === 'thoi') {
      A = { id: 'A', x: hw * 1.15, y: 0, z: 0, role: 'primary' };
      B = { id: 'B', x: 0, y: hd * 1.1, z: 0, role: 'primary' };
      C = { id: 'C', x: -hw * 1.15, y: 0, z: 0, role: 'primary' };
      D = { id: 'D', x: 0, y: -hd * 1.1, z: 0, role: 'primary' };
    } else {
      A = { id: 'A', x: hd, y: -hw, z: 0, role: 'primary' };
      B = { id: 'B', x: hd, y: hw, z: 0, role: 'primary' };
      C = { id: 'C', x: -hd, y: hw, z: 0, role: 'primary' };
      D = { id: 'D', x: -hd, y: -hw, z: 0, role: 'primary' };
    }
    baseVerts = [A, B, C, D];
    baseEdges = [
      { from: 'A', to: 'B', style: 'solid' },
      { from: 'B', to: 'C', style: 'solid' },
      { from: 'C', to: 'D', style: 'dashed' },
      { from: 'D', to: 'A', style: 'dashed' },
    ];
  }

  if (shape === 'lang-tru-dung' || shape === 'lang-tru-xien' || shape === 'hinh-hop') {
    const isOblique = shape === 'lang-tru-xien';
    const shiftX = isOblique ? 0.85 : 0;
    const shiftY = isOblique ? 0.65 : 0;
    const topVerts = baseVerts.map((v) => ({
      id: `${v.id}'`,
      x: v.x + shiftX,
      y: v.y + shiftY,
      z: h,
      role: 'primary',
    }));
    const edges = [...baseEdges];
    for (let i = 0; i < topVerts.length; i++) {
      edges.push({
        from: topVerts[i].id,
        to: topVerts[(i + 1) % topVerts.length].id,
        style: 'solid',
      });
    }
    baseVerts.forEach((v, idx) => {
      edges.push({
        from: v.id,
        to: topVerts[idx].id,
        style: idx === 0 && !isOblique ? 'altitude' : idx === baseVerts.length - 1 ? 'dashed' : 'solid',
      });
    });

    const extraVerts = [];
    const rightAngles = [];
    if (isOblique) {
      const H = { id: 'H', x: topVerts[0].x, y: topVerts[0].y, z: 0, role: 'projection' };
      extraVerts.push(H);
      edges.push({ from: topVerts[0].id, to: 'H', style: 'altitude', label: `h=${h}` });
      edges.push({ from: 'A', to: 'H', style: 'dashed' });
      rightAngles.push({ vertex: 'H', p1: topVerts[0].id, p2: 'A' });
    } else {
      rightAngles.push({ vertex: 'A', p1: "A'", p2: 'B' });
    }

    const bIds = baseVerts.map((v) => v.id);
    const tIds = topVerts.map((v) => v.id);
    const faces = [
      { vertices: bIds, color: '#3B82F6', opacity: 0.16 },
      { vertices: tIds, color: '#3B82F6', opacity: 0.16 },
    ];
    for (let i = 0; i < bIds.length; i++) {
      const j = (i + 1) % bIds.length;
      faces.push({ vertices: [bIds[i], bIds[j], tIds[j], tIds[i]], color: i === 0 ? '#10B981' : '#60A5FA', opacity: 0.13 });
    }
    const scene = normalizeSceneSpec({
      unitNote: `${isOblique ? 'Lăng trụ xiên' : shape === 'hinh-hop' ? 'Hình hộp đứng' : 'Lăng trụ đứng'}, đáy ${a.toFixed(1)}, cao h = ${h.toFixed(1)}`,
      vertices: [...baseVerts, ...topVerts, ...extraVerts],
      edges,
      faces,
      rightAngles,
    });
    const vol = polyhedronVolume(scene);
    return {
      title: isOblique ? `Lăng trụ xiên ${bIds.join('')}.${tIds.join('')}` : shape === 'hinh-hop' ? `Hình hộp đứng ${bIds.join('')}.${tIds.join('')}` : `Lăng trụ đứng ${bIds.join('')}.${tIds.join('')}`,
      grade: 'Lớp 11',
      formula: `V = S_đáy · h ≈ ${vol.toFixed(2)}`,
      scene,
      steps: [
        {
          stepTitle: isOblique ? "Đường cao A'H ⊥ mặt phẳng đáy" : "Cạnh bên AA' vuông góc với đáy",
          explanation: isOblique
            ? "Trong lăng trụ xiên, hình chiếu của A' xuống đáy là H. Chiều cao h = A'H."
            : "Trong lăng trụ đứng, mọi cạnh bên đều vuông góc với hai mặt đáy và có độ dài bằng h.",
          formula: `h = ${h.toFixed(2)}`,
          highlightVertices: isOblique ? ["A'", 'H', 'A'] : ['A', "A'"],
          highlightEdges: isOblique ? [{ from: "A'", to: 'H' }] : [{ from: 'A', to: "A'" }],
        },
        {
          stepTitle: 'Tính thể tích khối lăng trụ',
          explanation: 'Thể tích bằng diện tích đáy nhân chiều cao h.',
          formula: `V ≈ ${vol.toFixed(2)} đvtt`,
          highlightFaceVertices: bIds,
        },
      ],
    };
  }

  // Pyramid (Chóp tam giác / Chóp tứ giác)
  let footPt = { ...baseVerts[0] };
  let footLabel = 'A';
  const extraVerts = [];
  const edges = [...baseEdges];
  const rightAngles = [];
  if (foot === 'O' && baseVerts.length === 4) {
    footPt = centroid(baseVerts);
    footLabel = 'O';
    extraVerts.push({ id: 'O', ...footPt, role: 'center' });
    edges.push({ from: 'A', to: 'C', style: 'dashed' }, { from: 'B', to: 'D', style: 'dashed' });
  } else if (foot === 'H') {
    footPt = midpoint(baseVerts[0], baseVerts[1]);
    footLabel = 'H';
    extraVerts.push({ id: 'H', ...footPt, role: 'projection' });
  } else if (foot === 'G') {
    footPt = centroid(baseVerts.slice(0, 3));
    footLabel = 'G';
    extraVerts.push({ id: 'G', ...footPt, role: 'center' });
  }

  const S = { id: 'S', x: footPt.x, y: footPt.y, z: h, role: 'primary' };
  baseVerts.forEach((v, idx) => {
    const isFoot = footLabel === v.id;
    edges.push({
      from: 'S',
      to: v.id,
      style: isFoot ? 'altitude' : idx === baseVerts.length - 1 && footLabel !== 'A' ? 'dashed' : 'solid',
    });
  });
  if (footLabel !== 'A') {
    edges.push({ from: 'S', to: footLabel, style: 'altitude', label: `h=${h}` });
  }
  rightAngles.push({ vertex: footLabel, p1: 'S', p2: footLabel === baseVerts[1].id ? baseVerts[0].id : baseVerts[1].id });

  const bIds = baseVerts.map((v) => v.id);
  const faces = [{ vertices: bIds, color: '#3B82F6', opacity: 0.16 }];
  for (let i = 0; i < bIds.length; i++) {
    const j = (i + 1) % bIds.length;
    faces.push({
      vertices: ['S', bIds[i], bIds[j]],
      color: i === 0 && foot === 'H' ? '#10B981' : i === 1 ? '#F59E0B' : '#60A5FA',
      opacity: i === 0 && foot === 'H' ? 0.22 : 0.14,
    });
  }

  const scene = normalizeSceneSpec({
    unitNote: `Chóp S.${bIds.join('')}, đường cao S${footLabel} = ${h.toFixed(1)}`,
    vertices: [...baseVerts, ...extraVerts, S],
    edges,
    faces,
    rightAngles,
  });
  const vol = polyhedronVolume(scene);

  return {
    title: `Hình chóp S.${bIds.join('')} (S${footLabel} ⊥ đáy)`,
    grade: 'Lớp 11',
    formula: `V = (1/3)·S_đáy·S${footLabel} ≈ ${vol.toFixed(2)}`,
    scene,
    steps: [
      {
        stepTitle: `Xác định đường cao S${footLabel} ⊥ mặt phẳng đáy`,
        explanation:
          foot === 'H'
            ? 'Mặt bên (SAB) vuông góc với đáy theo giao tuyến AB, nên đường cao SH trong (SAB) vuông góc với đáy.'
            : foot === 'O'
              ? 'Hình chiếu của S xuống đáy trùng tâm O của đáy, nên SO là đường cao.'
              : `Chân đường cao hạ từ S trùng điểm ${footLabel}.`,
        formula: `S${footLabel} = ${h.toFixed(2)}`,
        highlightVertices: ['S', footLabel],
        highlightEdges: [{ from: 'S', to: footLabel }],
      },
      {
        stepTitle: 'Xác định thể tích khối chóp',
        explanation: 'Thể tích bằng 1/3 diện tích đáy nhân chiều cao.',
        formula: `V ≈ ${vol.toFixed(2)} đvtt`,
        highlightFaceVertices: bIds,
      },
    ],
  };
}

/**
 * Picks next natural textbook vertex label for easy interactive drawing.
 */
export function nextStandardVertexLabel(vertices = []) {
  const used = new Set((vertices || []).map((v) => v.id));
  const std = ['A', 'B', 'C', 'D', 'E', 'F', 'M', 'N', 'P', 'Q', 'H', 'I', 'K', 'O', 'S'];
  for (const ch of std) {
    if (!used.has(ch)) return ch;
  }
  for (let i = 1; i <= 50; i++) {
    if (!used.has(`P${i}`)) return `P${i}`;
  }
  return `V${Date.now() % 100}`;
}

/**
 * Orders planar points counter-clockwise around their centroid in the Oxy plane.
 */
export function orderPolygonVertices(pts = []) {
  if (!pts || pts.length <= 2) return [...(pts || [])];
  const ctr = centroid(pts);
  return [...pts].sort(
    (a, b) => Math.atan2(a.y - ctr.y, a.x - ctr.x) - Math.atan2(b.y - ctr.y, b.x - ctr.x),
  );
}

/**
 * Easy Self-Drawing Builder: turns user's drawn base vertices (z ≈ 0) into a complete Pyramid S.base.
 */
export function extrudeBaseToPyramid(rawScene, opts = {}) {
  const scene = normalizeSceneSpec(rawScene);
  const baseCandidates = scene.vertices.filter((v) => !v.hidden && Math.abs(v.z) < 0.25);
  const rawBase = baseCandidates.length >= 3 ? baseCandidates : scene.vertices.filter((v) => !v.hidden);
  if (rawBase.length < 3) {
    return { ok: false, message: 'Cần ít nhất 3 điểm đáy để dựng đỉnh chóp S.', scene };
  }
  const base = orderPolygonVertices(rawBase);
  const h = Math.max(1.0, Math.min(6.0, Number(opts.height) || 3.0));
  const used = new Set(scene.vertices.map((v) => v.id));
  const footVertex = opts.footId ? base.find((v) => v.id === opts.footId) : null;
  const ctr = footVertex ? { x: footVertex.x, y: footVertex.y, z: 0 } : centroid(base);

  let apexId = 'S';
  if (used.has(apexId)) {
    for (let i = 1; i <= 20; i++) {
      if (!used.has(`S${i}`)) { apexId = `S${i}`; break; }
    }
  }
  const apex = { id: apexId, x: ctr.x, y: ctr.y, z: h, role: 'primary' };
  const vertices = [...scene.vertices, apex];
  let footId = footVertex ? footVertex.id : '';
  if (!footId && !used.has('O') && base.length >= 4) {
    footId = 'O';
    vertices.push({ id: 'O', x: ctr.x, y: ctr.y, z: 0, role: 'center' });
  } else if (!footId && !used.has('H')) {
    footId = 'H';
    vertices.push({ id: 'H', x: ctr.x, y: ctr.y, z: 0, role: 'projection' });
  }

  const edges = [...scene.edges];
  const hasEdge = (u, w) => edges.some((e) => (e.from === u && e.to === w) || (e.from === w && e.to === u));
  for (let i = 0; i < base.length; i++) {
    const u = base[i].id;
    const w = base[(i + 1) % base.length].id;
    if (!hasEdge(u, w)) edges.push({ from: u, to: w, style: 'solid' });
    if (!hasEdge(apexId, u)) edges.push({ from: apexId, to: u, style: footVertex && u === footVertex.id ? 'altitude' : 'solid' });
  }
  if (footId && !footVertex && !hasEdge(apexId, footId)) {
    edges.push({ from: apexId, to: footId, style: 'altitude', label: `h=${h}` });
  }

  const bIds = base.map((v) => v.id);
  const faces = [
    { vertices: bIds, color: '#3B82F6', opacity: 0.16 },
    ...bIds.map((id, i) => ({
      vertices: [apexId, id, bIds[(i + 1) % bIds.length]],
      color: i === 1 ? '#F59E0B' : '#60A5FA',
      opacity: 0.14,
    })),
  ];

  return {
    ok: true,
    message: `Đã dựng hình chóp ${apexId}.${bIds.join('')} (cao h = ${h}).`,
    scene: normalizeSceneSpec({ ...scene, vertices, edges, faces }),
  };
}

/**
 * Easy Self-Drawing Builder: extrudes user's drawn base polygon (z ≈ 0) into a Prism base.base'.
 */
export function extrudeBaseToPrism(rawScene, opts = {}) {
  const scene = normalizeSceneSpec(rawScene);
  const baseCandidates = scene.vertices.filter((v) => !v.hidden && Math.abs(v.z) < 0.25);
  const rawBase = baseCandidates.length >= 3 ? baseCandidates : scene.vertices.filter((v) => !v.hidden);
  if (rawBase.length < 3) {
    return { ok: false, message: 'Cần ít nhất 3 điểm đáy để dựng lăng trụ.', scene };
  }
  const base = orderPolygonVertices(rawBase);
  const h = Math.max(1.0, Math.min(6.0, Number(opts.height) || 2.8));
  const shiftX = Number(opts.shiftX) || 0;
  const shiftY = Number(opts.shiftY) || 0;
  const used = new Set(scene.vertices.map((v) => v.id));

  const topVerts = base.map((v) => {
    let tid = `${v.id}'`;
    if (used.has(tid)) tid = nextStandardVertexLabel([...scene.vertices, ...base]);
    used.add(tid);
    return { id: tid, x: v.x + shiftX, y: v.y + shiftY, z: v.z + h, role: 'primary' };
  });

  const vertices = [...scene.vertices, ...topVerts];
  const edges = [...scene.edges];
  const hasEdge = (u, w) => edges.some((e) => (e.from === u && e.to === w) || (e.from === w && e.to === u));

  for (let i = 0; i < base.length; i++) {
    const j = (i + 1) % base.length;
    if (!hasEdge(base[i].id, base[j].id)) edges.push({ from: base[i].id, to: base[j].id, style: 'solid' });
    if (!hasEdge(topVerts[i].id, topVerts[j].id)) edges.push({ from: topVerts[i].id, to: topVerts[j].id, style: 'solid' });
    if (!hasEdge(base[i].id, topVerts[i].id)) {
      edges.push({ from: base[i].id, to: topVerts[i].id, style: i === 0 && shiftX === 0 && shiftY === 0 ? 'altitude' : 'solid' });
    }
  }

  const bIds = base.map((v) => v.id);
  const tIds = topVerts.map((v) => v.id);
  const faces = [
    { vertices: bIds, color: '#3B82F6', opacity: 0.16 },
    { vertices: tIds, color: '#3B82F6', opacity: 0.16 },
    ...bIds.map((id, i) => {
      const j = (i + 1) % bIds.length;
      return { vertices: [id, bIds[j], tIds[j], tIds[i]], color: i === 0 ? '#10B981' : '#60A5FA', opacity: 0.14 };
    }),
  ];

  return {
    ok: true,
    message: `Đã dựng lăng trụ ${bIds.join('')}.${tIds.join('')} (cao h = ${h}).`,
    scene: normalizeSceneSpec({ ...scene, vertices, edges, faces }),
  };
}

/**
 * Generates clean centered base stencils (regular n-gon, parallelogram, trapezoid) for quick user drawing.
 */
export function buildBaseStencilScene(kind = 'vuong', opts = {}) {
  const r = Math.max(1.0, Math.min(3.6, Number(opts.radius) || 2.0));
  const z = Number(opts.z) || 0;
  const labels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
  let pts = [];
  let note = '';

  if (kind === 'tam-giac-deu' || kind === 'regular-3') {
    for (let i = 0; i < 3; i++) {
      const ang = (i * 2 * Math.PI) / 3 - Math.PI / 6;
      pts.push({ id: labels[i], x: Math.cos(ang) * r, y: Math.sin(ang) * r, z, role: 'primary' });
    }
    note = 'Đáy tam giác đều ABC — bấm "Lên chóp S" hoặc "Lên lăng trụ" để dựng khối';
  } else if (kind === 'ngu-giac' || kind === 'luc-giac') {
    const n = kind === 'luc-giac' ? 6 : 5;
    for (let i = 0; i < n; i++) {
      const ang = (i * 2 * Math.PI) / n - Math.PI / 2;
      pts.push({ id: labels[i], x: Math.cos(ang) * r, y: Math.sin(ang) * r, z, role: 'primary' });
    }
    note = `Đáy ${n === 6 ? 'lục giác' : 'ngũ giác'} đều — sẵn sàng lên chóp hoặc lăng trụ`;
  } else if (kind === 'binh-hanh') {
    pts = [
      { id: 'A', x: 1.4, y: -1.5, z, role: 'primary' },
      { id: 'B', x: 1.4, y: 1.3, z, role: 'primary' },
      { id: 'C', x: -1.2, y: 1.9, z, role: 'primary' },
      { id: 'D', x: -1.2, y: -0.9, z, role: 'primary' },
    ];
    note = 'Đáy hình bình hành ABCD (AB // CD, AD // BC)';
  } else if (kind === 'hinh-thang') {
    pts = [
      { id: 'A', x: -1.0, y: -1.6, z, role: 'primary' },
      { id: 'B', x: -1.0, y: 1.6, z, role: 'primary' },
      { id: 'C', x: 0.7, y: 0.2, z, role: 'primary' },
      { id: 'D', x: 0.7, y: -1.6, z, role: 'primary' },
    ];
    note = 'Đáy hình thang vuông ABCD tại A và D (AB = 2·CD)';
  } else {
    const h = r * 0.75;
    pts = [
      { id: 'A', x: h, y: -h, z, role: 'primary' },
      { id: 'B', x: h, y: h, z, role: 'primary' },
      { id: 'C', x: -h, y: h, z, role: 'primary' },
      { id: 'D', x: -h, y: -h, z, role: 'primary' },
    ];
    note = 'Đáy hình vuông ABCD — bấm "Lên chóp S" hoặc "Lên lăng trụ"';
  }

  const edges = [];
  for (let i = 0; i < pts.length; i++) {
    edges.push({ from: pts[i].id, to: pts[(i + 1) % pts.length].id, style: 'solid' });
  }
  const faces = [{ vertices: pts.map((p) => p.id), color: '#3B82F6', opacity: 0.16 }];
  return normalizeSceneSpec({ unitNote: note, vertices: pts, edges, faces });
}

/**
 * Slices a polyhedron by plane {nx, ny, nz, d} and bakes real named intersection vertices,
 * perimeter highlight edges, and an internal cross-section polygon face into the scene.
 */
export function bakeCrossSectionVertices(rawScene, plane, startChar = 'E') {
  const next = normalizeSceneSpec(structuredClone(rawScene || {}));
  const cs = computeCrossSection(next, plane);
  if (!cs.valid || cs.points.length < 3) {
    return { ok: false, message: 'Mặt phẳng không cắt qua ít nhất 3 cạnh của khối đa diện.', scene: next, crossSection: cs };
  }

  const used = new Set(next.vertices.map((v) => v.id));
  const letterPool = [startChar, 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'M', 'N', 'P', 'Q', 'R', 'T', 'U', 'V'];
  const allocName = () => {
    for (const ch of letterPool) {
      if (!used.has(ch)) {
        used.add(ch);
        return ch;
      }
    }
    for (let i = 1; i < 60; i++) {
      const cand = `${startChar}${i}`;
      if (!used.has(cand)) {
        used.add(cand);
        return cand;
      }
    }
    return `X${Date.now() % 100}`;
  };

  const csIds = [];
  for (const pt of cs.points) {
    const existing = next.vertices.find((v) => vecDist(v, pt) < 1e-3);
    if (existing) {
      csIds.push(existing.id);
    } else {
      const id = allocName();
      next.vertices.push({ id, x: pt.x, y: pt.y, z: pt.z, role: 'aux', hidden: false });
      csIds.push(id);
    }
  }

  for (let i = 0; i < csIds.length; i++) {
    const u = csIds[i];
    const w = csIds[(i + 1) % csIds.length];
    next.edges = next.edges.filter((e) => !((e.from === u && e.to === w) || (e.from === w && e.to === u)));
    next.edges.push({ from: u, to: w, style: 'highlight', label: '' });
  }
  next.faces.push({
    vertices: csIds,
    color: '#F59E0B',
    opacity: 0.34,
    label: csIds.join(''),
    internal: true,
  });
  next.crossSection = csIds;

  return {
    ok: true,
    message: `Đã cắt và tạo ${csIds.length} đỉnh thiết diện ${cs.shapeName} (${csIds.join('')}), diện tích ≈ ${cs.area.toFixed(3)}.`,
    scene: normalizeSceneSpec(next),
    crossSection: { ...cs, vertexIds: csIds },
  };
}

/**
 * Deterministic Offline Grade 11/12 Geometry Problem Parser & Solver
 * Used when user explicitly clicks Offline Quick Solver or when AI key is not provisioned on server.
 */
export function solveGrade11Offline(rawPrompt) {
  const txt = String(rawPrompt || '').trim();
  const norm = txt.toLowerCase();

  // Extract explicit numeric values a=..., SA=..., SO=..., SH=..., h=... if present
  const parseCoef = (re) => {
    const m = re.exec(txt);
    if (!m) return null;
    let v = Number(m[1].replace(',', '.'));
    if (m[2]) v *= Math.sqrt(Number(m[2]));
    return Number.isFinite(v) && v > 0 ? v : null;
  };
  const aRaw = parseCoef(/\ba\s*=\s*(\d+(?:[.,]\d+)?)(?:\s*[√v]?\s*(\d+))?/i);
  const hRaw = parseCoef(/(?:sa|so|sh|aa'|cc'|chiều cao)\s*=\s*(?:a\s*)?(\d+(?:[.,]\d+)?)(?:\s*√\s*(\d+))?/i);
  const hasSqrtSA = /(?:sa|so|sh)\s*=\s*a\s*√\s*(\d+)/i.exec(txt);

  let aVal = aRaw ? Math.min(4.0, Math.max(1.6, aRaw)) : 2.6;
  let hVal = hRaw ? Math.min(4.8, Math.max(1.6, hRaw)) : (hasSqrtSA ? Math.min(4.5, aVal * Math.sqrt(Number(hasSqrtSA[1]))) : 2.8);
  if (hVal < 1.2) hVal = 2.6;

  let pickId = 'chop-vuong-sa-vuong';
  if (/phép chiếu song song|chiếu song song/.test(norm)) pickId = 'ss-phep-chieu-song-song';
  else if (/giao điểm.*mặt phẳng|bf\s*∩|\(acd\)|bài 10/.test(norm)) pickId = 'ss-giao-diem-tu-dien-b10';
  else if (/thiết diện.*song song|song song.*thiết diện|tứ diện.*song song|efgh/.test(norm)) pickId = 'ss-thiet-dien-binh-hanh';
  else if (/thal[eè]s|hai mặt phẳng song song|\(mnpq\)\s*\/\//.test(norm)) pickId = 'ss-thales-hai-mp';
  else if (/giao tuyến.*song song|hình bình hành.*giao tuyến|\(sab\).*\(scd\)/.test(norm)) pickId = 'ss-giao-tuyen-song-song';
  else if (/chóp cụt|cụt/.test(norm)) pickId = 'chop-cut-tu-giac-deu';
  else if (/mặt bên.*vuông|sab.*vuông.*đáy|\(sab\)\s*⊥/.test(norm)) pickId = 'chop-mat-ben-vuong-day';
  else if (/chóp tứ giác đều|chóp đều.*abcd/.test(norm)) pickId = 'chop-tu-giac-deu';
  else if (/hình thang/.test(norm)) pickId = 'chop-hinh-thang-vuong';
  else if (/lăng trụ xiên|nghiêng/.test(norm)) pickId = 'lang-tru-xien';
  else if (/lăng trụ|a'b'c'/.test(norm)) pickId = 'lang-tru-dung';
  else if (/tứ diện đều|vuông góc chung/.test(norm)) pickId = 'tu-dien-doan-vuong-goc-chung';
  else if (/lập phương|hình hộp/.test(norm)) pickId = 'hinh-lap-phuong';
  else if (/s\.abc\b|chóp tam giác/.test(norm)) pickId = 'chop-tam-giac-sa-vuong';
  else if (/oxyz|tọa độ|mặt cầu/.test(norm)) pickId = /mặt cầu/.test(norm) ? 'oxyz-mat-cau-mat-phang' : 'oxyz-toa-do-hoa';

  const tpl = TEMPLATES.find((t) => t.id === pickId) || TEMPLATES[0];
  const scene = structuredClone(tpl.scene);
  if ((hRaw || hasSqrtSA) && scene.vertices.some((v) => v.id === 'S')) {
    const s = scene.vertices.find((v) => v.id === 'S');
    if (s && s.z > 0.5) s.z = Math.round(hVal * 1000) / 1000;
    // Recompute projection H if chop-vuong-sa-vuong or chop-tam-giac-sa-vuong
    if (pickId === 'chop-vuong-sa-vuong') {
      const A = scene.vertices.find((v) => v.id === 'A');
      const O = scene.vertices.find((v) => v.id === 'O');
      const H = scene.vertices.find((v) => v.id === 'H');
      if (A && O && H && s) {
        const pr = projectPointOnLine(A, s, O);
        if (pr.valid) {
          H.x = Math.round(pr.point.x * 10000) / 10000;
          H.y = Math.round(pr.point.y * 10000) / 10000;
          H.z = Math.round(pr.point.z * 10000) / 10000;
        }
      }
    } else if (pickId === 'chop-tam-giac-sa-vuong') {
      const A = scene.vertices.find((v) => v.id === 'A');
      const B = scene.vertices.find((v) => v.id === 'B');
      const H = scene.vertices.find((v) => v.id === 'H');
      if (A && B && H && s) {
        const pr = projectPointOnLine(A, s, B);
        if (pr.valid) {
          H.x = Math.round(pr.point.x * 10000) / 10000;
          H.y = Math.round(pr.point.y * 10000) / 10000;
          H.z = Math.round(pr.point.z * 10000) / 10000;
        }
      }
    }
  }

  const normalized = normalizeSceneSpec(scene);
  const vMap = new Map(normalized.vertices.map((v) => [v.id, v]));
  const vol = polyhedronVolume(normalized);
  const extraChecks = ['Tọa độ dựng theo chuẩn SGK Toán 11 KNTT'];

  // Add real geometric readout matching user's prompt metrics
  const S = vMap.get('S'), A = vMap.get('A'), C = vMap.get('C'), O = vMap.get('O'), B = vMap.get('B'), D = vMap.get('D');
  let computedSummary = tpl.formula;
  if (S && A && C && B && D && pickId === 'chop-vuong-sa-vuong') {
    const angSC = angleLinePlane(S, C, A, B, C);
    const dih = dihedralAngle(S, B, D, A);
    const dASBD = projectPointOnPlane(A, S, B, D);
    if (angSC.valid && dih.valid && dASBD.valid) {
      computedSummary = `${tpl.formula} · Giá trị trên hình: ∠(SC,(ABCD)) ≈ ${angSC.deg.toFixed(1)}°, [S,BD,A] ≈ ${dih.deg.toFixed(1)}°, d(A,(SBD)) ≈ ${dASBD.distance.toFixed(2)}`;
      extraChecks.push(`✓ Kiểm chứng số đo trực tiếp: d(A,(SBD)) = ${dASBD.distance.toFixed(3)}, V = ${vol.toFixed(3)}`);
    }
  }

  return {
    title: `${tpl.name} (Dựng nhanh trên máy)`,
    grade: tpl.grade,
    topic: tpl.chapter === 'song-song' ? 'Toán 11 KNTT · Chương IV: Quan hệ song song' : 'Dựng hình & Giải chuẩn SGK Lớp 11',
    summary: txt ? `Phân tích tự động theo dạng chuẩn của đề: "${txt.slice(0, 120)}${txt.length > 120 ? '…' : ''}"` : tpl.subtitle,
    finalAnswer: computedSummary,
    visualTips: 'Xoay hình 360°, chuyển nhanh 3D ↔ 2D để xem nét khuất, hoặc bấm "✏️ Chỉnh sửa hình AI" để tự điều chỉnh đỉnh/cạnh.',
    isOfflineFallback: true,
    mathCheck: {
      vertexCount: normalized.vertices.length,
      edgeCount: normalized.edges.length,
      volume: Number(vol.toFixed(3)),
      verifiedConstructions: 0,
      checks: extraChecks,
    },
    scene: normalized,
    steps: tpl.steps || [],
  };
}

/**
 * Vietnamese GDPT 2018 Curriculum Geometry Templates (Lớp 11 Tập 1 KNTT Chương IV + Tập 2 Vuông góc)
 */
export const TEMPLATES = [
  {
    id: 'chop-vuong-sa-vuong',
    grade: 'Lớp 11',
    chapter: 'vuong-goc',
    name: 'Chóp S.ABCD (SA ⊥ đáy, đáy vuông)',
    subtitle: 'Dạng kinh điển Lớp 11 · Góc SC và (ABCD), d(A, (SBD)), góc nhị diện [S, BD, A]',
    formula: 'AO ⊥ BD & SO ⊥ BD ⇒ [S, BD, A] = ∠SOA · 1/AH² = 1/SA² + 1/AO²',
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: 'Đáy vuông cạnh a = 2.6, SA = 2.8 · O = AC ∩ BD · AH ⊥ SO',
      vertices: [
        { id: 'A', x: 1.3, y: -1.3, z: 0, role: 'primary' },
        { id: 'B', x: 1.3, y: 1.3, z: 0, role: 'primary' },
        { id: 'C', x: -1.3, y: 1.3, z: 0, role: 'primary' },
        { id: 'D', x: -1.3, y: -1.3, z: 0, role: 'primary' },
        { id: 'O', x: 0, y: 0, z: 0, role: 'center' },
        { id: 'S', x: 1.3, y: -1.3, z: 2.8, role: 'primary' },
        { id: 'H', x: 0.3916, y: -0.3916, z: 0.8435, role: 'projection' },
      ],
      edges: [
        { from: 'A', to: 'B', style: 'solid', label: 'a' },
        { from: 'B', to: 'C', style: 'solid', label: 'a' },
        { from: 'C', to: 'D', style: 'dashed' },
        { from: 'D', to: 'A', style: 'dashed' },
        { from: 'S', to: 'A', style: 'altitude', label: 'h' },
        { from: 'S', to: 'B', style: 'solid' },
        { from: 'S', to: 'C', style: 'solid' },
        { from: 'S', to: 'D', style: 'dashed' },
        { from: 'A', to: 'C', style: 'dashed' },
        { from: 'B', to: 'D', style: 'dashed' },
        { from: 'S', to: 'O', style: 'solid' },
        { from: 'A', to: 'H', style: 'highlight', label: 'd(A,(SBD))' },
      ],
      faces: [
        { vertices: ['A', 'B', 'C', 'D'], color: '#3B82F6', opacity: 0.16, label: '(ABCD)' },
        { vertices: ['S', 'A', 'B'], color: '#60A5FA', opacity: 0.13 },
        { vertices: ['S', 'B', 'C'], color: '#60A5FA', opacity: 0.13 },
        { vertices: ['S', 'C', 'D'], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['S', 'D', 'A'], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['S', 'B', 'D'], color: '#F59E0B', opacity: 0.22, label: '(SBD)', internal: true },
        { vertices: ['S', 'A', 'O'], color: '#10B981', opacity: 0.2, label: '(SAO)', internal: true },
      ],
      rightAngles: [
        { vertex: 'A', p1: 'S', p2: 'B' },
        { vertex: 'A', p1: 'S', p2: 'D' },
        { vertex: 'O', p1: 'A', p2: 'D' },
        { vertex: 'H', p1: 'A', p2: 'S' },
      ],
      angles: [
        { vertex: 'O', p1: 'A', p2: 'S', label: '[S,BD,A]' },
      ],
    }),
    steps: [
      {
        stepTitle: 'Xác định góc nhị diện [S, BD, A]',
        explanation: 'Vì ABCD là hình vuông nên AO ⊥ BD. Lại có SA ⊥ BD ⇒ BD ⊥ (SAO) ⇒ SO ⊥ BD. Vậy góc phẳng nhị diện [S, BD, A] là ∠SOA.',
        formula: 'tan ∠SOA = SA / AO',
        highlightVertices: ['S', 'O', 'A', 'B', 'D'],
        highlightEdges: [{ from: 'S', to: 'O' }, { from: 'A', to: 'O' }, { from: 'B', to: 'D' }],
        highlightFaceVertices: ['S', 'A', 'O'],
      },
      {
        stepTitle: 'Chứng minh (SAO) ⊥ (SBD) và dựng d(A, (SBD))',
        explanation: 'Vì BD ⊥ (SAO) nên (SBD) ⊥ (SAO) theo giao tuyến SO. Trong △SAO, kẻ AH ⊥ SO ⇒ AH ⊥ (SBD).',
        formula: '1/AH² = 1/SA² + 1/AO²',
        highlightVertices: ['A', 'H', 'S', 'O'],
        highlightEdges: [{ from: 'A', to: 'H' }, { from: 'S', to: 'O' }, { from: 'S', to: 'A' }],
        highlightFaceVertices: ['S', 'B', 'D'],
      },
      {
        stepTitle: 'Xác định góc giữa đường thẳng SC và (ABCD)',
        explanation: 'SA ⊥ (ABCD) nên AC là hình chiếu vuông góc của SC lên (ABCD) ⇒ ∠(SC, (ABCD)) = ∠SCA.',
        formula: 'tan ∠SCA = SA / AC = SA / (a√2)',
        highlightVertices: ['S', 'C', 'A'],
        highlightEdges: [{ from: 'S', to: 'C' }, { from: 'A', to: 'C' }, { from: 'S', to: 'A' }],
      },
    ],
  },
  {
    id: 'chop-tu-giac-deu',
    grade: 'Lớp 11',
    name: 'Chóp tứ giác đều S.ABCD',
    subtitle: 'Đáy vuông tâm O, đường cao SO ⊥ đáy · Góc mặt bên & khoảng cách tâm O',
    formula: 'V = (1/3)·S_ABCD·SO · d(O, (SBC)) = OH',
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: 'Quy ước cạnh đáy a = 3, chiều cao SO = 3.2',
      vertices: [
        { id: 'A', x: 1.5, y: -1.5, z: 0, role: 'primary' },
        { id: 'B', x: 1.5, y: 1.5, z: 0, role: 'primary' },
        { id: 'C', x: -1.5, y: 1.5, z: 0, role: 'primary' },
        { id: 'D', x: -1.5, y: -1.5, z: 0, role: 'primary' },
        { id: 'O', x: 0, y: 0, z: 0, role: 'center' },
        { id: 'S', x: 0, y: 0, z: 3.2, role: 'primary' },
        { id: 'M', x: 0, y: 1.5, z: 0, role: 'aux' },
        { id: 'H', x: 0, y: 1.23, z: 0.576, role: 'projection' },
      ],
      edges: [
        { from: 'A', to: 'B', style: 'solid', label: 'a' },
        { from: 'B', to: 'C', style: 'solid', label: 'a' },
        { from: 'C', to: 'D', style: 'dashed' },
        { from: 'D', to: 'A', style: 'dashed' },
        { from: 'S', to: 'A', style: 'solid' },
        { from: 'S', to: 'B', style: 'solid' },
        { from: 'S', to: 'C', style: 'solid' },
        { from: 'S', to: 'D', style: 'dashed' },
        { from: 'A', to: 'C', style: 'dashed' },
        { from: 'B', to: 'D', style: 'dashed' },
        { from: 'S', to: 'O', style: 'altitude', label: 'h' },
        { from: 'O', to: 'M', style: 'dashed' },
        { from: 'S', to: 'M', style: 'solid' },
        { from: 'O', to: 'H', style: 'highlight', label: 'd(O,(SBC))' },
      ],
      faces: [
        { vertices: ['A', 'B', 'C', 'D'], color: '#3B82F6', opacity: 0.16, label: '(ABCD)' },
        { vertices: ['S', 'A', 'B'], color: '#60A5FA', opacity: 0.14 },
        { vertices: ['S', 'B', 'C'], color: '#F59E0B', opacity: 0.22, label: '(SBC)' },
        { vertices: ['S', 'C', 'D'], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['S', 'D', 'A'], color: '#60A5FA', opacity: 0.12 },
      ],
      rightAngles: [
        { vertex: 'O', p1: 'S', p2: 'M' },
        { vertex: 'M', p1: 'S', p2: 'C' },
        { vertex: 'H', p1: 'O', p2: 'S' },
      ],
      angles: [
        { vertex: 'M', p1: 'O', p2: 'S', label: 'φ' },
      ],
    }),
    steps: [
      {
        stepTitle: 'Xác định đường cao SO và trung đoạn SM',
        explanation: 'Chóp tứ giác đều có chân đường cao là tâm O hình vuông đáy. Gọi M là trung điểm BC ⇒ OM ⊥ BC và SM ⊥ BC.',
        formula: 'OM = a/2, SO ⊥ (ABCD)',
        highlightVertices: ['S', 'O', 'M'],
        highlightEdges: [{ from: 'S', to: 'O' }, { from: 'O', to: 'M' }, { from: 'S', to: 'M' }],
      },
      {
        stepTitle: 'Góc phẳng nhị diện [S, BC, O] = φ',
        explanation: 'Vì OM ⊥ BC và SM ⊥ BC nên góc giữa mặt bên (SBC) và đáy là ∠SMO = φ.',
        formula: 'tan φ = SO / OM = 2·SO / a',
        highlightVertices: ['S', 'M', 'O', 'B', 'C'],
        highlightFaceVertices: ['S', 'B', 'C'],
      },
      {
        stepTitle: 'Khoảng cách từ tâm O đến mặt bên (SBC)',
        explanation: 'Kẻ OH ⊥ SM (H ∈ SM). Vì BC ⊥ (SOM) nên BC ⊥ OH ⇒ OH ⊥ (SBC), suy ra d(O, (SBC)) = OH.',
        formula: '1/OH² = 1/SO² + 1/OM²',
        highlightVertices: ['O', 'H', 'S', 'M'],
        highlightEdges: [{ from: 'O', to: 'H' }, { from: 'S', to: 'M' }],
      },
    ],
  },
  {
    id: 'chop-mat-ben-vuong-day',
    grade: 'Lớp 11',
    chapter: 'vuong-goc',
    name: 'Chóp có mặt bên (SAB) ⊥ (ABCD)',
    subtitle: 'Dạng trọng tâm Lớp 11 · △SAB cân/đều tại S nằm trong mặt phẳng vuông góc đáy',
    formula: '(SAB) ⊥ (ABCD) & SH ⊥ AB ⇒ SH ⊥ (ABCD)',
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: 'H là trung điểm AB, △SAB đều cạnh a = 2.8 ⇒ SH = a√3/2 ≈ 2.42',
      vertices: [
        { id: 'A', x: 1.4, y: -1.4, z: 0, role: 'primary' },
        { id: 'B', x: 1.4, y: 1.4, z: 0, role: 'primary' },
        { id: 'C', x: -1.4, y: 1.4, z: 0, role: 'primary' },
        { id: 'D', x: -1.4, y: -1.4, z: 0, role: 'primary' },
        { id: 'H', x: 1.4, y: 0, z: 0, role: 'projection' },
        { id: 'S', x: 1.4, y: 0, z: 2.425, role: 'primary' },
      ],
      edges: [
        { from: 'A', to: 'B', style: 'solid', label: 'a' },
        { from: 'B', to: 'C', style: 'solid', label: 'a' },
        { from: 'C', to: 'D', style: 'dashed' },
        { from: 'D', to: 'A', style: 'dashed' },
        { from: 'S', to: 'A', style: 'solid' },
        { from: 'S', to: 'B', style: 'solid' },
        { from: 'S', to: 'C', style: 'solid' },
        { from: 'S', to: 'D', style: 'dashed' },
        { from: 'S', to: 'H', style: 'altitude', label: 'h' },
        { from: 'H', to: 'C', style: 'highlight' },
      ],
      faces: [
        { vertices: ['A', 'B', 'C', 'D'], color: '#3B82F6', opacity: 0.16 },
        { vertices: ['S', 'A', 'B'], color: '#10B981', opacity: 0.24, label: '(SAB)' },
        { vertices: ['S', 'B', 'C'], color: '#60A5FA', opacity: 0.14 },
        { vertices: ['S', 'C', 'D'], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['S', 'D', 'A'], color: '#60A5FA', opacity: 0.12 },
      ],
      rightAngles: [
        { vertex: 'H', p1: 'S', p2: 'B' },
        { vertex: 'H', p1: 'S', p2: 'C' },
      ],
      angles: [
        { vertex: 'C', p1: 'H', p2: 'S', label: '∠(SC,(ABCD))' },
      ],
    }),
    steps: [
      {
        stepTitle: 'Định lý 2 mặt phẳng vuông góc: Dựng đường cao SH',
        explanation: 'Hai mặt phẳng (SAB) và (ABCD) vuông góc nhau theo giao tuyến AB. Trong (SAB), kẻ SH ⊥ AB (H là trung điểm AB) ⇒ SH ⊥ (ABCD).',
        formula: 'SH = a√3 / 2 (khi △SAB đều)',
        highlightVertices: ['S', 'H', 'A', 'B'],
        highlightEdges: [{ from: 'S', to: 'H' }, { from: 'A', to: 'B' }],
        highlightFaceVertices: ['S', 'A', 'B'],
      },
      {
        stepTitle: 'Tính góc giữa SC và mặt đáy (ABCD)',
        explanation: 'Vì SH ⊥ (ABCD) nên HC là hình chiếu của SC trên đáy ⇒ ∠(SC, (ABCD)) = ∠SCH.',
        formula: 'HC = √(HB² + BC²) = a√5 / 2',
        highlightVertices: ['S', 'C', 'H'],
        highlightEdges: [{ from: 'S', to: 'C' }, { from: 'H', to: 'C' }, { from: 'S', to: 'H' }],
      },
    ],
  },
  {
    id: 'chop-tam-giac-sa-vuong',
    grade: 'Lớp 11',
    name: 'Chóp tam giác S.ABC (SA ⊥ đáy)',
    subtitle: 'SA ⊥ (ABC), đáy △ABC vuông tại B · Ba đường vuông góc & d(A, (SBC))',
    formula: 'SA ⊥ (ABC) & BC ⊥ AB ⇒ BC ⊥ (SAB) ⇒ AH ⊥ (SBC)',
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: 'A tại góc, AB = 2.6, BC = 2.4, SA = 3.0',
      vertices: [
        { id: 'A', x: -1.3, y: -1.1, z: 0, role: 'primary' },
        { id: 'B', x: 1.3, y: -1.1, z: 0, role: 'primary' },
        { id: 'C', x: 1.3, y: 1.3, z: 0, role: 'primary' },
        { id: 'S', x: -1.3, y: -1.1, z: 3.0, role: 'primary' },
        { id: 'H', x: 0.1848, y: -1.1, z: 1.2868, role: 'projection' },
      ],
      edges: [
        { from: 'A', to: 'B', style: 'solid' },
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'A', to: 'C', style: 'dashed' },
        { from: 'S', to: 'A', style: 'altitude', label: 'h' },
        { from: 'S', to: 'B', style: 'solid' },
        { from: 'S', to: 'C', style: 'solid' },
        { from: 'A', to: 'H', style: 'highlight', label: 'd(A,(SBC))' },
      ],
      faces: [
        { vertices: ['A', 'B', 'C'], color: '#3B82F6', opacity: 0.16 },
        { vertices: ['S', 'A', 'B'], color: '#10B981', opacity: 0.18 },
        { vertices: ['S', 'B', 'C'], color: '#F59E0B', opacity: 0.18 },
        { vertices: ['S', 'A', 'C'], color: '#60A5FA', opacity: 0.12 },
      ],
      rightAngles: [
        { vertex: 'A', p1: 'S', p2: 'B' },
        { vertex: 'A', p1: 'S', p2: 'C' },
        { vertex: 'B', p1: 'A', p2: 'C' },
        { vertex: 'H', p1: 'A', p2: 'B' },
      ],
      angles: [
        { vertex: 'C', p1: 'A', p2: 'S', label: '∠(SC,(ABC))' },
      ],
    }),
    steps: [
      {
        stepTitle: 'Chứng minh BC ⊥ (SAB) và △SBC vuông tại B',
        explanation: 'Ta có BC ⊥ AB (giả thiết) và BC ⊥ SA (vì SA ⊥ đáy) ⇒ BC ⊥ (SAB) ⇒ BC ⊥ SB.',
        formula: 'BC ⊥ (SAB) ⇒ (SBC) ⊥ (SAB)',
        highlightVertices: ['B', 'C', 'S', 'A'],
        highlightEdges: [{ from: 'B', to: 'C' }, { from: 'S', to: 'B' }],
        highlightFaceVertices: ['S', 'A', 'B'],
      },
      {
        stepTitle: 'Tính khoảng cách d(A, (SBC)) = AH',
        explanation: 'Trong mặt phẳng (SAB), kẻ AH ⊥ SB (H ∈ SB). Vì BC ⊥ (SAB) nên BC ⊥ AH ⇒ AH ⊥ (SBC).',
        formula: '1/AH² = 1/SA² + 1/AB²',
        highlightVertices: ['A', 'H', 'S', 'B'],
        highlightEdges: [{ from: 'A', to: 'H' }, { from: 'S', to: 'B' }],
      },
    ],
  },
  {
    id: 'chop-hinh-thang-vuong',
    grade: 'Lớp 11',
    name: 'Chóp đáy hình thang vuông S.ABCD',
    subtitle: 'SA ⊥ (ABCD), đáy vuông tại A & D · AB = 2a, AD = CD = a',
    formula: 'AC² + BC² = AB² ⇒ BC ⊥ (SAC)',
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: 'Quy ước a = 1.6 · AB = 3.2, AD = CD = 1.6, SA = 2.8',
      vertices: [
        { id: 'A', x: -1.0, y: -1.6, z: 0, role: 'primary' },
        { id: 'D', x: 0.6, y: -1.6, z: 0, role: 'primary' },
        { id: 'C', x: 0.6, y: 0.0, z: 0, role: 'primary' },
        { id: 'B', x: -1.0, y: 1.6, z: 0, role: 'primary' },
        { id: 'S', x: -1.0, y: -1.6, z: 2.8, role: 'primary' },
      ],
      edges: [
        { from: 'A', to: 'D', style: 'solid' },
        { from: 'D', to: 'C', style: 'solid' },
        { from: 'C', to: 'B', style: 'solid' },
        { from: 'B', to: 'A', style: 'dashed' },
        { from: 'A', to: 'C', style: 'highlight' },
        { from: 'S', to: 'A', style: 'altitude' },
        { from: 'S', to: 'D', style: 'solid' },
        { from: 'S', to: 'C', style: 'solid' },
        { from: 'S', to: 'B', style: 'solid' },
      ],
      faces: [
        { vertices: ['A', 'D', 'C', 'B'], color: '#3B82F6', opacity: 0.16 },
        { vertices: ['S', 'A', 'D'], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['S', 'D', 'C'], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['S', 'C', 'B'], color: '#F59E0B', opacity: 0.16 },
        { vertices: ['S', 'B', 'A'], color: '#60A5FA', opacity: 0.13 },
        { vertices: ['S', 'A', 'C'], color: '#10B981', opacity: 0.2, internal: true },
      ],
      rightAngles: [
        { vertex: 'A', p1: 'S', p2: 'D' },
        { vertex: 'A', p1: 'D', p2: 'B' },
        { vertex: 'D', p1: 'A', p2: 'C' },
        { vertex: 'C', p1: 'A', p2: 'B' },
      ],
    }),
    steps: [
      {
        stepTitle: 'Kỹ thuật chia hình thang vuông tìm góc vuông phụ AC ⊥ BC',
        explanation: 'Vì AB = 2a và AD = CD = a nên M trung điểm AB cho AMCD là hình vuông ⇒ AC = BC = a√2 và AC ⊥ BC.',
        formula: 'AC² + BC² = 2a² + 2a² = 4a² = AB²',
        highlightVertices: ['A', 'C', 'B', 'D'],
        highlightEdges: [{ from: 'A', to: 'C' }, { from: 'C', to: 'B' }],
      },
      {
        stepTitle: 'Suy ra BC ⊥ (SAC) và (SBC) ⊥ (SAC)',
        explanation: 'Do BC ⊥ AC và BC ⊥ SA nên BC ⊥ (SAC), từ đó tính d(B, (SAC)) = BC và góc nhị diện [S, BC, A] = ∠SCA.',
        formula: 'd(B, (SAC)) = BC = a√2',
        highlightFaceVertices: ['S', 'A', 'C'],
      },
    ],
  },
  {
    id: 'chop-cut-tu-giac-deu',
    grade: 'Lớp 11',
    name: "Hình chóp cụt tứ giác đều ABCD.A'B'C'D'",
    subtitle: 'Nội dung trọng tâm mới SGK Lớp 11 GDPT 2018 · Thể tích & góc bên',
    formula: "V = (h/3)·(S + S' + √(S·S'))",
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: "Đáy lớn a = 3.2, đáy nhỏ b = 1.6, chiều cao OO' = 2.6",
      vertices: [
        { id: 'A', x: 1.6, y: -1.6, z: 0, role: 'primary' },
        { id: 'B', x: 1.6, y: 1.6, z: 0, role: 'primary' },
        { id: 'C', x: -1.6, y: 1.6, z: 0, role: 'primary' },
        { id: 'D', x: -1.6, y: -1.6, z: 0, role: 'primary' },
        { id: "A'", x: 0.8, y: -0.8, z: 2.6, role: 'primary' },
        { id: "B'", x: 0.8, y: 0.8, z: 2.6, role: 'primary' },
        { id: "C'", x: -0.8, y: 0.8, z: 2.6, role: 'primary' },
        { id: "D'", x: -0.8, y: -0.8, z: 2.6, role: 'primary' },
        { id: 'O', x: 0, y: 0, z: 0, role: 'center' },
        { id: "O'", x: 0, y: 0, z: 2.6, role: 'center' },
      ],
      edges: [
        { from: 'A', to: 'B', style: 'solid', label: 'a' },
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'C', to: 'D', style: 'dashed' },
        { from: 'D', to: 'A', style: 'dashed' },
        { from: "A'", to: "B'", style: 'solid', label: "a'" },
        { from: "B'", to: "C'", style: 'solid' },
        { from: "C'", to: "D'", style: 'solid' },
        { from: "D'", to: "A'", style: 'solid' },
        { from: 'A', to: "A'", style: 'solid' },
        { from: 'B', to: "B'", style: 'solid' },
        { from: 'C', to: "C'", style: 'solid' },
        { from: 'D', to: "D'", style: 'dashed' },
        { from: 'O', to: "O'", style: 'altitude', label: 'h' },
      ],
      faces: [
        { vertices: ['A', 'B', 'C', 'D'], color: '#3B82F6', opacity: 0.16 },
        { vertices: ["A'", "B'", "C'", "D'"], color: '#10B981', opacity: 0.22 },
        { vertices: ['A', 'B', "B'", "A'"], color: '#60A5FA', opacity: 0.13 },
        { vertices: ['B', 'C', "C'", "B'"], color: '#F59E0B', opacity: 0.18 },
        { vertices: ['C', 'D', "D'", "C'"], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['D', 'A', "A'", "D'"], color: '#60A5FA', opacity: 0.12 },
      ],
      rightAngles: [
        { vertex: 'O', p1: "O'", p2: 'B' },
      ],
    }),
    steps: [
      {
        stepTitle: 'Đặc điểm hình chóp cụt đều (SGK Lớp 11)',
        explanation: "Hai đáy ABCD và A'B'C'D' là hai hình vuông đồng dạng, nằm trên hai mặt phẳng song song và có tâm nối nhau bởi đường cao OO'.",
        formula: "OO' ⊥ (ABCD), OO' ⊥ (A'B'C'D')",
        highlightVertices: ['O', "O'"],
        highlightEdges: [{ from: 'O', to: "O'" }],
        highlightFaceVertices: ["A'", "B'", "C'", "D'"],
      },
      {
        stepTitle: 'Tính cạnh bên và thể tích khối chóp cụt',
        explanation: "Hạ B'H ⊥ OB, có BH = (a - a')√2/2. Thể tích bằng 1/3 chiều cao nhân (S + S' + √(S·S')).",
        formula: "V = (h/3)·(a² + a'² + a·a')",
        highlightFaceVertices: ['B', 'C', "C'", "B'"],
      },
    ],
  },
  {
    id: 'lang-tru-dung',
    grade: 'Lớp 11',
    name: "Lăng trụ đứng ABC.A'B'C'",
    subtitle: "Cạnh bên vuông góc đáy · Góc giữa A'B và (ABC) hoặc (ACC'A')",
    formula: "V = S_ABC · AA'",
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: "Đáy △ABC đều cạnh 2.6, chiều cao AA' = 3.0",
      vertices: [
        { id: 'A', x: 1.3, y: -1.3, z: 0, role: 'primary' },
        { id: 'B', x: 1.3, y: 1.3, z: 0, role: 'primary' },
        { id: 'C', x: -0.95, y: 0, z: 0, role: 'primary' },
        { id: "A'", x: 1.3, y: -1.3, z: 3.0, role: 'primary' },
        { id: "B'", x: 1.3, y: 1.3, z: 3.0, role: 'primary' },
        { id: "C'", x: -0.95, y: 0, z: 3.0, role: 'primary' },
      ],
      edges: [
        { from: 'A', to: 'B', style: 'solid' },
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'C', to: 'A', style: 'dashed' },
        { from: "A'", to: "B'", style: 'solid' },
        { from: "B'", to: "C'", style: 'solid' },
        { from: "C'", to: "A'", style: 'solid' },
        { from: 'A', to: "A'", style: 'altitude' },
        { from: 'B', to: "B'", style: 'solid' },
        { from: 'C', to: "C'", style: 'dashed' },
        { from: "A'", to: 'B', style: 'highlight' },
      ],
      faces: [
        { vertices: ['A', 'B', 'C'], color: '#3B82F6', opacity: 0.16 },
        { vertices: ["A'", "B'", "C'"], color: '#3B82F6', opacity: 0.16 },
        { vertices: ['A', 'B', "B'", "A'"], color: '#60A5FA', opacity: 0.14 },
        { vertices: ['B', 'C', "C'", "B'"], color: '#60A5FA', opacity: 0.14 },
        { vertices: ['A', 'C', "C'", "A'"], color: '#10B981', opacity: 0.14 },
      ],
      rightAngles: [
        { vertex: 'A', p1: "A'", p2: 'B' },
        { vertex: 'B', p1: "B'", p2: 'C' },
      ],
    }),
    steps: [
      {
        stepTitle: "Xác định góc giữa đường chéo A'B và đáy (ABC)",
        explanation: "Vì AA' ⊥ (ABC) nên AB là hình chiếu của A'B lên (ABC) ⇒ góc cần tìm là ∠A'BA.",
        formula: "tan ∠A'BA = AA' / AB",
        highlightVertices: ["A'", 'B', 'A'],
        highlightEdges: [{ from: "A'", to: 'B' }, { from: 'A', to: 'B' }, { from: 'A', to: "A'" }],
      },
      {
        stepTitle: "Khoảng cách giữa AA' và BC (hai đường chéo nhau)",
        explanation: "Gọi M là trung điểm BC (hoặc hạ AK ⊥ BC) ⇒ AK ⊥ BC và AK ⊥ AA' nên d(AA', BC) = AK = a√3/2.",
        formula: 'd(AA\', BC) = chiều cao △ABC',
        highlightFaceVertices: ['A', 'B', 'C'],
      },
    ],
  },
  {
    id: 'lang-tru-xien',
    grade: 'Lớp 11',
    name: "Lăng trụ xiên ABC.A'B'C'",
    subtitle: "Hình chiếu của A' lên (ABC) là trung điểm H của AB (hoặc trọng tâm G)",
    formula: "V = S_ABC · A'H · (ABB'A') ⊥ (ABC)",
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: "Đáy △ABC đều cạnh 2.6, hình chiếu A' trùng trung điểm H của AB, A'H = 2.6",
      vertices: [
        { id: 'A', x: 1.3, y: -1.3, z: 0, role: 'primary' },
        { id: 'B', x: 1.3, y: 1.3, z: 0, role: 'primary' },
        { id: 'C', x: -0.95, y: 0, z: 0, role: 'primary' },
        { id: 'H', x: 1.3, y: 0, z: 0, role: 'projection' },
        { id: "A'", x: 1.3, y: 0, z: 2.6, role: 'primary' },
        { id: "B'", x: 1.3, y: 2.6, z: 2.6, role: 'primary' },
        { id: "C'", x: -0.95, y: 1.3, z: 2.6, role: 'primary' },
      ],
      edges: [
        { from: 'A', to: 'B', style: 'solid' },
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'C', to: 'A', style: 'dashed' },
        { from: "A'", to: "B'", style: 'solid' },
        { from: "B'", to: "C'", style: 'solid' },
        { from: "C'", to: "A'", style: 'solid' },
        { from: 'A', to: "A'", style: 'solid' },
        { from: 'B', to: "B'", style: 'solid' },
        { from: 'C', to: "C'", style: 'dashed' },
        { from: "A'", to: 'H', style: 'altitude', label: 'h' },
        { from: 'C', to: 'H', style: 'dashed' },
      ],
      faces: [
        { vertices: ['A', 'B', 'C'], color: '#3B82F6', opacity: 0.16 },
        { vertices: ["A'", "B'", "C'"], color: '#3B82F6', opacity: 0.16 },
        { vertices: ['A', 'B', "B'", "A'"], color: '#10B981', opacity: 0.2 },
        { vertices: ['B', 'C', "C'", "B'"], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['C', 'A', "A'", "C'"], color: '#60A5FA', opacity: 0.12 },
      ],
      rightAngles: [
        { vertex: 'H', p1: "A'", p2: 'B' },
        { vertex: 'H', p1: "A'", p2: 'C' },
      ],
    }),
    steps: [
      {
        stepTitle: "Xác định đường cao A'H của lăng trụ xiên",
        explanation: "H là hình chiếu của A' xuống (ABC) nên A'H ⊥ (ABC), đồng thời (ABB'A') ⊥ (ABC).",
        formula: "h = A'H = √(AA'² - AH²)",
        highlightVertices: ["A'", 'H', 'A', 'B'],
        highlightEdges: [{ from: "A'", to: 'H' }, { from: 'A', to: "A'" }],
        highlightFaceVertices: ['A', 'B', "B'", "A'"],
      },
      {
        stepTitle: 'Góc giữa cạnh bên và mặt đáy',
        explanation: "Vì H là hình chiếu của A' lên đáy nên góc giữa AA' và (ABC) là ∠A'AH.",
        formula: "cos ∠A'AH = AH / AA'",
        highlightVertices: ["A'", 'A', 'H'],
        highlightEdges: [{ from: 'A', to: "A'" }, { from: 'A', to: 'H' }],
      },
    ],
  },
  {
    id: 'tu-dien-doan-vuong-goc-chung',
    grade: 'Lớp 11',
    name: 'Tứ diện & Đoạn vuông góc chung MN',
    subtitle: 'Dạng chuẩn Lớp 11 · Khoảng cách hai cạnh đối chéo nhau d(AB, CD)',
    formula: 'MN ⊥ AB & MN ⊥ CD ⇒ d(AB, CD) = MN = a√2 / 2',
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: 'Tứ diện đều A.BCD cạnh a = 3 · M trung điểm AB, N trung điểm CD',
      vertices: [
        { id: 'B', x: 1.732, y: 0, z: 0, role: 'primary' },
        { id: 'C', x: -0.866, y: 1.5, z: 0, role: 'primary' },
        { id: 'D', x: -0.866, y: -1.5, z: 0, role: 'primary' },
        { id: 'A', x: 0, y: 0, z: 2.449, role: 'primary' },
        { id: 'M', x: 0.866, y: 0, z: 1.2245, role: 'aux' },
        { id: 'N', x: -0.866, y: 0, z: 0, role: 'aux' },
      ],
      edges: [
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'C', to: 'D', style: 'solid' },
        { from: 'D', to: 'B', style: 'dashed' },
        { from: 'A', to: 'B', style: 'solid' },
        { from: 'A', to: 'C', style: 'solid' },
        { from: 'A', to: 'D', style: 'solid' },
        { from: 'M', to: 'N', style: 'highlight', label: 'd(AB,CD)' },
        { from: 'A', to: 'N', style: 'dashed' },
        { from: 'B', to: 'N', style: 'dashed' },
      ],
      faces: [
        { vertices: ['B', 'C', 'D'], color: '#3B82F6', opacity: 0.16 },
        { vertices: ['A', 'B', 'C'], color: '#60A5FA', opacity: 0.13 },
        { vertices: ['A', 'C', 'D'], color: '#F59E0B', opacity: 0.16 },
        { vertices: ['A', 'D', 'B'], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['A', 'B', 'N'], color: '#10B981', opacity: 0.18, internal: true },
      ],
      rightAngles: [
        { vertex: 'M', p1: 'N', p2: 'A' },
        { vertex: 'N', p1: 'M', p2: 'C' },
      ],
    }),
    steps: [
      {
        stepTitle: 'Chứng minh MN là đoạn vuông góc chung của AB và CD',
        explanation: 'Vì N là trung điểm CD nên AN = BN (hai trung tuyến của hai tam giác đều cạnh a). Suy ra △NAB cân tại N ⇒ MN ⊥ AB.',
        formula: 'MN ⊥ AB (đường trung tuyến tam giác cân)',
        highlightVertices: ['M', 'N', 'A', 'B'],
        highlightEdges: [{ from: 'M', to: 'N' }, { from: 'A', to: 'B' }],
        highlightFaceVertices: ['A', 'B', 'N'],
      },
      {
        stepTitle: 'Tính độ dài đoạn vuông góc chung MN',
        explanation: 'Tương tự chứng minh MN ⊥ CD. Áp dụng Pitago trong △MNA vuông tại M: MN² = AN² - AM² = (a√3/2)² - (a/2)².',
        formula: 'd(AB, CD) = MN = a√2 / 2',
        highlightVertices: ['M', 'N', 'C', 'D'],
        highlightEdges: [{ from: 'M', to: 'N' }, { from: 'C', to: 'D' }],
      },
    ],
  },
  {
    id: 'hinh-lap-phuong',
    grade: 'Lớp 11',
    name: "Hình lập phương ABCD.A'B'C'D'",
    subtitle: "Đường chéo AC', thiết diện lục giác đều qua trung điểm các cạnh",
    formula: "AC' = a√3 · d(A', (AB'D')) = a√3 / 3",
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: 'Hình lập phương cạnh a = 2.6',
      vertices: [
        { id: 'A', x: 1.3, y: -1.3, z: 0, role: 'primary' },
        { id: 'B', x: 1.3, y: 1.3, z: 0, role: 'primary' },
        { id: 'C', x: -1.3, y: 1.3, z: 0, role: 'primary' },
        { id: 'D', x: -1.3, y: -1.3, z: 0, role: 'primary' },
        { id: "A'", x: 1.3, y: -1.3, z: 2.6, role: 'primary' },
        { id: "B'", x: 1.3, y: 1.3, z: 2.6, role: 'primary' },
        { id: "C'", x: -1.3, y: 1.3, z: 2.6, role: 'primary' },
        { id: "D'", x: -1.3, y: -1.3, z: 2.6, role: 'primary' },
      ],
      edges: [
        { from: 'A', to: 'B', style: 'solid' },
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'C', to: 'D', style: 'dashed' },
        { from: 'D', to: 'A', style: 'dashed' },
        { from: "A'", to: "B'", style: 'solid' },
        { from: "B'", to: "C'", style: 'solid' },
        { from: "C'", to: "D'", style: 'solid' },
        { from: "D'", to: "A'", style: 'solid' },
        { from: 'A', to: "A'", style: 'solid' },
        { from: 'B', to: "B'", style: 'solid' },
        { from: 'C', to: "C'", style: 'solid' },
        { from: 'D', to: "D'", style: 'dashed' },
        { from: 'A', to: "C'", style: 'highlight' },
        { from: 'A', to: 'C', style: 'dashed' },
      ],
      faces: [
        { vertices: ['A', 'B', 'C', 'D'], color: '#3B82F6', opacity: 0.14 },
        { vertices: ["A'", "B'", "C'", "D'"], color: '#3B82F6', opacity: 0.14 },
        { vertices: ['A', 'B', "B'", "A'"], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['B', 'C', "C'", "B'"], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['C', 'D', "D'", "C'"], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['D', 'A', "A'", "D'"], color: '#60A5FA', opacity: 0.12 },
      ],
      rightAngles: [
        { vertex: 'C', p1: 'A', p2: "C'" },
      ],
    }),
    steps: [
      {
        stepTitle: "Tính độ dài đường chéo AC' và góc với mặt đáy",
        explanation: "Trong △ACC' vuông tại C: AC = a√2, CC' = a ⇒ AC' = √(2a² + a²) = a√3.",
        formula: "AC' = a√3 · sin ∠C'AC = 1/√3",
        highlightVertices: ['A', 'C', "C'"],
        highlightEdges: [{ from: 'A', to: "C'" }, { from: 'A', to: 'C' }, { from: 'C', to: "C'" }],
      },
      {
        stepTitle: 'Thử nghiệm cắt thiết diện lục giác đều',
        explanation: 'Chuyển sang tab "Thiết diện & Đo", bật mặt cắt rồi bấm mẫu "Lục giác (x+y+z = d)" để xem mặt phẳng trung trực AC\' cắt thành lục giác đều!',
        formula: 'S_lục_giác = (3√3/4)·a²',
        highlightVertices: ['A', "C'"],
      },
    ],
  },
  {
    id: 'oxyz-toa-do-hoa',
    grade: 'Lớp 12',
    name: 'Tọa độ hóa Oxyz trên hình chóp',
    subtitle: 'Gắn hệ trục Oxyz: O ≡ A, Ox ≡ AB, Oy ≡ AD, Oz ≡ AS',
    formula: 'd(M, (P)) = |ax₀ + by₀ + cz₀ + d| / √(a² + b² + c²)',
    scene: normalizeSceneSpec({
      showOxyz: true,
      unitNote: 'O ≡ A(0,0,0), B(2.5,0,0), D(0,2.5,0), S(0,0,3.0)',
      vertices: [
        { id: 'A', x: 0, y: 0, z: 0, role: 'center' },
        { id: 'B', x: 2.5, y: 0, z: 0, role: 'primary' },
        { id: 'C', x: 2.5, y: 2.5, z: 0, role: 'primary' },
        { id: 'D', x: 0, y: 2.5, z: 0, role: 'primary' },
        { id: 'S', x: 0, y: 0, z: 3.0, role: 'primary' },
        { id: 'M', x: 1.25, y: 1.25, z: 1.5, role: 'aux' },
      ],
      edges: [
        { from: 'A', to: 'B', style: 'solid' },
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'C', to: 'D', style: 'solid' },
        { from: 'D', to: 'A', style: 'solid' },
        { from: 'S', to: 'A', style: 'altitude' },
        { from: 'S', to: 'B', style: 'solid' },
        { from: 'S', to: 'C', style: 'solid' },
        { from: 'S', to: 'D', style: 'solid' },
        { from: 'A', to: 'M', style: 'highlight' },
      ],
      faces: [
        { vertices: ['A', 'B', 'C', 'D'], color: '#3B82F6', opacity: 0.14 },
        { vertices: ['S', 'B', 'C'], color: '#F59E0B', opacity: 0.2 },
      ],
      rightAngles: [
        { vertex: 'A', p1: 'B', p2: 'D' },
        { vertex: 'A', p1: 'S', p2: 'B' },
      ],
    }),
    steps: [
      {
        stepTitle: 'Gắn hệ trục tọa độ Oxyz vào góc tam diện vuông tại A',
        explanation: 'Vì AB, AD, AS đôi một vuông góc nên chọn O ≡ A(0;0;0), tia Ox chứa B, Oy chứa D, Oz chứa S.',
        formula: 'A(0;0;0), B(2.5;0;0), D(0;2.5;0), S(0;0;3)',
        highlightVertices: ['A', 'B', 'D', 'S'],
        highlightEdges: [{ from: 'A', to: 'B' }, { from: 'A', to: 'D' }, { from: 'A', to: 'S' }],
      },
    ],
  },
  {
    id: 'oxyz-mat-cau-mat-phang',
    grade: 'Lớp 12',
    name: 'Mặt cầu (S) cắt Mặt phẳng (P) trong Oxyz',
    subtitle: 'Tâm I(0,0,1.6), bán kính R = 2.0, mặt phẳng cắt tạo đường tròn (C) tâm H',
    formula: 'R² = d² + r² (với d = d(I, (P)))',
    scene: normalizeSceneSpec({
      showOxyz: true,
      unitNote: 'I(0, 0, 1.6), R = 2.0, H(0, 0, 0.5) ⇒ r = √(4 - 1.21) ≈ 1.67',
      vertices: [
        { id: 'I', x: 0, y: 0, z: 1.6, role: 'center' },
        { id: 'H', x: 0, y: 0, z: 0.5, role: 'projection' },
        { id: 'M', x: 1.67, y: 0, z: 0.5, role: 'aux' },
        { id: 'P1', x: 2.3, y: -2.3, z: 0.5, role: 'aux' },
        { id: 'P2', x: 2.3, y: 2.3, z: 0.5, role: 'aux' },
        { id: 'P3', x: -2.3, y: 2.3, z: 0.5, role: 'aux' },
        { id: 'P4', x: -2.3, y: -2.3, z: 0.5, role: 'aux' },
      ],
      edges: [
        { from: 'I', to: 'H', style: 'altitude', label: 'd' },
        { from: 'H', to: 'M', style: 'highlight', label: 'r' },
        { from: 'I', to: 'M', style: 'solid', label: 'R' },
        { from: 'P1', to: 'P2', style: 'solid' },
        { from: 'P2', to: 'P3', style: 'solid' },
        { from: 'P3', to: 'P4', style: 'solid' },
        { from: 'P4', to: 'P1', style: 'solid' },
      ],
      faces: [
        { vertices: ['P1', 'P2', 'P3', 'P4'], color: '#10B981', opacity: 0.18, label: '(P)' },
      ],
      rightAngles: [
        { vertex: 'H', p1: 'I', p2: 'M' },
      ],
      spheres: [
        { center: 'I', cx: 0, cy: 0, cz: 1.6, radius: 2.0, label: '(S)' },
      ],
    }),
    steps: [
      {
        stepTitle: 'Tam giác vuông IHM liên hệ giữa R, d và bán kính đường tròn giao tuyến r',
        explanation: 'H là hình chiếu tâm I lên (P) nên IH ⊥ HM. Áp dụng Pitago trong △IHM: R² = d² + r².',
        formula: 'r = √(R² - d(I,(P))²)',
        highlightVertices: ['I', 'H', 'M'],
        highlightEdges: [{ from: 'I', to: 'H' }, { from: 'H', to: 'M' }, { from: 'I', to: 'M' }],
      },
    ],
  },
  {
    id: 'hinh-non-tru',
    grade: 'Lớp 11-12',
    name: 'Hình nón & Thiết diện qua trục',
    subtitle: 'Đỉnh S, tâm đáy O, đường sinh SA, SB · Thiết diện △SAB cân tại S',
    formula: 'l² = h² + r² · S_xq = πrl · V = (1/3)πr²h',
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: 'Bán kính r = 1.8, chiều cao h = SO = 3.0',
      vertices: [
        { id: 'O', x: 0, y: 0, z: 0, role: 'center' },
        { id: 'S', x: 0, y: 0, z: 3.0, role: 'primary' },
        { id: 'A', x: 0, y: -1.8, z: 0, role: 'primary' },
        { id: 'B', x: 0, y: 1.8, z: 0, role: 'primary' },
      ],
      edges: [
        { from: 'S', to: 'O', style: 'altitude', label: 'h' },
        { from: 'A', to: 'B', style: 'dashed', label: '2r' },
        { from: 'S', to: 'A', style: 'highlight', label: 'l' },
        { from: 'S', to: 'B', style: 'highlight', label: 'l' },
      ],
      faces: [
        { vertices: ['S', 'A', 'B'], color: '#F59E0B', opacity: 0.24 },
      ],
      rightAngles: [
        { vertex: 'O', p1: 'S', p2: 'B' },
      ],
      cones: [
        { apex: 'S', baseCenter: 'O', radius: 1.8 },
      ],
    }),
    steps: [
      {
        stepTitle: 'Thiết diện qua trục của hình nón',
        explanation: 'Thiết diện qua trục là tam giác cân SAB có đáy AB = 2r và đường cao SO = h.',
        formula: 'l = √(h² + r²)',
        highlightVertices: ['S', 'A', 'B', 'O'],
        highlightFaceVertices: ['S', 'A', 'B'],
      },
    ],
  },
  {
    id: 'ss-giao-tuyen-song-song',
    grade: 'Lớp 11',
    chapter: 'song-song',
    name: 'Bài 11 KNTT · Giao tuyến song song (SAB) ∩ (SCD)',
    subtitle: 'Chương IV Quan hệ song song (HK1) · Đáy ABCD là hình bình hành, giao tuyến Sx // AB // CD',
    formula: 'AB // CD & S ∈ (SAB) ∩ (SCD) ⇒ (SAB) ∩ (SCD) = Sx // AB // CD',
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: 'SGK Toán 11 KNTT Tập 1 · Bài 11: Hình 4.25 · ABCD hình bình hành',
      vertices: [
        { id: 'A', x: 1.4, y: -1.5, z: 0, role: 'primary' },
        { id: 'B', x: 1.4, y: 1.3, z: 0, role: 'primary' },
        { id: 'C', x: -1.2, y: 1.9, z: 0, role: 'primary' },
        { id: 'D', x: -1.2, y: -0.9, z: 0, role: 'primary' },
        { id: 'S', x: 0.2, y: 0.1, z: 2.8, role: 'primary' },
        { id: 'x1', x: 0.2, y: -1.7, z: 2.8, role: 'aux' },
        { id: 'x2', x: 0.2, y: 2.1, z: 2.8, role: 'aux' },
      ],
      edges: [
        { from: 'A', to: 'B', style: 'solid', label: 'AB' },
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'C', to: 'D', style: 'dashed', label: 'CD' },
        { from: 'D', to: 'A', style: 'dashed' },
        { from: 'S', to: 'A', style: 'solid' },
        { from: 'S', to: 'B', style: 'solid' },
        { from: 'S', to: 'C', style: 'solid' },
        { from: 'S', to: 'D', style: 'dashed' },
        { from: 'x1', to: 'x2', style: 'highlight', label: 'Sx // AB' },
      ],
      faces: [
        { vertices: ['A', 'B', 'C', 'D'], color: '#3B82F6', opacity: 0.16 },
        { vertices: ['S', 'A', 'B'], color: '#10B981', opacity: 0.2, label: '(SAB)' },
        { vertices: ['S', 'B', 'C'], color: '#60A5FA', opacity: 0.13 },
        { vertices: ['S', 'C', 'D'], color: '#F59E0B', opacity: 0.2, label: '(SCD)' },
        { vertices: ['S', 'D', 'A'], color: '#60A5FA', opacity: 0.12 },
      ],
    }),
    steps: [
      {
        stepTitle: 'Tìm điểm chung của hai mặt phẳng (SAB) và (SCD)',
        explanation: 'Hai mặt phẳng (SAB) và (SCD) có chung đỉnh S nhưng chưa có điểm chung thứ hai rõ rệt trên đáy vì AB // CD.',
        formula: 'S ∈ (SAB) ∩ (SCD)',
        highlightVertices: ['S', 'A', 'B', 'C', 'D'],
        highlightFaceVertices: ['S', 'A', 'B'],
      },
      {
        stepTitle: 'Áp dụng Định lí 2 (Bài 11 KNTT): Giao tuyến song song',
        explanation: 'Vì AB ⊂ (SAB), CD ⊂ (SCD) và AB // CD nên giao tuyến của (SAB) và (SCD) là đường thẳng Sx đi qua S và song song với cả AB và CD.',
        formula: '(SAB) ∩ (SCD) = Sx (với Sx // AB // CD)',
        highlightVertices: ['S', 'x1', 'x2'],
        highlightEdges: [{ from: 'x1', to: 'x2' }, { from: 'A', to: 'B' }, { from: 'C', to: 'D' }],
      },
    ],
  },
  {
    id: 'ss-thiet-dien-binh-hanh',
    grade: 'Lớp 11',
    chapter: 'song-song',
    name: 'Bài 12 KNTT · Thiết diện song song hình bình hành EFGH',
    subtitle: 'Chương IV (HK1) · Tứ diện ABCD cắt bởi (P) qua E ∈ AC song song với AB và CD',
    formula: '(P) // AB, CD ⇒ Thiết diện EFGH là hình bình hành',
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: 'SGK Toán 11 KNTT Tập 1 · Bài 12: Hình 4.39 · k = 0.45',
      vertices: [
        { id: 'A', x: 0.1, y: 0.1, z: 2.9, role: 'primary' },
        { id: 'B', x: 1.6, y: -1.3, z: 0, role: 'primary' },
        { id: 'C', x: 1.2, y: 1.5, z: 0, role: 'primary' },
        { id: 'D', x: -1.5, y: -0.2, z: 0, role: 'primary' },
        { id: 'E', x: 0.595, y: 0.73, z: 1.595, role: 'aux' },
        { id: 'F', x: 1.42, y: -0.04, z: 0, role: 'aux' },
        { id: 'G', x: 0.205, y: -0.805, z: 0, role: 'aux' },
        { id: 'H', x: -0.62, y: -0.035, z: 1.595, role: 'aux' },
      ],
      edges: [
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'C', to: 'D', style: 'solid' },
        { from: 'D', to: 'B', style: 'dashed' },
        { from: 'A', to: 'B', style: 'solid' },
        { from: 'A', to: 'C', style: 'solid' },
        { from: 'A', to: 'D', style: 'solid' },
        { from: 'E', to: 'F', style: 'highlight' },
        { from: 'F', to: 'G', style: 'highlight' },
        { from: 'G', to: 'H', style: 'highlight' },
        { from: 'H', to: 'E', style: 'highlight' },
      ],
      faces: [
        { vertices: ['B', 'C', 'D'], color: '#3B82F6', opacity: 0.16 },
        { vertices: ['A', 'B', 'C'], color: '#60A5FA', opacity: 0.13 },
        { vertices: ['A', 'C', 'D'], color: '#60A5FA', opacity: 0.13 },
        { vertices: ['A', 'D', 'B'], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['E', 'F', 'G', 'H'], color: '#F59E0B', opacity: 0.34, label: 'EFGH', internal: true },
      ],
    }),
    steps: [
      {
        stepTitle: 'Xác định giao tuyến (P) với các mặt của tứ diện',
        explanation: 'Qua E ∈ AC, vì (P) // AB nên (P) ∩ (ABC) = EF // AB (F ∈ BC) và (P) ∩ (ABD) = GH // AB (G ∈ BD, H ∈ AD).',
        formula: 'EF // AB và GH // AB ⇒ EF // GH',
        highlightVertices: ['E', 'F', 'G', 'H', 'A', 'B'],
        highlightEdges: [{ from: 'E', to: 'F' }, { from: 'G', to: 'H' }, { from: 'A', to: 'B' }],
      },
      {
        stepTitle: 'Chứng minh thiết diện EFGH là hình bình hành',
        explanation: 'Tương tự vì (P) // CD nên FG // CD và HE // CD ⇒ FG // HE. Tứ giác EFGH có các cặp cạnh đối song song nên là hình bình hành.',
        formula: 'EF // HG và FG // EH ⇒ EFGH là hình bình hành',
        highlightVertices: ['E', 'F', 'G', 'H'],
        highlightFaceVertices: ['E', 'F', 'G', 'H'],
      },
    ],
  },
  {
    id: 'ss-thales-hai-mp',
    grade: 'Lớp 11',
    chapter: 'song-song',
    name: 'Bài 13 KNTT · Hai mặt phẳng song song & Định lí Thalès',
    subtitle: 'Chương IV (HK1) · (MNPQ) // (ABCD) cắt hình chóp theo tỉ số k = SM/SA',
    formula: 'SM/SA = SN/SB = SP/SC = SQ/SD = k · S_MNPQ / S_ABCD = k²',
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: 'SGK Toán 11 KNTT Tập 1 · Bài 13: Hình 4.45 / 4.49 · k = 0.52',
      vertices: [
        { id: 'A', x: 1.4, y: -1.4, z: 0, role: 'primary' },
        { id: 'B', x: 1.4, y: 1.4, z: 0, role: 'primary' },
        { id: 'C', x: -1.4, y: 1.4, z: 0, role: 'primary' },
        { id: 'D', x: -1.4, y: -1.4, z: 0, role: 'primary' },
        { id: 'S', x: 0.3, y: -0.2, z: 3.1, role: 'primary' },
        { id: 'M', x: 0.872, y: -0.824, z: 1.488, role: 'aux' },
        { id: 'N', x: 0.872, y: 0.632, z: 1.488, role: 'aux' },
        { id: 'P', x: -0.584, y: 0.632, z: 1.488, role: 'aux' },
        { id: 'Q', x: -0.584, y: -0.824, z: 1.488, role: 'aux' },
      ],
      edges: [
        { from: 'A', to: 'B', style: 'solid' },
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'C', to: 'D', style: 'dashed' },
        { from: 'D', to: 'A', style: 'dashed' },
        { from: 'S', to: 'A', style: 'solid' },
        { from: 'S', to: 'B', style: 'solid' },
        { from: 'S', to: 'C', style: 'solid' },
        { from: 'S', to: 'D', style: 'dashed' },
        { from: 'M', to: 'N', style: 'highlight' },
        { from: 'N', to: 'P', style: 'highlight' },
        { from: 'P', to: 'Q', style: 'highlight' },
        { from: 'Q', to: 'M', style: 'highlight' },
      ],
      faces: [
        { vertices: ['A', 'B', 'C', 'D'], color: '#3B82F6', opacity: 0.16, label: '(ABCD)' },
        { vertices: ['S', 'A', 'B'], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['S', 'B', 'C'], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['S', 'C', 'D'], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['S', 'D', 'A'], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['M', 'N', 'P', 'Q'], color: '#10B981', opacity: 0.3, label: '(MNPQ)', internal: true },
      ],
    }),
    steps: [
      {
        stepTitle: 'Hai mặt phẳng song song bị cắt bởi mặt phẳng thứ ba',
        explanation: 'Vì (MNPQ) // (ABCD) nên giao tuyến của mặt bên (SAB) với hai mặt phẳng đó song song nhau: MN // AB. Tương tự NP // BC, PQ // CD, QM // DA.',
        formula: '(α) // (β) ⇒ MN // AB, NP // BC, PQ // CD',
        highlightVertices: ['M', 'N', 'P', 'Q'],
        highlightFaceVertices: ['M', 'N', 'P', 'Q'],
      },
      {
        stepTitle: 'Định lí Thalès trong không gian (Bài 13 KNTT)',
        explanation: 'Ba mặt phẳng song song chắn trên các đường thẳng bất kì những đoạn thẳng tỉ lệ: SM/SA = SN/SB = SP/SC = SQ/SD = k.',
        formula: 'MNPQ đồng dạng với ABCD theo tỉ số k',
        highlightVertices: ['S', 'M', 'N', 'A', 'B'],
        highlightEdges: [{ from: 'M', to: 'N' }, { from: 'A', to: 'B' }],
      },
    ],
  },
  {
    id: 'ss-phep-chieu-song-song',
    grade: 'Lớp 11',
    chapter: 'song-song',
    name: 'Bài 14 KNTT · Phép chiếu song song lên (P)',
    subtitle: 'Chương IV (HK1) · Chiếu hình bình hành ABCD theo phương Δ cho ảnh A\'B\'C\'D\'',
    formula: "AB // CD ⇒ A'B' // C'D' · A'B' / C'D' = AB / CD",
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: 'SGK Toán 11 KNTT Tập 1 · Bài 14: Hình 4.57 / 4.60 · Tia chiếu song song AA\' // BB\' // CC\' // DD\'',
      vertices: [
        { id: 'P1', x: 2.3, y: -2.4, z: 0, role: 'aux' },
        { id: 'P2', x: 2.3, y: 2.4, z: 0, role: 'aux' },
        { id: 'P3', x: -2.3, y: 2.4, z: 0, role: 'aux' },
        { id: 'P4', x: -2.3, y: -2.4, z: 0, role: 'aux' },
        { id: 'A', x: 1.5, y: -0.9, z: 2.4, role: 'primary' },
        { id: 'B', x: 1.5, y: 1.1, z: 2.4, role: 'primary' },
        { id: 'C', x: -0.4, y: 1.6, z: 2.4, role: 'primary' },
        { id: 'D', x: -0.4, y: -0.4, z: 2.4, role: 'primary' },
        { id: "A'", x: 0.9, y: -1.4, z: 0, role: 'projection' },
        { id: "B'", x: 0.9, y: 0.6, z: 0, role: 'projection' },
        { id: "C'", x: -1.0, y: 1.1, z: 0, role: 'projection' },
        { id: "D'", x: -1.0, y: -0.9, z: 0, role: 'projection' },
      ],
      edges: [
        { from: 'P1', to: 'P2', style: 'solid' },
        { from: 'P2', to: 'P3', style: 'solid' },
        { from: 'P3', to: 'P4', style: 'solid' },
        { from: 'P4', to: 'P1', style: 'solid' },
        { from: 'A', to: 'B', style: 'solid' },
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'C', to: 'D', style: 'solid' },
        { from: 'D', to: 'A', style: 'solid' },
        { from: "A'", to: "B'", style: 'highlight' },
        { from: "B'", to: "C'", style: 'highlight' },
        { from: "C'", to: "D'", style: 'highlight' },
        { from: "D'", to: "A'", style: 'highlight' },
        { from: 'A', to: "A'", style: 'dashed', label: 'Δ' },
        { from: 'B', to: "B'", style: 'dashed' },
        { from: 'C', to: "C'", style: 'dashed' },
        { from: 'D', to: "D'", style: 'dashed' },
      ],
      faces: [
        { vertices: ['P1', 'P2', 'P3', 'P4'], color: '#94A3B8', opacity: 0.14, label: '(P)' },
        { vertices: ['A', 'B', 'C', 'D'], color: '#3B82F6', opacity: 0.24 },
        { vertices: ["A'", "B'", "C'", "D'"], color: '#F59E0B', opacity: 0.28 },
      ],
    }),
    steps: [
      {
        stepTitle: 'Các tia chiếu song song phương Δ cắt mặt phẳng chiếu (P)',
        explanation: "Từ các đỉnh A, B, C, D dựng đường thẳng song song với phương chiếu Δ, cắt (P) tại hình chiếu song song A', B', C', D'.",
        formula: "AA' // BB' // CC' // DD' // Δ",
        highlightVertices: ['A', "A'", 'B', "B'", 'C', "C'", 'D', "D'"],
        highlightEdges: [{ from: 'A', to: "A'" }, { from: 'B', to: "B'" }, { from: 'C', to: "C'" }, { from: 'D', to: "D'" }],
      },
      {
        stepTitle: 'Tính chất bảo toàn song song và tỉ số đoạn thẳng (Bài 14 KNTT)',
        explanation: "Phép chiếu song song biến hai đường thẳng song song thành hai đường thẳng song song hoặc trùng nhau, biến hình bình hành ABCD thành hình bình hành A'B'C'D'.",
        formula: "A'B' // C'D' & M trung điểm AB ⇒ M' trung điểm A'B'",
        highlightFaceVertices: ["A'", "B'", "C'", "D'"],
      },
    ],
  },
  {
    id: 'ss-giao-diem-tu-dien-b10',
    grade: 'Lớp 11',
    chapter: 'song-song',
    name: 'Bài 10 KNTT · Giao điểm đường thẳng & mặt phẳng trong tứ diện',
    subtitle: 'Chương IV (HK1) · Tứ diện ABCD, M ∈ BC, I là giao điểm AM với mặt phẳng phụ (BCD)/(ACD)',
    formula: 'Chọn mp phụ (ABM) chứa đường cần tìm ⇒ tìm giao tuyến d = (ABM) ∩ (ACD) ⇒ I = BM ∩ d',
    scene: normalizeSceneSpec({
      showOxyz: false,
      unitNote: 'SGK Toán 11 KNTT Tập 1 · Bài 10: Hình 4.13 · Kéo dài DM cắt AB tại E',
      vertices: [
        { id: 'A', x: 0.1, y: 0.0, z: 2.9, role: 'primary' },
        { id: 'B', x: 1.6, y: -1.3, z: 0, role: 'primary' },
        { id: 'C', x: 1.2, y: 1.5, z: 0, role: 'primary' },
        { id: 'D', x: -1.5, y: -0.2, z: 0, role: 'primary' },
        { id: 'M', x: 0.85, y: -0.65, z: 1.45, role: 'aux' },
        { id: 'N', x: -0.15, y: 0.65, z: 0, role: 'aux' },
        { id: 'I', x: -0.433, y: 0.167, z: 0.967, role: 'projection' },
      ],
      edges: [
        { from: 'B', to: 'C', style: 'solid' },
        { from: 'C', to: 'D', style: 'solid' },
        { from: 'D', to: 'B', style: 'dashed' },
        { from: 'A', to: 'B', style: 'solid' },
        { from: 'A', to: 'C', style: 'solid' },
        { from: 'A', to: 'D', style: 'solid' },
        { from: 'D', to: 'M', style: 'solid' },
        { from: 'A', to: 'N', style: 'dashed' },
        { from: 'C', to: 'M', style: 'highlight', label: 'CM' },
        { from: 'B', to: 'I', style: 'highlight' },
      ],
      faces: [
        { vertices: ['B', 'C', 'D'], color: '#3B82F6', opacity: 0.15 },
        { vertices: ['A', 'B', 'C'], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['A', 'C', 'D'], color: '#F59E0B', opacity: 0.19, label: '(ACD)' },
        { vertices: ['A', 'D', 'B'], color: '#60A5FA', opacity: 0.12 },
        { vertices: ['A', 'B', 'N'], color: '#10B981', opacity: 0.18, internal: true },
      ],
    }),
    steps: [
      {
        stepTitle: 'Bước 1 (Bài 10 KNTT): Chọn mặt phẳng phụ chứa đường thẳng',
        explanation: 'Muốn tìm giao điểm I của đường thẳng (ví dụ AN hoặc CM) với mặt phẳng (BCD)/(ABD), ta chọn mặt phẳng phụ (ABN) chứa đường thẳng đó (với N là trung điểm CD).',
        formula: 'Chọn mp phụ (ABN) ⊃ AN',
        highlightVertices: ['A', 'B', 'N', 'C', 'D'],
        highlightFaceVertices: ['A', 'B', 'N'],
      },
      {
        stepTitle: 'Bước 2: Tìm giao tuyến của mặt phẳng phụ và mặt phẳng đích',
        explanation: 'Tìm 2 điểm chung để dựng giao tuyến d = (ABN) ∩ (ACD) hoặc cắt nhau trong cùng một mặt tam giác, từ đó xác định giao điểm duy nhất I.',
        formula: 'I = AN ∩ d ⇒ I ∈ (ACD)',
        highlightVertices: ['I', 'M', 'C', 'B'],
        highlightEdges: [{ from: 'C', to: 'M' }, { from: 'B', to: 'I' }],
      },
    ],
  },
];

/* ===== GeoGebra 3D Standard Kernel Algorithms (Intersections, Transformations, Polyhedron Net & Surface Grapher) ===== */

/**
 * Computes exact intersection point between line AB and plane (p1, p2, p3).
 * Mirrors GeoGebra AlgoIntersectLinePlane3D.
 */
export function intersectLinePlane(a, b, p1, p2, p3) {
  const pl = planeFrom3Points(p1, p2, p3);
  if (!pl.valid) return { valid: false, reason: 'Ba điểm xác định mặt phẳng thẳng hàng.' };
  const dir = vecSub(b, a);
  const denom = vecDot(pl.normal, dir);
  const s1 = vecDot(pl.normal, a) + pl.d;
  if (Math.abs(denom) < EPS) {
    return {
      valid: false,
      parallel: true,
      coplanar: Math.abs(s1) < 1e-4,
      reason: Math.abs(s1) < 1e-4 ? 'Đường thẳng nằm trong mặt phẳng.' : 'Đường thẳng song song với mặt phẳng.',
    };
  }
  const t = -s1 / denom;
  const point = lerpPoint(a, b, t);
  return { valid: true, point, t, onSegment: t >= -1e-4 && t <= 1 + 1e-4 };
}

/**
 * Computes exact intersection line between two 3D planes (a1,b1,c1) and (a2,b2,c2).
 * Mirrors GeoGebra AlgoIntersectPlanes.
 */
export function intersectTwoPlanes(a1, b1, c1, a2, b2, c2) {
  const p1 = planeFrom3Points(a1, b1, c1);
  const p2 = planeFrom3Points(a2, b2, c2);
  if (!p1.valid || !p2.valid) return { valid: false, reason: 'Mặt phẳng không xác định.' };

  const dirRaw = vecCross(p1.normal, p2.normal);
  const dirLen = vecLen(dirRaw);
  if (dirLen < 1e-5) {
    return { valid: false, parallel: true, reason: 'Hai mặt phẳng song song hoặc trùng nhau.' };
  }
  const dir = vecScale(dirRaw, 1 / dirLen);
  // Cramer / direct projection onto plane normal system: point = c1*n1 + c2*n2
  const n1 = p1.normal;
  const n2 = p2.normal;
  const n1n2 = vecDot(n1, n2);
  const det = 1 - n1n2 * n1n2;
  const rhs1 = -p1.d;
  const rhs2 = -p2.d;
  const k1 = (rhs1 - n1n2 * rhs2) / det;
  const k2 = (rhs2 - n1n2 * rhs1) / det;
  const origin = vecAdd(vecScale(n1, k1), vecScale(n2, k2));

  // Recenter segment near the centroid of the 6 defining points so it renders nicely inside view
  const ctr = centroid([a1, b1, c1, a2, b2, c2]);
  const proj = vecAdd(origin, vecScale(dir, vecDot(vecSub(ctr, origin), dir)));
  const span = 2.6;
  return {
    valid: true,
    origin: proj,
    dir,
    segA: vecAdd(proj, vecScale(dir, -span)),
    segB: vecAdd(proj, vecScale(dir, span)),
  };
}

/**
 * Reflects point P across plane (a, b, c) — GeoGebra AlgoMirrorPointPlane3D.
 */
export function reflectPointAcrossPlane(p, a, b, c) {
  const pr = projectPointOnPlane(p, a, b, c);
  if (!pr.valid) return { valid: false, point: { ...p } };
  return { valid: true, point: vecSub(vecScale(pr.point, 2), p), foot: pr.point, distance: pr.distance };
}

/**
 * Reflects point P across center point C — GeoGebra AlgoMirrorPointPoint.
 */
export function reflectPointAcrossPoint(p, center) {
  return vecSub(vecScale(center, 2), p);
}

/**
 * Homothety / Dilation from center by factor k — GeoGebra AlgoDilate.
 */
export function dilatePoint(p, center, k = 2) {
  return vecAdd(center, vecScale(vecSub(p, center), k));
}

/**
 * Rodrigues' rotation formula around axis passing through origin with unit direction vector `axisUnit`.
 */
export function rodriguesRotate(point, origin, axisUnit, angleRad) {
  const rel = vecSub(point, origin);
  const cos = Math.cos(angleRad);
  const sin = Math.sin(angleRad);
  const cross = vecCross(axisUnit, rel);
  const dot = vecDot(axisUnit, rel);
  const rot = {
    x: rel.x * cos + cross.x * sin + axisUnit.x * dot * (1 - cos),
    y: rel.y * cos + cross.y * sin + axisUnit.y * dot * (1 - cos),
    z: rel.z * cos + cross.z * sin + axisUnit.z * dot * (1 - cos),
  };
  return vecAdd(origin, rot);
}

/**
 * Computes GeoGebra-standard interactive 3D -> 2D Polyhedron Net (`AlgoPolyhedronNet`).
 * `unfoldRatio` in [0, 1]: 0 = folded 3D polyhedron, 1 = completely flat 2D net on base plane!
 */
export function computePolyhedronNet(scene, unfoldRatio = 1) {
  const t = Math.min(1, Math.max(0, Number(unfoldRatio) || 0));
  if (!scene || !Array.isArray(scene.faces) || scene.faces.length < 3) {
    return { valid: false, faces: [] };
  }
  const vMap = new Map((scene.vertices || []).map((v) => [v.id, v]));
  const facesData = scene.faces
    .map((f, idx) => {
      const ids = f.vertices || [];
      const pts = ids.map((id) => vMap.get(id)).filter(Boolean);
      if (pts.length < 3) return null;
      const avgZ = pts.reduce((s, p) => s + p.z, 0) / pts.length;
      return { idx, ids, pts, avgZ, color: f.color || '#3B82F6', label: f.label || '' };
    })
    .filter(Boolean);

  if (!facesData.length) return { valid: false, faces: [] };

  // Select lowest face (z ≈ 0) as fixed base polygon
  let baseFace = facesData[0];
  for (const fd of facesData) {
    if (fd.avgZ < baseFace.avgZ - 1e-4) baseFace = fd;
  }
  const baseCenter = centroid(baseFace.pts);

  const findSharedEdge = (idsA, idsB) => {
    const shared = idsA.filter((id) => idsB.includes(id));
    if (shared.length < 2) return null;
    for (let i = 0; i < idsA.length; i++) {
      const u = idsA[i];
      const v = idsA[(i + 1) % idsA.length];
      if (idsB.includes(u) && idsB.includes(v)) return [u, v];
    }
    return [shared[0], shared[1]];
  };

  const computeOutwardFold = (parentPts, parentCenter, childPts, hingeU, hingeV) => {
    const axis = vecNormalize(vecSub(hingeV, hingeU));
    if (vecLen(axis) < EPS) return 0;
    const pProj = projectPointOnLine(parentCenter, hingeU, hingeV).point;
    const outDir = vecNormalize(vecSub(hingeU, hingeU)); // placeholder replaced right below
    void outDir;
    const outFromParent = vecNormalize(vecSub(pProj, parentCenter));
    const childCenter = centroid(childPts);
    const cProj = projectPointOnLine(childCenter, hingeU, hingeV).point;
    const childDir = vecNormalize(vecSub(childCenter, cProj));
    if (vecLen(outFromParent) < EPS || vecLen(childDir) < EPS) return 0;
    return Math.atan2(vecDot(vecCross(childDir, outFromParent), axis), vecDot(childDir, outFromParent));
  };

  const resultFaces = [{
    points: baseFace.pts.map((p) => ({ x: p.x, y: p.y, z: p.z })),
    color: baseFace.color,
    isBase: true,
    area: polygonArea(baseFace.pts),
  }];

  const firstLevelTransforms = []; // store parent lateral face transforms for chaining top face
  const unattached = [];

  for (const fd of facesData) {
    if (fd.idx === baseFace.idx) continue;
    const edge = findSharedEdge(baseFace.ids, fd.ids);
    if (edge) {
      const U = vMap.get(edge[0]);
      const V = vMap.get(edge[1]);
      const axis = vecNormalize(vecSub(V, U));
      const fullAngle = computeOutwardFold(baseFace.pts, baseCenter, fd.pts, U, V);
      const ang = t * fullAngle;
      const rotPts = fd.pts.map((p) => rodriguesRotate(p, U, axis, ang));
      resultFaces.push({
        points: rotPts,
        color: fd.color,
        isBase: false,
        area: polygonArea(fd.pts),
      });
      firstLevelTransforms.push({ fd, U, V, axis, ang });
    } else {
      unattached.push(fd);
    }
  }

  // Chain remaining faces (e.g. top face of prism, cube, or frustum) via first lateral face sharing an edge
  for (const fd of unattached) {
    let attached = null;
    for (const parent of firstLevelTransforms) {
      const edge = findSharedEdge(parent.fd.ids, fd.ids);
      if (edge) {
        attached = { parent, edge };
        break;
      }
    }
    if (!attached) {
      resultFaces.push({ points: fd.pts, color: fd.color, isBase: false, area: polygonArea(fd.pts) });
      continue;
    }
    const { parent, edge } = attached;
    const U2 = vMap.get(edge[0]);
    const V2 = vMap.get(edge[1]);
    const axis2 = vecNormalize(vecSub(V2, U2));
    const fullAngle2 = computeOutwardFold(parent.fd.pts, centroid(parent.fd.pts), fd.pts, U2, V2);
    const ang2 = t * fullAngle2;
    const rotPts = fd.pts
      .map((p) => rodriguesRotate(p, U2, axis2, ang2))
      .map((p) => rodriguesRotate(p, parent.U, parent.axis, parent.ang));
    resultFaces.push({
      points: rotPts,
      color: fd.color,
      isBase: false,
      area: polygonArea(fd.pts),
    });
  }

  const totalArea = resultFaces.reduce((s, f) => s + f.area, 0);
  return { valid: true, faces: resultFaces, totalArea };
}

/**
 * Safe recursive-descent math expression evaluator (NO eval/new Function) for GeoGebra Surface z = f(x, y).
 */
export function safeEvalMathExpr(expr, vars = {}) {
  const src = String(expr || '').trim().toLowerCase().replace(/\s+/g, '');
  if (!src) return NaN;
  let pos = 0;

  const peek = () => src[pos] || '';
  const consume = () => src[pos++];

  const parseExpr = () => {
    let val = parseTerm();
    while (peek() === '+' || peek() === '-') {
      const op = consume();
      const rhs = parseTerm();
      val = op === '+' ? val + rhs : val - rhs;
    }
    return val;
  };

  const parseTerm = () => {
    let val = parsePower();
    while (peek() === '*' || peek() === '/') {
      const op = consume();
      const rhs = parsePower();
      val = op === '*' ? val * rhs : val / rhs;
    }
    return val;
  };

  const parsePower = () => {
    let base = parseUnary();
    if (peek() === '^') {
      consume();
      const exp = parsePower(); // right-associative
      base = Math.pow(base, exp);
    }
    return base;
  };

  const parseUnary = () => {
    if (peek() === '+') { consume(); return parseUnary(); }
    if (peek() === '-') { consume(); return -parseUnary(); }
    return parsePrimary();
  };

  const parsePrimary = () => {
    if (peek() === '(') {
      consume();
      const val = parseExpr();
      if (peek() === ')') consume();
      return val;
    }
    if (/[0-9.]/.test(peek())) {
      const start = pos;
      while (/[0-9.]/.test(peek())) consume();
      return Number(src.slice(start, pos));
    }
    if (/[a-z]/.test(peek())) {
      const start = pos;
      while (/[a-z0-9]/.test(peek())) consume();
      const ident = src.slice(start, pos);
      if (peek() === '(') {
        consume();
        const arg = parseExpr();
        if (peek() === ')') consume();
        if (ident === 'sin') return Math.sin(arg);
        if (ident === 'cos') return Math.cos(arg);
        if (ident === 'tan') return Math.tan(arg);
        if (ident === 'sqrt') return arg >= 0 ? Math.sqrt(arg) : NaN;
        if (ident === 'abs') return Math.abs(arg);
        if (ident === 'exp') return Math.exp(arg);
        if (ident === 'ln' || ident === 'log') return arg > 0 ? Math.log(arg) : NaN;
        return NaN;
      }
      if (ident === 'pi') return Math.PI;
      if (ident === 'e') return Math.E;
      if (Object.prototype.hasOwnProperty.call(vars, ident)) return Number(vars[ident]);
      return NaN;
    }
    return NaN;
  };

  const res = parseExpr();
  return pos === src.length && Number.isFinite(res) ? res : NaN;
}

/**
 * Samples z = f(x, y) over [-range, range]^2 for 3D Surface graphing (GeoGebra 3D Surface tool).
 */
export function sampleSurfaceZ(expr, range = 2.8, segs = 28) {
  const n = Math.max(8, Math.min(48, Math.round(segs)));
  const r = Math.max(1, Math.min(6, Number(range) || 2.8));
  const step = (2 * r) / n;
  const grid = [];
  let minZ = Infinity;
  let maxZ = -Infinity;
  let validCount = 0;

  for (let i = 0; i <= n; i++) {
    const x = -r + i * step;
    const row = [];
    for (let j = 0; j <= n; j++) {
      const y = -r + j * step;
      let z = safeEvalMathExpr(expr, { x, y });
      if (!Number.isFinite(z)) z = NaN;
      else {
        z = Math.max(-5, Math.min(5, z));
        if (z < minZ) minZ = z;
        if (z > maxZ) maxZ = z;
        validCount++;
      }
      row.push({ x, y, z });
    }
    grid.push(row);
  }
  return {
    valid: validCount > 4,
    expr,
    range: r,
    segs: n,
    minZ: Number.isFinite(minZ) ? minZ : 0,
    maxZ: Number.isFinite(maxZ) ? maxZ : 0,
    grid,
  };
}

/**
 * Solves 3x3 linear system A * x = b using Gaussian elimination with partial pivoting.
 */
function solveLinear3x3(A, b) {
  const M = [
    [A[0][0], A[0][1], A[0][2], b[0]],
    [A[1][0], A[1][1], A[1][2], b[1]],
    [A[2][0], A[2][1], A[2][2], b[2]],
  ];
  for (let col = 0; col < 3; col++) {
    let piv = col;
    for (let r = col + 1; r < 3; r++) {
      if (Math.abs(M[r][col]) > Math.abs(M[piv][col])) piv = r;
    }
    if (Math.abs(M[piv][col]) < 1e-9) return null;
    if (piv !== col) [M[col], M[piv]] = [M[piv], M[col]];
    const inv = 1 / M[col][col];
    for (let j = col; j < 4; j++) M[col][j] *= inv;
    for (let r = 0; r < 3; r++) {
      if (r === col) continue;
      const factor = M[r][col];
      for (let j = col; j < 4; j++) M[r][j] -= factor * M[col][j];
    }
  }
  return { x: M[0][3], y: M[1][3], z: M[2][3] };
}

/**
 * GeoGebra `AlgoOrthoPlaneBisectorPointPoint`: perpendicular bisector plane of segment AB.
 */
export function planeBisector(a, b) {
  const dir = vecSub(b, a);
  if (vecLen(dir) < EPS) return { valid: false, reason: 'Hai điểm trùng nhau.' };
  const mid = midpoint(a, b);
  return { ...planeFromPointAndNormal(mid, dir), point: mid };
}

/**
 * GeoGebra `AlgoDistancePlanes`: exact distance between two planes (0 if intersecting, |(O2-O1)·n| if parallel).
 */
export function distanceParallelPlanes(a1, b1, c1, a2, b2, c2) {
  const p1 = planeFrom3Points(a1, b1, c1);
  const p2 = planeFrom3Points(a2, b2, c2);
  if (!p1.valid || !p2.valid) return { valid: false, reason: 'Mặt phẳng không xác định.' };
  const cross = vecCross(p1.normal, p2.normal);
  if (vecLen(cross) > 1e-4) {
    return { valid: true, parallel: false, distance: 0 };
  }
  const distance = Math.abs(vecDot(vecSub(a2, a1), p1.normal));
  return { valid: true, parallel: true, distance };
}

/**
 * Computes circumsphere (tâm I, bán kính R) passing through 4 non-coplanar vertices A, B, C, D.
 */
export function circumSphere4Points(a, b, c, d) {
  const rows = [b, c, d].map((p) => [
    2 * (p.x - a.x),
    2 * (p.y - a.y),
    2 * (p.z - a.z),
  ]);
  const aSq = a.x * a.x + a.y * a.y + a.z * a.z;
  const rhs = [b, c, d].map((p) => p.x * p.x + p.y * p.y + p.z * p.z - aSq);
  const center = solveLinear3x3(rows, rhs);
  if (!center) {
    return { valid: false, reason: 'Bốn điểm đồng phẳng, không xác định duy nhất mặt cầu ngoại tiếp.' };
  }
  return { valid: true, center, radius: vecDist(center, a) };
}

/**
 * GeoGebra `AlgoIntersectLineQuadric3D`: intersects line AB with sphere (center, radius).
 */
export function intersectLineSphere(a, b, center, radius) {
  const dir = vecSub(b, a);
  const aa = vecDot(dir, dir);
  if (aa < EPS * EPS || radius <= 0) return { valid: false, points: [], reason: 'Đường thẳng hoặc mặt cầu không hợp lệ.' };
  const oc = vecSub(a, center);
  const bb = 2 * vecDot(oc, dir);
  const cc = vecDot(oc, oc) - radius * radius;
  const disc = bb * bb - 4 * aa * cc;
  if (disc < -1e-5) return { valid: true, points: [], status: 'DISJOINT' };
  if (Math.abs(disc) <= 1e-5) {
    const t = -bb / (2 * aa);
    return { valid: true, points: [lerpPoint(a, b, t)], status: 'TANGENT', params: [t] };
  }
  const sq = Math.sqrt(disc);
  const t1 = (-bb - sq) / (2 * aa);
  const t2 = (-bb + sq) / (2 * aa);
  return { valid: true, points: [lerpPoint(a, b, t1), lerpPoint(a, b, t2)], status: 'SECANT', params: [t1, t2] };
}

/**
 * GeoGebra `AlgoIntersectPlaneQuadric`: intersection circle between sphere and plane (p1, p2, p3).
 */
export function intersectSpherePlane(center, radius, p1, p2, p3) {
  const proj = projectPointOnPlane(center, p1, p2, p3);
  if (!proj.valid || radius <= 0) return { valid: false, reason: 'Mặt phẳng hoặc mặt cầu không hợp lệ.' };
  const d = proj.distance;
  if (d > radius + 1e-5) return { valid: true, status: 'DISJOINT', distance: d, rCircle: 0 };
  if (Math.abs(d - radius) <= 1e-4) {
    return { valid: true, status: 'TANGENT', center: proj.point, normal: proj.normal, distance: d, rCircle: 0 };
  }
  const rCircle = Math.sqrt(Math.max(0, radius * radius - d * d));
  return { valid: true, status: 'CIRCLE', center: proj.point, normal: proj.normal, distance: d, rCircle };
}

/**
 * GeoGebra `AlgoIntersectQuadricsAsCircle`: intersection circle of two spheres.
 */
export function intersectTwoSpheres(c1, r1, c2, r2) {
  const diff = vecSub(c2, c1);
  const d = vecLen(diff);
  if (d < EPS) return { valid: false, reason: 'Hai mặt cầu đồng tâm.' };
  if (d > r1 + r2 + 1e-5 || d < Math.abs(r1 - r2) - 1e-5) {
    return { valid: true, status: 'DISJOINT', distance: d, rCircle: 0 };
  }
  const dir = vecScale(diff, 1 / d);
  const x = (d + (r1 * r1 - r2 * r2) / d) * 0.5;
  const center = vecAdd(c1, vecScale(dir, x));
  const rCircle = Math.sqrt(Math.max(0, r1 * r1 - x * x));
  return {
    valid: true,
    status: rCircle < 1e-4 ? 'TANGENT' : 'CIRCLE',
    center,
    normal: dir,
    rCircle,
    distance: d,
  };
}

/**
 * Builds the 5 Platonic solids using GeoGebra `PlatonicSolidsFactory` exact coordinates (EUPL v1.2),
 * scaled to edge length `a` and centered horizontally with base at z = 0.
 */
export function buildPlatonicSolid(kind = 'octahedron', edgeLen = 2.2) {
  const a = Math.max(0.8, Math.min(4.2, Number(edgeLen) || 2.2));
  const k = String(kind || 'octahedron').toLowerCase();

  const RAW = {
    tetrahedron: {
      name: 'Tứ diện đều',
      verts: [
        [0, 0, 0],
        [1, 0, 0],
        [0.5, 0.8660254037844398, 0],
        [0.5, 0.28867513459481, 0.8164965809277199],
      ],
      faces: [[2, 0, 1], [3, 0, 2], [1, 0, 3], [2, 1, 3]],
    },
    cube: {
      name: 'Hình lập phương',
      verts: [
        [0, 0, 0], [1, 0, 0], [1, 1, 0], [0, 1, 0],
        [0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1],
      ],
      faces: [[3, 0, 1, 2], [4, 0, 3, 7], [1, 0, 4, 5], [2, 1, 5, 6], [3, 2, 6, 7], [4, 7, 6, 5]],
    },
    octahedron: {
      name: 'Bát diện đều',
      verts: [
        [0, 0, 0],
        [1, 0, 0],
        [0.5, 0.8660254037844398, 0],
        [0.5, -0.28867513459481986, 0.81649658092772],
        [1, 0.57735026918962, 0.81649658092772],
        [0, 0.57735026918962, 0.81649658092772],
      ],
      faces: [
        [2, 0, 1], [5, 0, 2], [3, 0, 5], [1, 0, 3],
        [4, 1, 3], [2, 1, 4], [5, 2, 4], [5, 4, 3],
      ],
    },
    dodecahedron: {
      name: 'Thập nhị diện đều (12 mặt đều)',
      verts: [
        [0, 0, 0], [1, 0, 0], [1.3090169943749501, 0.9510565162951601, 0], [0.5, 1.5388417685876306, 0], [-0.30901699437495, 0.9510565162951601, 0],
        [1.3090169943749501, -0.42532540417601983, 0.85065080835204], [1.8090169943749501, 1.1135163644116104, 0.85065080835204],
        [0.5, 2.06457288070676, 0.85065080835204], [-0.8090169943749501, 1.1135163644116104, 0.85065080835204],
        [-0.30901699437495, -0.42532540417601983, 0.85065080835204], [0.5, -0.6881909602355799, 1.3763819204711698],
        [1.8090169943749501, 0.26286555605956996, 1.37638192047118], [1.3090169943749501, 1.8017073246472002, 1.3763819204711698],
        [-0.30901699437495, 1.8017073246472002, 1.3763819204711698], [-0.8090169943749501, 0.26286555605956996, 1.3763819204711698],
        [0.5, -0.1624598481164502, 2.22703272882321], [1.3090169943749501, 0.42532540417602016, 2.22703272882321],
        [1, 1.37638192047117, 2.22703272882321], [0, 1.37638192047117, 2.22703272882321], [-0.30901699437495, 0.42532540417602016, 2.22703272882321],
      ],
      faces: [
        [4, 0, 1, 2, 3], [9, 0, 4, 8, 14], [1, 0, 9, 10, 5], [2, 1, 5, 11, 6],
        [3, 2, 6, 12, 7], [4, 3, 7, 13, 8], [14, 8, 13, 18, 19], [9, 14, 19, 15, 10],
        [5, 10, 15, 16, 11], [6, 11, 16, 17, 12], [7, 12, 17, 18, 13], [19, 18, 17, 16, 15],
      ],
    },
    icosahedron: {
      name: 'Nhị thập diện đều (20 mặt đều)',
      verts: [
        [0, 0, 0], [1, 0, 0], [0.5, 0.8660254037844398, 0],
        [0.5, -0.6454972243679103, 0.5773502691896201], [1.3090169943749501, 0.7557613140761701, 0.5773502691896302],
        [-0.30901699437495, 0.7557613140761701, 0.5773502691896201], [-0.30901699437495, -0.17841104488655019, 0.93417235896271],
        [1.3090169943749501, -0.17841104488655019, 0.9341723589627201], [0.5, 1.2228474935575302, 0.93417235896271],
        [0.5, -0.28867513459481986, 1.5115226281523402], [1, 0.57735026918962, 1.5115226281523402], [0, 0.57735026918962, 1.5115226281523402],
      ],
      faces: [
        [2, 0, 1], [5, 0, 2], [6, 0, 5], [3, 0, 6], [1, 0, 3],
        [7, 1, 3], [4, 1, 7], [2, 1, 4], [8, 2, 4], [5, 2, 8],
        [10, 4, 7], [8, 4, 10], [11, 8, 10], [5, 8, 11], [9, 10, 7],
        [11, 10, 9], [6, 11, 9], [5, 11, 6], [3, 9, 7], [6, 9, 3],
      ],
    },
  };

  const spec = RAW[k] || RAW.octahedron;
  const cx = spec.verts.reduce((s, p) => s + p[0], 0) / spec.verts.length;
  const cy = spec.verts.reduce((s, p) => s + p[1], 0) / spec.verts.length;

  const ids = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U'];
  const vertices = spec.verts.map((p, idx) => ({
    id: ids[idx] || `V${idx + 1}`,
    x: (p[0] - cx) * a,
    y: (p[1] - cy) * a,
    z: p[2] * a,
    role: 'primary',
  }));

  const edges = [];
  const edgeKeys = new Set();
  const faces = spec.faces.map((f, fi) => {
    const fIds = f.map((vi) => vertices[vi].id);
    for (let i = 0; i < fIds.length; i++) {
      const u = fIds[i];
      const w = fIds[(i + 1) % fIds.length];
      const key = u < w ? `${u}|${w}` : `${w}|${u}`;
      if (!edgeKeys.has(key)) {
        edgeKeys.add(key);
        edges.push({ from: u, to: w, style: 'solid' });
      }
    }
    return {
      vertices: fIds,
      color: fi === 0 ? '#10B981' : fi % 3 === 1 ? '#60A5FA' : '#3B82F6',
      opacity: 0.16,
    };
  });

  const scene = normalizeSceneSpec({
    unitNote: `${spec.name} cạnh a = ${a.toFixed(1)} (theo GeoGebra PlatonicSolidsFactory)`,
    vertices,
    edges,
    faces,
  });
  return { name: spec.name, scene, volume: polyhedronVolume(scene) };
}

/**
 * Computes aspect-aware, HUD-safe camera framing (distance, target & ortho half-height)
 * so all 3D points stay cleanly inside [sidePad, w - sidePad] x [topPad, h - botPad]
 * on narrow mobile portrait, expanded mobile, and desktop viewports.
 */
export function computeCameraFraming(points3D = [], opts = {}) {
  const w = Math.max(180, Number(opts.width) || 400);
  const h = Math.max(180, Number(opts.height) || 320);
  const fovDeg = Number(opts.fovDeg) || 38;
  const preset = opts.preset || 'default';
  const topPad = Number.isFinite(opts.topPad) ? opts.topPad : (w < 640 ? 92 : 52);
  const botPad = Number.isFinite(opts.botPad) ? opts.botPad : (w < 640 ? 54 : 84);
  const sidePad = Number.isFinite(opts.sidePad) ? opts.sidePad : 26;

  const rawPts = (points3D || []).length
    ? points3D
    : [
        { x: -1.3, y: 0, z: -1.3 },
        { x: 1.3, y: 2.8, z: 1.3 },
      ];
  const pts = rawPts.map((p) =>
    Array.isArray(p)
      ? { x: Number(p[0]) || 0, y: Number(p[1]) || 0, z: Number(p[2]) || 0 }
      : { x: Number(p?.x) || 0, y: Number(p?.y) || 0, z: Number(p?.z) || 0 },
  );

  let minX = Infinity, minY = Infinity, minZ = Infinity;
  let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
  for (const p of pts) {
    if (p.x < minX) minX = p.x;
    if (p.y < minY) minY = p.y;
    if (p.z < minZ) minZ = p.z;
    if (p.x > maxX) maxX = p.x;
    if (p.y > maxY) maxY = p.y;
    if (p.z > maxZ) maxZ = p.z;
  }

  const center = {
    x: (minX + maxX) * 0.5,
    y: (minY + maxY) * 0.5,
    z: (minZ + maxZ) * 0.5,
  };

  let rawDir = { x: 0.78, y: 0.56, z: 0.88 };
  if (preset === 'top') rawDir = { x: 0, y: 1.25, z: 0.01 };
  else if (preset === 'front') rawDir = { x: 0, y: 0.25, z: 1 };
  else if (preset === 'side') rawDir = { x: 1, y: 0.3, z: 0 };
  else if (preset === 'oxyz') rawDir = { x: 0.85, y: 0.65, z: 0.85 };
  else if (preset === '2d-oblique') rawDir = { x: 0.65, y: 0.44, z: 0.96 };

  const fwd = vecNormalize(rawDir); // points from target -> camera
  const worldUp = Math.abs(fwd.y) > 0.97 ? { x: 0, y: 0, z: -1 } : { x: 0, y: 1, z: 0 };
  // Camera right = worldUp x fwd (in Three.js RH coords: forward into screen is -fwd, right is worldUp x fwd)
  const right = vecNormalize(vecCross(worldUp, fwd));
  const up = vecNormalize(vecCross(fwd, right));

  // Measure bounding extent of points in camera (right, up, fwd) basis relative to `center`
  let uMin = Infinity, uMax = -Infinity;
  let vMin = Infinity, vMax = -Infinity;
  let wMin = Infinity, wMax = -Infinity;
  for (const p of pts) {
    const rel = vecSub(p, center);
    const u = vecDot(rel, right);
    const v = vecDot(rel, up);
    const d = vecDot(rel, fwd);
    if (u < uMin) uMin = u;
    if (u > uMax) uMax = u;
    if (v < vMin) vMin = v;
    if (v > vMax) vMax = v;
    if (d < wMin) wMin = d;
    if (d > wMax) wMax = d;
  }

  // Shift target in camera (right, up) plane so bounding box centers inside usable [sidePad..w-sidePad] x [topPad..h-botPad]
  const usableW = Math.max(0.45, (w - sidePad * 2) / w);
  const usableH = Math.max(0.42, (h - topPad - botPad) / h);
  const centerScreenYShiftPx = (topPad - botPad) * 0.5; // positive means usable center is lower on screen -> shift target UP slightly to push object down? Wait:
  // If topPad > botPad (e.g. 92 vs 54), usable center is at (92 + (h-54))/2 = h/2 + 19px (19px LOWER than h/2).
  // Pushing target UP (+up) pushes object DOWN on screen.
  const uMid = (uMin + uMax) * 0.5;
  const vMid = (vMin + vMax) * 0.5;
  const halfSpanU = Math.max(0.9, (uMax - uMin) * 0.5);
  const halfSpanV = Math.max(0.9, (vMax - vMin) * 0.5);
  const frontDepth = Math.max(0.4, wMax);

  const aspect = w / h;
  const tanHalfY = Math.tan((fovDeg * Math.PI) / 360);
  const tanHalfX = tanHalfY * aspect;

  // Distance so front-most corners still fit comfortably inside usable width & height
  const reqDistV = (halfSpanV * 1.12) / (tanHalfY * usableH) + frontDepth * 0.85;
  const reqDistH = (halfSpanU * 1.12) / (tanHalfX * usableW) + frontDepth * 0.85;
  const distance = Math.max(4.6, reqDistV, reqDistH);

  // Convert screen Y shift into world units at `distance`
  const worldHeightAtDist = 2 * distance * tanHalfY;
  const targetOffsetUp = (centerScreenYShiftPx / h) * worldHeightAtDist;

  const target = {
    x: center.x + right.x * uMid + up.x * (vMid + targetOffsetUp),
    y: center.y + right.y * uMid + up.y * (vMid + targetOffsetUp),
    z: center.z + right.z * uMid + up.z * (vMid + targetOffsetUp),
  };
  const position = {
    x: target.x + fwd.x * distance,
    y: target.y + fwd.y * distance,
    z: target.z + fwd.z * distance,
  };

  // Orthographic half-height (for 2D mode)
  const orthoHalfHeight = Math.max(
    (halfSpanV * 1.18) / usableH,
    (halfSpanU * 1.18) / (usableW * aspect),
    1.8,
  );

  return { position, target, distance, orthoHalfHeight, aspect };
}


