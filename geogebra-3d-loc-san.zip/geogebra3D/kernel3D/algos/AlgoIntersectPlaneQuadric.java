/*
 * GeoGebra - Dynamic Mathematics for Everyone
 * Copyright (c) GeoGebra GmbH, Altenbergerstr. 69, 4040 Linz, Austria
 * https://www.geogebra.org
 *
 * This file is licensed by GeoGebra GmbH under the EUPL 1.2 licence and
 * may be used under the EUPL 1.2 in compatible projects (see Article 5
 * and the Appendix of EUPL 1.2 for details).
 * You may obtain a copy of the licence at:
 * https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Note: The overall GeoGebra software package is free to use for
 * non-commercial purposes only.
 * See https://www.geogebra.org/license for full licensing details
 */

package org.geogebra.common.geogebra3D.kernel3D.algos;

import org.geogebra.common.geogebra3D.kernel3D.geos.GeoConic3D;
import org.geogebra.common.kernel.Construction;
import org.geogebra.common.kernel.StringTemplate;
import org.geogebra.common.kernel.commands.Commands;
import org.geogebra.common.kernel.geos.GeoElement;
import org.geogebra.common.kernel.kernelND.GeoCoordSys2D;
import org.geogebra.common.kernel.kernelND.GeoQuadricND;
import org.geogebra.common.kernel.matrix.CoordMatrix;

/**
 *
 * @author ggb3D
 *
 */
public class AlgoIntersectPlaneQuadric extends AlgoElement3D {

	// inputs
	/** plane */
	protected GeoCoordSys2D plane;
	/** second coord sys */
	protected GeoQuadricND quadric;

	// output
	/** intersection */
	protected GeoConic3D conic;

	private CoordMatrix cm = new CoordMatrix(3, 3);
	private CoordMatrix tmpMatrix = new CoordMatrix(3, 4);
	private CoordMatrix parametricMatrix;

	/**
	 * Creates new AlgoIntersectLinePlane
	 *
	 * @param cons
	 *            the construction
	 * @param plane
	 *            plane
	 * @param quadric
	 *            quadric
	 * @param addToCons
	 *            whether to add to cons
	 */
	AlgoIntersectPlaneQuadric(
			Construction cons, GeoCoordSys2D plane, GeoQuadricND quadric, boolean addToCons) {

		super(cons, addToCons);

		this.plane = plane;
		this.quadric = quadric;

		conic = newConic(cons);

		// end
		if (addToCons) {
			end();
		}
	}

	/**
	 * Creates new AlgoIntersectLinePlane
	 *
	 * @param cons
	 *            the construction
	 * @param plane
	 *            plane
	 * @param quadric
	 *            quadric
	 */
	AlgoIntersectPlaneQuadric(Construction cons, GeoCoordSys2D plane, GeoQuadricND quadric) {

		this(cons, plane, quadric, true);
	}

	/**
	 * end of constructor for this algo
	 */
	protected void end() {
		setInputOutput(new GeoElement[] {plane.toGeoElement(), quadric}, new GeoElement[] {conic});
	}

	/**
	 *
	 * @param cons1
	 *            construction
	 * @return new conic for intersection
	 */
	protected GeoConic3D newConic(Construction cons1) {
		return new GeoConic3D(cons1, true);
	}

	/**
	 * return the intersection
	 *
	 * @return the intersection
	 */
	public GeoConic3D getConic() {
		return conic;
	}

	// /////////////////////////////////////////////
	// COMPUTE

	@Override
	public void compute() {
		conic.setCoordSys(plane.getCoordSys());
		if (!quadric.isDefined() || !plane.isDefined()) {
			conic.setUndefined();
			return;
		}
		intersectPlaneQuadric(plane, quadric, conic);
	}

	private void intersectPlaneQuadric(
			GeoCoordSys2D inputPlane, GeoQuadricND inputQuad, GeoConic3D outputConic) {
		if (parametricMatrix == null) {
			parametricMatrix = new CoordMatrix(4, 3);
		}
		CoordMatrix qm = inputQuad.getSymmetricMatrix();
		CoordMatrix pm = inputPlane.getCoordSys().getParametricMatrix(parametricMatrix);

		// sets the conic matrix from plane and quadric matrix
		cm.setMul(tmpMatrix.setMulT1(pm, qm), pm);

		outputConic.setCoordSys(inputPlane.getCoordSys());
		outputConic.setMatrix(cm);
	}

	@Override
	public Commands getClassName() {
		return Commands.IntersectPath;
	}

	@Override
	public final String toString(StringTemplate tpl) {
		StringBuilder sb = new StringBuilder();

		sb.append(
				getLoc().getPlain("IntersectionCurveOfAB", plane.getLabel(tpl), quadric.getLabel(tpl)));

		return sb.toString();
	}
}
