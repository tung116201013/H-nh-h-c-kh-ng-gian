# Mã nguồn GeoGebra - phần hình học không gian (đã lọc)

Nguồn: github.com/geogebra/geogebra (nhánh main). Giấy phép mã nguồn: EUPL v1.2.
Khi viết lại thuật toán cho web, chỉ lấy Ý TƯỞNG, viết lại bằng JavaScript, ghi chú nguồn GeoGebra.
Đây là mã Java, KHÔNG chạy trực tiếp trên web.

Đường dẫn gốc trong repo: source/shared/common/src/main/java/org/geogebra/common/

## Nên đọc theo thứ tự này
1. kernel/matrix/Coords.java, CoordSys.java, CoordMatrix*.java  -> toán vector, hệ tọa độ, mặt phẳng
2. geogebra3D/kernel3D/geos/: GeoPoint3D, GeoLine3D, GeoSegment3D, GeoPlane3D, GeoPolygon3D, GeoPolyhedron
3. geogebra3D/kernel3D/algos/ - THUẬT TOÁN:
   - Dựng hình: AlgoPolyhedronPointsPyramid, AlgoPolyhedronPointsPrism, AlgoPolyhedronPoints, AlgoPolyhedronConvex
   - Mặt phẳng: AlgoPlaneThreePoints, AlgoPlaneThroughPoint*, AlgoOrthoPlane*
   - Giao tuyến, thiết diện: AlgoIntersectPlanes, AlgoIntersectCoordSys, AlgoIntersectPlanePolygon, AlgoIntersectPlanePolyhedron, AlgoIntersectLinePolygon3D
   - Khoảng cách: AlgoDistancePointPlane3D, AlgoDistanceLines3D, AlgoDistancePlanes
   - Góc: AlgoAngleLines3D, AlgoAngleLinePlane, AlgoAnglePlanes
   - Đường vuông góc: AlgoOrthoLine*
4. geogebra3D/kernel3D/solid/: khối đa diện đều (PlatonicSolid*)
5. geogebra3D/euclidian3D/: DrawPolyhedron3D, DrawSegment3D, Drawable3D... -> cách VẼ, nét đứt/nét liền

## Không có trong gói này
Phần giao diện web (GWT) và toàn bộ nhân tính toán (kernel) khác. Cần thì lấy lại từ
geogebra-source-phan-1.zip và geogebra-source-phan-2.zip.
