/*
 * GeoGebra - Dynamic Mathematics for Everyone
 * Copyright (c) GeoGebra GmbH, Altenbergerstr. 69, 4040 Linz, Austria
 * https://www.geogebra.org
 *
 * This file is licensed by GeoGebra GmbH under the EUPL 1.2 licence and
 * may be used under the EUPL 1.2 in compatible projects (see Article 5
 * and the Appendix of EUPL 1.2 for details).
 * You may obtain a copy of the licence at:
 * https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Note: The overall GeoGebra software package is free to use for
 * non-commercial purposes only.
 * See https://www.geogebra.org/license for full licensing details
 */

package org.geogebra.desktop.geogebra3D.euclidian3D;

import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.swing.Box;
import javax.swing.JPanel;
import javax.swing.border.Border;

import org.geogebra.common.awt.GBufferedImage;
import org.geogebra.common.awt.GColor;
import org.geogebra.common.awt.GDimension;
import org.geogebra.common.awt.GFont;
import org.geogebra.common.awt.GGraphics2D;
import org.geogebra.common.awt.GPointWithZ;
import org.geogebra.common.euclidian.EuclidianStyleBar;
import org.geogebra.common.euclidian3D.Mouse3DEvent;
import org.geogebra.common.geogebra3D.euclidian3D.EuclidianController3D;
import org.geogebra.common.geogebra3D.euclidian3D.EuclidianView3D;
import org.geogebra.common.geogebra3D.euclidian3D.openGL.Renderer;
import org.geogebra.common.main.App.ExportType;
import org.geogebra.common.main.settings.EuclidianSettings;
import org.geogebra.common.plugin.EuclidianStyleConstants;
import org.geogebra.common.util.debug.Log;
import org.geogebra.desktop.awt.GBufferedImageD;
import org.geogebra.desktop.awt.GColorD;
import org.geogebra.desktop.awt.GDimensionD;
import org.geogebra.desktop.awt.GFontD;
import org.geogebra.desktop.awt.GGraphics2DD;
import org.geogebra.desktop.euclidian.CoordSystemAnimationD;
import org.geogebra.desktop.euclidian.EuclidianControllerListeners;
import org.geogebra.desktop.euclidian.EuclidianViewJPanelD;
import org.geogebra.desktop.euclidianND.EuclidianViewInterfaceD;
import org.geogebra.desktop.export.GraphicExportDialog;
import org.geogebra.desktop.geogebra3D.App3D;
import org.geogebra.desktop.geogebra3D.euclidian3D.opengl.RendererCheckGLVersionD;
import org.geogebra.desktop.geogebra3D.euclidianInput3D.Mouse3DEventD;
import org.geogebra.desktop.io.MyImageIO;
import org.geogebra.desktop.main.AppD;

/**
 * 3D view for desktop
 *
 * @author mathieu
 *
 */
public class EuclidianView3DD extends EuclidianView3D implements EuclidianViewInterfaceD {

	/** Java component for this view */
	protected EuclidianViewJPanelD evjpanel;

	private Component canvas;
	private boolean exportToClipboard;
	private File exportFile;
	private int exportDPI;

	// temp image
	private final Graphics2D g2Dtemp =
			new BufferedImage(5, 5, BufferedImage.TYPE_INT_RGB).createGraphics();

	/**
	 * constructor
	 *
	 * @param ec
	 *            controller
	 * @param settings
	 *            settings
	 */
	public EuclidianView3DD(EuclidianController3D ec, EuclidianSettings settings) {

		super(ec, settings);

		initView(false);

		EuclidianSettings es;
		if (settings != null) {
			es = settings;
		} else {
			es = getApplication().getSettings().getEuclidian(3);
		}

		if (es != null) {
			settingsChanged(es);
			es.addListener(this);
		}
	}

	@Override
	protected void createPanel() {
		evjpanel = new EuclidianViewJPanelD(this);

		canvas = (Component) renderer.getCanvas();
		getJPanel().setLayout(new BorderLayout());
		getJPanel().add(BorderLayout.CENTER, canvas);

		// register Listener
		((EuclidianControllerListeners) getEuclidianController()).addListenersTo(canvas);
		canvas.setFocusable(true);
	}

	@Override
	protected Renderer createRenderer() {

		// set stereo on/off
		getCompanion().setIsStereoBuffered(((App3D) app).isStereo3D());

		return new RendererCheckGLVersionD(this, canUseCanvas());
	}

	private boolean canUseCanvas() {
		// TODO remove that (quick fix for jogl 2.3.2)
		if (AppD.MAC_OS) {
			Log.debug("XXXXXXXXXXXXXXX mac osx");
			return false;
		}

		return true;
	}

	@Override
	public void setBackground(GColor updatedColor, GColor appliedColor) {
		super.setBackground(updatedColor, appliedColor);
		evjpanel.setBackground(GColorD.getAwtColor(bgAppliedColor));
	}

	@Override
	public void setTransparentCursor() {

		setCursor(((AppD) app).getTransparentCursor());
	}

	// ////////////////////////////
	// EVJPANEL
	// ////////////////////////////

	/**
	 * @param cursor
	 *            new cursor
	 */
	@Override
	public void setCursor(Cursor cursor) {
		evjpanel.setCursor(cursor);
	}

	@Override
	public boolean hasFocus() {
		return evjpanel.hasFocus();
	}

	@Override
	public void repaint() {
		this.updateBackgroundIfNecessary();
		evjpanel.repaint();
	}

	@Override
	public void add(Box box) {
		evjpanel.add(box);
	}

	/**
	 * @return underlying component
	 */
	@Override
	public JPanel getJPanel() {
		return evjpanel;
	}

	/**
	 * This view should be focused
	 */
	@Override
	public void requestFocus() {
		evjpanel.requestFocus();
	}

	@Override
	public GFont getFont() {
		return new GFontD(evjpanel.getFont());
	}

	/**
	 * @return mouse position
	 */
	@Override
	public java.awt.Point getMousePosition() {
		return evjpanel.getMousePosition();
	}

	/**
	 * @see JPanel#getFontMetrics(Font)
	 * @param font
	 *            font
	 * @return font metrics
	 */
	public FontMetrics getFontMetrics(Font font) {
		return evjpanel.getFontMetrics(font);
	}

	/**
	 * @return whether this view is visible
	 */
	@Override
	public boolean isShowing() {
		return evjpanel.isShowing();
	}

	@Override
	public boolean requestFocusInWindow() {
		return evjpanel.requestFocusInWindow();
	}

	/**
	 * @see JPanel#setPreferredSize(Dimension)
	 * @param preferredSize
	 *            preferred size
	 */
	public void setPreferredSize(Dimension preferredSize) {
		evjpanel.setPreferredSize(preferredSize);
	}

	@Override
	public void setPreferredSize(GDimension preferredSize) {
		evjpanel.setPreferredSize(GDimensionD.getAWTDimension(preferredSize));
	}

	/**
	 * @see JPanel#revalidate()
	 */
	public void revalidate() {
		evjpanel.revalidate();
	}

	/**
	 * @see JPanel#addMouseListener(MouseListener)
	 * @param ml
	 *            mouse listener
	 */
	public void addMouseListener(MouseListener ml) {
		canvas.addMouseListener(ml);
	}

	/**
	 * @see JPanel#removeComponentListener(ComponentListener)
	 * @param ml
	 *            mouse listener
	 */
	public void removeMouseListener(MouseListener ml) {
		canvas.removeMouseListener(ml);
	}

	/**
	 * @see JPanel#addMouseMotionListener(MouseMotionListener)
	 * @param mml
	 *            mouse motion listener
	 */
	public void addMouseMotionListener(MouseMotionListener mml) {
		canvas.addMouseMotionListener(mml);
	}

	/**
	 * @see JPanel#removeMouseMotionListener(MouseMotionListener)
	 * @param mml
	 *            mouse motion listener
	 */
	public void removeMouseMotionListener(MouseMotionListener mml) {
		canvas.removeMouseMotionListener(mml);
	}

	/**
	 * @see JPanel#addMouseWheelListener(MouseWheelListener)
	 * @param mwl
	 *            mouse wheel listener
	 */
	public void addMouseWheelListener(MouseWheelListener mwl) {
		canvas.addMouseWheelListener(mwl);
	}

	/**
	 * @see JPanel#removeMouseWheelListener(MouseWheelListener)
	 * @param mwl
	 *            mouse wheel listener
	 */
	public void removeMouseWheelListener(MouseWheelListener mwl) {
		canvas.removeMouseWheelListener(mwl);
	}

	/**
	 * @see JPanel#dispatchEvent(AWTEvent)
	 * @param componentEvent
	 *            component event
	 */
	public void dispatchEvent(ComponentEvent componentEvent) {
		evjpanel.dispatchEvent(componentEvent);
	}

	/**
	 * @see JPanel#setBorder(Border)
	 * @param border
	 *            new border
	 */
	@Override
	public void setBorder(Border border) {
		evjpanel.setBorder(border);
	}

	/**
	 * @see JPanel#addComponentListener(ComponentListener)
	 * @param componentListener
	 *            component listener
	 */
	public void addComponentListener(ComponentListener componentListener) {
		canvas.addComponentListener(componentListener);
	}

	/**
	 * @param dimension
	 *            new size
	 */
	public void setSize(Dimension dimension) {
		evjpanel.setSize(dimension);
	}

	/**
	 * @return preferred size
	 */
	public Dimension getPreferredSize() {
		return evjpanel.getPreferredSize();
	}

	/**
	 * Initializes this panel
	 *
	 * @param repaint
	 *            ignored parameter
	 */
	protected void initPanel(boolean repaint) {
		// preferred size
		evjpanel.setPreferredSize(null);
	}

	// @Override
	@Override
	public void setToolTipText(String plainText) {
		if ((tooltipsInThisView == EuclidianStyleConstants.TOOLTIPS_ON)
				|| (tooltipsInThisView == EuclidianStyleConstants.TOOLTIPS_AUTOMATIC)) {
			evjpanel.setToolTipText(plainText);
		}
	}

	@Override
	public int getWidth() {
		return evjpanel.getWidth();
	}

	@Override
	public int getHeight() {
		return evjpanel.getHeight();
	}

	@Override
	protected void updateSizeKeepDrawables() {
		// not needed for 3D
	}

	@Override
	public final GGraphics2D getTempGraphics2D(GFont font) {
		g2Dtemp.setFont(GFontD.getAwtFont(font));

		return new GGraphics2DD(g2Dtemp);
	}

	@Override
	protected final void setStyleBarMode(int mode) {
		if (hasStyleBar()) {
			getStyleBar().setMode(mode);
		}
	}

	@Override
	protected CoordSystemAnimationD newZoomer() {
		return new CoordSystemAnimationD(this);
	}

	@Override
	protected boolean getShiftDown() {
		return ((AppD) app).getShiftDown();
	}

	@Override
	protected void setDefault2DCursor() {
		setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}

	@Override
	public App3D getApplication() {
		return (App3D) this.app;
	}

	@Override
	public GBufferedImage getExportImage(double scale) {
		return getExportImage(scale, false, ExportType.PNG);
	}

	@Override
	public GBufferedImage getExportImage(double scale, boolean transparency, ExportType exportType)
			throws OutOfMemoryError {
		getRenderer().needExportImage(scale, true);

		return getRenderer().getExportImage();
	}

	@Override
	public void exportImagePNG(
			double scale,
			boolean transparency,
			int dpi,
			File file,
			boolean exportToClipboard0,
			ExportType exportType) {

		exportDPI = dpi;
		exportFile = file;
		this.exportToClipboard = exportToClipboard0;

		getRenderer().needExportImage(scale, false);
	}

	/**
	 * write current renderer's image to current export file
	 */
	public void writeExportImage() {

		if (exportFile == null) {
			Log.debug("exportFile not set");
			return;
		}

		try {
			BufferedImage img = GBufferedImageD.getAwtBufferedImage(getRenderer().getExportImage());
			MyImageIO.write(img, "png", exportDPI, exportFile);
			if (exportToClipboard) {
				GraphicExportDialog.sendToClipboard(exportFile);
			}
		} catch (IOException e) {
			Log.debug(e);
		}
	}

	@Override
	protected EuclidianStyleBar newEuclidianStyleBar() {
		return new EuclidianStyleBar3D(this);
	}

	@Override
	public boolean suggestRepaint() {
		return false;
		// only for web
	}

	@Override
	public void exportPaintPre(GGraphics2D g2d, double scale, boolean transparency) {
		Log.error("exportPaintPre unimplemented");
	}

	@Override
	public void repaintView() {
		// done by FPS animator
	}

	@Override
	protected void drawBackgroundImage(GGraphics2D g2d) {
		// nothing to do here
	}

	@Override
	public Mouse3DEvent createMouse3DEvent(GPointWithZ mouse3DLoc) {
		return new Mouse3DEventD(mouse3DLoc, getJPanel());
	}

	@Override
	protected EuclidianStyleBar newDynamicStyleBar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void addDynamicStylebarToEV(EuclidianStyleBar dynamicStylebar) {
		// TODO Auto-generated method stub

	}
}
