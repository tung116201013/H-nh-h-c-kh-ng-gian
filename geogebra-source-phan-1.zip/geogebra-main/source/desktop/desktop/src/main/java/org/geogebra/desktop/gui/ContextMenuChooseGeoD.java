/*
 * GeoGebra - Dynamic Mathematics for Everyone
 * Copyright (c) GeoGebra GmbH, Altenbergerstr. 69, 4040 Linz, Austria
 * https://www.geogebra.org
 *
 * This file is licensed by GeoGebra GmbH under the EUPL 1.2 licence and
 * may be used under the EUPL 1.2 in compatible projects (see Article 5
 * and the Appendix of EUPL 1.2 for details).
 * You may obtain a copy of the licence at:
 * https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Note: The overall GeoGebra software package is free to use for
 * non-commercial purposes only.
 * See https://www.geogebra.org/license for full licensing details
 */

package org.geogebra.desktop.gui;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.TreeSet;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import org.geogebra.common.awt.GPoint;
import org.geogebra.common.euclidian.EuclidianConstants;
import org.geogebra.common.euclidian.EuclidianView;
import org.geogebra.common.euclidian.Hits;
import org.geogebra.common.kernel.geos.FromMeta;
import org.geogebra.common.kernel.geos.GeoElement;
import org.geogebra.common.main.Localization;
import org.geogebra.desktop.main.AppD;

/**
 * Popup Menu for choosing a geo
 *
 * @author mathieu
 *
 */
public class ContextMenuChooseGeoD extends ContextMenuGeoElementD {

	/**
	 *
	 */
	protected EuclidianView view;

	/**
	 * polygons/polyhedra parents of segments, polygons, ...
	 */
	private TreeSet<GeoElement> metas;

	private final ArrayList<GeoElement> selectedGeos;
	private GPoint loc;

	private JMenu selectAnotherMenu;
	private boolean geoAddedForSelectAnother = false;

	/**
	 *
	 * @param app
	 *            application
	 * @param view
	 *            view
	 * @param selectedGeos
	 *            selected geos
	 * @param geos
	 *            geos
	 * @param location
	 *            place to show
	 */
	public ContextMenuChooseGeoD(
			AppD app,
			EuclidianView view,
			ArrayList<GeoElement> selectedGeos,
			ArrayList<GeoElement> geos,
			Point location,
			GPoint invokerLocation) {

		super(app, selectedGeos, location);

		this.view = view;
		this.selectedGeos = selectedGeos;

		// return if just one geo, or if first geos more than one
		if (
		/* geos.size()<2 || */ selectedGeos.size() > 1) {
			justOneGeo = false;
			return;
		}

		justOneGeo = true;

		// section to choose a geo
		// addSeparator();
		createSelectAnotherMenu(view.getMode());

		this.loc = invokerLocation;
		this.setGeos(geos);

		GeoElement geoSelected = selectedGeos.get(0);

		// add geos
		geoAddedForSelectAnother = false;

		metas = new TreeSet<>();

		for (GeoElement geo : geos) {
			if (geo != geoSelected && !metas.contains(geo)) { // don't add selected geo
				addGeo(geo);
			}

			if (geo.getMetasLength() > 0) {
				for (GeoElement meta : ((FromMeta) geo).getMetas()) {
					if (!metas.contains(meta)) {
						addGeo(meta);
					}
				}
			}
		}

		if (geoAddedForSelectAnother) {
			addSelectAnotherMenu();
		}

		// TODO: clear selection is not working from here
		this.getWrappedPopup().getSelectionModel().clearSelection();
	}

	private void createSelectAnotherMenu(int mode) {
		Localization localization = app.getLocalization();
		if (EuclidianConstants.isMoveOrSelectionMode(mode)) {
			selectAnotherMenu = new JMenu(localization.getMenu("SelectAnother"));
		} else {
			selectAnotherMenu = new JMenu(localization.getMenu("PerformToolOn"));
		}
		selectAnotherMenu.setIcon(((AppD) app).getEmptyIcon());
		selectAnotherMenu.setBackground(getWrappedPopup().getBackground());
		selectAnotherMenu.setFont(((AppD) app).getItalicFont());
	}

	private void addSelectAnotherMenu() {

		// add the selection menu just under the title
		getWrappedPopup().add(selectAnotherMenu, 1);
	}

	/**
	 *
	 */
	private void addGeo(GeoElement geo) {

		// prevent selection of xOy plane
		if (geo == app.getKernel().getXOYPlane()) {
			return;
		}

		geoAddedForSelectAnother = true;

		GeoAction chooser = new GeoAction(geo);
		JMenuItem mi = selectAnotherMenu.add(chooser);
		mi.setBackground(bgColor);
		mi.setText(getDescription(geo, true));
		mi.addMouseListener(new HighlightingMouseAdapter(geo));

		// prevent to add meta twice
		metas.add(geo);
	}

	/**
	 * Action when select a geo
	 *
	 * @author mathieu
	 *
	 */
	private final class GeoAction extends AbstractAction {

		/**
		 *
		 */
		private static final long serialVersionUID = 1L;

		private GeoElement geo;

		/**
		 * Create chooser for this geo
		 *
		 * @param geo
		 *            geo to choose
		 */
		private GeoAction(GeoElement geo) {
			super();
			this.geo = geo;
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			geoActionCmd(this.geo, selectedGeos, getGeos(), view, loc);
		}
	}

	private final class HighlightingMouseAdapter extends MouseAdapter {

		private final GeoElement geo;

		private HighlightingMouseAdapter(GeoElement geo) {
			this.geo = geo;
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			view.getEuclidianController().doSingleHighlighting(geo);
		}

		/*
		 * @Override public void mouseExited(MouseEvent e) {
		 * geo.setHighlighted(false); app.getKernel().notifyRepaint();
		 *
		 * }
		 */
	}

	@Override
	protected void setTitle(String str) {

		AbstractAction titleAction = new AbstractAction() {
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {

				if (selectedGeos.size() < 2) {
					if (EuclidianConstants.isMoveOrSelectionMode(view.getMode())) { // change
						// selection
						// to
						// geo
						// clicked

						app.getSelectionManager().clearSelectedGeos(false); // repaint
						// done
						// next
						// step
						app.getSelectionManager().addSelectedGeo(getGeo());

					} else { // use geo clicked to process mode
						Hits hits = new Hits();
						hits.add(getGeo());
						view.getEuclidianController().processMode(hits, false, false);
					}
				}
			}
		};

		JMenuItem title = wrappedPopup.add(titleAction);
		title.setText(str);
		title.setFont(((AppD) app).getBoldFont());
		title.setBackground(bgColor);
		title.setForeground(fgColor);

		title.setIcon(((AppD) app).getEmptyIcon());
		title.setBorder(BorderFactory.createEmptyBorder(5, 0, 2, 15));
	}
}
