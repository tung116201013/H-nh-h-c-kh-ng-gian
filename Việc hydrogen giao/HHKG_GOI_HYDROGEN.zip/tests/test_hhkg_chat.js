// Chạy:  node tests/test_hhkg_chat.js        (không cần trình duyệt; dùng vm + stub của index.html)
const vm = require('vm'), fs = require('fs'), path = require('path'), assert = require('assert');
const root = path.join(__dirname, '..');
const geo = fs.readFileSync(path.join(root, 'prompt/geo_system.txt'), 'utf8').trim();
const fmt = fs.readFileSync(path.join(root, 'prompt/fmt.txt'), 'utf8').trim();
const src = fs.readFileSync(path.join(root, 'src/hhkg-chat.module.js'), 'utf8')
  .replace('__GEO_SYSTEM__', JSON.stringify(geo)).replace('__FMT__', JSON.stringify(fmt));
let queue = []; const sent = [];
const doc = { getElementById: () => null, createElement: () => ({}), head: { appendChild() {} }, addEventListener() {} };
const win = { document: doc, location: { search: '', pathname: '/', hash: '' }, history: { replaceState() {} } }; win.window = win;
const ctx = vm.createContext(Object.assign(win, { console, setTimeout, setInterval, clearInterval, Promise,
  GCHAT: {}, GCUR: '', GPICK: 'm', GGOOD: '', GEMINI_MODELS: ['g'], GBUSY: 0, aiSheet() {}, gProbeAll() {}, xkProbeAll() {}, gRender() {}, toast() {},
  AG: { sys: () => 'BASE' },
  gSend(t) { const c = ctx.GCHAT.hhkg; sent.push(t); c.msgs.push({ r: 'user', t }); c.busy = 1; setTimeout(() => { c.msgs.push({ r: 'model', t: queue.shift() }); c.busy = 0; }, 150); } }));
vm.runInContext(src, ctx);
const X = ctx.HHKGCHAT, mk = o => 'Lời giải\n```hhkg\n' + JSON.stringify(o) + '\n```';
const clone = o => JSON.parse(JSON.stringify(o));
// Ví dụ mẫu nằm trong luật phải qua kiểm tra
const good = JSON.parse(/```hhkg\n(\{"title":"Chóp[\s\S]*?)\n```/.exec(fmt)[1]);
(async () => {
  assert.strictEqual(JSON.stringify(X.validate(good)), '{"hard":[],"soft":[]}');
  // Các lỗi phải bị bắt
  const bad = clone(good); bad.scene.vertices[2].z = 0.5; bad.scene.vertices[4].x = -0.2;
  bad.scene.edges.push({ from: 'S', to: 'Z' }); bad.scene.vertices[1].x = '2*sqrt(3)';
  const v = X.validate(bad);
  assert(v.hard.some(s => /không phải số/.test(s)) && v.hard.some(s => /"Z"/.test(s)));
  assert(v.soft.some(s => /không đồng phẳng/.test(s)) && v.soft.some(s => /cos =/.test(s)));
  // JSON bị cắt giữa chừng vẫn đọc được
  const full = JSON.stringify(good); assert(X.loose(full.slice(0, full.length - 80)));
  // Ẩn khối hhkg khi hiển thị
  assert.strictEqual(X.hide('a\n```hhkg\n{"x":1}\n```\nb'), 'a\n\nb');
  // Prompt hệ thống chỉ gắn vào chat hình học
  assert(ctx.AG.sys({ title: '📐 x' }).length > 3000); assert.strictEqual(ctx.AG.sys({ title: 'free' }), 'BASE');
  // Giải bài: 1 lượt đúng
  queue = [mk(good)]; let d = await ctx.__hhkgAsk({ mode: 'solve', problemText: 'đề' }); assert.strictEqual(d.title, good.title);
  // Lần đầu sai nhẹ -> tự nhắn sửa 1 lần -> đúng
  sent.length = 0; const wrong = clone(good); wrong.scene.vertices[2].z = 0.5;
  queue = [mk(wrong), mk(good)]; d = await ctx.__hhkgAsk({ mode: 'solve', problemText: 'đề' });
  assert.strictEqual(sent.length, 2); assert(/^🔧/.test(sent[1]));
  // Vẫn sai nhẹ sau khi sửa -> dựng kèm cảnh báo; sai nặng -> báo lỗi
  queue = [mk(wrong), mk(wrong)]; d = await ctx.__hhkgAsk({ mode: 'solve', problemText: 'đề' }); assert(/^⚠/.test(d.verificationNote));
  const hard = clone(good); hard.scene.edges.push({ from: 'S', to: 'Z' }); queue = [mk(hard), mk(hard)];
  await assert.rejects(ctx.__hhkgAsk({ mode: 'solve', problemText: 'đề' }), /vẫn trả hình lỗi/);
  // Hỏi thêm: trả answer + updatedScene
  queue = ['Trung điểm M.\n```hhkg\n{"answer":"ok","updatedScene":{"addVertices":[{"id":"M","x":1,"y":1,"z":1}]}}\n```'];
  d = await ctx.__hhkgAsk({ mode: 'followup', question: 'vẽ M', currentScene: good.scene }); assert.strictEqual(d.updatedScene.addVertices[0].id, 'M');
  // Thiếu đề -> 400
  await assert.rejects(ctx.__hhkgAsk({ mode: 'solve', problemText: '' }), e => e.status === 400);
  console.log('TẤT CẢ TEST ĐẠT');
})().catch(e => { console.error('TEST LỖI:', e.message); process.exit(1); });
