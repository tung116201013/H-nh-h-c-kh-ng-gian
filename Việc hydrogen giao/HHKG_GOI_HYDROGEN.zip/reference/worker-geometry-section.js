// THAM CHIEU, KHONG DUNG: phan hinh hoc cua api-worker_1.js (dong 305-722) - schema JSON, GEO_SYSTEM, geometrySolve. Ban chay that da bo Worker nay.
const GEO_SOLVE_SCHEMA = {
  type: 'OBJECT',
  properties: {
    title: { type: 'STRING', description: 'Tên ngắn gọn của bài toán (tiếng Việt).' },
    grade: { type: 'STRING', description: 'Lớp 11 hoặc Lớp 12 (theo chương trình GDPT 2018).' },
    topic: { type: 'STRING', description: 'Chuyên đề chính: Quan hệ vuông góc, Góc, Khoảng cách, Thể tích, Thiết diện, hoặc Tọa độ Oxyz.' },
    method: { type: 'STRING', description: 'Phương pháp giải chủ đạo: Hình học tổng hợp, Tọa độ hóa Oxyz, hoặc Kết hợp song song & thiết diện.' },
    keyFormula: { type: 'STRING', description: 'Công thức cốt lõi / định lí chìa khóa của bài (viết gọn, dễ nhớ).' },
    summary: { type: 'STRING', description: 'Tóm tắt ngắn gọn giả thiết và mục tiêu bài toán (1-2 câu).' },
    finalAnswer: { type: 'STRING', description: 'Đáp số cuối cùng chính xác, viết rõ ràng (ví dụ: a√6 / 3 hoặc 60°).' },
    visualTips: { type: 'STRING', description: 'Mẹo quan sát hình 3D trực quan để học sinh dễ hiểu.' },
    verificationNote: { type: 'STRING', description: 'Tự kiểm tra ngắn gọn các điều kiện vuông góc, song song, tỉ số trên tọa độ đã dựng.' },
    suggestedFollowups: {
      type: 'ARRAY',
      description: '2-3 gợi ý câu hỏi nối tiếp để học sinh khám phá thêm trên hình 3D.',
      items: { type: 'STRING' },
    },
    constructions: {
      type: 'ARRAY',
      description: 'Danh sách lệnh dựng hình GeoGebra 3D chuẩn chạy tuần tự sau các đỉnh gốc trong scene.vertices để khóa tọa độ chính xác tuyệt đối (ví dụ: M = Midpoint(S, C), H = PerpendicularPoint(A, S, B, D), ParallelLine(S, A, B), I = Intersect(B, F, A, C, D), E = CrossSectionParallel(M, A, B, C, D)).',
      items: {
        type: 'OBJECT',
        properties: {
          command: { type: 'STRING', description: 'Lệnh GeoGebra 3D hợp lệ.' },
          note: { type: 'STRING', description: 'Mục đích phép dựng trong lời giải.' },
        },
        required: ['command'],
      },
    },
    scene: {
      type: 'OBJECT',
      description: 'Mô tả hình học không gian 3D theo hệ tọa độ Toán học (x hướng ra trước, y hướng sang phải, z hướng lên trên). Đặt đơn vị chuẩn a = 2 hoặc a = 3 để hình cân đối quanh gốc tọa độ.',
      properties: {
        showOxyz: { type: 'BOOLEAN', description: 'Bật hệ trục tọa độ Oxyz khi bài toán thuộc Lớp 12 hoặc dùng phương pháp tọa độ hóa.' },
        unitNote: { type: 'STRING', description: 'Ghi chú tỉ lệ quy ước khi dựng hình 3D (ví dụ: Quy ước a = 2 đơn vị).' },
        vertices: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              id: { type: 'STRING', description: 'Tên đỉnh ngắn gọn, viết hoa như S, A, B, C, D, A\', M, H, O, I.' },
              x: { type: 'NUMBER' },
              y: { type: 'NUMBER' },
              z: { type: 'NUMBER' },
              role: { type: 'STRING', description: 'primary | aux | projection | center' },
            },
            required: ['id', 'x', 'y', 'z'],
          },
        },
        edges: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              from: { type: 'STRING' },
              to: { type: 'STRING' },
              style: { type: 'STRING', description: 'solid | dashed | highlight | altitude' },
              label: { type: 'STRING', description: 'Độ dài hoặc ký hiệu cạnh nếu cần (ví dụ a, a√2), có thể để trống.' },
            },
            required: ['from', 'to', 'style'],
          },
        },
        faces: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              vertices: { type: 'ARRAY', items: { type: 'STRING' } },
              color: { type: 'STRING', description: 'Mã màu hex nhạt, ví dụ #3B82F6, #10B981, #F59E0B.' },
              opacity: { type: 'NUMBER', description: 'Từ 0.12 đến 0.45.' },
              label: { type: 'STRING' },
              internal: { type: 'BOOLEAN', description: 'Đặt true nếu là mặt cắt chéo / mặt phẳng phụ bên trong khối đa diện (không phải mặt ngoài).' },
            },
            required: ['vertices'],
          },
        },
        rightAngles: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              vertex: { type: 'STRING', description: 'Đỉnh góc vuông.' },
              p1: { type: 'STRING', description: 'Điểm thứ nhất tạo tia vuông góc.' },
              p2: { type: 'STRING', description: 'Điểm thứ hai tạo tia vuông góc.' },
            },
            required: ['vertex', 'p1', 'p2'],
          },
        },
        angles: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              vertex: { type: 'STRING' },
              p1: { type: 'STRING' },
              p2: { type: 'STRING' },
              label: { type: 'STRING', description: 'Ví dụ: α = 60° hoặc φ.' },
            },
            required: ['vertex', 'p1', 'p2'],
          },
        },
        vectors: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              from: { type: 'STRING' },
              to: { type: 'STRING' },
              label: { type: 'STRING' },
              color: { type: 'STRING' },
            },
            required: ['from', 'to'],
          },
        },
        planes: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              label: { type: 'STRING' },
              nx: { type: 'NUMBER' },
              ny: { type: 'NUMBER' },
              nz: { type: 'NUMBER' },
              d: { type: 'NUMBER' },
              color: { type: 'STRING' },
            },
            required: ['nx', 'ny', 'nz', 'd'],
          },
        },
        spheres: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              center: { type: 'STRING', description: 'ID đỉnh làm tâm hoặc để trống nếu dùng tọa độ.' },
              cx: { type: 'NUMBER' },
              cy: { type: 'NUMBER' },
              cz: { type: 'NUMBER' },
              radius: { type: 'NUMBER' },
              label: { type: 'STRING' },
            },
            required: ['radius'],
          },
        },
        cones: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              apex: { type: 'STRING' },
              baseCenter: { type: 'STRING' },
              radius: { type: 'NUMBER' },
            },
            required: ['apex', 'baseCenter', 'radius'],
          },
        },
        cylinders: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              topCenter: { type: 'STRING' },
              bottomCenter: { type: 'STRING' },
              radius: { type: 'NUMBER' },
            },
            required: ['topCenter', 'bottomCenter', 'radius'],
          },
        },
        circles: {
          type: 'ARRAY',
          description: 'Các đường tròn giao tuyến 3D (ví dụ giao mặt cầu và mặt phẳng hoặc hai mặt cầu).',
          items: {
            type: 'OBJECT',
            properties: {
              center: {
                type: 'OBJECT',
                properties: {
                  x: { type: 'NUMBER' },
                  y: { type: 'NUMBER' },
                  z: { type: 'NUMBER' },
                },
                required: ['x', 'y', 'z'],
              },
              normal: {
                type: 'OBJECT',
                properties: {
                  x: { type: 'NUMBER' },
                  y: { type: 'NUMBER' },
                  z: { type: 'NUMBER' },
                },
                required: ['x', 'y', 'z'],
              },
              radius: { type: 'NUMBER' },
              color: { type: 'STRING' },
              label: { type: 'STRING' },
            },
            required: ['center', 'normal', 'radius'],
          },
        },
        crossSection: {
          type: 'ARRAY',
          items: { type: 'STRING' },
          description: 'Danh sách ID các đỉnh theo đúng thứ tự vòng tạo thành thiết diện nếu bài toán có thiết diện.',
        },
      },
      required: ['vertices', 'edges', 'faces'],
    },
    steps: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          stepTitle: { type: 'STRING' },
          explanation: { type: 'STRING', description: 'Giải thích rõ ràng, chặt chẽ theo chuẩn Toán 11/12 GDPT 2018.' },
          formula: { type: 'STRING', description: 'Biểu thức tính toán chính ở bước này (viết gọn dễ đọc).' },
          highlightVertices: { type: 'ARRAY', items: { type: 'STRING' } },
          highlightEdges: {
            type: 'ARRAY',
            items: {
              type: 'OBJECT',
              properties: {
                from: { type: 'STRING' },
                to: { type: 'STRING' },
              },
              required: ['from', 'to'],
            },
          },
          highlightFaceVertices: { type: 'ARRAY', items: { type: 'STRING' } },
        },
        required: ['stepTitle', 'explanation'],
      },
    },
  },
  required: ['title', 'grade', 'topic', 'summary', 'finalAnswer', 'scene', 'steps'],
};

const GEO_FOLLOWUP_SCHEMA = {
  type: 'OBJECT',
  properties: {
    answer: { type: 'STRING', description: 'Câu trả lời sư phạm chính xác, trực quan bằng tiếng Việt.' },
    highlightVertices: { type: 'ARRAY', items: { type: 'STRING' } },
    highlightEdges: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          from: { type: 'STRING' },
          to: { type: 'STRING' },
        },
        required: ['from', 'to'],
      },
    },
    updatedScene: {
      type: 'OBJECT',
      description: 'Chỉ điền nếu người dùng yêu cầu vẽ thêm điểm/đoạn thẳng/mặt phẳng/thiết diện hoặc sửa hình.',
      properties: {
        addConstructions: {
          type: 'ARRAY',
          items: { type: 'STRING' },
          description: 'Lệnh GeoGebra 3D thực thi thêm vào hình hiện tại (ví dụ: M = Midpoint(S, C), ParallelLine(S, A, B), CrossSection(A, M, N)).',
        },
        addVertices: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              id: { type: 'STRING' },
              x: { type: 'NUMBER' },
              y: { type: 'NUMBER' },
              z: { type: 'NUMBER' },
              role: { type: 'STRING' },
            },
            required: ['id', 'x', 'y', 'z'],
          },
        },
        addEdges: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              from: { type: 'STRING' },
              to: { type: 'STRING' },
              style: { type: 'STRING' },
              label: { type: 'STRING' },
            },
            required: ['from', 'to', 'style'],
          },
        },
        addFaces: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              vertices: { type: 'ARRAY', items: { type: 'STRING' } },
              color: { type: 'STRING' },
              opacity: { type: 'NUMBER' },
              internal: { type: 'BOOLEAN' },
            },
            required: ['vertices'],
          },
        },
        addRightAngles: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              vertex: { type: 'STRING' },
              p1: { type: 'STRING' },
              p2: { type: 'STRING' },
            },
            required: ['vertex', 'p1', 'p2'],
          },
        },
        updateVertices: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              id: { type: 'STRING' },
              x: { type: 'NUMBER' },
              y: { type: 'NUMBER' },
              z: { type: 'NUMBER' },
              role: { type: 'STRING' },
            },
            required: ['id', 'x', 'y', 'z'],
          },
        },
        updateEdges: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: {
              from: { type: 'STRING' },
              to: { type: 'STRING' },
              style: { type: 'STRING' },
              label: { type: 'STRING' },
              remove: { type: 'BOOLEAN' },
            },
            required: ['from', 'to'],
          },
        },
      },
    },
  },
  required: ['answer'],
};

const GEO_SYSTEM = `Bạn là giáo viên Toán THPT xuất sắc tại Việt Nam và là chuyên gia dựng hình GeoGebra 3D, chuyên Hình học không gian lớp 11 và lớp 12 theo Chương trình GDPT 2018 (SGK Toán 11 Kết nối tri thức Tập 1 Chương IV Song song, Tập 2 Vuông góc, và Toán 12 Oxyz).

QUY TRÌNH 5 BƯỚC BẮT BUỘC ĐỂ VẼ HÌNH & GIẢI CHÍNH XÁC TUYỆT ĐỐI:
1. Đặt hệ trục chuẩn (x hướng ra trước, y sang phải, z hướng lên). Quy ước cạnh a = 2 hoặc a = 3 (hoặc số đo cụ thể nếu đề cho sẵn) để khối nằm gọn trong [-4, +4]. Đỉnh đáy đặt tại z = 0; chân đường cao đặt chính xác (SA ⊥ đáy ⇒ S có cùng (x,y) với A; mặt bên (SAB) ⊥ đáy ⇒ chân đường cao H ∈ AB; hình chóp đều ⇒ tâm đáy O).
2. Khai báo đầy đủ CÁC ĐỈNH GỐC trong scene.vertices và ĐẦY ĐỦ MẶT NGOÀI đồng phẳng của khối đa diện trong scene.faces. Mọi mặt cắt chéo, thiết diện hoặc mặt phụ nằm bên trong khối PHẢI đặt internal: true để bộ dựng hình 3D tự động chia nét liền / nét đứt chuẩn xác theo góc xoay camera 360° mà không tạo sọc nhầm.
3. DÙNG TRƯỜNG constructions (lệnh GeoGebra 3D) cho mọi điểm/đoạn suy dẫn quan trọng để hệ thống tính lại tọa độ chính xác tuyệt đối, không bị sai số làm tròn:
   - Trung điểm: M = Midpoint(S, C)
   - Trọng tâm: G = Centroid(A, B, C)
   - Trực tâm △ABC: H = Orthocenter(A, B, C)
   - Tâm đường tròn ngoại tiếp / nội tiếp △ABC: O = Circumcenter(A, B, C), I = Incenter(A, B, C)
   - Chia đoạn tỉ lệ k: K = Ratio(A, B, 0.3333)
   - Tia phân giác ∠ABC: D = AngleBisector(A, B, C)
   - Đường song song (Bài 11-12 KNTT): Q = ParallelLine(S, A, B)
   - Đỉnh thứ 4 hình bình hành: D = Parallelogram(A, B, C)
   - Hình chiếu ⊥ lên đường thẳng / mặt phẳng: H = FootOnLine(A, S, O), H = PerpendicularPoint(A, S, B, D)
   - Giao điểm đường & mặt / 2 đường đồng phẳng / giao tuyến 2 mặt phẳng: I = Intersect(B, F, A, C, D), I = IntersectLines(A, C, B, D), IntersectPlanes(S, A, B, S, C, D)
   - Phép chiếu song song (Bài 14 KNTT): A' = ProjectParallel(A, D1, D2, P1, P2, P3)
   - Mặt phẳng trung trực đoạn AB: PlaneBisector(A, B)
   - Mặt cầu ngoại tiếp tứ diện & giao tuyến: I = CircumSphere(A, B, C, D), IntersectSpherePlane(I, R, A, B, C), IntersectLineSphere(A, B, I, R)
   - Cắt & tạo đỉnh thiết diện thật: CrossSection(A, M, N) hoặc CrossSectionParallel(E, A, B, C, D)
   - Đánh dấu góc vuông / góc: RightAngle(H, A, S), MarkAngle(O, A, S, φ)
4. Điền đầy đủ method, keyFormula, rightAngles, angles, vectors, planes, circles, kiểu cạnh ("altitude" cho đường cao, "highlight" cho khoảng cách/giao tuyến/thiết diện) và 2-3 gợi ý câu hỏi nối tiếp trong suggestedFollowups.
5. Trình bày mỗi bước lời giải theo cấu trúc 4 phần chuẩn SGK Toán 11 KNTT: (a) Nêu giả thiết & chọn mặt phẳng phụ/đường cao chuẩn; (b) Lập luận song song / giao tuyến / 3 đường vuông góc theo đúng định lí; (c) Thay số hoặc biểu thức theo a (ví dụ góc nhị diện [P, d, Q], thể tích chóp cụt đều V = h/3*(S1 + S2 + √(S1*S2))); (d) Kết luận rõ ràng kèm highlightVertices/highlightEdges/highlightFaceVertices khớp 100% ID đỉnh.`;


async function geometrySolve(req, env, uid, ctx) {
  if (!ctx.feat.ai) return json(env, { error: 'Tính năng AI đã bị tắt cho tài khoản này.' }, 403);
  const key = String(env.GEMINI_API_KEY || '').trim();
  if (!key) return json(env, { error: 'Máy chủ chưa có khóa GEMINI_API_KEY nên chưa dùng được AI giải hình. Bạn vẫn dùng được Dựng & Giải nhanh Offline.' }, 503);
  const raw = await req.text();
  if (raw.length > 12e6) return json(env, { error: 'Ảnh/đề quá lớn (tối đa ~9 MB).' }, 413);
  let b = {}; try { b = JSON.parse(raw); } catch {}
  const mode = b.mode === 'followup' || b.mode === 'recompute' ? b.mode : 'solve';
  const { problemText, imageBase64, imageMimeType, currentScene, question } = b;
  let parts, schema = GEO_SOLVE_SCHEMA;
  if (mode === 'followup') {
    const q = String(question || '').trim();
    if (!q) return json(env, { error: 'Vui lòng nhập câu hỏi thêm về hình đang vẽ.' }, 400);
    parts = [{ text: `Ngữ cảnh bài toán / mô hình 3D hiện tại (JSON):\n${JSON.stringify(currentScene || {}).slice(0, 12000)}\n\nCâu hỏi của người dùng: ${q}\nHãy giải thích chính xác, trực quan dựa đúng vào tọa độ và ký hiệu đỉnh đang có. Nếu người dùng nhờ vẽ thêm hoặc sửa điểm/cạnh/thiết diện phụ, ưu tiên xuất lệnh GeoGebra trong updatedScene.addConstructions (ví dụ "N = Midpoint(S, C)", "CrossSection(A, M, N)") hoặc dùng addVertices/addEdges/updateVertices/updateEdges.` }]; schema = GEO_FOLLOWUP_SCHEMA;
  } else if (mode === 'recompute') {
    if (!currentScene || !Array.isArray(currentScene.vertices) || !currentScene.vertices.length) return json(env, { error: 'Chưa có mô hình hình học 3D hiện tại để giải lại.' }, 400);
    const txtCtx = String(problemText || '').trim();
    parts = [{ text: `Người dùng vừa TỰ CHỈNH SỬA trực tiếp mô hình hình học 3D dưới đây (tọa độ đỉnh, cạnh, mặt). Hãy tôn trọng và giữ nguyên cấu trúc đỉnh gốc/tọa độ đã sửa trong scene hiện tại (chỉ bổ sung điểm dựng phụ qua constructions hoặc đánh dấu rightAngles/angles/planes cần thiết cho lời giải), rồi tính toán lại đáp số và viết lời giải từng bước khớp với hình mới.\n\nĐề bài gốc (nếu có): ${txtCtx || 'Bài toán dựa trên mô hình 3D đã chỉnh sửa'}\n\nMô hình 3D hiện tại sau khi người dùng chỉnh sửa (JSON):\n${JSON.stringify(currentScene).slice(0, 14000)}` }];
  } else {
    const txt = String(problemText || '').trim();
    if (!txt && !imageBase64) return json(env, { error: 'Vui lòng nhập đề bài hoặc tải ảnh đề bài hình học không gian.' }, 400);
    parts = [];
    if (imageBase64 && typeof imageBase64 === 'string') parts.push({ inlineData: { mimeType: String(imageMimeType || 'image/png'), data: imageBase64.replace(/^data:[^;]+;base64,/, '') } });
    parts.push({ text: txt ? `Hãy phân tích bài toán Hình học không gian sau theo quy trình 5 bước, dựng mô hình 3D chính xác tọa độ kèm lệnh GeoGebra constructions để kiểm chứng hình học và giải chi tiết từng bước:\n\n${txt}` : 'Hãy đọc đề bài Hình học không gian trong ảnh, dựng mô hình 3D chính xác tọa độ kèm lệnh GeoGebra constructions và giải chi tiết từng bước.' });
  }
  if (await limited(env, 'geo:' + uid, Math.round(20 * (QMUL[ctx.role] || 1)), 864e5)) return json(env, { error: 'Hôm nay bạn đã dùng hết lượt AI giải hình. Thử lại sau hoặc dùng chế độ Offline.' }, 429);
  const model = String(env.GEMINI_MODEL || 'gemini-4-hydrogen');
  let up, data;
  try {
    up = await fetch('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(model) + ':generateContent', {
      method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: GEO_SYSTEM }] }, contents: [{ role: 'user', parts }], generationConfig: { responseMimeType: 'application/json', responseSchema: schema, thinkingConfig: { thinkingLevel: 'HIGH' } } }),
    });
    data = await up.json().catch(() => ({}));
  } catch (e) { return json(env, { error: 'Không kết nối được Gemini: ' + (e && e.message || e) }, 502); }
  if (!up.ok) return json(env, { error: (data && data.error && data.error.message) || ('Gemini trả lỗi ' + up.status) }, up.status === 429 ? 429 : 502);
  await countUse(env, uid, 'geo');
  const ps = (((data.candidates || [])[0] || {}).content || {}).parts || [];
  const txt = ps.filter(p => !p.thought && typeof p.text === 'string').map(p => p.text).join('').trim();
  let out; try { out = JSON.parse(txt.replace(/^```(?:json)?\s*|\s*```$/g, '')); } catch { return json(env, { error: 'AI trả về dữ liệu không đọc được (có thể bị cắt giữa chừng). Hãy thử lại hoặc rút gọn đề.' }, 502); }
  return json(env, { ok: true, data: out });
}

async function api(req, env, url, uid, ctx) {
  const path = url.pathname, method = req.method;
  if (path.startsWith('/api/admin/')) return await admin(req, env, url, ctx);
