/* ===== hhkg-chat: Hình học không gian 11 & 12 — AI giải DÙNG CHUNG khung chat AI của Dobai =====
   - Không gọi Worker /api/geometry/solve → không cần sửa/cập nhật api-worker.js.
   - Bấm thẻ 📐 → nạp /hhkg.js vào chính trang này (chỉ khi cần) và hiện lớp vẽ 3D.
   - "AI Giải" / hỏi thêm / giải lại trong lớp 3D → gửi vào khung chat AI có sẵn (cùng khóa API, model, lịch sử).
     AI trả lời lời giải (Markdown) + 1 khối ```hhkg (JSON hình) → web dựng hình 3D từ khối đó.
   - Trong khung chat, tin AI có khối hhkg hiện thẻ "Dựng hình 3D" để dựng lại bất cứ lúc nào. */
(function () {
  'use strict';
  const W = window, D = document;
  const $ = id => D.getElementById(id);
  const ID = 'hhkg-entry';
  const GEO = __GEO_SYSTEM__;
  const FMT = __FMT__;
  const h = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const toastS = m => { try { toast(m); } catch (e) {} };
  const mkErr = (m, s) => { const e = new Error(m); e.status = s || 502; return e; };

  /* ---------- CSS ---------- */
  try {
    const st = D.createElement('style'); st.id = 'hhkg-chat-css';
    st.textContent = '#hhkg-ov{z-index:29!important}'
      + '.hh-card{margin:12px 0 4px;padding:10px 12px;border:1px solid #BFD0F5;background:#F2F6FF;border-radius:12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}'
      + '.hh-card b{flex:1 1 150px;font-size:14px;color:#17233B;line-height:1.35}'
      + '.hh-card button{min-height:40px;padding:0 14px;border:0;border-radius:10px;background:#243B8F;color:#fff;font-weight:600;font-size:14px}';
    D.head.appendChild(st);
  } catch (e) {}

  /* ---------- Thẻ ở Trang chủ ---------- */
  const HTML = '<section class="st-card" id="' + ID + '"><h2>📐 Hình học không gian 11 &amp; 12</h2>'
    + '<p style="margin:0 0 10px;font-size:13px;color:var(--mute);line-height:1.5">Vẽ 3D/2D chuẩn GeoGebra: chóp, lăng trụ, thiết diện, góc, khoảng cách, trải phẳng. AI giải từng bước ngay trong khung chat AI của Dobai (dùng chung khóa API và model đã cài).</p>'
    + '<button type="button" class="st-btn pri" data-hhkg-entry="open" style="min-height:44px">📐 Mở Hình học 3D</button></section>';
  function addEntry() {
    try {
      const app = $('app'); if (!app || $(ID)) return;
      if (typeof V !== 'undefined' && V && V.view !== 'home' && V.view !== 'start') return;
      const anchor = $('o2-entry') || $('tl-entry') || $('uimp-entry');
      if (anchor) anchor.insertAdjacentHTML('afterend', HTML);
      else {
        const a2 = app.querySelector('details.bkp') || app.querySelector('.st-ft');
        if (a2) a2.insertAdjacentHTML('beforebegin', HTML); else app.insertAdjacentHTML('beforeend', HTML);
      }
    } catch (e) { console.warn('[HHKG] addEntry', e); }
  }
  ['renderHome', 'renderStart'].forEach(fn => {
    try { const o = W[fn]; if (typeof o !== 'function') return; W[fn] = function () { const r = o.apply(this, arguments); addEntry(); return r; }; } catch (e) {}
  });
  try { const app = $('app'); if (app && W.MutationObserver) new MutationObserver(() => { try { addEntry(); } catch (e) {} }).observe(app, { childList: true }); } catch (e) {}
  try { if (typeof V !== 'undefined' && V && (V.view === 'home' || V.view === 'start')) addEntry(); } catch (e) {}

  /* ---------- Nạp /hhkg.js khi cần ---------- */
  let loading = null;
  function load() {
    if (W.HHKG && typeof W.HHKG.open === 'function') return Promise.resolve(W.HHKG);
    if (!loading) loading = import('/hhkg.js').then(() => { if (!W.HHKG) throw new Error('hhkg.js không khởi tạo được'); return W.HHKG; }).catch(e => { loading = null; throw e; });
    return loading;
  }
  function openHH(tab) {
    if (!W.HHKG) toastS('Đang mở Hình học 3D…');
    return load().then(H => { H.open(tab || 'templates'); return H; })
      .catch(e => { console.warn('[HHKG]', e); toastS('Không tải được Hình học 3D — kiểm tra mạng rồi thử lại'); });
  }
  D.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('[data-hhkg-entry]'); if (!b) return;
    openHH('templates');
  });
  try {
    if (/[?&]hhkg=1(&|$)/.test(W.location.search)) { openHH('templates'); W.history.replaceState(null, '', W.location.pathname + W.location.hash); }
  } catch (e) {}

  /* ---------- Prompt hệ thống cho cuộc trò chuyện hình học ---------- */
  const isHH = c => !!(c && (c.hhkg || (typeof c.title === 'string' && c.title.indexOf('📐') === 0)));
  try {
    if (typeof AG !== 'undefined' && AG && typeof AG.sys === 'function') {
      const s0 = AG.sys;
      AG.sys = function (c) { let b = ''; try { b = s0.apply(this, arguments); } catch (e) {} return b + (isHH(c) ? '\n\n' + GEO + '\n\n' + FMT : ''); };
    }
  } catch (e) { console.warn('[HHKG] AG.sys', e); }

  /* ---------- Tách khối ```hhkg và đọc JSON chịu lỗi ---------- */
  function fences(text) {
    const re = /```([A-Za-z0-9_-]*)[ \t]*\r?\n?([\s\S]*?)(```|$)/g, out = []; let m;
    while ((m = re.exec(String(text || '')))) out.push({ lang: (m[1] || '').toLowerCase(), body: m[2], start: m.index, end: m.index + m[0].length, closed: m[3] === '```' });
    return out;
  }
  function repair(t) {
    const cuts = []; const stack = []; let inS = false, es = false;
    for (let i = 0; i < t.length; i++) {
      const ch = t[i];
      if (inS) { if (es) es = false; else if (ch === '\\') es = true; else if (ch === '"') inS = false; continue; }
      if (ch === '"') inS = true;
      else if (ch === '{' || ch === '[') stack.push(ch);
      else if (ch === '}' || ch === ']') stack.pop();
      else if (ch === ',') cuts.push([i, stack.slice()]);
    }
    const close = (s, stk, inStr) => {
      if (inStr) s += '"';
      for (let k = stk.length - 1; k >= 0; k--) s += stk[k] === '{' ? '}' : ']';
      try { return JSON.parse(s.replace(/,\s*([}\]])/g, '$1')); } catch (e) { return null; }
    };
    let r = close(t, stack, inS); if (r) return r;
    for (let k = cuts.length - 1, n = 0; k >= 0 && n < 40; k--, n++) { r = close(t.slice(0, cuts[k][0]), cuts[k][1], false); if (r) return r; }
    return null;
  }
  function loose(s) {
    s = String(s || '').trim();
    if (!s) return null;
    try { return JSON.parse(s); } catch (e) {}
    const t = s.replace(/,\s*([}\]])/g, '$1');
    try { return JSON.parse(t); } catch (e) {}
    return repair(t);
  }
  function extract(text) {
    let best = null;
    for (const f of fences(text)) {
      const ok = f.lang === 'hhkg' || ((f.lang === 'json' || f.lang === '') && /"(scene|updatedScene)"\s*:/.test(f.body));
      if (!ok) continue;
      const o = loose(f.body);
      const rec = { obj: o && typeof o === 'object' && !Array.isArray(o) ? o : null, start: f.start, end: f.end, closed: f.closed, lang: f.lang };
      if (rec.obj) return rec;
      if (!best) best = rec;
    }
    return best;
  }
  const prose = (text, ex) => (ex ? String(text).slice(0, ex.start) + String(text).slice(ex.end) : String(text || '')).trim();
  function hide(s) {
    if (typeof s !== 'string' || s.indexOf('```') < 0) return s;
    const f = fences(s).find(x => x.lang === 'hhkg'); if (!f) return s;
    return s.slice(0, f.start) + (f.closed ? '' : '\n\n_⏳ Đang soạn dữ liệu dựng hình 3D…_\n') + s.slice(f.end);
  }
  try {
    const m0 = W.mdRender;
    if (typeof m0 === 'function') W.mdRender = function (s) { let x = s; try { x = hide(s); } catch (e) {} return m0.call(this, x); };
  } catch (e) {}

  /* ---------- Chuẩn hóa dữ liệu trả về cho hhkg.js ---------- */
  const clean = s => String(s || '').replace(/\*\*/g, '').replace(/^#{1,6}\s*/gm, '').replace(/\n{3,}/g, '\n\n').trim();
  function normSolve(o, pr) {
    const d = Object.assign({}, o), sc = d.scene = Object.assign({}, d.scene);
    ['vertices', 'edges', 'faces', 'rightAngles', 'angles'].forEach(k => { if (!Array.isArray(sc[k])) sc[k] = []; });
    if (!d.title) d.title = 'Bài toán Hình học 3D';
    if (!d.grade) d.grade = ''; if (!d.topic) d.topic = '';
    if (!d.summary) d.summary = clean(pr).slice(0, 200);
    if (!d.finalAnswer) d.finalAnswer = '';
    if (!Array.isArray(d.steps) || !d.steps.length) d.steps = [{ stepTitle: 'Lời giải', explanation: clean(pr).slice(0, 1800) || 'Xem lời giải trong khung chat AI.' }];
    return d;
  }
  function sceneText(sc) {
    if (!sc) return '';
    const n = v => { const x = Number(v); return Number.isFinite(x) ? String(Math.round(x * 1e4) / 1e4) : '0'; };
    const Vs = (sc.vertices || []).map(v => v.id + '(' + n(v.x) + ', ' + n(v.y) + ', ' + n(v.z) + ')').join('; ');
    const Es = (sc.edges || []).map(e => e.from + '-' + e.to + (e.style && e.style !== 'solid' ? '[' + e.style + ']' : '')).join(', ');
    const Fs = (sc.faces || []).map(f => (f.internal ? 'trong:' : '') + (f.vertices || []).join('-')).join(', ');
    return 'Đỉnh: ' + Vs + '\nCạnh: ' + Es + (Fs ? '\nMặt: ' + Fs : '');
  }

  /* ---------- Kiểm tra hình trước khi dựng (ID, đồng phẳng, vuông góc) ---------- */
  const vsub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
  const vdot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const vcross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const vlen = a => Math.sqrt(vdot(a, a));
  function coplanar(pts) {
    if (pts.length < 4) return true;
    const a = pts[0]; let n = null;
    for (let i = 1; i < pts.length - 1 && !n; i++) for (let j = i + 1; j < pts.length && !n; j++) { const c = vcross(vsub(pts[i], a), vsub(pts[j], a)), l = vlen(c); if (l > 1e-6) n = c.map(x => x / l); }
    return !n || pts.every(p => Math.abs(vdot(vsub(p, a), n)) < 0.02);
  }
  function validate(o) {
    const hard = [], soft = [], sc = o && o.scene;
    if (!sc || !Array.isArray(sc.vertices) || !sc.vertices.length) return { hard: ['scene.vertices trống hoặc thiếu'], soft };
    const P = {};
    sc.vertices.forEach(v => {
      if (!v || typeof v.id !== 'string' || !v.id.trim()) { hard.push('có đỉnh không có id'); return; }
      const c = [v.x, v.y, v.z].map(Number);
      if (c.some(x => !Number.isFinite(x))) hard.push('đỉnh ' + v.id + ' có tọa độ không phải số (cấm biểu thức/căn/phân số, phải là số thập phân)');
      else if (c.some(x => Math.abs(x) > 12)) soft.push('đỉnh ' + v.id + ' có tọa độ quá lớn (> 12), hãy đặt a = 2 hoặc 3');
      if (P[v.id]) hard.push('id đỉnh bị trùng: ' + v.id);
      P[v.id] = c;
    });
    const made = {};
    (Array.isArray(o.constructions) ? o.constructions : []).forEach(k => { const m = /^\s*([A-Za-z][A-Za-z0-9_']*)\s*=/.exec(typeof k === 'string' ? k : (k && k.command) || ''); if (m) made[m[1]] = 1; });
    const known = id => !!(P[id] || made[id]);
    const need = (id, where, arr) => { if (!known(id)) arr.push(where + ' dùng đỉnh "' + id + '" không có trong vertices'); };
    (Array.isArray(sc.edges) ? sc.edges : []).forEach(e => {
      if (!e) return; need(e.from, 'cạnh', hard); need(e.to, 'cạnh', hard);
      if (e.from === e.to) hard.push('cạnh ' + e.from + '-' + e.to + ' có hai đầu trùng nhau');
      if (e.style && !/^(solid|dashed|highlight|altitude)$/.test(e.style)) soft.push('cạnh ' + e.from + '-' + e.to + ' có style không hợp lệ: ' + e.style);
    });
    (Array.isArray(sc.faces) ? sc.faces : []).forEach(f => {
      const vs = f && Array.isArray(f.vertices) ? f.vertices : [];
      if (vs.length < 3) { hard.push('có mặt ít hơn 3 đỉnh'); return; }
      vs.forEach(id => need(id, 'mặt ' + vs.join('-'), hard));
      if (vs.every(id => P[id]) && !coplanar(vs.map(id => P[id]))) soft.push('mặt ' + vs.join('-') + ' không đồng phẳng theo tọa độ (kiểm tra lại tọa độ các đỉnh)');
    });
    (Array.isArray(sc.rightAngles) ? sc.rightAngles : []).forEach(r => {
      if (!r) return; [r.vertex, r.p1, r.p2].forEach(id => need(id, 'góc vuông', hard));
      if (P[r.vertex] && P[r.p1] && P[r.p2]) {
        const u = vsub(P[r.p1], P[r.vertex]), w = vsub(P[r.p2], P[r.vertex]), lu = vlen(u), lw = vlen(w);
        if (lu < 1e-6 || lw < 1e-6) soft.push('góc vuông tại ' + r.vertex + ' có hai điểm trùng đỉnh');
        else { const cs = vdot(u, w) / (lu * lw); if (Math.abs(cs) > 0.02) soft.push('góc ' + r.p1 + r.vertex + r.p2 + ' được khai báo vuông nhưng theo tọa độ cos = ' + cs.toFixed(3)); }
      }
    });
    (Array.isArray(sc.angles) ? sc.angles : []).forEach(a => { if (a) [a.vertex, a.p1, a.p2].forEach(id => need(id, 'góc', hard)); });
    (Array.isArray(o.steps) ? o.steps : []).forEach((st, i) => {
      if (!st) return;
      (Array.isArray(st.highlightVertices) ? st.highlightVertices : []).forEach(id => need(id, 'bước ' + (i + 1), soft));
      (Array.isArray(st.highlightEdges) ? st.highlightEdges : []).forEach(e => { if (e) { need(e.from, 'bước ' + (i + 1), soft); need(e.to, 'bước ' + (i + 1), soft); } });
    });
    if (!String(o.finalAnswer || '').trim()) soft.push('thiếu finalAnswer');
    return { hard: hard.slice(0, 8), soft: soft.slice(0, 8) };
  }

  /* ---------- Gửi vào khung chat AI có sẵn và chờ trả lời ---------- */
  function chat(fresh) {
    let c = GCHAT.hhkg;
    if (!c || fresh) c = GCHAT.hhkg = { free: 1, hhkg: 1, orig: '', title: '📐 Hình học 3D · AI giải', msgs: [], api: GPICK || GGOOD || GEMINI_MODELS[0] };
    GCUR = 'hhkg'; aiSheet(); gProbeAll(false); xkProbeAll(false); gRender();
    return c;
  }
  function waitReply(c, before) {
    return new Promise((res, rej) => {
      const t0 = Date.now(); let idle = 0;
      const tm = setInterval(() => {
        if (Date.now() - t0 > 24e4) { clearInterval(tm); rej(mkErr('AI trả lời quá lâu. Thử lại hoặc đổi model trong khung chat.', 504)); return; }
        if (c.busy || (typeof GBUSY !== 'undefined' && GBUSY)) { idle = 0; return; }
        if (++idle < 3) return;
        clearInterval(tm);
        if (c.msgs.length <= before) { rej(mkErr('Chưa gửi được câu hỏi — hãy kiểm tra khóa API / chọn model trong khung chat AI.', 502)); return; }
        const last = c.msgs[c.msgs.length - 1];
        if (last && last.r === 'err') { rej(mkErr(last.t || 'AI báo lỗi.', 502)); return; }
        for (let i = c.msgs.length - 1; i >= before; i--) if (c.msgs[i].r === 'model') { res(String(c.msgs[i].t || '')); return; }
        rej(mkErr('AI chưa trả lời.', 502));
      }, 300);
    });
  }
  function shape(mode, reply) {
    const ex = extract(reply), pr = prose(reply, ex);
    if (mode === 'followup') {
      const o = (ex && ex.obj) || {};
      let a = clean(pr) || clean(o.answer);
      if (a.length > 1800) a = a.slice(0, 1800) + '… (xem đầy đủ trong khung chat AI)';
      return { answer: a, highlightVertices: o.highlightVertices, highlightEdges: o.highlightEdges, updatedScene: o.updatedScene };
    }
    const o = ex && ex.obj;
    if (!o || !o.scene || !Array.isArray(o.scene.vertices) || !o.scene.vertices.length)
      throw mkErr('AI chưa trả về khối dữ liệu hình (```hhkg) hợp lệ. Lời giải (nếu có) nằm trong khung chat AI — bấm "Hỏi lại" hoặc đổi model rồi thử lại, hoặc dùng Dựng & Giải nhanh Offline.', 502);
    return normSolve(o, pr);
  }
  async function ask(req) {
    req = req || {};
    const mode = req.mode === 'followup' || req.mode === 'recompute' ? req.mode : 'solve';
    if (typeof GBUSY !== 'undefined' && GBUSY) throw mkErr('AI đang trả lời câu khác — chờ xong rồi thử lại.', 429);
    let text = '', atts;
    if (mode === 'solve') {
      const t = String(req.problemText || '').trim();
      if (!t && !req.imageBase64) throw mkErr('Vui lòng nhập đề bài hoặc tải ảnh đề bài hình học không gian.', 400);
      text = '📐 Giải bài Hình học không gian & dựng hình 3D:\n\n' + (t || '(Đề bài ở ảnh đính kèm — hãy đọc ảnh.)');
      if (req.imageBase64) {
        const mime = String(req.imageMimeType || 'image/png'), b64 = String(req.imageBase64).replace(/^data:[^;]+;base64,/, '');
        atts = [{ kind: 'image', name: 'de-bai.' + (mime.split('/')[1] || 'png'), mime: mime, size: Math.round(b64.length * 0.75), b64: b64, url: 'data:' + mime + ';base64,' + b64 }];
      }
    } else if (mode === 'followup') {
      const q = String(req.question || '').trim();
      if (!q) throw mkErr('Vui lòng nhập câu hỏi thêm về hình đang vẽ.', 400);
      text = '📐 Hỏi thêm về hình đang mở: ' + q + '\n\n— Hình hiện tại —\n' + sceneText(req.currentScene).slice(0, 6000);
    } else {
      if (!req.currentScene || !Array.isArray(req.currentScene.vertices) || !req.currentScene.vertices.length) throw mkErr('Chưa có hình 3D hiện tại để giải lại.', 400);
      const t = String(req.problemText || '').trim();
      text = '📐 Mình vừa tự chỉnh hình 3D (tọa độ / cạnh / mặt bên dưới). Hãy giữ nguyên các đỉnh gốc đã sửa, tính lại đáp số và viết lại lời giải khớp hình mới; trả đủ lời giải + khối hhkg đầy đủ như khi giải bài mới.'
        + (t ? '\n\nĐề bài gốc: ' + t : '') + '\n\n— Hình hiện tại —\n' + sceneText(req.currentScene).slice(0, 6000);
    }
    const c = chat(mode === 'solve');
    let before = c.msgs.length;
    gSend(text, atts);
    let reply = await waitReply(c, before);
    if (mode === 'followup') return shape(mode, reply);
    for (let k = 0; ; k++) {
      const ex = extract(reply), o = ex && ex.obj;
      const v = o && o.scene ? validate(o) : { hard: ['thiếu khối ```hhkg hợp lệ (JSON đọc được và có "scene")'], soft: [] };
      const bad = v.hard.concat(v.soft);
      if (!bad.length) return normSolve(o, prose(reply, ex));
      if (k >= 1) {
        if (v.hard.length) throw mkErr('AI vẫn trả hình lỗi sau khi được nhắc sửa: ' + v.hard.slice(0, 3).join('; ') + '. Xem lời giải trong khung chat AI, đổi model rồi bấm "Hỏi lại", hoặc dùng Dựng & Giải nhanh Offline.', 502);
        const d = normSolve(o, prose(reply, ex));
        d.verificationNote = ('⚠ Chưa qua kiểm tra tự động: ' + v.soft.slice(0, 4).join('; ') + '. ' + (d.verificationNote || '')).trim();
        return d;
      }
      before = c.msgs.length;
      gSend('🔧 Kiểm tra tự động phát hiện lỗi trong câu trả lời của bạn:\n' + bad.map(x => '- ' + x).join('\n')
        + '\nHãy sửa tọa độ / ID cho đúng, chạy lại CHECKLIST mục E, rồi gửi lại ĐẦY ĐỦ: lời giải (chỉnh nếu đáp số đổi) + MỘT khối ```hhkg hoàn chỉnh.');
      reply = await waitReply(c, before);
    }
  }
  W.__hhkgAsk = ask;
  W.HHKGCHAT = { ask, extract, loose, hide, normSolve, sceneText, validate, open: openHH };

  /* ---------- Thẻ "Dựng hình 3D" dưới tin AI trong khung chat ---------- */
  const cache = new WeakMap();
  function exOf(m) { let r = cache.get(m); if (!r || r.t !== m.t) { r = { t: m.t, ex: extract(m.t) }; cache.set(m, r); } return r.ex; }
  function decorate() {
    const c = typeof GCUR !== 'undefined' ? GCHAT[GCUR] : null; if (!c || !c.msgs) return;
    const box = $('gmsgs'); if (!box) return;
    c.msgs.forEach((m, i) => {
      if (m.r !== 'model' || typeof m.t !== 'string' || m.t.indexOf('```') < 0) return;
      const ex = exOf(m); if (!ex || !ex.obj) return;
      const o = ex.obj, kind = o.scene ? 'solve' : (o.updatedScene ? 'patch' : ''); if (!kind) return;
      const host = box.querySelector('#gm' + i + ' .md'); if (!host || host.querySelector('.hh-card')) return;
      host.insertAdjacentHTML('beforeend', '<div class="hh-card"><b>📐 ' + h(kind === 'solve' ? (o.title || 'Hình 3D của bài toán') : 'Vẽ thêm / sửa hình đang mở')
        + '</b><button type="button" data-hh-act="' + kind + '" data-hh-i="' + i + '">' + (kind === 'solve' ? 'Dựng hình 3D' : 'Áp dụng vào hình') + '</button></div>');
    });
  }
  try {
    const g0 = W.gRender;
    if (typeof g0 === 'function') W.gRender = function () { const r = g0.apply(this, arguments); try { decorate(); } catch (e) { console.warn('[HHKG] decorate', e); } return r; };
  } catch (e) {}
  function closeChat() { try { const p = $('aiansw'), x = p && p.querySelector('.gclose'); if (x) x.click(); } catch (e) {} }
  D.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('[data-hh-act]'); if (!b) return;
    e.preventDefault();
    const c = GCHAT[GCUR], m = c && c.msgs[+b.dataset.hhI], ex = m && exOf(m);
    if (!ex || !ex.obj) return;
    const kind = b.dataset.hhAct, o = ex.obj, pr = prose(m.t, ex);
    load().then(H => {
      H.open('ai');
      if (kind === 'solve') { H.applySolve(normSolve(o, pr)); try { const v = validate(o), n = v.hard.length + v.soft.length; if (n) toastS('⚠ Hình có ' + n + ' điểm chưa khớp: ' + v.hard.concat(v.soft)[0]); } catch (e) {} } else H.applyPatch(o);
      closeChat();
    }).catch(er => { console.warn('[HHKG]', er); toastS('Không dựng được hình — thử lại'); });
  });
})();
