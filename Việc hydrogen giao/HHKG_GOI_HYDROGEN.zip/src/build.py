#!/usr/bin/env python3
"""Ghép bản HHKG dùng chung khung chat AI.
Dùng:  python3 build.py <thu_muc_vao> <thu_muc_ra>
Thư mục vào cần: index_1.html (index.html + khối <script id="hhkg-link"> cũ), hhkg.js, hhkg.html
Thư mục ra:      index.html, hhkg.js, hhkg.html
Mỗi bước vá đều assert đúng số lần xuất hiện; nếu hhkg.js gốc đổi mã nguồn thì build báo lỗi chứ không vá bừa."""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
SRC, OUT = sys.argv[1], sys.argv[2]
rd = lambda p: open(p, encoding='utf8').read()
def wr(p, s): open(p, 'w', encoding='utf8', newline='').write(s)

# ---------- 1) index.html: thay khối hhkg-link bằng hhkg-chat ----------
mod = rd(os.path.join(HERE, 'hhkg-chat.module.js'))
geo = rd(os.path.join(HERE, '..', 'prompt', 'geo_system.txt')).strip()
fmt = rd(os.path.join(HERE, '..', 'prompt', 'fmt.txt')).strip()
mod = mod.replace('__GEO_SYSTEM__', json.dumps(geo, ensure_ascii=False)).replace('__FMT__', json.dumps(fmt, ensure_ascii=False))
assert '</script' not in mod.lower()
t = rd(os.path.join(SRC, 'index_1.html'))
assert t.count('<script id="hhkg-link">') == 1
a = t.index('<script id="hhkg-link">'); b = t.index('</script>', a) + len('</script>')
wr(os.path.join(OUT, 'index.html'), t[:a] + '<script id="hhkg-chat">\n' + mod + '</script>' + t[b:])

# ---------- 2) hhkg.js (đã minify): 3 chỗ gọi Worker -> cầu nối sang chat AI ----------
js = rd(os.path.join(SRC, 'hhkg.js'))
BRIDGE = ('const __hhkgFetch=async(u,i)=>{let b={};try{b=JSON.parse(i.body)}catch{}let f=window.__hhkgAsk;'
  'if(typeof f!=="function")return{ok:!1,status:503,json:async()=>({error:"Chưa có khung chat AI của Dobai — hãy mở Hình học 3D từ Trang chủ Dobai (thẻ 📐) để dùng AI giải."})};'
  'try{let d=await f(b);return{ok:!0,status:200,json:async()=>({ok:!0,data:d})}}'
  'catch(e){return{ok:!1,status:e&&e.status||502,json:async()=>({error:String(e&&e.message||e)})}}};\n')
CALL = 'fetch(w+"/api/geometry/solve"'
assert js.count(CALL) == 3                      # nt (giải), _e (giải lại), Te (hỏi thêm)
js = js.replace(CALL, '__hhkgFetch(w+"/api/geometry/solve"')
ANCHOR = 't.HHKG={open:I,close:ot,state:r,'
assert js.count(ANCHOR) == 1
APPLY = ('applySolve:T=>{r.tab="ai",me(T),gt()},'
 'applyPatch:F=>{if(F){if(F.updatedScene){d();let C=structuredClone(r.scene);'
 'if(Array.isArray(F.updatedScene.updateVertices))for(let X of F.updatedScene.updateVertices){let M=C.vertices.findIndex(O=>O.id===X.id);M>=0?C.vertices[M]={...C.vertices[M],...X}:C.vertices.push(X)}'
 'if(Array.isArray(F.updatedScene.updateEdges))for(let X of F.updatedScene.updateEdges)C.edges=C.edges.filter(M=>!(M.from===X.from&&M.to===X.to||M.from===X.to&&M.to===X.from)),X.remove||C.edges.push({from:X.from,to:X.to,style:X.style||"solid",label:X.label||""});'
 'if(Array.isArray(F.updatedScene.addVertices))for(let X of F.updatedScene.addVertices)C.vertices.some(M=>M.id===X.id)||C.vertices.push(X);'
 'if(Array.isArray(F.updatedScene.addEdges)&&C.edges.push(...F.updatedScene.addEdges),Array.isArray(F.updatedScene.addFaces)&&C.faces.push(...F.updatedScene.addFaces),Array.isArray(F.updatedScene.addRightAngles)&&C.rightAngles.push(...F.updatedScene.addRightAngles),Array.isArray(F.updatedScene.addConstructions))'
 'for(let X of F.updatedScene.addConstructions){let M=Bl(String(X||""),C);M.ok&&M.scene&&(C=M.scene)}'
 'r.scene=yt(C),dt({keepCamera:!0})}(F.highlightVertices||F.highlightEdges)&&it({vertices:F.highlightVertices||[],edges:F.highlightEdges||[]});r.tab="ai";gt()}},')
wr(os.path.join(OUT, 'hhkg.js'), BRIDGE + js.replace(ANCHOR, ANCHOR + APPLY))

# ---------- 3) hhkg.html: mở riêng thì chuyển về trang chủ (trừ ?solo=1) ----------
H = rd(os.path.join(SRC, 'hhkg.html'))
assert H.count('<body>') >= 1
wr(os.path.join(OUT, 'hhkg.html'), H.replace('<body>', '<body>\n  <script>if(!/[?&]solo=1/.test(location.search)){location.replace("/?hhkg=1")}</script>', 1))
print('build ok ->', OUT)
