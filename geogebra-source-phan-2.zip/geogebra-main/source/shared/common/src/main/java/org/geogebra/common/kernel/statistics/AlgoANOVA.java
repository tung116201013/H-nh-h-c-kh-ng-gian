/*
 * GeoGebra - Dynamic Mathematics for Everyone
 * Copyright (c) GeoGebra GmbH, Altenbergerstr. 69, 4040 Linz, Austria
 * https://www.geogebra.org
 *
 * This file is licensed by GeoGebra GmbH under the EUPL 1.2 licence and
 * may be used under the EUPL 1.2 in compatible projects (see Article 5
 * and the Appendix of EUPL 1.2 for details).
 * You may obtain a copy of the licence at:
 * https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Note: The overall GeoGebra software package is free to use for
 * non-commercial purposes only.
 * See https://www.geogebra.org/license for full licensing details
 */

package org.geogebra.common.kernel.statistics;

import java.util.ArrayList;

import org.apache.commons.math3.stat.inference.OneWayAnova;
import org.geogebra.common.kernel.Construction;
import org.geogebra.common.kernel.algos.AlgoElement;
import org.geogebra.common.kernel.arithmetic.NumberValue;
import org.geogebra.common.kernel.commands.Commands;
import org.geogebra.common.kernel.geos.GeoElement;
import org.geogebra.common.kernel.geos.GeoList;
import org.geogebra.common.util.debug.Log;

/**
 * Performs a one way ANOVA test.
 *
 *
 * @author G. Sturr
 */
public class AlgoANOVA extends AlgoElement {

	private GeoList geoList; // input
	private GeoList result; // output

	private ArrayList<double[]> categoryData;
	private double p;
	private double testStat;
	private OneWayAnova anovaImpl;

	/**
	 * @param cons
	 *            construction
	 * @param label
	 *            label
	 * @param geoList
	 *            list of lists of values
	 */
	public AlgoANOVA(Construction cons, String label, GeoList geoList) {
		super(cons);
		this.geoList = geoList;
		result = new GeoList(cons);
		setInputOutput(); // for AlgoElement

		compute();
		result.setLabel(label);
	}

	@Override
	public Commands getClassName() {
		return Commands.ANOVA;
	}

	@Override
	protected void setInputOutput() {

		input = new GeoElement[1];
		input[0] = geoList;

		setOnlyOutput(result);
		setDependencies(); // done by AlgoElement
	}

	/**
	 * @return resulting list of Pvalues and Fvalues
	 */
	public GeoList getResult() {
		return result;
	}

	@Override
	public final void compute() {

		int size = geoList.size();
		// exit if less than two data lists
		if (size < 2) {
			result.setUndefined();
			return;
		}

		// exit if data lists are not defined or have less than two values
		for (int index = 0; index < size; index++) {

			if (!geoList.get(index).isDefined()
					|| !geoList.get(index).isGeoList()
					|| ((GeoList) geoList.get(index)).size() < 2) {
				result.setUndefined();
				return;
			}
		}

		// create an array list of data arrays
		if (categoryData == null) {
			categoryData = new ArrayList<>();
		} else {
			categoryData.clear();
		}

		// load the data arrays from the input GeoList
		GeoList list;
		for (int index = 0; index < size; index++) {

			list = (GeoList) geoList.get(index);
			double[] val = new double[list.size()];

			for (int i = 0; i < list.size(); i++) {
				GeoElement geo = list.get(i);
				if (geo instanceof NumberValue) {
					val[i] = geo.evaluateDouble();
				} else {
					result.setUndefined();
					return;
				}
			}
			categoryData.add(val);
		}

		try {

			// get the test statistic and p value
			if (anovaImpl == null) {
				anovaImpl = new OneWayAnova();
			}
			p = anovaImpl.anovaPValue(categoryData);
			testStat = anovaImpl.anovaFValue(categoryData);

			// put these results into the output list
			result.clear();
			result.addNumber(p, null);
			result.addNumber(testStat, null);

		} catch (Exception e) {
			result.setUndefined();
			Log.debug(e);
		}
	}
}
