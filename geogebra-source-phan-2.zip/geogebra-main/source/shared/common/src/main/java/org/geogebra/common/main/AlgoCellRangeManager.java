/*
 * GeoGebra - Dynamic Mathematics for Everyone
 * Copyright (c) GeoGebra GmbH, Altenbergerstr. 69, 4040 Linz, Austria
 * https://www.geogebra.org
 *
 * This file is licensed by GeoGebra GmbH under the EUPL 1.2 licence and
 * may be used under the EUPL 1.2 in compatible projects (see Article 5
 * and the Appendix of EUPL 1.2 for details).
 * You may obtain a copy of the licence at:
 * https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Note: The overall GeoGebra software package is free to use for
 * non-commercial purposes only.
 * See https://www.geogebra.org/license for full licensing details
 */

package org.geogebra.common.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.geogebra.common.kernel.Construction;
import org.geogebra.common.kernel.geos.GeoElement;
import org.geogebra.common.kernel.statistics.AlgoCellRange;
import org.geogebra.common.spreadsheet.core.SpreadsheetCoords;
import org.geogebra.common.spreadsheet.core.TabularRange;
import org.jspecify.annotations.Nullable;

/**
 * Maintains a list of all instances of AlgoCellRange in a construction and
 * handles updates to the AlgoCellRanges when a spreadsheet cell GeoElement is
 * changed.
 *
 * @author G. Sturr
 *
 */
public class AlgoCellRangeManager {

	private @Nullable HashMap<String, AlgoCellRange> algos;

	/**
	 * Removes an AlgoCellRange algorithm from the internal algorithm list.
	 *
	 * @param algo
	 *            algorithm to remove
	 */
	public void unregisterCellRangeListenerAlgo(AlgoCellRange algo) {
		if (algos != null) {
			algos.remove(getKey(algo.getStart(), algo.getEnd()));
		}
	}

	/**
	 * Updates registered AlgoCellRanges with cell ranges that contain the
	 * coordinates of the given GeoElement. This method should be called when
	 * GeoElements have been added, removed or renamed.
	 *
	 * @param geo
	 *            GeoElement that has changed
	 * @param location
	 *            spreadsheet coordinate location (this may be the previous
	 *            location if a cell has been renamed)
	 * @param isRemoveAction
	 *            true if the given GeoElement has been removed
	 *
	 */
	public void updateCellRangeAlgos(
			GeoElement geo, SpreadsheetCoords location, boolean isRemoveAction) {
		if (geo == null || algos == null) {
			return;
		}

		for (AlgoCellRange algo : algos.values()) {
			if (algo.getRange().contains(location)) {
				algo.updateList(geo, isRemoveAction);
			}
		}
	}

	/**
	 * add the geo at specified location to cell range algos
	 *
	 * @param geo
	 *            geo
	 * @param location
	 *            location on spreadsheet
	 */
	public void addToCellRangeAlgos(GeoElement geo, SpreadsheetCoords location) {
		if (geo == null || algos == null) {
			return;
		}

		for (AlgoCellRange algo : algos.values()) {
			if (algo.getRange().contains(location)) {
				algo.addToList(geo, location);
			}
		}
	}

	/**
	 * CLear the algo list
	 */
	public void clear() {
		if (algos != null) {
			algos.clear();
		}
	}

	/**
	 *
	 * @param cons
	 *            construction
	 * @param label
	 *            label
	 * @param start
	 *            start cell
	 * @param end
	 *            end cell
	 * @return algo corresponding to string start:end
	 */
	public AlgoCellRange getAlgoCellRange(Construction cons, String label, String start, String end) {

		if (algos == null) {
			algos = new HashMap<>();
		}

		String key = getKey(start, end);
		AlgoCellRange algo = algos.get(key);
		if (algo == null) {
			algo = new AlgoCellRange(cons, start, end);
			algo.getList().setLabel(label);
			algos.put(key, algo);
		} else {
			if (label != null && label.length() > 0) {
				algo.getList().setLabel(label);
			}
			if (!algo.isInConstructionList()) {
				cons.addToConstructionList(algo, false);
			}
		}
		return algo;
	}

	private static String getKey(String start, String end) {
		return start + ":" + end;
	}

	/**
	 * Shift columns from a starting index.
	 * @param column index of first shifted column
	 * @param by increment (+1 adds 1 column, -1 deletes one column)
	 */
	public void shiftColumnsFrom(int column, int by) {
		if (algos == null) {
			return;
		}
		List<GeoElement> toUpdate = new ArrayList<>();
		for (AlgoCellRange range : algos.values()) {
			TabularRange tabularRange = range.getRange();
			int minColumn = tabularRange.getMinColumn();
			int maxColumn = tabularRange.getMaxColumn();
			boolean changed = false;
			if (minColumn >= column) {
				minColumn += by;
				changed = true;
			}
			if (maxColumn >= column) {
				maxColumn += by;
				changed = true;
			}
			if (changed) {
				tabularRange = new TabularRange(
						tabularRange.getMinRow(), minColumn, tabularRange.getMaxRow(), maxColumn);
				range.setRange(tabularRange);
				toUpdate.add(range.getList());
			}
		}
		GeoElement.updateCascade(toUpdate);
	}

	/**
	 * Shift rows from a starting index.
	 * @param row index of first shifted row
	 * @param by increment (+1 adds 1 row, -1 deletes one row)
	 */
	public void shiftRowsFrom(int row, int by) {
		if (algos == null) {
			return;
		}
		List<GeoElement> toUpdate = new ArrayList<>();
		for (AlgoCellRange range : algos.values()) {
			TabularRange tabularRange = range.getRange();
			int minRow = tabularRange.getMinRow();
			int maxRow = tabularRange.getMaxRow();
			boolean changed = false;
			if (minRow >= row) {
				minRow += by;
				changed = true;
			}
			if (maxRow >= row) {
				maxRow += by;
				changed = true;
			}
			if (changed) {
				tabularRange = new TabularRange(
						minRow, tabularRange.getMinColumn(), maxRow, tabularRange.getMaxColumn());
				range.setRange(tabularRange);
				toUpdate.add(range.getList());
			}
		}
		GeoElement.updateCascade(toUpdate);
	}
}
