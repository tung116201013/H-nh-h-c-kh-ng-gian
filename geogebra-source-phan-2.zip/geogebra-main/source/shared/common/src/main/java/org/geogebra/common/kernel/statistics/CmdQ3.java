/*
 * GeoGebra - Dynamic Mathematics for Everyone
 * Copyright (c) GeoGebra GmbH, Altenbergerstr. 69, 4040 Linz, Austria
 * https://www.geogebra.org
 *
 * This file is licensed by GeoGebra GmbH under the EUPL 1.2 licence and
 * may be used under the EUPL 1.2 in compatible projects (see Article 5
 * and the Appendix of EUPL 1.2 for details).
 * You may obtain a copy of the licence at:
 * https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Note: The overall GeoGebra software package is free to use for
 * non-commercial purposes only.
 * See https://www.geogebra.org/license for full licensing details
 */

package org.geogebra.common.kernel.statistics;

import org.geogebra.common.kernel.Kernel;
import org.geogebra.common.kernel.algos.AlgoQ3;
import org.geogebra.common.kernel.arithmetic.Command;
import org.geogebra.common.kernel.commands.CmdOneListFunction;
import org.geogebra.common.kernel.geos.GeoElement;
import org.geogebra.common.kernel.geos.GeoList;

/**
 * Q3[ list ]
 *
 * @author Michael Borcherds
 * @version 2008-02-16
 */
public class CmdQ3 extends CmdOneListFunction {
	/**
	 * Creates new command processor
	 *
	 * @param kernel
	 *            kernel
	 */
	public CmdQ3(Kernel kernel) {
		super(kernel);
	}

	@Override
	protected final GeoElement doCommand(String a, GeoList b) {
		AlgoQ3 algo = new AlgoQ3(cons, b);
		algo.getQ3().setLabel(a);
		return algo.getQ3();
	}

	@Override
	protected final GeoElement doCommand(String a, Command c, GeoList list, GeoList freq) {
		AlgoQ3 algo = new AlgoQ3(cons, list, freq);
		algo.getQ3().setLabel(a);
		return algo.getQ3();
	}
}
