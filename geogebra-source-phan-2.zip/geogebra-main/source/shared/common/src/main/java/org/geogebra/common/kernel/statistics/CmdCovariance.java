/*
 * GeoGebra - Dynamic Mathematics for Everyone
 * Copyright (c) GeoGebra GmbH, Altenbergerstr. 69, 4040 Linz, Austria
 * https://www.geogebra.org
 *
 * This file is licensed by GeoGebra GmbH under the EUPL 1.2 licence and
 * may be used under the EUPL 1.2 in compatible projects (see Article 5
 * and the Appendix of EUPL 1.2 for details).
 * You may obtain a copy of the licence at:
 * https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Note: The overall GeoGebra software package is free to use for
 * non-commercial purposes only.
 * See https://www.geogebra.org/license for full licensing details
 */

package org.geogebra.common.kernel.statistics;

import org.geogebra.common.kernel.Kernel;
import org.geogebra.common.kernel.commands.CmdOneOrTwoListsFunction;
import org.geogebra.common.kernel.geos.GeoElement;
import org.geogebra.common.kernel.geos.GeoList;

/**
 * Covariance[ &lt;list1&gt;, &lt;list2&gt; ]
 * Covariance[ &lt;List of Points&gt; ]
 */
public class CmdCovariance extends CmdOneOrTwoListsFunction {
	/**
	 * Create new command processor
	 *
	 * @param kernel
	 *            kernel
	 */
	public CmdCovariance(Kernel kernel) {
		super(kernel);
	}

	@Override
	protected final GeoElement doCommand(String a, GeoList b) {
		AlgoListCovariance algo = new AlgoListCovariance(cons, a, b);
		return algo.getResult();
	}

	@Override
	protected final GeoElement doCommand(String a, GeoList b, GeoList c) {
		AlgoDoubleListCovariance algo = new AlgoDoubleListCovariance(cons, a, b, c);

		return algo.getResult();
	}
}
