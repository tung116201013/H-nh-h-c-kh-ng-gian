/*
 * GeoGebra - Dynamic Mathematics for Everyone
 * Copyright (c) GeoGebra GmbH, Altenbergerstr. 69, 4040 Linz, Austria
 * https://www.geogebra.org
 *
 * This file is licensed by GeoGebra GmbH under the EUPL 1.2 licence and
 * may be used under the EUPL 1.2 in compatible projects (see Article 5
 * and the Appendix of EUPL 1.2 for details).
 * You may obtain a copy of the licence at:
 * https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Note: The overall GeoGebra software package is free to use for
 * non-commercial purposes only.
 * See https://www.geogebra.org/license for full licensing details
 */

package org.geogebra.common.kernel.kernelND;

import org.geogebra.common.kernel.arithmetic.ExpressionValue;

/**
 *
 * @author mathieu
 *
 */
public interface GeoVecInterface extends ExpressionValue {

	/**
	 *
	 * @return x value
	 */
	double getX();

	/**
	 *
	 * @return y value
	 */
	double getY();

	/**
	 *
	 * @return 3D z value
	 */
	double getZ();

	/**
	 * Yields true if the coordinates of this vector are equal to those of
	 * vector v.
	 *
	 * @param vector
	 *            other vector
	 * @return true if both vectors have equal coords
	 */
	boolean isEqual(GeoVecInterface vector);
}
