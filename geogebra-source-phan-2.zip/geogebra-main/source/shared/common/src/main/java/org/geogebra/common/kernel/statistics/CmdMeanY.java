/*
 * GeoGebra - Dynamic Mathematics for Everyone
 * Copyright (c) GeoGebra GmbH, Altenbergerstr. 69, 4040 Linz, Austria
 * https://www.geogebra.org
 *
 * This file is licensed by GeoGebra GmbH under the EUPL 1.2 licence and
 * may be used under the EUPL 1.2 in compatible projects (see Article 5
 * and the Appendix of EUPL 1.2 for details).
 * You may obtain a copy of the licence at:
 * https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Note: The overall GeoGebra software package is free to use for
 * non-commercial purposes only.
 * See https://www.geogebra.org/license for full licensing details
 */

package org.geogebra.common.kernel.statistics;

import org.geogebra.common.kernel.Kernel;
import org.geogebra.common.kernel.arithmetic.Command;
import org.geogebra.common.kernel.commands.CmdOneOrTwoListsFunction;
import org.geogebra.common.kernel.commands.EvalInfo;
import org.geogebra.common.kernel.geos.GeoElement;
import org.geogebra.common.kernel.geos.GeoList;
import org.geogebra.common.main.MyError;

/**
 * MeanX[ &lt;List of points&gt; ]
 */
public class CmdMeanY extends CmdOneOrTwoListsFunction {
	/**
	 * Create new command processor
	 *
	 * @param kernel
	 *            kernel
	 */
	public CmdMeanY(Kernel kernel) {
		super(kernel);
	}

	@Override
	public GeoElement[] process(Command c, EvalInfo info) throws MyError {
		int n = c.getArgumentNumber();
		switch (n) {
			case 1:
				GeoElement[] arg = resArgs(c, info);
				if (arg[0].isGeoList()) {
					GeoElement[] ret = {doCommand(c.getLabel(), (GeoList) arg[0])};
					return ret;
				}
				throw argErr(c, arg[0]);

			default:
				throw argNumErr(c);
		}
	}

	@Override
	protected final GeoElement doCommand(String a, GeoList b) {

		AlgoListMeanY algo = new AlgoListMeanY(cons, a, b);
		return algo.getResult();
	}

	@Override
	protected final GeoElement doCommand(String a, GeoList b, GeoList c) {
		// never gets called
		return null;
	}
}
