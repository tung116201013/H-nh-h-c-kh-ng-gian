/*
 * GeoGebra - Dynamic Mathematics for Everyone
 * Copyright (c) GeoGebra GmbH, Altenbergerstr. 69, 4040 Linz, Austria
 * https://www.geogebra.org
 *
 * This file is licensed by GeoGebra GmbH under the EUPL 1.2 licence and
 * may be used under the EUPL 1.2 in compatible projects (see Article 5
 * and the Appendix of EUPL 1.2 for details).
 * You may obtain a copy of the licence at:
 * https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Note: The overall GeoGebra software package is free to use for
 * non-commercial purposes only.
 * See https://www.geogebra.org/license for full licensing details
 */

package org.geogebra.common.kernel.statistics;

import org.geogebra.common.kernel.Construction;
import org.geogebra.common.kernel.algos.AlgoElement;
import org.geogebra.common.kernel.commands.Commands;
import org.geogebra.common.kernel.geos.GeoElement;
import org.geogebra.common.kernel.geos.GeoFunctionable;
import org.geogebra.common.kernel.geos.GeoList;
import org.geogebra.common.kernel.geos.GeoNumeric;
import org.geogebra.common.kernel.geos.GeoPoint;

/**
 * Command: RSquare[&lt;List&gt;,&lt;Function&gt;] Calculates coefficient of
 * determination, R^2, for a function f(x) fitted to the list.
 *
 * @author G.Sturr
 */
public class AlgoRSquare extends AlgoElement {

	private GeoList inputList; // input
	private GeoFunctionable function; // input
	private GeoNumeric r2; // output
	private int size;

	/**
	 *
	 * @param cons
	 *            construction
	 * @param inputList
	 *            list of points
	 * @param function
	 *            model function
	 */
	public AlgoRSquare(Construction cons, GeoList inputList, GeoFunctionable function) {
		super(cons);
		this.inputList = inputList;
		this.function = function;

		r2 = new GeoNumeric(cons);

		setInputOutput();
		compute();
	}

	@Override
	public Commands getClassName() {
		return Commands.RSquare;
	}

	@Override
	protected void setInputOutput() {
		input = new GeoElement[2];
		input[0] = inputList;
		input[1] = function.toGeoElement();

		setOnlyOutput(r2);
		setDependencies(); // done by AlgoElement
	}

	public GeoNumeric getRSquare() {
		return r2;
	}

	@Override
	public final void compute() {

		size = inputList.size();
		if (!inputList.isDefined() || !function.toGeoElement().isDefined()) {
			r2.setUndefined();
			return;
		}

		// Calculate errorsum and ssy:
		double sumyy = 0.0d;
		double sumy = 0.0d;
		double syy;
		double errorsum = 0.0d;
		GeoElement geo;
		GeoPoint point;
		double x, y, v;

		for (int i = 0; i < size; i++) {
			geo = inputList.get(i);
			if (geo instanceof GeoPoint) {
				point = (GeoPoint) geo;
				x = point.getX();
				y = point.getY();
				v = function.value(x);
				errorsum += (v - y) * (v - y);
				sumy += y;
				sumyy += y * y;
			} else {
				r2.setUndefined();
				return;
			} // if calculation is possible
		} // for all points

		syy = sumyy - sumy * sumy / size;

		// calculate RSquare
		r2.setValue(1 - errorsum / syy);
	}
}
