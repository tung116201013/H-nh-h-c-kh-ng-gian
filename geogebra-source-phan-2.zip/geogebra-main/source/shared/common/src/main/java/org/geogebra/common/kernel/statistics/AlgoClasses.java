/*
 * GeoGebra - Dynamic Mathematics for Everyone
 * Copyright (c) GeoGebra GmbH, Altenbergerstr. 69, 4040 Linz, Austria
 * https://www.geogebra.org
 *
 * This file is licensed by GeoGebra GmbH under the EUPL 1.2 licence and
 * may be used under the EUPL 1.2 in compatible projects (see Article 5
 * and the Appendix of EUPL 1.2 for details).
 * You may obtain a copy of the licence at:
 * https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Note: The overall GeoGebra software package is free to use for
 * non-commercial purposes only.
 * See https://www.geogebra.org/license for full licensing details
 */

package org.geogebra.common.kernel.statistics;

import java.util.ArrayList;

import org.geogebra.common.kernel.Construction;
import org.geogebra.common.kernel.StringTemplate;
import org.geogebra.common.kernel.algos.AlgoElement;
import org.geogebra.common.kernel.commands.Commands;
import org.geogebra.common.kernel.geos.GeoElement;
import org.geogebra.common.kernel.geos.GeoList;
import org.geogebra.common.kernel.geos.GeoNumeric;
import org.geogebra.common.plugin.GeoClass;

/**
 * Algo for Classes[]
 *
 */
public class AlgoClasses extends AlgoElement {

	private GeoList dataList; // input
	private GeoNumeric start; // input
	private GeoNumeric width; // input
	private GeoNumeric numClasses; // input

	private GeoList classList; // output

	// for compute

	/**
	 * @param cons
	 *            construction
	 * @param dataList
	 *            data
	 * @param start
	 *            first class start
	 * @param width
	 *            class width
	 * @param numClasses
	 *            number of classes
	 */
	public AlgoClasses(
			Construction cons,
			GeoList dataList,
			GeoNumeric start,
			GeoNumeric width,
			GeoNumeric numClasses) {
		super(cons);
		this.dataList = dataList;
		this.start = start;
		this.width = width;
		this.numClasses = numClasses;

		classList = new GeoList(cons);
		setInputOutput();
		compute();
	}

	@Override
	public Commands getClassName() {
		return Commands.Classes;
	}

	@Override
	protected void setInputOutput() {
		ArrayList<GeoElement> tempList = new ArrayList<>();

		tempList.add(dataList);

		if (start != null) {
			tempList.add(start);
		}

		if (width != null) {
			tempList.add(width);
		}

		if (numClasses != null) {
			tempList.add(numClasses);
		}

		input = new GeoElement[tempList.size()];
		input = tempList.toArray(input);

		setOnlyOutput(classList);
		setDependencies(); // done by AlgoElement
	}

	/**
	 * @return class list
	 */
	public GeoList getResult() {
		return classList;
	}

	@Override
	public final void compute() {

		// Validate input arguments
		// =======================================================

		if (!dataList.isDefined() || dataList.size() == 0) {
			classList.setUndefined();
			return;
		}

		if (!(dataList.getElementType().equals(GeoClass.TEXT)
				|| dataList.getElementType().equals(GeoClass.NUMERIC))) {
			classList.setUndefined();
			return;
		}

		classList.setDefined(true);
		classList.clear();

		// Get data max and min
		// =======================================================

		double minGeoValue = 0;
		double maxGeoValue = 0;
		String minGeoString;
		String maxGeoString;

		if (dataList.getElementType().equals(GeoClass.NUMERIC)) {
			minGeoValue = ((GeoNumeric) dataList.get(0)).getDouble();
			maxGeoValue = ((GeoNumeric) dataList.get(0)).getDouble();
			for (int i = 1; i < dataList.size(); i++) {
				double geoValue = ((GeoNumeric) dataList.get(i)).getDouble();
				minGeoValue = Math.min(geoValue, minGeoValue);
				maxGeoValue = Math.max(geoValue, maxGeoValue);
			}

		} else {
			minGeoString = dataList.get(0).toValueString(StringTemplate.defaultTemplate);
			maxGeoString = dataList.get(0).toValueString(StringTemplate.defaultTemplate);
			for (int i = 1; i < dataList.size(); i++) {
				String geoString = dataList.get(i).toValueString(StringTemplate.defaultTemplate);
				if (geoString.compareTo(minGeoString) < 0) {
					minGeoString = geoString;
				}
				if (geoString.compareTo(maxGeoString) < 0) {
					maxGeoString = geoString;
				}
			}
		}

		// Create class list using number of classes
		// =======================================================

		if (input.length == 2) {

			int n = (int) numClasses.getDouble();
			if (n < 1) {
				classList.setUndefined();
			}

			double width1 = (maxGeoValue - minGeoValue) / n;
			for (int i = 0; i < n; i++) {
				classList.addNumber(minGeoValue + i * width1, null);
			}
			classList.addNumber(maxGeoValue, null);
		}

		// Create class list using start and width
		// =======================================================
		if (input.length == 3) {

			if (width.getDouble() <= 0) {
				classList.setUndefined();
				return;
			}

			double value = start.getDouble();
			classList.addNumber(value, null);
			while (value < maxGeoValue) {
				value = value + width.getDouble();
				classList.addNumber(value, null);
			}
			if (classList.size() < 2) {
				classList.setUndefined();
			}
		}
	}
}
